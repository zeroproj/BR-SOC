"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Agents/GitHub visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Agents-GitHub-Alerts-Evolution-By-Organization',
  _source: {
    title: 'Alerts evolution by organization',
    visState: JSON.stringify({
      "title": "Alerts evolution by organization",
      "type": "area",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "2",
        "enabled": true,
        "type": "date_histogram",
        "params": {
          "field": "timestamp",
          "timeRange": {
            "from": "now-7d",
            "to": "now"
          },
          "useNormalizedEsInterval": true,
          "scaleMetricValues": false,
          "interval": "auto",
          "drop_partials": false,
          "min_doc_count": 1,
          "extended_bounds": {},
          "customLabel": ""
        },
        "schema": "segment"
      }, {
        "id": "3",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "group"
      }],
      "params": {
        "type": "area",
        "grid": {
          "categoryLines": false
        },
        "categoryAxes": [{
          "id": "CategoryAxis-1",
          "type": "category",
          "position": "bottom",
          "show": true,
          "style": {},
          "scale": {
            "type": "linear"
          },
          "labels": {
            "show": true,
            "filter": true,
            "truncate": 100,
            "rotate": 0
          },
          "title": {}
        }],
        "valueAxes": [{
          "id": "ValueAxis-1",
          "name": "LeftAxis-1",
          "type": "value",
          "position": "left",
          "show": true,
          "style": {},
          "scale": {
            "type": "linear",
            "mode": "normal"
          },
          "labels": {
            "show": true,
            "rotate": 0,
            "filter": false,
            "truncate": 100
          },
          "title": {
            "text": "Count"
          }
        }],
        "seriesParams": [{
          "show": true,
          "type": "line",
          "mode": "normal",
          "data": {
            "label": "Count",
            "id": "1"
          },
          "drawLinesBetweenPoints": true,
          "lineWidth": 2,
          "showCircles": true,
          "interpolate": "linear",
          "valueAxis": "ValueAxis-1"
        }],
        "addTooltip": true,
        "addLegend": true,
        "legendPosition": "right",
        "times": [],
        "addTimeMarker": false,
        "thresholdLine": {
          "show": false,
          "value": 10,
          "width": 1,
          "style": "full",
          "color": "#E7664C"
        },
        "labels": {},
        "orderBucketsBySum": false
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-GitHub-Top-5-Organizations-By-Alerts',
  _source: {
    title: 'Top 5 organizations by alerts',
    visState: JSON.stringify({
      "title": "Top 5 organizations by alerts",
      "type": "pie",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "2",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "segment"
      }],
      "params": {
        "type": "pie",
        "addTooltip": true,
        "addLegend": true,
        "legendPosition": "right",
        "isDonut": false,
        "labels": {
          "show": false,
          "values": true,
          "last_level": true,
          "truncate": 100
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-GitHub-Users-With-More-Alerts',
  _source: {
    title: 'Users with more alerts',
    visState: JSON.stringify({
      "title": "Users with more alerts",
      "type": "line",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "4",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "segment"
      }, {
        "id": "3",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.actor",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "group"
      }],
      "params": {
        "type": "line",
        "grid": {
          "categoryLines": false
        },
        "categoryAxes": [{
          "id": "CategoryAxis-1",
          "type": "category",
          "position": "bottom",
          "show": true,
          "style": {},
          "scale": {
            "type": "linear"
          },
          "labels": {
            "show": true,
            "filter": true,
            "truncate": 100
          },
          "title": {}
        }],
        "valueAxes": [{
          "id": "ValueAxis-1",
          "name": "LeftAxis-1",
          "type": "value",
          "position": "left",
          "show": true,
          "style": {},
          "scale": {
            "type": "linear",
            "mode": "normal"
          },
          "labels": {
            "show": true,
            "rotate": 0,
            "filter": false,
            "truncate": 100
          },
          "title": {
            "text": "Count"
          }
        }],
        "seriesParams": [{
          "show": true,
          "type": "histogram",
          "mode": "stacked",
          "data": {
            "label": "Count",
            "id": "1"
          },
          "valueAxis": "ValueAxis-1",
          "drawLinesBetweenPoints": true,
          "lineWidth": 2,
          "interpolate": "linear",
          "showCircles": true
        }],
        "addTooltip": true,
        "addLegend": true,
        "legendPosition": "right",
        "times": [],
        "addTimeMarker": false,
        "labels": {},
        "thresholdLine": {
          "show": false,
          "value": 10,
          "width": 1,
          "style": "full",
          "color": "#E7664C"
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-GitHub-Alert-Action-Type-By-Organization',
  _source: {
    title: 'Top alerts by alert action type and organization',
    visState: JSON.stringify({
      "title": "Top alerts by alert action type and organization",
      "type": "pie",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "3",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 5,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "segment"
      }, {
        "id": "2",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.action",
          "orderBy": "1",
          "order": "desc",
          "size": 3,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "segment"
      }],
      "params": {
        "type": "pie",
        "addTooltip": true,
        "addLegend": true,
        "legendPosition": "right",
        "isDonut": true,
        "labels": {
          "show": false,
          "values": true,
          "last_level": true,
          "truncate": 100
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-GitHub-Alert-Summary',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      "title": "Alerts summary",
      "type": "table",
      "aggs": [{
        "id": "1",
        "enabled": true,
        "type": "count",
        "params": {},
        "schema": "metric"
      }, {
        "id": "2",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "agent.name",
          "orderBy": "1",
          "order": "desc",
          "size": 50,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "bucket"
      }, {
        "id": "3",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "data.github.org",
          "orderBy": "1",
          "order": "desc",
          "size": 10,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "bucket"
      }, {
        "id": "4",
        "enabled": true,
        "type": "terms",
        "params": {
          "field": "rule.description",
          "orderBy": "1",
          "order": "desc",
          "size": 10,
          "otherBucket": false,
          "otherBucketLabel": "Other",
          "missingBucket": false,
          "missingBucketLabel": "Missing"
        },
        "schema": "bucket"
      }],
      "params": {
        "perPage": 10,
        "showPartialRows": false,
        "showMetricsAtAllLevels": false,
        "sort": {
          "columnIndex": null,
          "direction": null
        },
        "showTotal": false,
        "totalFunc": "sum",
        "percentageCol": ""
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl9zb3VyY2UiLCJ0aXRsZSIsInZpc1N0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsInVpU3RhdGVKU09OIiwiZGVzY3JpcHRpb24iLCJ2ZXJzaW9uIiwia2liYW5hU2F2ZWRPYmplY3RNZXRhIiwic2VhcmNoU291cmNlSlNPTiIsIl90eXBlIiwidmlzIiwicGFyYW1zIiwic29ydCIsImNvbHVtbkluZGV4IiwiZGlyZWN0aW9uIiwiZXhwb3J0cyIsImRlZmF1bHQiLCJtb2R1bGUiXSwic291cmNlcyI6WyJhZ2VudHMtZ2l0aHViLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBhcHAgLSBNb2R1bGUgZm9yIEFnZW50cy9HaXRIdWIgdmlzdWFsaXphdGlvbnNcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXG4gKlxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxuICovXG5cbmV4cG9ydCBkZWZhdWx0IFtcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtR2l0SHViLUFsZXJ0cy1Fdm9sdXRpb24tQnktT3JnYW5pemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0FsZXJ0cyBldm9sdXRpb24gYnkgb3JnYW5pemF0aW9uJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIFwidGl0bGVcIjogXCJBbGVydHMgZXZvbHV0aW9uIGJ5IG9yZ2FuaXphdGlvblwiLFxuICAgICAgICBcInR5cGVcIjogXCJhcmVhXCIsXG4gICAgICAgIFwiYWdnc1wiOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjFcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwiY291bnRcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHt9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJtZXRyaWNcIlxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjJcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwiZGF0ZV9oaXN0b2dyYW1cIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcInRpbWVzdGFtcFwiLFxuICAgICAgICAgICAgICBcInRpbWVSYW5nZVwiOiB7XG4gICAgICAgICAgICAgICAgXCJmcm9tXCI6IFwibm93LTdkXCIsXG4gICAgICAgICAgICAgICAgXCJ0b1wiOiBcIm5vd1wiXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIFwidXNlTm9ybWFsaXplZEVzSW50ZXJ2YWxcIjogdHJ1ZSxcbiAgICAgICAgICAgICAgXCJzY2FsZU1ldHJpY1ZhbHVlc1wiOiBmYWxzZSxcbiAgICAgICAgICAgICAgXCJpbnRlcnZhbFwiOiBcImF1dG9cIixcbiAgICAgICAgICAgICAgXCJkcm9wX3BhcnRpYWxzXCI6IGZhbHNlLFxuICAgICAgICAgICAgICBcIm1pbl9kb2NfY291bnRcIjogMSxcbiAgICAgICAgICAgICAgXCJleHRlbmRlZF9ib3VuZHNcIjoge30sXG4gICAgICAgICAgICAgIFwiY3VzdG9tTGFiZWxcIjogXCJcIlxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwic2NoZW1hXCI6IFwic2VnbWVudFwiXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBcImlkXCI6IFwiM1wiLFxuICAgICAgICAgICAgXCJlbmFibGVkXCI6IHRydWUsXG4gICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXJtc1wiLFxuICAgICAgICAgICAgXCJwYXJhbXNcIjoge1xuICAgICAgICAgICAgICBcImZpZWxkXCI6IFwiZGF0YS5naXRodWIub3JnXCIsXG4gICAgICAgICAgICAgIFwib3JkZXJCeVwiOiBcIjFcIixcbiAgICAgICAgICAgICAgXCJvcmRlclwiOiBcImRlc2NcIixcbiAgICAgICAgICAgICAgXCJzaXplXCI6IDUsXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRcIjogZmFsc2UsXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRMYWJlbFwiOiBcIk90aGVyXCIsXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldFwiOiBmYWxzZSxcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0TGFiZWxcIjogXCJNaXNzaW5nXCJcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInNjaGVtYVwiOiBcImdyb3VwXCJcbiAgICAgICAgICB9XG4gICAgICAgIF0sXG4gICAgICAgIFwicGFyYW1zXCI6IHtcbiAgICAgICAgICBcInR5cGVcIjogXCJhcmVhXCIsXG4gICAgICAgICAgXCJncmlkXCI6IHtcbiAgICAgICAgICAgIFwiY2F0ZWdvcnlMaW5lc1wiOiBmYWxzZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjYXRlZ29yeUF4ZXNcIjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBcImlkXCI6IFwiQ2F0ZWdvcnlBeGlzLTFcIixcbiAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiY2F0ZWdvcnlcIixcbiAgICAgICAgICAgICAgXCJwb3NpdGlvblwiOiBcImJvdHRvbVwiLFxuICAgICAgICAgICAgICBcInNob3dcIjogdHJ1ZSxcbiAgICAgICAgICAgICAgXCJzdHlsZVwiOiB7fSxcbiAgICAgICAgICAgICAgXCJzY2FsZVwiOiB7XG4gICAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwibGluZWFyXCJcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgXCJsYWJlbHNcIjoge1xuICAgICAgICAgICAgICAgIFwic2hvd1wiOiB0cnVlLFxuICAgICAgICAgICAgICAgIFwiZmlsdGVyXCI6IHRydWUsXG4gICAgICAgICAgICAgICAgXCJ0cnVuY2F0ZVwiOiAxMDAsXG4gICAgICAgICAgICAgICAgXCJyb3RhdGVcIjogMFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBcInRpdGxlXCI6IHt9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgXSxcbiAgICAgICAgICBcInZhbHVlQXhlc1wiOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIFwiaWRcIjogXCJWYWx1ZUF4aXMtMVwiLFxuICAgICAgICAgICAgICBcIm5hbWVcIjogXCJMZWZ0QXhpcy0xXCIsXG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcInZhbHVlXCIsXG4gICAgICAgICAgICAgIFwicG9zaXRpb25cIjogXCJsZWZ0XCIsXG4gICAgICAgICAgICAgIFwic2hvd1wiOiB0cnVlLFxuICAgICAgICAgICAgICBcInN0eWxlXCI6IHt9LFxuICAgICAgICAgICAgICBcInNjYWxlXCI6IHtcbiAgICAgICAgICAgICAgICBcInR5cGVcIjogXCJsaW5lYXJcIixcbiAgICAgICAgICAgICAgICBcIm1vZGVcIjogXCJub3JtYWxcIlxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBcImxhYmVsc1wiOiB7XG4gICAgICAgICAgICAgICAgXCJzaG93XCI6IHRydWUsXG4gICAgICAgICAgICAgICAgXCJyb3RhdGVcIjogMCxcbiAgICAgICAgICAgICAgICBcImZpbHRlclwiOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBcInRydW5jYXRlXCI6IDEwMFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBcInRpdGxlXCI6IHtcbiAgICAgICAgICAgICAgICBcInRleHRcIjogXCJDb3VudFwiXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICBdLFxuICAgICAgICAgIFwic2VyaWVzUGFyYW1zXCI6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgXCJzaG93XCI6IHRydWUsXG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcImxpbmVcIixcbiAgICAgICAgICAgICAgXCJtb2RlXCI6IFwibm9ybWFsXCIsXG4gICAgICAgICAgICAgIFwiZGF0YVwiOiB7XG4gICAgICAgICAgICAgICAgXCJsYWJlbFwiOiBcIkNvdW50XCIsXG4gICAgICAgICAgICAgICAgXCJpZFwiOiBcIjFcIlxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBcImRyYXdMaW5lc0JldHdlZW5Qb2ludHNcIjogdHJ1ZSxcbiAgICAgICAgICAgICAgXCJsaW5lV2lkdGhcIjogMixcbiAgICAgICAgICAgICAgXCJzaG93Q2lyY2xlc1wiOiB0cnVlLFxuICAgICAgICAgICAgICBcImludGVycG9sYXRlXCI6IFwibGluZWFyXCIsXG4gICAgICAgICAgICAgIFwidmFsdWVBeGlzXCI6IFwiVmFsdWVBeGlzLTFcIlxuICAgICAgICAgICAgfVxuICAgICAgICAgIF0sXG4gICAgICAgICAgXCJhZGRUb29sdGlwXCI6IHRydWUsXG4gICAgICAgICAgXCJhZGRMZWdlbmRcIjogdHJ1ZSxcbiAgICAgICAgICBcImxlZ2VuZFBvc2l0aW9uXCI6IFwicmlnaHRcIixcbiAgICAgICAgICBcInRpbWVzXCI6IFtdLFxuICAgICAgICAgIFwiYWRkVGltZU1hcmtlclwiOiBmYWxzZSxcbiAgICAgICAgICBcInRocmVzaG9sZExpbmVcIjoge1xuICAgICAgICAgICAgXCJzaG93XCI6IGZhbHNlLFxuICAgICAgICAgICAgXCJ2YWx1ZVwiOiAxMCxcbiAgICAgICAgICAgIFwid2lkdGhcIjogMSxcbiAgICAgICAgICAgIFwic3R5bGVcIjogXCJmdWxsXCIsXG4gICAgICAgICAgICBcImNvbG9yXCI6IFwiI0U3NjY0Q1wiXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImxhYmVsc1wiOiB7fSxcbiAgICAgICAgICBcIm9yZGVyQnVja2V0c0J5U3VtXCI6IGZhbHNlXG4gICAgICAgIH1cbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICcnLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcbiAgICAgIH1cbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUdpdEh1Yi1Ub3AtNS1Pcmdhbml6YXRpb25zLUJ5LUFsZXJ0cycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdUb3AgNSBvcmdhbml6YXRpb25zIGJ5IGFsZXJ0cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBcInRpdGxlXCI6IFwiVG9wIDUgb3JnYW5pemF0aW9ucyBieSBhbGVydHNcIixcbiAgICAgICAgXCJ0eXBlXCI6IFwicGllXCIsXG4gICAgICAgIFwiYWdnc1wiOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjFcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwiY291bnRcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHt9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJtZXRyaWNcIlxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjJcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGVybXNcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcImRhdGEuZ2l0aHViLm9yZ1wiLFxuICAgICAgICAgICAgICBcIm9yZGVyQnlcIjogXCIxXCIsXG4gICAgICAgICAgICAgIFwib3JkZXJcIjogXCJkZXNjXCIsXG4gICAgICAgICAgICAgIFwic2l6ZVwiOiA1LFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0XCI6IGZhbHNlLFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0TGFiZWxcIjogXCJPdGhlclwiLFxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldExhYmVsXCI6IFwiTWlzc2luZ1wiXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJzZWdtZW50XCJcbiAgICAgICAgICB9XG4gICAgICAgIF0sXG4gICAgICAgIFwicGFyYW1zXCI6IHtcbiAgICAgICAgICBcInR5cGVcIjogXCJwaWVcIixcbiAgICAgICAgICBcImFkZFRvb2x0aXBcIjogdHJ1ZSxcbiAgICAgICAgICBcImFkZExlZ2VuZFwiOiB0cnVlLFxuICAgICAgICAgIFwibGVnZW5kUG9zaXRpb25cIjogXCJyaWdodFwiLFxuICAgICAgICAgIFwiaXNEb251dFwiOiBmYWxzZSxcbiAgICAgICAgICBcImxhYmVsc1wiOiB7XG4gICAgICAgICAgICBcInNob3dcIjogZmFsc2UsXG4gICAgICAgICAgICBcInZhbHVlc1wiOiB0cnVlLFxuICAgICAgICAgICAgXCJsYXN0X2xldmVsXCI6IHRydWUsXG4gICAgICAgICAgICBcInRydW5jYXRlXCI6IDEwMFxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJycsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046ICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfVxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtR2l0SHViLVVzZXJzLVdpdGgtTW9yZS1BbGVydHMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVXNlcnMgd2l0aCBtb3JlIGFsZXJ0cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICBcInRpdGxlXCI6IFwiVXNlcnMgd2l0aCBtb3JlIGFsZXJ0c1wiLFxuICAgICAgICBcInR5cGVcIjogXCJsaW5lXCIsXG4gICAgICAgIFwiYWdnc1wiOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjFcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwiY291bnRcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHt9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJtZXRyaWNcIlxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjRcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGVybXNcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcImRhdGEuZ2l0aHViLm9yZ1wiLFxuICAgICAgICAgICAgICBcIm9yZGVyQnlcIjogXCIxXCIsXG4gICAgICAgICAgICAgIFwib3JkZXJcIjogXCJkZXNjXCIsXG4gICAgICAgICAgICAgIFwic2l6ZVwiOiA1LFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0XCI6IGZhbHNlLFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0TGFiZWxcIjogXCJPdGhlclwiLFxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldExhYmVsXCI6IFwiTWlzc2luZ1wiXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJzZWdtZW50XCJcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIFwiaWRcIjogXCIzXCIsXG4gICAgICAgICAgICBcImVuYWJsZWRcIjogdHJ1ZSxcbiAgICAgICAgICAgIFwidHlwZVwiOiBcInRlcm1zXCIsXG4gICAgICAgICAgICBcInBhcmFtc1wiOiB7XG4gICAgICAgICAgICAgIFwiZmllbGRcIjogXCJkYXRhLmdpdGh1Yi5hY3RvclwiLFxuICAgICAgICAgICAgICBcIm9yZGVyQnlcIjogXCIxXCIsXG4gICAgICAgICAgICAgIFwib3JkZXJcIjogXCJkZXNjXCIsXG4gICAgICAgICAgICAgIFwic2l6ZVwiOiA1LFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0XCI6IGZhbHNlLFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0TGFiZWxcIjogXCJPdGhlclwiLFxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldExhYmVsXCI6IFwiTWlzc2luZ1wiXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJncm91cFwiXG4gICAgICAgICAgfVxuICAgICAgICBdLFxuICAgICAgICBcInBhcmFtc1wiOiB7XG4gICAgICAgICAgXCJ0eXBlXCI6IFwibGluZVwiLFxuICAgICAgICAgIFwiZ3JpZFwiOiB7XG4gICAgICAgICAgICBcImNhdGVnb3J5TGluZXNcIjogZmFsc2VcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiY2F0ZWdvcnlBeGVzXCI6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgXCJpZFwiOiBcIkNhdGVnb3J5QXhpcy0xXCIsXG4gICAgICAgICAgICAgIFwidHlwZVwiOiBcImNhdGVnb3J5XCIsXG4gICAgICAgICAgICAgIFwicG9zaXRpb25cIjogXCJib3R0b21cIixcbiAgICAgICAgICAgICAgXCJzaG93XCI6IHRydWUsXG4gICAgICAgICAgICAgIFwic3R5bGVcIjoge30sXG4gICAgICAgICAgICAgIFwic2NhbGVcIjoge1xuICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcImxpbmVhclwiXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIFwibGFiZWxzXCI6IHtcbiAgICAgICAgICAgICAgICBcInNob3dcIjogdHJ1ZSxcbiAgICAgICAgICAgICAgICBcImZpbHRlclwiOiB0cnVlLFxuICAgICAgICAgICAgICAgIFwidHJ1bmNhdGVcIjogMTAwXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIFwidGl0bGVcIjoge31cbiAgICAgICAgICAgIH1cbiAgICAgICAgICBdLFxuICAgICAgICAgIFwidmFsdWVBeGVzXCI6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgXCJpZFwiOiBcIlZhbHVlQXhpcy0xXCIsXG4gICAgICAgICAgICAgIFwibmFtZVwiOiBcIkxlZnRBeGlzLTFcIixcbiAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwidmFsdWVcIixcbiAgICAgICAgICAgICAgXCJwb3NpdGlvblwiOiBcImxlZnRcIixcbiAgICAgICAgICAgICAgXCJzaG93XCI6IHRydWUsXG4gICAgICAgICAgICAgIFwic3R5bGVcIjoge30sXG4gICAgICAgICAgICAgIFwic2NhbGVcIjoge1xuICAgICAgICAgICAgICAgIFwidHlwZVwiOiBcImxpbmVhclwiLFxuICAgICAgICAgICAgICAgIFwibW9kZVwiOiBcIm5vcm1hbFwiXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIFwibGFiZWxzXCI6IHtcbiAgICAgICAgICAgICAgICBcInNob3dcIjogdHJ1ZSxcbiAgICAgICAgICAgICAgICBcInJvdGF0ZVwiOiAwLFxuICAgICAgICAgICAgICAgIFwiZmlsdGVyXCI6IGZhbHNlLFxuICAgICAgICAgICAgICAgIFwidHJ1bmNhdGVcIjogMTAwXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIFwidGl0bGVcIjoge1xuICAgICAgICAgICAgICAgIFwidGV4dFwiOiBcIkNvdW50XCJcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIF0sXG4gICAgICAgICAgXCJzZXJpZXNQYXJhbXNcIjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBcInNob3dcIjogdHJ1ZSxcbiAgICAgICAgICAgICAgXCJ0eXBlXCI6IFwiaGlzdG9ncmFtXCIsXG4gICAgICAgICAgICAgIFwibW9kZVwiOiBcInN0YWNrZWRcIixcbiAgICAgICAgICAgICAgXCJkYXRhXCI6IHtcbiAgICAgICAgICAgICAgICBcImxhYmVsXCI6IFwiQ291bnRcIixcbiAgICAgICAgICAgICAgICBcImlkXCI6IFwiMVwiXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIFwidmFsdWVBeGlzXCI6IFwiVmFsdWVBeGlzLTFcIixcbiAgICAgICAgICAgICAgXCJkcmF3TGluZXNCZXR3ZWVuUG9pbnRzXCI6IHRydWUsXG4gICAgICAgICAgICAgIFwibGluZVdpZHRoXCI6IDIsXG4gICAgICAgICAgICAgIFwiaW50ZXJwb2xhdGVcIjogXCJsaW5lYXJcIixcbiAgICAgICAgICAgICAgXCJzaG93Q2lyY2xlc1wiOiB0cnVlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgXSxcbiAgICAgICAgICBcImFkZFRvb2x0aXBcIjogdHJ1ZSxcbiAgICAgICAgICBcImFkZExlZ2VuZFwiOiB0cnVlLFxuICAgICAgICAgIFwibGVnZW5kUG9zaXRpb25cIjogXCJyaWdodFwiLFxuICAgICAgICAgIFwidGltZXNcIjogW10sXG4gICAgICAgICAgXCJhZGRUaW1lTWFya2VyXCI6IGZhbHNlLFxuICAgICAgICAgIFwibGFiZWxzXCI6IHt9LFxuICAgICAgICAgIFwidGhyZXNob2xkTGluZVwiOiB7XG4gICAgICAgICAgICBcInNob3dcIjogZmFsc2UsXG4gICAgICAgICAgICBcInZhbHVlXCI6IDEwLFxuICAgICAgICAgICAgXCJ3aWR0aFwiOiAxLFxuICAgICAgICAgICAgXCJzdHlsZVwiOiBcImZ1bGxcIixcbiAgICAgICAgICAgIFwiY29sb3JcIjogXCIjRTc2NjRDXCJcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICcnLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcbiAgICAgIH1cbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUdpdEh1Yi1BbGVydC1BY3Rpb24tVHlwZS1CeS1Pcmdhbml6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIGFsZXJ0cyBieSBhbGVydCBhY3Rpb24gdHlwZSBhbmQgb3JnYW5pemF0aW9uJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIFwidGl0bGVcIjogXCJUb3AgYWxlcnRzIGJ5IGFsZXJ0IGFjdGlvbiB0eXBlIGFuZCBvcmdhbml6YXRpb25cIixcbiAgICAgICAgXCJ0eXBlXCI6IFwicGllXCIsXG4gICAgICAgIFwiYWdnc1wiOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjFcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwiY291bnRcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHt9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJtZXRyaWNcIlxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjNcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGVybXNcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcImRhdGEuZ2l0aHViLm9yZ1wiLFxuICAgICAgICAgICAgICBcIm9yZGVyQnlcIjogXCIxXCIsXG4gICAgICAgICAgICAgIFwib3JkZXJcIjogXCJkZXNjXCIsXG4gICAgICAgICAgICAgIFwic2l6ZVwiOiA1LFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0XCI6IGZhbHNlLFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0TGFiZWxcIjogXCJPdGhlclwiLFxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldExhYmVsXCI6IFwiTWlzc2luZ1wiXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJzZWdtZW50XCJcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIFwiaWRcIjogXCIyXCIsXG4gICAgICAgICAgICBcImVuYWJsZWRcIjogdHJ1ZSxcbiAgICAgICAgICAgIFwidHlwZVwiOiBcInRlcm1zXCIsXG4gICAgICAgICAgICBcInBhcmFtc1wiOiB7XG4gICAgICAgICAgICAgIFwiZmllbGRcIjogXCJkYXRhLmdpdGh1Yi5hY3Rpb25cIixcbiAgICAgICAgICAgICAgXCJvcmRlckJ5XCI6IFwiMVwiLFxuICAgICAgICAgICAgICBcIm9yZGVyXCI6IFwiZGVzY1wiLFxuICAgICAgICAgICAgICBcInNpemVcIjogMyxcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldFwiOiBmYWxzZSxcbiAgICAgICAgICAgICAgXCJvdGhlckJ1Y2tldExhYmVsXCI6IFwiT3RoZXJcIixcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0XCI6IGZhbHNlLFxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRMYWJlbFwiOiBcIk1pc3NpbmdcIlxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwic2NoZW1hXCI6IFwic2VnbWVudFwiXG4gICAgICAgICAgfVxuICAgICAgICBdLFxuICAgICAgICBcInBhcmFtc1wiOiB7XG4gICAgICAgICAgXCJ0eXBlXCI6IFwicGllXCIsXG4gICAgICAgICAgXCJhZGRUb29sdGlwXCI6IHRydWUsXG4gICAgICAgICAgXCJhZGRMZWdlbmRcIjogdHJ1ZSxcbiAgICAgICAgICBcImxlZ2VuZFBvc2l0aW9uXCI6IFwicmlnaHRcIixcbiAgICAgICAgICBcImlzRG9udXRcIjogdHJ1ZSxcbiAgICAgICAgICBcImxhYmVsc1wiOiB7XG4gICAgICAgICAgICBcInNob3dcIjogZmFsc2UsXG4gICAgICAgICAgICBcInZhbHVlc1wiOiB0cnVlLFxuICAgICAgICAgICAgXCJsYXN0X2xldmVsXCI6IHRydWUsXG4gICAgICAgICAgICBcInRydW5jYXRlXCI6IDEwMFxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJycsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046ICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfVxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtR2l0SHViLUFsZXJ0LVN1bW1hcnknLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgXCJ0aXRsZVwiOiBcIkFsZXJ0cyBzdW1tYXJ5XCIsXG4gICAgICAgIFwidHlwZVwiOiBcInRhYmxlXCIsXG4gICAgICAgIFwiYWdnc1wiOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjFcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwiY291bnRcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHt9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJtZXRyaWNcIlxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjJcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGVybXNcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcImFnZW50Lm5hbWVcIixcbiAgICAgICAgICAgICAgXCJvcmRlckJ5XCI6IFwiMVwiLFxuICAgICAgICAgICAgICBcIm9yZGVyXCI6IFwiZGVzY1wiLFxuICAgICAgICAgICAgICBcInNpemVcIjogNTAsXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRcIjogZmFsc2UsXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRMYWJlbFwiOiBcIk90aGVyXCIsXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldFwiOiBmYWxzZSxcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0TGFiZWxcIjogXCJNaXNzaW5nXCJcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInNjaGVtYVwiOiBcImJ1Y2tldFwiXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBcImlkXCI6IFwiM1wiLFxuICAgICAgICAgICAgXCJlbmFibGVkXCI6IHRydWUsXG4gICAgICAgICAgICBcInR5cGVcIjogXCJ0ZXJtc1wiLFxuICAgICAgICAgICAgXCJwYXJhbXNcIjoge1xuICAgICAgICAgICAgICBcImZpZWxkXCI6IFwiZGF0YS5naXRodWIub3JnXCIsXG4gICAgICAgICAgICAgIFwib3JkZXJCeVwiOiBcIjFcIixcbiAgICAgICAgICAgICAgXCJvcmRlclwiOiBcImRlc2NcIixcbiAgICAgICAgICAgICAgXCJzaXplXCI6IDEwLFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0XCI6IGZhbHNlLFxuICAgICAgICAgICAgICBcIm90aGVyQnVja2V0TGFiZWxcIjogXCJPdGhlclwiLFxuICAgICAgICAgICAgICBcIm1pc3NpbmdCdWNrZXRcIjogZmFsc2UsXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldExhYmVsXCI6IFwiTWlzc2luZ1wiXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJzY2hlbWFcIjogXCJidWNrZXRcIlxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcIjRcIixcbiAgICAgICAgICAgIFwiZW5hYmxlZFwiOiB0cnVlLFxuICAgICAgICAgICAgXCJ0eXBlXCI6IFwidGVybXNcIixcbiAgICAgICAgICAgIFwicGFyYW1zXCI6IHtcbiAgICAgICAgICAgICAgXCJmaWVsZFwiOiBcInJ1bGUuZGVzY3JpcHRpb25cIixcbiAgICAgICAgICAgICAgXCJvcmRlckJ5XCI6IFwiMVwiLFxuICAgICAgICAgICAgICBcIm9yZGVyXCI6IFwiZGVzY1wiLFxuICAgICAgICAgICAgICBcInNpemVcIjogMTAsXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRcIjogZmFsc2UsXG4gICAgICAgICAgICAgIFwib3RoZXJCdWNrZXRMYWJlbFwiOiBcIk90aGVyXCIsXG4gICAgICAgICAgICAgIFwibWlzc2luZ0J1Y2tldFwiOiBmYWxzZSxcbiAgICAgICAgICAgICAgXCJtaXNzaW5nQnVja2V0TGFiZWxcIjogXCJNaXNzaW5nXCJcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInNjaGVtYVwiOiBcImJ1Y2tldFwiXG4gICAgICAgICAgfVxuICAgICAgICBdLFxuICAgICAgICBcInBhcmFtc1wiOiB7XG4gICAgICAgICAgXCJwZXJQYWdlXCI6IDEwLFxuICAgICAgICAgIFwic2hvd1BhcnRpYWxSb3dzXCI6IGZhbHNlLFxuICAgICAgICAgIFwic2hvd01ldHJpY3NBdEFsbExldmVsc1wiOiBmYWxzZSxcbiAgICAgICAgICBcInNvcnRcIjoge1xuICAgICAgICAgICAgXCJjb2x1bW5JbmRleFwiOiBudWxsLFxuICAgICAgICAgICAgXCJkaXJlY3Rpb25cIjogbnVsbFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzaG93VG90YWxcIjogZmFsc2UsXG4gICAgICAgICAgXCJ0b3RhbEZ1bmNcIjogXCJzdW1cIixcbiAgICAgICAgICBcInBlcmNlbnRhZ2VDb2xcIjogXCJcIlxuICAgICAgICB9XG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXG4gICAgICB9XG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9XG5dO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVkEsSUFBQUEsUUFBQSxHQVllLENBQ2I7RUFDRUMsR0FBRyxFQUFFLDBEQUEwRDtFQUMvREMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxrQ0FBa0M7SUFDekNDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkIsT0FBTyxFQUFFLGtDQUFrQztNQUMzQyxNQUFNLEVBQUUsTUFBTTtNQUNkLE1BQU0sRUFBRSxDQUNOO1FBQ0UsSUFBSSxFQUFFLEdBQUc7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLE1BQU0sRUFBRSxPQUFPO1FBQ2YsUUFBUSxFQUFFLENBQUMsQ0FBQztRQUNaLFFBQVEsRUFBRTtNQUNaLENBQUMsRUFDRDtRQUNFLElBQUksRUFBRSxHQUFHO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixNQUFNLEVBQUUsZ0JBQWdCO1FBQ3hCLFFBQVEsRUFBRTtVQUNSLE9BQU8sRUFBRSxXQUFXO1VBQ3BCLFdBQVcsRUFBRTtZQUNYLE1BQU0sRUFBRSxRQUFRO1lBQ2hCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRCx5QkFBeUIsRUFBRSxJQUFJO1VBQy9CLG1CQUFtQixFQUFFLEtBQUs7VUFDMUIsVUFBVSxFQUFFLE1BQU07VUFDbEIsZUFBZSxFQUFFLEtBQUs7VUFDdEIsZUFBZSxFQUFFLENBQUM7VUFDbEIsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDO1VBQ3JCLGFBQWEsRUFBRTtRQUNqQixDQUFDO1FBQ0QsUUFBUSxFQUFFO01BQ1osQ0FBQyxFQUNEO1FBQ0UsSUFBSSxFQUFFLEdBQUc7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLE1BQU0sRUFBRSxPQUFPO1FBQ2YsUUFBUSxFQUFFO1VBQ1IsT0FBTyxFQUFFLGlCQUFpQjtVQUMxQixTQUFTLEVBQUUsR0FBRztVQUNkLE9BQU8sRUFBRSxNQUFNO1VBQ2YsTUFBTSxFQUFFLENBQUM7VUFDVCxhQUFhLEVBQUUsS0FBSztVQUNwQixrQkFBa0IsRUFBRSxPQUFPO1VBQzNCLGVBQWUsRUFBRSxLQUFLO1VBQ3RCLG9CQUFvQixFQUFFO1FBQ3hCLENBQUM7UUFDRCxRQUFRLEVBQUU7TUFDWixDQUFDLENBQ0Y7TUFDRCxRQUFRLEVBQUU7UUFDUixNQUFNLEVBQUUsTUFBTTtRQUNkLE1BQU0sRUFBRTtVQUNOLGVBQWUsRUFBRTtRQUNuQixDQUFDO1FBQ0QsY0FBYyxFQUFFLENBQ2Q7VUFDRSxJQUFJLEVBQUUsZ0JBQWdCO1VBQ3RCLE1BQU0sRUFBRSxVQUFVO1VBQ2xCLFVBQVUsRUFBRSxRQUFRO1VBQ3BCLE1BQU0sRUFBRSxJQUFJO1VBQ1osT0FBTyxFQUFFLENBQUMsQ0FBQztVQUNYLE9BQU8sRUFBRTtZQUNQLE1BQU0sRUFBRTtVQUNWLENBQUM7VUFDRCxRQUFRLEVBQUU7WUFDUixNQUFNLEVBQUUsSUFBSTtZQUNaLFFBQVEsRUFBRSxJQUFJO1lBQ2QsVUFBVSxFQUFFLEdBQUc7WUFDZixRQUFRLEVBQUU7VUFDWixDQUFDO1VBQ0QsT0FBTyxFQUFFLENBQUM7UUFDWixDQUFDLENBQ0Y7UUFDRCxXQUFXLEVBQUUsQ0FDWDtVQUNFLElBQUksRUFBRSxhQUFhO1VBQ25CLE1BQU0sRUFBRSxZQUFZO1VBQ3BCLE1BQU0sRUFBRSxPQUFPO1VBQ2YsVUFBVSxFQUFFLE1BQU07VUFDbEIsTUFBTSxFQUFFLElBQUk7VUFDWixPQUFPLEVBQUUsQ0FBQyxDQUFDO1VBQ1gsT0FBTyxFQUFFO1lBQ1AsTUFBTSxFQUFFLFFBQVE7WUFDaEIsTUFBTSxFQUFFO1VBQ1YsQ0FBQztVQUNELFFBQVEsRUFBRTtZQUNSLE1BQU0sRUFBRSxJQUFJO1lBQ1osUUFBUSxFQUFFLENBQUM7WUFDWCxRQUFRLEVBQUUsS0FBSztZQUNmLFVBQVUsRUFBRTtVQUNkLENBQUM7VUFDRCxPQUFPLEVBQUU7WUFDUCxNQUFNLEVBQUU7VUFDVjtRQUNGLENBQUMsQ0FDRjtRQUNELGNBQWMsRUFBRSxDQUNkO1VBQ0UsTUFBTSxFQUFFLElBQUk7VUFDWixNQUFNLEVBQUUsTUFBTTtVQUNkLE1BQU0sRUFBRSxRQUFRO1VBQ2hCLE1BQU0sRUFBRTtZQUNOLE9BQU8sRUFBRSxPQUFPO1lBQ2hCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRCx3QkFBd0IsRUFBRSxJQUFJO1VBQzlCLFdBQVcsRUFBRSxDQUFDO1VBQ2QsYUFBYSxFQUFFLElBQUk7VUFDbkIsYUFBYSxFQUFFLFFBQVE7VUFDdkIsV0FBVyxFQUFFO1FBQ2YsQ0FBQyxDQUNGO1FBQ0QsWUFBWSxFQUFFLElBQUk7UUFDbEIsV0FBVyxFQUFFLElBQUk7UUFDakIsZ0JBQWdCLEVBQUUsT0FBTztRQUN6QixPQUFPLEVBQUUsRUFBRTtRQUNYLGVBQWUsRUFBRSxLQUFLO1FBQ3RCLGVBQWUsRUFBRTtVQUNmLE1BQU0sRUFBRSxLQUFLO1VBQ2IsT0FBTyxFQUFFLEVBQUU7VUFDWCxPQUFPLEVBQUUsQ0FBQztVQUNWLE9BQU8sRUFBRSxNQUFNO1VBQ2YsT0FBTyxFQUFFO1FBQ1gsQ0FBQztRQUNELFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDWixtQkFBbUIsRUFBRTtNQUN2QjtJQUNGLENBQUMsQ0FBQztJQUNGQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU7SUFDcEI7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFWCxHQUFHLEVBQUUsdURBQXVEO0VBQzVEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLCtCQUErQjtJQUN0Q0MsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QixPQUFPLEVBQUUsK0JBQStCO01BQ3hDLE1BQU0sRUFBRSxLQUFLO01BQ2IsTUFBTSxFQUFFLENBQ047UUFDRSxJQUFJLEVBQUUsR0FBRztRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsTUFBTSxFQUFFLE9BQU87UUFDZixRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ1osUUFBUSxFQUFFO01BQ1osQ0FBQyxFQUNEO1FBQ0UsSUFBSSxFQUFFLEdBQUc7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLE1BQU0sRUFBRSxPQUFPO1FBQ2YsUUFBUSxFQUFFO1VBQ1IsT0FBTyxFQUFFLGlCQUFpQjtVQUMxQixTQUFTLEVBQUUsR0FBRztVQUNkLE9BQU8sRUFBRSxNQUFNO1VBQ2YsTUFBTSxFQUFFLENBQUM7VUFDVCxhQUFhLEVBQUUsS0FBSztVQUNwQixrQkFBa0IsRUFBRSxPQUFPO1VBQzNCLGVBQWUsRUFBRSxLQUFLO1VBQ3RCLG9CQUFvQixFQUFFO1FBQ3hCLENBQUM7UUFDRCxRQUFRLEVBQUU7TUFDWixDQUFDLENBQ0Y7TUFDRCxRQUFRLEVBQUU7UUFDUixNQUFNLEVBQUUsS0FBSztRQUNiLFlBQVksRUFBRSxJQUFJO1FBQ2xCLFdBQVcsRUFBRSxJQUFJO1FBQ2pCLGdCQUFnQixFQUFFLE9BQU87UUFDekIsU0FBUyxFQUFFLEtBQUs7UUFDaEIsUUFBUSxFQUFFO1VBQ1IsTUFBTSxFQUFFLEtBQUs7VUFDYixRQUFRLEVBQUUsSUFBSTtVQUNkLFlBQVksRUFBRSxJQUFJO1VBQ2xCLFVBQVUsRUFBRTtRQUNkO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFO0lBQ3BCO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRVgsR0FBRyxFQUFFLGdEQUFnRDtFQUNyREMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSx3QkFBd0I7SUFDL0JDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkIsT0FBTyxFQUFFLHdCQUF3QjtNQUNqQyxNQUFNLEVBQUUsTUFBTTtNQUNkLE1BQU0sRUFBRSxDQUNOO1FBQ0UsSUFBSSxFQUFFLEdBQUc7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLE1BQU0sRUFBRSxPQUFPO1FBQ2YsUUFBUSxFQUFFLENBQUMsQ0FBQztRQUNaLFFBQVEsRUFBRTtNQUNaLENBQUMsRUFDRDtRQUNFLElBQUksRUFBRSxHQUFHO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixNQUFNLEVBQUUsT0FBTztRQUNmLFFBQVEsRUFBRTtVQUNSLE9BQU8sRUFBRSxpQkFBaUI7VUFDMUIsU0FBUyxFQUFFLEdBQUc7VUFDZCxPQUFPLEVBQUUsTUFBTTtVQUNmLE1BQU0sRUFBRSxDQUFDO1VBQ1QsYUFBYSxFQUFFLEtBQUs7VUFDcEIsa0JBQWtCLEVBQUUsT0FBTztVQUMzQixlQUFlLEVBQUUsS0FBSztVQUN0QixvQkFBb0IsRUFBRTtRQUN4QixDQUFDO1FBQ0QsUUFBUSxFQUFFO01BQ1osQ0FBQyxFQUNEO1FBQ0UsSUFBSSxFQUFFLEdBQUc7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLE1BQU0sRUFBRSxPQUFPO1FBQ2YsUUFBUSxFQUFFO1VBQ1IsT0FBTyxFQUFFLG1CQUFtQjtVQUM1QixTQUFTLEVBQUUsR0FBRztVQUNkLE9BQU8sRUFBRSxNQUFNO1VBQ2YsTUFBTSxFQUFFLENBQUM7VUFDVCxhQUFhLEVBQUUsS0FBSztVQUNwQixrQkFBa0IsRUFBRSxPQUFPO1VBQzNCLGVBQWUsRUFBRSxLQUFLO1VBQ3RCLG9CQUFvQixFQUFFO1FBQ3hCLENBQUM7UUFDRCxRQUFRLEVBQUU7TUFDWixDQUFDLENBQ0Y7TUFDRCxRQUFRLEVBQUU7UUFDUixNQUFNLEVBQUUsTUFBTTtRQUNkLE1BQU0sRUFBRTtVQUNOLGVBQWUsRUFBRTtRQUNuQixDQUFDO1FBQ0QsY0FBYyxFQUFFLENBQ2Q7VUFDRSxJQUFJLEVBQUUsZ0JBQWdCO1VBQ3RCLE1BQU0sRUFBRSxVQUFVO1VBQ2xCLFVBQVUsRUFBRSxRQUFRO1VBQ3BCLE1BQU0sRUFBRSxJQUFJO1VBQ1osT0FBTyxFQUFFLENBQUMsQ0FBQztVQUNYLE9BQU8sRUFBRTtZQUNQLE1BQU0sRUFBRTtVQUNWLENBQUM7VUFDRCxRQUFRLEVBQUU7WUFDUixNQUFNLEVBQUUsSUFBSTtZQUNaLFFBQVEsRUFBRSxJQUFJO1lBQ2QsVUFBVSxFQUFFO1VBQ2QsQ0FBQztVQUNELE9BQU8sRUFBRSxDQUFDO1FBQ1osQ0FBQyxDQUNGO1FBQ0QsV0FBVyxFQUFFLENBQ1g7VUFDRSxJQUFJLEVBQUUsYUFBYTtVQUNuQixNQUFNLEVBQUUsWUFBWTtVQUNwQixNQUFNLEVBQUUsT0FBTztVQUNmLFVBQVUsRUFBRSxNQUFNO1VBQ2xCLE1BQU0sRUFBRSxJQUFJO1VBQ1osT0FBTyxFQUFFLENBQUMsQ0FBQztVQUNYLE9BQU8sRUFBRTtZQUNQLE1BQU0sRUFBRSxRQUFRO1lBQ2hCLE1BQU0sRUFBRTtVQUNWLENBQUM7VUFDRCxRQUFRLEVBQUU7WUFDUixNQUFNLEVBQUUsSUFBSTtZQUNaLFFBQVEsRUFBRSxDQUFDO1lBQ1gsUUFBUSxFQUFFLEtBQUs7WUFDZixVQUFVLEVBQUU7VUFDZCxDQUFDO1VBQ0QsT0FBTyxFQUFFO1lBQ1AsTUFBTSxFQUFFO1VBQ1Y7UUFDRixDQUFDLENBQ0Y7UUFDRCxjQUFjLEVBQUUsQ0FDZDtVQUNFLE1BQU0sRUFBRSxJQUFJO1VBQ1osTUFBTSxFQUFFLFdBQVc7VUFDbkIsTUFBTSxFQUFFLFNBQVM7VUFDakIsTUFBTSxFQUFFO1lBQ04sT0FBTyxFQUFFLE9BQU87WUFDaEIsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNELFdBQVcsRUFBRSxhQUFhO1VBQzFCLHdCQUF3QixFQUFFLElBQUk7VUFDOUIsV0FBVyxFQUFFLENBQUM7VUFDZCxhQUFhLEVBQUUsUUFBUTtVQUN2QixhQUFhLEVBQUU7UUFDakIsQ0FBQyxDQUNGO1FBQ0QsWUFBWSxFQUFFLElBQUk7UUFDbEIsV0FBVyxFQUFFLElBQUk7UUFDakIsZ0JBQWdCLEVBQUUsT0FBTztRQUN6QixPQUFPLEVBQUUsRUFBRTtRQUNYLGVBQWUsRUFBRSxLQUFLO1FBQ3RCLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDWixlQUFlLEVBQUU7VUFDZixNQUFNLEVBQUUsS0FBSztVQUNiLE9BQU8sRUFBRSxFQUFFO1VBQ1gsT0FBTyxFQUFFLENBQUM7VUFDVixPQUFPLEVBQUUsTUFBTTtVQUNmLE9BQU8sRUFBRTtRQUNYO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFO0lBQ3BCO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRVgsR0FBRyxFQUFFLDJEQUEyRDtFQUNoRUMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxrREFBa0Q7SUFDekRDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkIsT0FBTyxFQUFFLGtEQUFrRDtNQUMzRCxNQUFNLEVBQUUsS0FBSztNQUNiLE1BQU0sRUFBRSxDQUNOO1FBQ0UsSUFBSSxFQUFFLEdBQUc7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLE1BQU0sRUFBRSxPQUFPO1FBQ2YsUUFBUSxFQUFFLENBQUMsQ0FBQztRQUNaLFFBQVEsRUFBRTtNQUNaLENBQUMsRUFDRDtRQUNFLElBQUksRUFBRSxHQUFHO1FBQ1QsU0FBUyxFQUFFLElBQUk7UUFDZixNQUFNLEVBQUUsT0FBTztRQUNmLFFBQVEsRUFBRTtVQUNSLE9BQU8sRUFBRSxpQkFBaUI7VUFDMUIsU0FBUyxFQUFFLEdBQUc7VUFDZCxPQUFPLEVBQUUsTUFBTTtVQUNmLE1BQU0sRUFBRSxDQUFDO1VBQ1QsYUFBYSxFQUFFLEtBQUs7VUFDcEIsa0JBQWtCLEVBQUUsT0FBTztVQUMzQixlQUFlLEVBQUUsS0FBSztVQUN0QixvQkFBb0IsRUFBRTtRQUN4QixDQUFDO1FBQ0QsUUFBUSxFQUFFO01BQ1osQ0FBQyxFQUNEO1FBQ0UsSUFBSSxFQUFFLEdBQUc7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLE1BQU0sRUFBRSxPQUFPO1FBQ2YsUUFBUSxFQUFFO1VBQ1IsT0FBTyxFQUFFLG9CQUFvQjtVQUM3QixTQUFTLEVBQUUsR0FBRztVQUNkLE9BQU8sRUFBRSxNQUFNO1VBQ2YsTUFBTSxFQUFFLENBQUM7VUFDVCxhQUFhLEVBQUUsS0FBSztVQUNwQixrQkFBa0IsRUFBRSxPQUFPO1VBQzNCLGVBQWUsRUFBRSxLQUFLO1VBQ3RCLG9CQUFvQixFQUFFO1FBQ3hCLENBQUM7UUFDRCxRQUFRLEVBQUU7TUFDWixDQUFDLENBQ0Y7TUFDRCxRQUFRLEVBQUU7UUFDUixNQUFNLEVBQUUsS0FBSztRQUNiLFlBQVksRUFBRSxJQUFJO1FBQ2xCLFdBQVcsRUFBRSxJQUFJO1FBQ2pCLGdCQUFnQixFQUFFLE9BQU87UUFDekIsU0FBUyxFQUFFLElBQUk7UUFDZixRQUFRLEVBQUU7VUFDUixNQUFNLEVBQUUsS0FBSztVQUNiLFFBQVEsRUFBRSxJQUFJO1VBQ2QsWUFBWSxFQUFFLElBQUk7VUFDbEIsVUFBVSxFQUFFO1FBQ2Q7TUFDRjtJQUNGLENBQUMsQ0FBQztJQUNGQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU7SUFDcEI7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFWCxHQUFHLEVBQUUsdUNBQXVDO0VBQzVDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QixPQUFPLEVBQUUsZ0JBQWdCO01BQ3pCLE1BQU0sRUFBRSxPQUFPO01BQ2YsTUFBTSxFQUFFLENBQ047UUFDRSxJQUFJLEVBQUUsR0FBRztRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsTUFBTSxFQUFFLE9BQU87UUFDZixRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQ1osUUFBUSxFQUFFO01BQ1osQ0FBQyxFQUNEO1FBQ0UsSUFBSSxFQUFFLEdBQUc7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLE1BQU0sRUFBRSxPQUFPO1FBQ2YsUUFBUSxFQUFFO1VBQ1IsT0FBTyxFQUFFLFlBQVk7VUFDckIsU0FBUyxFQUFFLEdBQUc7VUFDZCxPQUFPLEVBQUUsTUFBTTtVQUNmLE1BQU0sRUFBRSxFQUFFO1VBQ1YsYUFBYSxFQUFFLEtBQUs7VUFDcEIsa0JBQWtCLEVBQUUsT0FBTztVQUMzQixlQUFlLEVBQUUsS0FBSztVQUN0QixvQkFBb0IsRUFBRTtRQUN4QixDQUFDO1FBQ0QsUUFBUSxFQUFFO01BQ1osQ0FBQyxFQUNEO1FBQ0UsSUFBSSxFQUFFLEdBQUc7UUFDVCxTQUFTLEVBQUUsSUFBSTtRQUNmLE1BQU0sRUFBRSxPQUFPO1FBQ2YsUUFBUSxFQUFFO1VBQ1IsT0FBTyxFQUFFLGlCQUFpQjtVQUMxQixTQUFTLEVBQUUsR0FBRztVQUNkLE9BQU8sRUFBRSxNQUFNO1VBQ2YsTUFBTSxFQUFFLEVBQUU7VUFDVixhQUFhLEVBQUUsS0FBSztVQUNwQixrQkFBa0IsRUFBRSxPQUFPO1VBQzNCLGVBQWUsRUFBRSxLQUFLO1VBQ3RCLG9CQUFvQixFQUFFO1FBQ3hCLENBQUM7UUFDRCxRQUFRLEVBQUU7TUFDWixDQUFDLEVBQ0Q7UUFDRSxJQUFJLEVBQUUsR0FBRztRQUNULFNBQVMsRUFBRSxJQUFJO1FBQ2YsTUFBTSxFQUFFLE9BQU87UUFDZixRQUFRLEVBQUU7VUFDUixPQUFPLEVBQUUsa0JBQWtCO1VBQzNCLFNBQVMsRUFBRSxHQUFHO1VBQ2QsT0FBTyxFQUFFLE1BQU07VUFDZixNQUFNLEVBQUUsRUFBRTtVQUNWLGFBQWEsRUFBRSxLQUFLO1VBQ3BCLGtCQUFrQixFQUFFLE9BQU87VUFDM0IsZUFBZSxFQUFFLEtBQUs7VUFDdEIsb0JBQW9CLEVBQUU7UUFDeEIsQ0FBQztRQUNELFFBQVEsRUFBRTtNQUNaLENBQUMsQ0FDRjtNQUNELFFBQVEsRUFBRTtRQUNSLFNBQVMsRUFBRSxFQUFFO1FBQ2IsaUJBQWlCLEVBQUUsS0FBSztRQUN4Qix3QkFBd0IsRUFBRSxLQUFLO1FBQy9CLE1BQU0sRUFBRTtVQUNOLGFBQWEsRUFBRSxJQUFJO1VBQ25CLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRCxXQUFXLEVBQUUsS0FBSztRQUNsQixXQUFXLEVBQUUsS0FBSztRQUNsQixlQUFlLEVBQUU7TUFDbkI7SUFDRixDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFRixJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUMxQk8sR0FBRyxFQUFFO1FBQUVDLE1BQU0sRUFBRTtVQUFFQyxJQUFJLEVBQUU7WUFBRUMsV0FBVyxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQU87UUFBRTtNQUFFO0lBQ2pFLENBQUMsQ0FBQztJQUNGVCxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU7SUFDcEI7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsQ0FDRjtBQUFBTSxPQUFBLENBQUFDLE9BQUEsR0FBQW5CLFFBQUE7QUFBQW9CLE1BQUEsQ0FBQUYsT0FBQSxHQUFBQSxPQUFBLENBQUFDLE9BQUEifQ==