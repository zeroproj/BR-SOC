"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Overview/AWS visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Agents-AWS-Top-5-rules',
  _type: 'visualization',
  _source: {
    title: 'Top rules',
    visState: JSON.stringify({
      title: 'Top rules',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: 2,
          direction: 'desc'
        },
        showTotal: false,
        showtoolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.id',
          size: 500,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Rule ID'
        }
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          size: 10,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Event'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 2,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Agents-AWS-geo',
  _type: 'visualization',
  _source: {
    title: 'Geolocation map',
    visState: JSON.stringify({
      title: 'Geolocation map',
      type: 'tile_map',
      params: {
        colorSchema: 'Green to Red',
        mapType: 'Scaled Circle Markers',
        isDesaturated: false,
        addTooltip: true,
        heatClusterSize: 1.5,
        legendPosition: 'bottomright',
        mapZoom: 1,
        mapCenter: [0, 0],
        wms: {
          enabled: false,
          options: {
            format: 'image/png',
            transparent: true
          }
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          geohash: {
            accessor: 0,
            format: {
              id: 'string'
            },
            params: {
              precision: 2,
              useGeocentroid: true
            },
            aggType: 'geohash_grid'
          },
          geocentroid: {
            accessor: 2,
            format: {
              id: 'string'
            },
            params: {},
            aggType: 'geo_centroid'
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'geohash_grid',
        schema: 'segment',
        params: {
          field: 'GeoLocation.location',
          autoPrecision: true,
          precision: 2,
          useGeocentroid: true,
          isFilteredByCollar: true,
          mapZoom: 1,
          mapCenter: [0, 0]
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      mapZoom: 2,
      mapCenter: [38.685509760012025, -31.816406250000004]
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Agents-AWS-Events-by-source',
  _type: 'visualization',
  _source: {
    title: 'Events by source over time',
    visState: JSON.stringify({
      title: 'Alerts by action over time',
      type: 'area',
      params: {
        type: 'area',
        grid: {
          categoryLines: true,
          style: {
            color: '#eee'
          },
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'area',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'cardinal',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'left',
        times: [],
        addTimeMarker: false
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-24h',
            to: 'now',
            mode: 'quick'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          time_zone: 'Europe/Berlin',
          drop_partials: false,
          customInterval: '2h',
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'data.aws.source',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Agents-AWS-Top-accounts',
  _type: 'visualization',
  _source: {
    title: 'Accounts',
    visState: JSON.stringify({
      title: 'Accounts',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.aws.accountId',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Agents-AWS-Top-sources',
  _type: 'visualization',
  _source: {
    title: 'Sources',
    visState: JSON.stringify({
      title: 'Sources',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.aws.source',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Agents-AWS-Top-buckets',
  _type: 'visualization',
  _source: {
    title: 'Buckets',
    visState: JSON.stringify({
      title: 'Buckets',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.aws.log_info.s3bucket',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Agents-AWS-Top-regions',
  _type: 'visualization',
  _source: {
    title: 'Regions',
    visState: JSON.stringify({
      title: 'Regions',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.aws.region',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Agents-AWS-Events-by-s3-bucket',
  _type: 'visualization',
  _source: {
    title: 'Events by S3 bucket over time',
    visState: JSON.stringify({
      title: 'Alerts by action over time',
      type: 'area',
      params: {
        type: 'area',
        grid: {
          categoryLines: true,
          style: {
            color: '#eee'
          },
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'area',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'cardinal',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-24h',
            to: 'now',
            mode: 'quick'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          time_zone: 'Europe/Berlin',
          drop_partials: false,
          customInterval: '2h',
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'data.aws.log_info.s3bucket',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Agents-AWS-Alerts-summary',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'Alerts summary',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMeticsAtAllLevels: false,
        sort: {
          columnIndex: 3,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.id',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 50,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Rule ID'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 1,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Description'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.level',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 1,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Level'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl90eXBlIiwiX3NvdXJjZSIsInRpdGxlIiwidmlzU3RhdGUiLCJKU09OIiwic3RyaW5naWZ5IiwidHlwZSIsInBhcmFtcyIsInBlclBhZ2UiLCJzaG93UGFydGlhbFJvd3MiLCJzaG93TWV0cmljc0F0QWxsTGV2ZWxzIiwic29ydCIsImNvbHVtbkluZGV4IiwiZGlyZWN0aW9uIiwic2hvd1RvdGFsIiwic2hvd3Rvb2xiYXIiLCJ0b3RhbEZ1bmMiLCJhZ2dzIiwiaWQiLCJlbmFibGVkIiwic2NoZW1hIiwiZmllbGQiLCJzaXplIiwib3JkZXIiLCJvcmRlckJ5Iiwib3RoZXJCdWNrZXQiLCJvdGhlckJ1Y2tldExhYmVsIiwibWlzc2luZ0J1Y2tldCIsIm1pc3NpbmdCdWNrZXRMYWJlbCIsImN1c3RvbUxhYmVsIiwidWlTdGF0ZUpTT04iLCJ2aXMiLCJkZXNjcmlwdGlvbiIsInZlcnNpb24iLCJraWJhbmFTYXZlZE9iamVjdE1ldGEiLCJzZWFyY2hTb3VyY2VKU09OIiwiaW5kZXgiLCJxdWVyeSIsImxhbmd1YWdlIiwiZmlsdGVyIiwiY29sb3JTY2hlbWEiLCJtYXBUeXBlIiwiaXNEZXNhdHVyYXRlZCIsImFkZFRvb2x0aXAiLCJoZWF0Q2x1c3RlclNpemUiLCJsZWdlbmRQb3NpdGlvbiIsIm1hcFpvb20iLCJtYXBDZW50ZXIiLCJ3bXMiLCJvcHRpb25zIiwiZm9ybWF0IiwidHJhbnNwYXJlbnQiLCJkaW1lbnNpb25zIiwibWV0cmljIiwiYWNjZXNzb3IiLCJhZ2dUeXBlIiwiZ2VvaGFzaCIsInByZWNpc2lvbiIsInVzZUdlb2NlbnRyb2lkIiwiZ2VvY2VudHJvaWQiLCJhdXRvUHJlY2lzaW9uIiwiaXNGaWx0ZXJlZEJ5Q29sbGFyIiwiZ3JpZCIsImNhdGVnb3J5TGluZXMiLCJzdHlsZSIsImNvbG9yIiwidmFsdWVBeGlzIiwiY2F0ZWdvcnlBeGVzIiwicG9zaXRpb24iLCJzaG93Iiwic2NhbGUiLCJsYWJlbHMiLCJ0cnVuY2F0ZSIsInZhbHVlQXhlcyIsIm5hbWUiLCJtb2RlIiwicm90YXRlIiwidGV4dCIsInNlcmllc1BhcmFtcyIsImRhdGEiLCJsYWJlbCIsImRyYXdMaW5lc0JldHdlZW5Qb2ludHMiLCJzaG93Q2lyY2xlcyIsImludGVycG9sYXRlIiwiYWRkTGVnZW5kIiwidGltZXMiLCJhZGRUaW1lTWFya2VyIiwidGltZVJhbmdlIiwiZnJvbSIsInRvIiwidXNlTm9ybWFsaXplZEVzSW50ZXJ2YWwiLCJpbnRlcnZhbCIsInRpbWVfem9uZSIsImRyb3BfcGFydGlhbHMiLCJjdXN0b21JbnRlcnZhbCIsIm1pbl9kb2NfY291bnQiLCJleHRlbmRlZF9ib3VuZHMiLCJpc0RvbnV0IiwidmFsdWVzIiwibGFzdF9sZXZlbCIsInNob3dNZXRpY3NBdEFsbExldmVscyIsInNob3dUb29sYmFyIiwiZXhwb3J0cyIsImRlZmF1bHQiLCJtb2R1bGUiXSwic291cmNlcyI6WyJhZ2VudHMtYXdzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBhcHAgLSBNb2R1bGUgZm9yIE92ZXJ2aWV3L0FXUyB2aXN1YWxpemF0aW9uc1xuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IFtcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtQVdTLVRvcC01LXJ1bGVzJyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIHJ1bGVzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnVG9wIHJ1bGVzJyxcbiAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgcGVyUGFnZTogMTAsXG4gICAgICAgICAgc2hvd1BhcnRpYWxSb3dzOiBmYWxzZSxcbiAgICAgICAgICBzaG93TWV0cmljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiAyLCBkaXJlY3Rpb246ICdkZXNjJyB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgc2hvd3Rvb2xiYXI6IHRydWUsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmlkJyxcbiAgICAgICAgICAgICAgc2l6ZTogNTAwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1J1bGUgSUQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmRlc2NyaXB0aW9uJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnRXZlbnQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDIsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxuICAgICAgfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtQVdTLWdlbycsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0dlb2xvY2F0aW9uIG1hcCcsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0dlb2xvY2F0aW9uIG1hcCcsXG4gICAgICAgIHR5cGU6ICd0aWxlX21hcCcsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGNvbG9yU2NoZW1hOiAnR3JlZW4gdG8gUmVkJyxcbiAgICAgICAgICBtYXBUeXBlOiAnU2NhbGVkIENpcmNsZSBNYXJrZXJzJyxcbiAgICAgICAgICBpc0Rlc2F0dXJhdGVkOiBmYWxzZSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGhlYXRDbHVzdGVyU2l6ZTogMS41LFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAnYm90dG9tcmlnaHQnLFxuICAgICAgICAgIG1hcFpvb206IDEsXG4gICAgICAgICAgbWFwQ2VudGVyOiBbMCwgMF0sXG4gICAgICAgICAgd21zOiB7IGVuYWJsZWQ6IGZhbHNlLCBvcHRpb25zOiB7IGZvcm1hdDogJ2ltYWdlL3BuZycsIHRyYW5zcGFyZW50OiB0cnVlIH0gfSxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICBtZXRyaWM6IHsgYWNjZXNzb3I6IDEsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9LFxuICAgICAgICAgICAgZ2VvaGFzaDoge1xuICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcbiAgICAgICAgICAgICAgZm9ybWF0OiB7IGlkOiAnc3RyaW5nJyB9LFxuICAgICAgICAgICAgICBwYXJhbXM6IHsgcHJlY2lzaW9uOiAyLCB1c2VHZW9jZW50cm9pZDogdHJ1ZSB9LFxuICAgICAgICAgICAgICBhZ2dUeXBlOiAnZ2VvaGFzaF9ncmlkJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZW9jZW50cm9pZDoge1xuICAgICAgICAgICAgICBhY2Nlc3NvcjogMixcbiAgICAgICAgICAgICAgZm9ybWF0OiB7IGlkOiAnc3RyaW5nJyB9LFxuICAgICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgICBhZ2dUeXBlOiAnZ2VvX2NlbnRyb2lkJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2dlb2hhc2hfZ3JpZCcsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ0dlb0xvY2F0aW9uLmxvY2F0aW9uJyxcbiAgICAgICAgICAgICAgYXV0b1ByZWNpc2lvbjogdHJ1ZSxcbiAgICAgICAgICAgICAgcHJlY2lzaW9uOiAyLFxuICAgICAgICAgICAgICB1c2VHZW9jZW50cm9pZDogdHJ1ZSxcbiAgICAgICAgICAgICAgaXNGaWx0ZXJlZEJ5Q29sbGFyOiB0cnVlLFxuICAgICAgICAgICAgICBtYXBab29tOiAxLFxuICAgICAgICAgICAgICBtYXBDZW50ZXI6IFswLCAwXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgbWFwWm9vbTogMixcbiAgICAgICAgbWFwQ2VudGVyOiBbMzguNjg1NTA5NzYwMDEyMDI1LCAtMzEuODE2NDA2MjUwMDAwMDA0XSxcbiAgICAgIH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUFXUy1FdmVudHMtYnktc291cmNlJyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnRXZlbnRzIGJ5IHNvdXJjZSBvdmVyIHRpbWUnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydHMgYnkgYWN0aW9uIG92ZXIgdGltZScsXG4gICAgICAgIHR5cGU6ICdhcmVhJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ2FyZWEnLFxuICAgICAgICAgIGdyaWQ6IHsgY2F0ZWdvcnlMaW5lczogdHJ1ZSwgc3R5bGU6IHsgY29sb3I6ICcjZWVlJyB9LCB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScgfSxcbiAgICAgICAgICBjYXRlZ29yeUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdDYXRlZ29yeUF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICdjYXRlZ29yeScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgZmlsdGVyOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJywgbW9kZTogJ25vcm1hbCcgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIHJvdGF0ZTogMCwgZmlsdGVyOiBmYWxzZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZTogeyB0ZXh0OiAnQ291bnQnIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNob3c6ICd0cnVlJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2FyZWEnLFxuICAgICAgICAgICAgICBtb2RlOiAnc3RhY2tlZCcsXG4gICAgICAgICAgICAgIGRhdGE6IHsgbGFiZWw6ICdDb3VudCcsIGlkOiAnMScgfSxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgc2hvd0NpcmNsZXM6IHRydWUsXG4gICAgICAgICAgICAgIGludGVycG9sYXRlOiAnY2FyZGluYWwnLFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXG4gICAgICAgICAgICAgIHRpbWVSYW5nZTogeyBmcm9tOiAnbm93LTI0aCcsIHRvOiAnbm93JywgbW9kZTogJ3F1aWNrJyB9LFxuICAgICAgICAgICAgICB1c2VOb3JtYWxpemVkRXNJbnRlcnZhbDogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJ2YWw6ICdhdXRvJyxcbiAgICAgICAgICAgICAgdGltZV96b25lOiAnRXVyb3BlL0JlcmxpbicsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBjdXN0b21JbnRlcnZhbDogJzJoJyxcbiAgICAgICAgICAgICAgbWluX2RvY19jb3VudDogMSxcbiAgICAgICAgICAgICAgZXh0ZW5kZWRfYm91bmRzOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdncm91cCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmF3cy5zb3VyY2UnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1BV1MtVG9wLWFjY291bnRzJyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWNjb3VudHMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBY2NvdW50cycsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICAgIGxhYmVsczogeyBzaG93OiBmYWxzZSwgdmFsdWVzOiB0cnVlLCBsYXN0X2xldmVsOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuYXdzLmFjY291bnRJZCcsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUFXUy1Ub3Atc291cmNlcycsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1NvdXJjZXMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdTb3VyY2VzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IGZhbHNlLCB2YWx1ZXM6IHRydWUsIGxhc3RfbGV2ZWw6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5hd3Muc291cmNlJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtQVdTLVRvcC1idWNrZXRzJyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQnVja2V0cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0J1Y2tldHMnLFxuICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogdHJ1ZSxcbiAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogZmFsc2UsIHZhbHVlczogdHJ1ZSwgbGFzdF9sZXZlbDogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmF3cy5sb2dfaW5mby5zM2J1Y2tldCcsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUFXUy1Ub3AtcmVnaW9ucycsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1JlZ2lvbnMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdSZWdpb25zJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IGZhbHNlLCB2YWx1ZXM6IHRydWUsIGxhc3RfbGV2ZWw6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5hd3MucmVnaW9uJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtQVdTLUV2ZW50cy1ieS1zMy1idWNrZXQnLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdFdmVudHMgYnkgUzMgYnVja2V0IG92ZXIgdGltZScsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0FsZXJ0cyBieSBhY3Rpb24gb3ZlciB0aW1lJyxcbiAgICAgICAgdHlwZTogJ2FyZWEnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgZ3JpZDogeyBjYXRlZ29yeUxpbmVzOiB0cnVlLCBzdHlsZTogeyBjb2xvcjogJyNlZWUnIH0sIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgcm90YXRlOiAwLCBmaWx0ZXI6IGZhbHNlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdDb3VudCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogJ3RydWUnLFxuICAgICAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgICAgIG1vZGU6ICdzdGFja2VkJyxcbiAgICAgICAgICAgICAgZGF0YTogeyBsYWJlbDogJ0NvdW50JywgaWQ6ICcxJyB9LFxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJwb2xhdGU6ICdjYXJkaW5hbCcsXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXG4gICAgICAgICAgICAgIHRpbWVSYW5nZTogeyBmcm9tOiAnbm93LTI0aCcsIHRvOiAnbm93JywgbW9kZTogJ3F1aWNrJyB9LFxuICAgICAgICAgICAgICB1c2VOb3JtYWxpemVkRXNJbnRlcnZhbDogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJ2YWw6ICdhdXRvJyxcbiAgICAgICAgICAgICAgdGltZV96b25lOiAnRXVyb3BlL0JlcmxpbicsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBjdXN0b21JbnRlcnZhbDogJzJoJyxcbiAgICAgICAgICAgICAgbWluX2RvY19jb3VudDogMSxcbiAgICAgICAgICAgICAgZXh0ZW5kZWRfYm91bmRzOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdncm91cCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmF3cy5sb2dfaW5mby5zM2J1Y2tldCcsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUFXUy1BbGVydHMtc3VtbWFyeScsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0FsZXJ0cyBzdW1tYXJ5JyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBwZXJQYWdlOiAxMCxcbiAgICAgICAgICBzaG93UGFydGlhbFJvd3M6IGZhbHNlLFxuICAgICAgICAgIHNob3dNZXRpY3NBdEFsbExldmVsczogZmFsc2UsXG4gICAgICAgICAgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSxcbiAgICAgICAgICBzaG93VG90YWw6IGZhbHNlLFxuICAgICAgICAgIHNob3dUb29sYmFyOiB0cnVlLFxuICAgICAgICAgIHRvdGFsRnVuYzogJ3N1bScsXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5pZCcsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBzaXplOiA1MCxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1J1bGUgSUQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmRlc2NyaXB0aW9uJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDEsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdEZXNjcmlwdGlvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICc0JyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgc2l6ZTogMSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0xldmVsJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdmlzOiB7IHBhcmFtczogeyBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9IH0gfSxcbiAgICAgIH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG5dO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVkEsSUFBQUEsUUFBQSxHQVdlLENBQ2I7RUFDRUMsR0FBRyxFQUFFLGtDQUFrQztFQUN2Q0MsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsV0FBVztJQUNsQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLFdBQVc7TUFDbEJJLElBQUksRUFBRSxPQUFPO01BQ2JDLE1BQU0sRUFBRTtRQUNOQyxPQUFPLEVBQUUsRUFBRTtRQUNYQyxlQUFlLEVBQUUsS0FBSztRQUN0QkMsc0JBQXNCLEVBQUUsS0FBSztRQUM3QkMsSUFBSSxFQUFFO1VBQUVDLFdBQVcsRUFBRSxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFPLENBQUM7UUFDM0NDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsU0FBUyxFQUFFO01BQ2IsQ0FBQztNQUNEQyxJQUFJLEVBQUUsQ0FDSjtRQUFFQyxFQUFFLEVBQUUsR0FBRztRQUFFQyxPQUFPLEVBQUUsSUFBSTtRQUFFYixJQUFJLEVBQUUsT0FBTztRQUFFYyxNQUFNLEVBQUUsUUFBUTtRQUFFYixNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRVcsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYmIsSUFBSSxFQUFFLE9BQU87UUFDYmMsTUFBTSxFQUFFLFFBQVE7UUFDaEJiLE1BQU0sRUFBRTtVQUNOYyxLQUFLLEVBQUUsU0FBUztVQUNoQkMsSUFBSSxFQUFFLEdBQUc7VUFDVEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCQyxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFWCxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiYixJQUFJLEVBQUUsT0FBTztRQUNiYyxNQUFNLEVBQUUsUUFBUTtRQUNoQmIsTUFBTSxFQUFFO1VBQ05jLEtBQUssRUFBRSxrQkFBa0I7VUFDekJDLElBQUksRUFBRSxFQUFFO1VBQ1JDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3QkMsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZDLFdBQVcsRUFBRTFCLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQzFCMEIsR0FBRyxFQUFFO1FBQUV4QixNQUFNLEVBQUU7VUFBRUksSUFBSSxFQUFFO1lBQUVDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLFNBQVMsRUFBRTtVQUFPO1FBQUU7TUFBRTtJQUNqRSxDQUFDLENBQUM7SUFDRm1CLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRS9CLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CK0IsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFDO1FBQ3hDQyxNQUFNLEVBQUU7TUFDVixDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFeEMsR0FBRyxFQUFFLDBCQUEwQjtFQUMvQkMsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsaUJBQWlCO0lBQ3hCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsaUJBQWlCO01BQ3hCSSxJQUFJLEVBQUUsVUFBVTtNQUNoQkMsTUFBTSxFQUFFO1FBQ05pQyxXQUFXLEVBQUUsY0FBYztRQUMzQkMsT0FBTyxFQUFFLHVCQUF1QjtRQUNoQ0MsYUFBYSxFQUFFLEtBQUs7UUFDcEJDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxlQUFlLEVBQUUsR0FBRztRQUNwQkMsY0FBYyxFQUFFLGFBQWE7UUFDN0JDLE9BQU8sRUFBRSxDQUFDO1FBQ1ZDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDakJDLEdBQUcsRUFBRTtVQUFFN0IsT0FBTyxFQUFFLEtBQUs7VUFBRThCLE9BQU8sRUFBRTtZQUFFQyxNQUFNLEVBQUUsV0FBVztZQUFFQyxXQUFXLEVBQUU7VUFBSztRQUFFLENBQUM7UUFDNUVDLFVBQVUsRUFBRTtVQUNWQyxNQUFNLEVBQUU7WUFBRUMsUUFBUSxFQUFFLENBQUM7WUFBRUosTUFBTSxFQUFFO2NBQUVoQyxFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVYLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRWdELE9BQU8sRUFBRTtVQUFRLENBQUM7VUFDL0VDLE9BQU8sRUFBRTtZQUNQRixRQUFRLEVBQUUsQ0FBQztZQUNYSixNQUFNLEVBQUU7Y0FBRWhDLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFDeEJYLE1BQU0sRUFBRTtjQUFFa0QsU0FBUyxFQUFFLENBQUM7Y0FBRUMsY0FBYyxFQUFFO1lBQUssQ0FBQztZQUM5Q0gsT0FBTyxFQUFFO1VBQ1gsQ0FBQztVQUNESSxXQUFXLEVBQUU7WUFDWEwsUUFBUSxFQUFFLENBQUM7WUFDWEosTUFBTSxFQUFFO2NBQUVoQyxFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQ3hCWCxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZnRCxPQUFPLEVBQUU7VUFDWDtRQUNGO01BQ0YsQ0FBQztNQUNEdEMsSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxjQUFjO1FBQ3BCYyxNQUFNLEVBQUUsU0FBUztRQUNqQmIsTUFBTSxFQUFFO1VBQ05jLEtBQUssRUFBRSxzQkFBc0I7VUFDN0J1QyxhQUFhLEVBQUUsSUFBSTtVQUNuQkgsU0FBUyxFQUFFLENBQUM7VUFDWkMsY0FBYyxFQUFFLElBQUk7VUFDcEJHLGtCQUFrQixFQUFFLElBQUk7VUFDeEJmLE9BQU8sRUFBRSxDQUFDO1VBQ1ZDLFNBQVMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQ2xCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGakIsV0FBVyxFQUFFMUIsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUJ5QyxPQUFPLEVBQUUsQ0FBQztNQUNWQyxTQUFTLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDLGtCQUFrQjtJQUNyRCxDQUFDLENBQUM7SUFDRmYsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFL0IsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0IrQixLQUFLLEVBQUUsY0FBYztRQUNyQkMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTLENBQUM7UUFDeENDLE1BQU0sRUFBRTtNQUNWLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0V4QyxHQUFHLEVBQUUsdUNBQXVDO0VBQzVDQyxLQUFLLEVBQUUsZUFBZTtFQUN0QkMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSw0QkFBNEI7SUFDbkNDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSw0QkFBNEI7TUFDbkNJLElBQUksRUFBRSxNQUFNO01BQ1pDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsTUFBTTtRQUNad0QsSUFBSSxFQUFFO1VBQUVDLGFBQWEsRUFBRSxJQUFJO1VBQUVDLEtBQUssRUFBRTtZQUFFQyxLQUFLLEVBQUU7VUFBTyxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFjLENBQUM7UUFDakZDLFlBQVksRUFBRSxDQUNaO1VBQ0VqRCxFQUFFLEVBQUUsZ0JBQWdCO1VBQ3BCWixJQUFJLEVBQUUsVUFBVTtVQUNoQjhELFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUFFaEUsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6QmlFLE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsSUFBSTtZQUFFOUIsTUFBTSxFQUFFLElBQUk7WUFBRWlDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDbkR0RSxLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEdUUsU0FBUyxFQUFFLENBQ1Q7VUFDRXZELEVBQUUsRUFBRSxhQUFhO1VBQ2pCd0QsSUFBSSxFQUFFLFlBQVk7VUFDbEJwRSxJQUFJLEVBQUUsT0FBTztVQUNiOEQsUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZMLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVE0sS0FBSyxFQUFFO1lBQUVoRSxJQUFJLEVBQUUsUUFBUTtZQUFFcUUsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6Q0osTUFBTSxFQUFFO1lBQUVGLElBQUksRUFBRSxJQUFJO1lBQUVPLE1BQU0sRUFBRSxDQUFDO1lBQUVyQyxNQUFNLEVBQUUsS0FBSztZQUFFaUMsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUMvRHRFLEtBQUssRUFBRTtZQUFFMkUsSUFBSSxFQUFFO1VBQVE7UUFDekIsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0VULElBQUksRUFBRSxNQUFNO1VBQ1ovRCxJQUFJLEVBQUUsTUFBTTtVQUNacUUsSUFBSSxFQUFFLFNBQVM7VUFDZkksSUFBSSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUU5RCxFQUFFLEVBQUU7VUFBSSxDQUFDO1VBQ2pDK0Qsc0JBQXNCLEVBQUUsSUFBSTtVQUM1QkMsV0FBVyxFQUFFLElBQUk7VUFDakJDLFdBQVcsRUFBRSxVQUFVO1VBQ3ZCakIsU0FBUyxFQUFFO1FBQ2IsQ0FBQyxDQUNGO1FBQ0R2QixVQUFVLEVBQUUsSUFBSTtRQUNoQnlDLFNBQVMsRUFBRSxJQUFJO1FBQ2Z2QyxjQUFjLEVBQUUsTUFBTTtRQUN0QndDLEtBQUssRUFBRSxFQUFFO1FBQ1RDLGFBQWEsRUFBRTtNQUNqQixDQUFDO01BQ0RyRSxJQUFJLEVBQUUsQ0FDSjtRQUFFQyxFQUFFLEVBQUUsR0FBRztRQUFFQyxPQUFPLEVBQUUsSUFBSTtRQUFFYixJQUFJLEVBQUUsT0FBTztRQUFFYyxNQUFNLEVBQUUsUUFBUTtRQUFFYixNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRVcsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYmIsSUFBSSxFQUFFLGdCQUFnQjtRQUN0QmMsTUFBTSxFQUFFLFNBQVM7UUFDakJiLE1BQU0sRUFBRTtVQUNOYyxLQUFLLEVBQUUsV0FBVztVQUNsQmtFLFNBQVMsRUFBRTtZQUFFQyxJQUFJLEVBQUUsU0FBUztZQUFFQyxFQUFFLEVBQUUsS0FBSztZQUFFZCxJQUFJLEVBQUU7VUFBUSxDQUFDO1VBQ3hEZSx1QkFBdUIsRUFBRSxJQUFJO1VBQzdCQyxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsU0FBUyxFQUFFLGVBQWU7VUFDMUJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxjQUFjLEVBQUUsSUFBSTtVQUNwQkMsYUFBYSxFQUFFLENBQUM7VUFDaEJDLGVBQWUsRUFBRSxDQUFDO1FBQ3BCO01BQ0YsQ0FBQyxFQUNEO1FBQ0U5RSxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiYixJQUFJLEVBQUUsT0FBTztRQUNiYyxNQUFNLEVBQUUsT0FBTztRQUNmYixNQUFNLEVBQUU7VUFDTmMsS0FBSyxFQUFFLGlCQUFpQjtVQUN4QkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkUsV0FBVyxFQUFFLElBQUk7SUFDakJFLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRS9CLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CK0IsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFDO1FBQ3hDQyxNQUFNLEVBQUU7TUFDVixDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFeEMsR0FBRyxFQUFFLG1DQUFtQztFQUN4Q0MsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsVUFBVTtJQUNqQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLFVBQVU7TUFDakJJLElBQUksRUFBRSxLQUFLO01BQ1hDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYcUMsVUFBVSxFQUFFLElBQUk7UUFDaEJ5QyxTQUFTLEVBQUUsSUFBSTtRQUNmdkMsY0FBYyxFQUFFLE9BQU87UUFDdkJvRCxPQUFPLEVBQUUsSUFBSTtRQUNiMUIsTUFBTSxFQUFFO1VBQUVGLElBQUksRUFBRSxLQUFLO1VBQUU2QixNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFM0IsUUFBUSxFQUFFO1FBQUk7TUFDdkUsQ0FBQztNQUNEdkQsSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxPQUFPO1FBQ2JjLE1BQU0sRUFBRSxTQUFTO1FBQ2pCYixNQUFNLEVBQUU7VUFDTmMsS0FBSyxFQUFFLG9CQUFvQjtVQUMzQkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkUsV0FBVyxFQUFFLElBQUk7SUFDakJFLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRS9CLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CK0IsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFDO1FBQ3hDQyxNQUFNLEVBQUU7TUFDVixDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFeEMsR0FBRyxFQUFFLGtDQUFrQztFQUN2Q0MsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsU0FBUztJQUNoQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLFNBQVM7TUFDaEJJLElBQUksRUFBRSxLQUFLO01BQ1hDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYcUMsVUFBVSxFQUFFLElBQUk7UUFDaEJ5QyxTQUFTLEVBQUUsSUFBSTtRQUNmdkMsY0FBYyxFQUFFLE9BQU87UUFDdkJvRCxPQUFPLEVBQUUsSUFBSTtRQUNiMUIsTUFBTSxFQUFFO1VBQUVGLElBQUksRUFBRSxLQUFLO1VBQUU2QixNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFM0IsUUFBUSxFQUFFO1FBQUk7TUFDdkUsQ0FBQztNQUNEdkQsSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxPQUFPO1FBQ2JjLE1BQU0sRUFBRSxTQUFTO1FBQ2pCYixNQUFNLEVBQUU7VUFDTmMsS0FBSyxFQUFFLGlCQUFpQjtVQUN4QkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkUsV0FBVyxFQUFFLElBQUk7SUFDakJFLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRS9CLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CK0IsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFDO1FBQ3hDQyxNQUFNLEVBQUU7TUFDVixDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFeEMsR0FBRyxFQUFFLGtDQUFrQztFQUN2Q0MsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsU0FBUztJQUNoQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLFNBQVM7TUFDaEJJLElBQUksRUFBRSxLQUFLO01BQ1hDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYcUMsVUFBVSxFQUFFLElBQUk7UUFDaEJ5QyxTQUFTLEVBQUUsSUFBSTtRQUNmdkMsY0FBYyxFQUFFLE9BQU87UUFDdkJvRCxPQUFPLEVBQUUsSUFBSTtRQUNiMUIsTUFBTSxFQUFFO1VBQUVGLElBQUksRUFBRSxLQUFLO1VBQUU2QixNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFM0IsUUFBUSxFQUFFO1FBQUk7TUFDdkUsQ0FBQztNQUNEdkQsSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxPQUFPO1FBQ2JjLE1BQU0sRUFBRSxTQUFTO1FBQ2pCYixNQUFNLEVBQUU7VUFDTmMsS0FBSyxFQUFFLDRCQUE0QjtVQUNuQ0MsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkUsV0FBVyxFQUFFLElBQUk7SUFDakJFLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRS9CLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CK0IsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFDO1FBQ3hDQyxNQUFNLEVBQUU7TUFDVixDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFeEMsR0FBRyxFQUFFLGtDQUFrQztFQUN2Q0MsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsU0FBUztJQUNoQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLFNBQVM7TUFDaEJJLElBQUksRUFBRSxLQUFLO01BQ1hDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYcUMsVUFBVSxFQUFFLElBQUk7UUFDaEJ5QyxTQUFTLEVBQUUsSUFBSTtRQUNmdkMsY0FBYyxFQUFFLE9BQU87UUFDdkJvRCxPQUFPLEVBQUUsSUFBSTtRQUNiMUIsTUFBTSxFQUFFO1VBQUVGLElBQUksRUFBRSxLQUFLO1VBQUU2QixNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFM0IsUUFBUSxFQUFFO1FBQUk7TUFDdkUsQ0FBQztNQUNEdkQsSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxPQUFPO1FBQ2JjLE1BQU0sRUFBRSxTQUFTO1FBQ2pCYixNQUFNLEVBQUU7VUFDTmMsS0FBSyxFQUFFLGlCQUFpQjtVQUN4QkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkUsV0FBVyxFQUFFLElBQUk7SUFDakJFLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRS9CLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CK0IsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFDO1FBQ3hDQyxNQUFNLEVBQUU7TUFDVixDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFeEMsR0FBRyxFQUFFLDBDQUEwQztFQUMvQ0MsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsK0JBQStCO0lBQ3RDQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsNEJBQTRCO01BQ25DSSxJQUFJLEVBQUUsTUFBTTtNQUNaQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLE1BQU07UUFDWndELElBQUksRUFBRTtVQUFFQyxhQUFhLEVBQUUsSUFBSTtVQUFFQyxLQUFLLEVBQUU7WUFBRUMsS0FBSyxFQUFFO1VBQU8sQ0FBQztVQUFFQyxTQUFTLEVBQUU7UUFBYyxDQUFDO1FBQ2pGQyxZQUFZLEVBQUUsQ0FDWjtVQUNFakQsRUFBRSxFQUFFLGdCQUFnQjtVQUNwQlosSUFBSSxFQUFFLFVBQVU7VUFDaEI4RCxRQUFRLEVBQUUsUUFBUTtVQUNsQkMsSUFBSSxFQUFFLElBQUk7VUFDVkwsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTSxLQUFLLEVBQUU7WUFBRWhFLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekJpRSxNQUFNLEVBQUU7WUFBRUYsSUFBSSxFQUFFLElBQUk7WUFBRTlCLE1BQU0sRUFBRSxJQUFJO1lBQUVpQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQ25EdEUsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRHVFLFNBQVMsRUFBRSxDQUNUO1VBQ0V2RCxFQUFFLEVBQUUsYUFBYTtVQUNqQndELElBQUksRUFBRSxZQUFZO1VBQ2xCcEUsSUFBSSxFQUFFLE9BQU87VUFDYjhELFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUFFaEUsSUFBSSxFQUFFLFFBQVE7WUFBRXFFLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekNKLE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsSUFBSTtZQUFFTyxNQUFNLEVBQUUsQ0FBQztZQUFFckMsTUFBTSxFQUFFLEtBQUs7WUFBRWlDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDL0R0RSxLQUFLLEVBQUU7WUFBRTJFLElBQUksRUFBRTtVQUFRO1FBQ3pCLENBQUMsQ0FDRjtRQUNEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFVCxJQUFJLEVBQUUsTUFBTTtVQUNaL0QsSUFBSSxFQUFFLE1BQU07VUFDWnFFLElBQUksRUFBRSxTQUFTO1VBQ2ZJLElBQUksRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFOUQsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQytELHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFdBQVcsRUFBRSxJQUFJO1VBQ2pCQyxXQUFXLEVBQUUsVUFBVTtVQUN2QmpCLFNBQVMsRUFBRTtRQUNiLENBQUMsQ0FDRjtRQUNEdkIsVUFBVSxFQUFFLElBQUk7UUFDaEJ5QyxTQUFTLEVBQUUsSUFBSTtRQUNmdkMsY0FBYyxFQUFFLE9BQU87UUFDdkJ3QyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUU7TUFDakIsQ0FBQztNQUNEckUsSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxnQkFBZ0I7UUFDdEJjLE1BQU0sRUFBRSxTQUFTO1FBQ2pCYixNQUFNLEVBQUU7VUFDTmMsS0FBSyxFQUFFLFdBQVc7VUFDbEJrRSxTQUFTLEVBQUU7WUFBRUMsSUFBSSxFQUFFLFNBQVM7WUFBRUMsRUFBRSxFQUFFLEtBQUs7WUFBRWQsSUFBSSxFQUFFO1VBQVEsQ0FBQztVQUN4RGUsdUJBQXVCLEVBQUUsSUFBSTtVQUM3QkMsUUFBUSxFQUFFLE1BQU07VUFDaEJDLFNBQVMsRUFBRSxlQUFlO1VBQzFCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsY0FBYyxFQUFFLElBQUk7VUFDcEJDLGFBQWEsRUFBRSxDQUFDO1VBQ2hCQyxlQUFlLEVBQUUsQ0FBQztRQUNwQjtNQUNGLENBQUMsRUFDRDtRQUNFOUUsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYmIsSUFBSSxFQUFFLE9BQU87UUFDYmMsTUFBTSxFQUFFLE9BQU87UUFDZmIsTUFBTSxFQUFFO1VBQ05jLEtBQUssRUFBRSw0QkFBNEI7VUFDbkNDLElBQUksRUFBRSxDQUFDO1VBQ1BDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEI7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZFLFdBQVcsRUFBRSxJQUFJO0lBQ2pCRSxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUUvQixJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQitCLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVMsQ0FBQztRQUN4Q0MsTUFBTSxFQUFFO01BQ1YsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRXhDLEdBQUcsRUFBRSxxQ0FBcUM7RUFDMUNDLEtBQUssRUFBRSxlQUFlO0VBQ3RCQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGdCQUFnQjtNQUN2QkksSUFBSSxFQUFFLE9BQU87TUFDYkMsTUFBTSxFQUFFO1FBQ05DLE9BQU8sRUFBRSxFQUFFO1FBQ1hDLGVBQWUsRUFBRSxLQUFLO1FBQ3RCMkYscUJBQXFCLEVBQUUsS0FBSztRQUM1QnpGLElBQUksRUFBRTtVQUFFQyxXQUFXLEVBQUUsQ0FBQztVQUFFQyxTQUFTLEVBQUU7UUFBTyxDQUFDO1FBQzNDQyxTQUFTLEVBQUUsS0FBSztRQUNoQnVGLFdBQVcsRUFBRSxJQUFJO1FBQ2pCckYsU0FBUyxFQUFFO01BQ2IsQ0FBQztNQUNEQyxJQUFJLEVBQUUsQ0FDSjtRQUFFQyxFQUFFLEVBQUUsR0FBRztRQUFFQyxPQUFPLEVBQUUsSUFBSTtRQUFFYixJQUFJLEVBQUUsT0FBTztRQUFFYyxNQUFNLEVBQUUsUUFBUTtRQUFFYixNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRVcsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYmIsSUFBSSxFQUFFLE9BQU87UUFDYmMsTUFBTSxFQUFFLFFBQVE7UUFDaEJiLE1BQU0sRUFBRTtVQUNOYyxLQUFLLEVBQUUsU0FBUztVQUNoQkksV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCTixJQUFJLEVBQUUsRUFBRTtVQUNSQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaSyxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFWCxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiYixJQUFJLEVBQUUsT0FBTztRQUNiYyxNQUFNLEVBQUUsUUFBUTtRQUNoQmIsTUFBTSxFQUFFO1VBQ05jLEtBQUssRUFBRSxrQkFBa0I7VUFDekJJLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qk4sSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkssV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDLEVBQ0Q7UUFDRVgsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYmIsSUFBSSxFQUFFLE9BQU87UUFDYmMsTUFBTSxFQUFFLFFBQVE7UUFDaEJiLE1BQU0sRUFBRTtVQUNOYyxLQUFLLEVBQUUsWUFBWTtVQUNuQkksV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCTixJQUFJLEVBQUUsQ0FBQztVQUNQQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaSyxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFMUIsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUIwQixHQUFHLEVBQUU7UUFBRXhCLE1BQU0sRUFBRTtVQUFFSSxJQUFJLEVBQUU7WUFBRUMsV0FBVyxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQU87UUFBRTtNQUFFO0lBQ2pFLENBQUMsQ0FBQztJQUNGbUIsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFL0IsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0IrQixLQUFLLEVBQUUsY0FBYztRQUNyQkcsTUFBTSxFQUFFLEVBQUU7UUFDVkYsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxDQUNGO0FBQUFnRSxPQUFBLENBQUFDLE9BQUEsR0FBQXpHLFFBQUE7QUFBQTBHLE1BQUEsQ0FBQUYsT0FBQSxHQUFBQSxPQUFBLENBQUFDLE9BQUEifQ==