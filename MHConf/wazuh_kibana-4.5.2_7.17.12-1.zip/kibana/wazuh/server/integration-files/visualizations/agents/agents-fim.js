"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Agents/FIM visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Agents-FIM-Users',
  _source: {
    title: 'Most active users',
    visState: JSON.stringify({
      title: 'Most active users',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: false,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: true,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'syscheck.uname_after',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-FIM-Actions',
  _source: {
    title: 'Actions',
    visState: JSON.stringify({
      title: 'Actions',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: false,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: true,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'syscheck.event',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-FIM-Events',
  _source: {
    title: 'Events',
    visState: JSON.stringify({
      title: 'Unique events',
      type: 'line',
      params: {
        type: 'line',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          useNormalizedEsInterval: true,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'syscheck.event',
          order: 'desc',
          size: 5,
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-FIM-Files-added',
  _source: {
    title: 'Files added',
    visState: JSON.stringify({
      title: 'Files added',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'syscheck.path',
          size: 5,
          order: 'desc',
          orderBy: '1'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            type: 'phrases',
            key: 'syscheck.event',
            value: 'added, readded',
            params: ['added', 'readded'],
            negate: false,
            disabled: false,
            alias: null
          },
          query: {
            bool: {
              should: [{
                match_phrase: {
                  'syscheck.event': 'added'
                }
              }, {
                match_phrase: {
                  'syscheck.event': 'readded'
                }
              }],
              minimum_should_match: 1
            }
          },
          $state: {
            store: 'appState'
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-FIM-Files-modified',
  _source: {
    title: 'Files modified',
    visState: JSON.stringify({
      title: 'Files modified',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'syscheck.path',
          size: 5,
          order: 'desc',
          orderBy: '1'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            negate: false,
            disabled: false,
            alias: null,
            type: 'phrase',
            key: 'syscheck.event',
            value: 'modified',
            params: {
              query: 'modified',
              type: 'phrase'
            }
          },
          query: {
            match: {
              'syscheck.event': {
                query: 'modified',
                type: 'phrase'
              }
            }
          },
          $state: {
            store: 'appState'
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-FIM-Files-deleted',
  _source: {
    title: 'Files deleted',
    visState: JSON.stringify({
      title: 'Files deleted',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'syscheck.path',
          size: 5,
          order: 'desc',
          orderBy: '1'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            negate: false,
            disabled: false,
            alias: null,
            type: 'phrase',
            key: 'syscheck.event',
            value: 'deleted',
            params: {
              query: 'deleted',
              type: 'phrase'
            }
          },
          query: {
            match: {
              'syscheck.event': {
                query: 'deleted',
                type: 'phrase'
              }
            }
          },
          $state: {
            store: 'appState'
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-FIM-Alerts-summary',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'Alerts summary',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMeticsAtAllLevels: false,
        sort: {
          columnIndex: 2,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'syscheck.path',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 50,
          order: 'desc',
          orderBy: '1',
          customLabel: 'File'
        }
      }, {
        id: '5',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 10,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Description'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 2,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl9zb3VyY2UiLCJ0aXRsZSIsInZpc1N0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsInR5cGUiLCJwYXJhbXMiLCJhZGRUb29sdGlwIiwiYWRkTGVnZW5kIiwibGVnZW5kUG9zaXRpb24iLCJpc0RvbnV0IiwibGFiZWxzIiwic2hvdyIsInZhbHVlcyIsImxhc3RfbGV2ZWwiLCJ0cnVuY2F0ZSIsImFnZ3MiLCJpZCIsImVuYWJsZWQiLCJzY2hlbWEiLCJmaWVsZCIsInNpemUiLCJvcmRlciIsIm9yZGVyQnkiLCJvdGhlckJ1Y2tldCIsIm90aGVyQnVja2V0TGFiZWwiLCJtaXNzaW5nQnVja2V0IiwibWlzc2luZ0J1Y2tldExhYmVsIiwidWlTdGF0ZUpTT04iLCJkZXNjcmlwdGlvbiIsInZlcnNpb24iLCJraWJhbmFTYXZlZE9iamVjdE1ldGEiLCJzZWFyY2hTb3VyY2VKU09OIiwiaW5kZXgiLCJmaWx0ZXIiLCJxdWVyeSIsImxhbmd1YWdlIiwiX3R5cGUiLCJncmlkIiwiY2F0ZWdvcnlMaW5lcyIsImNhdGVnb3J5QXhlcyIsInBvc2l0aW9uIiwic3R5bGUiLCJzY2FsZSIsInZhbHVlQXhlcyIsIm5hbWUiLCJtb2RlIiwicm90YXRlIiwidGV4dCIsInNlcmllc1BhcmFtcyIsImRhdGEiLCJsYWJlbCIsInZhbHVlQXhpcyIsImRyYXdMaW5lc0JldHdlZW5Qb2ludHMiLCJzaG93Q2lyY2xlcyIsInRpbWVzIiwiYWRkVGltZU1hcmtlciIsImRpbWVuc2lvbnMiLCJ4IiwiYWNjZXNzb3IiLCJmb3JtYXQiLCJhZ2dUeXBlIiwieSIsInNlcmllcyIsInVzZU5vcm1hbGl6ZWRFc0ludGVydmFsIiwiaW50ZXJ2YWwiLCJkcm9wX3BhcnRpYWxzIiwibWluX2RvY19jb3VudCIsImV4dGVuZGVkX2JvdW5kcyIsIm1ldGEiLCJrZXkiLCJ2YWx1ZSIsIm5lZ2F0ZSIsImRpc2FibGVkIiwiYWxpYXMiLCJib29sIiwic2hvdWxkIiwibWF0Y2hfcGhyYXNlIiwibWluaW11bV9zaG91bGRfbWF0Y2giLCIkc3RhdGUiLCJzdG9yZSIsIm1hdGNoIiwicGVyUGFnZSIsInNob3dQYXJ0aWFsUm93cyIsInNob3dNZXRpY3NBdEFsbExldmVscyIsInNvcnQiLCJjb2x1bW5JbmRleCIsImRpcmVjdGlvbiIsInNob3dUb3RhbCIsInNob3dUb29sYmFyIiwidG90YWxGdW5jIiwiY3VzdG9tTGFiZWwiLCJ2aXMiLCJleHBvcnRzIiwiZGVmYXVsdCIsIm1vZHVsZSJdLCJzb3VyY2VzIjpbImFnZW50cy1maW0udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIGFwcCAtIE1vZHVsZSBmb3IgQWdlbnRzL0ZJTSB2aXN1YWxpemF0aW9uc1xuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IFtcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtRklNLVVzZXJzJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ01vc3QgYWN0aXZlIHVzZXJzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnTW9zdCBhY3RpdmUgdXNlcnMnLFxuICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIHZhbHVlczogdHJ1ZSwgbGFzdF9sZXZlbDogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdzeXNjaGVjay51bmFtZV9hZnRlcicsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtRklNLUFjdGlvbnMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWN0aW9ucycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0FjdGlvbnMnLFxuICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIHZhbHVlczogdHJ1ZSwgbGFzdF9sZXZlbDogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdzeXNjaGVjay5ldmVudCcsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtRklNLUV2ZW50cycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdFdmVudHMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdVbmlxdWUgZXZlbnRzJyxcbiAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnbGluZScsXG4gICAgICAgICAgZ3JpZDogeyBjYXRlZ29yeUxpbmVzOiBmYWxzZSB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgcm90YXRlOiAwLCBmaWx0ZXI6IGZhbHNlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdDb3VudCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogJ3RydWUnLFxuICAgICAgICAgICAgICB0eXBlOiAnbGluZScsXG4gICAgICAgICAgICAgIG1vZGU6ICdub3JtYWwnLFxuICAgICAgICAgICAgICBkYXRhOiB7IGxhYmVsOiAnQ291bnQnLCBpZDogJzEnIH0sXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgc2hvd0NpcmNsZXM6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgdGltZXM6IFtdLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIHg6IHtcbiAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXG4gICAgICAgICAgICAgIGZvcm1hdDoge1xuICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgIHBhcmFtczogeyBpZDogJ3N0cmluZycsIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgeTogW3sgYWNjZXNzb3I6IDIsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9XSxcbiAgICAgICAgICAgIHNlcmllczogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDEsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAndGltZXN0YW1wJyxcbiAgICAgICAgICAgICAgdXNlTm9ybWFsaXplZEVzSW50ZXJ2YWw6IHRydWUsXG4gICAgICAgICAgICAgIGludGVydmFsOiAnYXV0bycsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3N5c2NoZWNrLmV2ZW50JyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1GSU0tRmlsZXMtYWRkZWQnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnRmlsZXMgYWRkZWQnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdGaWxlcyBhZGRlZCcsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHsgZmllbGQ6ICdzeXNjaGVjay5wYXRoJywgc2l6ZTogNSwgb3JkZXI6ICdkZXNjJywgb3JkZXJCeTogJzEnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG1ldGE6IHtcbiAgICAgICAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgICAgICAgdHlwZTogJ3BocmFzZXMnLFxuICAgICAgICAgICAgICAgIGtleTogJ3N5c2NoZWNrLmV2ZW50JyxcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ2FkZGVkLCByZWFkZGVkJyxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IFsnYWRkZWQnLCAncmVhZGRlZCddLFxuICAgICAgICAgICAgICAgIG5lZ2F0ZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGFsaWFzOiBudWxsLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgIGJvb2w6IHtcbiAgICAgICAgICAgICAgICAgIHNob3VsZDogW1xuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgbWF0Y2hfcGhyYXNlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnc3lzY2hlY2suZXZlbnQnOiAnYWRkZWQnLFxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICBtYXRjaF9waHJhc2U6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdzeXNjaGVjay5ldmVudCc6ICdyZWFkZGVkJyxcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgIG1pbmltdW1fc2hvdWxkX21hdGNoOiAxLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICRzdGF0ZToge1xuICAgICAgICAgICAgICAgIHN0b3JlOiAnYXBwU3RhdGUnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUZJTS1GaWxlcy1tb2RpZmllZCcsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdGaWxlcyBtb2RpZmllZCcsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0ZpbGVzIG1vZGlmaWVkJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczogeyBmaWVsZDogJ3N5c2NoZWNrLnBhdGgnLCBzaXplOiA1LCBvcmRlcjogJ2Rlc2MnLCBvcmRlckJ5OiAnMScgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbWV0YToge1xuICAgICAgICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICAgICAgICBuZWdhdGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBhbGlhczogbnVsbCxcbiAgICAgICAgICAgICAgICB0eXBlOiAncGhyYXNlJyxcbiAgICAgICAgICAgICAgICBrZXk6ICdzeXNjaGVjay5ldmVudCcsXG4gICAgICAgICAgICAgICAgdmFsdWU6ICdtb2RpZmllZCcsXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICBxdWVyeTogJ21vZGlmaWVkJyxcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2UnLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgbWF0Y2g6IHtcbiAgICAgICAgICAgICAgICAgICdzeXNjaGVjay5ldmVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk6ICdtb2RpZmllZCcsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2UnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAkc3RhdGU6IHtcbiAgICAgICAgICAgICAgICBzdG9yZTogJ2FwcFN0YXRlJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1GSU0tRmlsZXMtZGVsZXRlZCcsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdGaWxlcyBkZWxldGVkJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnRmlsZXMgZGVsZXRlZCcsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHsgZmllbGQ6ICdzeXNjaGVjay5wYXRoJywgc2l6ZTogNSwgb3JkZXI6ICdkZXNjJywgb3JkZXJCeTogJzEnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG1ldGE6IHtcbiAgICAgICAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgICAgICAgbmVnYXRlOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBkaXNhYmxlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgYWxpYXM6IG51bGwsXG4gICAgICAgICAgICAgICAgdHlwZTogJ3BocmFzZScsXG4gICAgICAgICAgICAgICAga2V5OiAnc3lzY2hlY2suZXZlbnQnLFxuICAgICAgICAgICAgICAgIHZhbHVlOiAnZGVsZXRlZCcsXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICBxdWVyeTogJ2RlbGV0ZWQnLFxuICAgICAgICAgICAgICAgICAgdHlwZTogJ3BocmFzZScsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICBtYXRjaDoge1xuICAgICAgICAgICAgICAgICAgJ3N5c2NoZWNrLmV2ZW50Jzoge1xuICAgICAgICAgICAgICAgICAgICBxdWVyeTogJ2RlbGV0ZWQnLFxuICAgICAgICAgICAgICAgICAgICB0eXBlOiAncGhyYXNlJyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgJHN0YXRlOiB7XG4gICAgICAgICAgICAgICAgc3RvcmU6ICdhcHBTdGF0ZScsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtRklNLUFsZXJ0cy1zdW1tYXJ5JyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydHMgc3VtbWFyeScsXG4gICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDEwLFxuICAgICAgICAgIHNob3dQYXJ0aWFsUm93czogZmFsc2UsXG4gICAgICAgICAgc2hvd01ldGljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiAyLCBkaXJlY3Rpb246ICdkZXNjJyB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgc2hvd1Rvb2xiYXI6IHRydWUsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdzeXNjaGVjay5wYXRoJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDUwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnRmlsZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICc1JyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuZGVzY3JpcHRpb24nLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdEZXNjcmlwdGlvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMiwgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuXTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVZBLElBQUFBLFFBQUEsR0FXZSxDQUNiO0VBQ0VDLEdBQUcsRUFBRSw0QkFBNEI7RUFDakNDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsbUJBQW1CO0lBQzFCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsbUJBQW1CO01BQzFCSSxJQUFJLEVBQUUsS0FBSztNQUNYQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLEtBQUs7UUFDWEUsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxjQUFjLEVBQUUsT0FBTztRQUN2QkMsT0FBTyxFQUFFLElBQUk7UUFDYkMsTUFBTSxFQUFFO1VBQUVDLElBQUksRUFBRSxJQUFJO1VBQUVDLE1BQU0sRUFBRSxJQUFJO1VBQUVDLFVBQVUsRUFBRSxJQUFJO1VBQUVDLFFBQVEsRUFBRTtRQUFJO01BQ3RFLENBQUM7TUFDREMsSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxPQUFPO1FBQ2JjLE1BQU0sRUFBRSxTQUFTO1FBQ2pCYixNQUFNLEVBQUU7VUFDTmMsS0FBSyxFQUFFLHNCQUFzQjtVQUM3QkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTdCLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CNkIsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxFQUFFO1FBQ1ZDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFdEMsR0FBRyxFQUFFLDhCQUE4QjtFQUNuQ0MsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxTQUFTO0lBQ2hCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsU0FBUztNQUNoQkksSUFBSSxFQUFFLEtBQUs7TUFDWEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1hFLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsS0FBSztRQUNoQkMsY0FBYyxFQUFFLE9BQU87UUFDdkJDLE9BQU8sRUFBRSxJQUFJO1FBQ2JDLE1BQU0sRUFBRTtVQUFFQyxJQUFJLEVBQUUsSUFBSTtVQUFFQyxNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFQyxRQUFRLEVBQUU7UUFBSTtNQUN0RSxDQUFDO01BQ0RDLElBQUksRUFBRSxDQUNKO1FBQUVDLEVBQUUsRUFBRSxHQUFHO1FBQUVDLE9BQU8sRUFBRSxJQUFJO1FBQUViLElBQUksRUFBRSxPQUFPO1FBQUVjLE1BQU0sRUFBRSxRQUFRO1FBQUViLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFVyxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiYixJQUFJLEVBQUUsT0FBTztRQUNiYyxNQUFNLEVBQUUsU0FBUztRQUNqQmIsTUFBTSxFQUFFO1VBQ05jLEtBQUssRUFBRSxnQkFBZ0I7VUFDdkJDLElBQUksRUFBRSxDQUFDO1VBQ1BDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEI7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZDLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU3QixJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjZCLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxNQUFNLEVBQUUsRUFBRTtRQUNWQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRXRDLEdBQUcsRUFBRSw2QkFBNkI7RUFDbENDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsUUFBUTtJQUNmQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsZUFBZTtNQUN0QkksSUFBSSxFQUFFLE1BQU07TUFDWkMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxNQUFNO1FBQ1ppQyxJQUFJLEVBQUU7VUFBRUMsYUFBYSxFQUFFO1FBQU0sQ0FBQztRQUM5QkMsWUFBWSxFQUFFLENBQ1o7VUFDRXZCLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJaLElBQUksRUFBRSxVQUFVO1VBQ2hCb0MsUUFBUSxFQUFFLFFBQVE7VUFDbEI3QixJQUFJLEVBQUUsSUFBSTtVQUNWOEIsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUQyxLQUFLLEVBQUU7WUFBRXRDLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekJNLE1BQU0sRUFBRTtZQUFFQyxJQUFJLEVBQUUsSUFBSTtZQUFFc0IsTUFBTSxFQUFFLElBQUk7WUFBRW5CLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDbkRkLEtBQUssRUFBRSxDQUFDO1FBQ1YsQ0FBQyxDQUNGO1FBQ0QyQyxTQUFTLEVBQUUsQ0FDVDtVQUNFM0IsRUFBRSxFQUFFLGFBQWE7VUFDakI0QixJQUFJLEVBQUUsWUFBWTtVQUNsQnhDLElBQUksRUFBRSxPQUFPO1VBQ2JvQyxRQUFRLEVBQUUsTUFBTTtVQUNoQjdCLElBQUksRUFBRSxJQUFJO1VBQ1Y4QixLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RDLEtBQUssRUFBRTtZQUFFdEMsSUFBSSxFQUFFLFFBQVE7WUFBRXlDLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekNuQyxNQUFNLEVBQUU7WUFBRUMsSUFBSSxFQUFFLElBQUk7WUFBRW1DLE1BQU0sRUFBRSxDQUFDO1lBQUViLE1BQU0sRUFBRSxLQUFLO1lBQUVuQixRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQy9EZCxLQUFLLEVBQUU7WUFBRStDLElBQUksRUFBRTtVQUFRO1FBQ3pCLENBQUMsQ0FDRjtRQUNEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFckMsSUFBSSxFQUFFLE1BQU07VUFDWlAsSUFBSSxFQUFFLE1BQU07VUFDWnlDLElBQUksRUFBRSxRQUFRO1VBQ2RJLElBQUksRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFbEMsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQ21DLFNBQVMsRUFBRSxhQUFhO1VBQ3hCQyxzQkFBc0IsRUFBRSxJQUFJO1VBQzVCQyxXQUFXLEVBQUU7UUFDZixDQUFDLENBQ0Y7UUFDRC9DLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QjhDLEtBQUssRUFBRSxFQUFFO1FBQ1RDLGFBQWEsRUFBRSxLQUFLO1FBQ3BCQyxVQUFVLEVBQUU7VUFDVkMsQ0FBQyxFQUFFO1lBQ0RDLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUNOM0MsRUFBRSxFQUFFLE9BQU87Y0FDWFgsTUFBTSxFQUFFO2dCQUFFVyxFQUFFLEVBQUUsUUFBUTtnQkFBRVEsZ0JBQWdCLEVBQUUsT0FBTztnQkFBRUUsa0JBQWtCLEVBQUU7Y0FBVTtZQUNuRixDQUFDO1lBQ0RyQixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1Z1RCxPQUFPLEVBQUU7VUFDWCxDQUFDO1VBQ0RDLENBQUMsRUFBRSxDQUFDO1lBQUVILFFBQVEsRUFBRSxDQUFDO1lBQUVDLE1BQU0sRUFBRTtjQUFFM0MsRUFBRSxFQUFFO1lBQVMsQ0FBQztZQUFFWCxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQUV1RCxPQUFPLEVBQUU7VUFBUSxDQUFDLENBQUM7VUFDNUVFLE1BQU0sRUFBRSxDQUNOO1lBQ0VKLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUNOM0MsRUFBRSxFQUFFLE9BQU87Y0FDWFgsTUFBTSxFQUFFO2dCQUNOVyxFQUFFLEVBQUUsUUFBUTtnQkFDWlEsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJFLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNEckIsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWdUQsT0FBTyxFQUFFO1VBQ1gsQ0FBQztRQUVMO01BQ0YsQ0FBQztNQUNEN0MsSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxnQkFBZ0I7UUFDdEJjLE1BQU0sRUFBRSxTQUFTO1FBQ2pCYixNQUFNLEVBQUU7VUFDTmMsS0FBSyxFQUFFLFdBQVc7VUFDbEI0Qyx1QkFBdUIsRUFBRSxJQUFJO1VBQzdCQyxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGFBQWEsRUFBRSxDQUFDO1VBQ2hCQyxlQUFlLEVBQUUsQ0FBQztRQUNwQjtNQUNGLENBQUMsRUFDRDtRQUNFbkQsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYmIsSUFBSSxFQUFFLE9BQU87UUFDYmMsTUFBTSxFQUFFLE9BQU87UUFDZmIsTUFBTSxFQUFFO1VBQ05jLEtBQUssRUFBRSxnQkFBZ0I7VUFDdkJFLEtBQUssRUFBRSxNQUFNO1VBQ2JELElBQUksRUFBRSxDQUFDO1VBQ1BFLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEI7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZDLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU3QixJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjZCLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxNQUFNLEVBQUUsRUFBRTtRQUNWQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRXRDLEdBQUcsRUFBRSxrQ0FBa0M7RUFDdkNDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsYUFBYTtJQUNwQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGFBQWE7TUFDcEJJLElBQUksRUFBRSxLQUFLO01BQ1hDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYRSxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJDLE9BQU8sRUFBRTtNQUNYLENBQUM7TUFDRE0sSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxPQUFPO1FBQ2JjLE1BQU0sRUFBRSxTQUFTO1FBQ2pCYixNQUFNLEVBQUU7VUFBRWMsS0FBSyxFQUFFLGVBQWU7VUFBRUMsSUFBSSxFQUFFLENBQUM7VUFBRUMsS0FBSyxFQUFFLE1BQU07VUFBRUMsT0FBTyxFQUFFO1FBQUk7TUFDekUsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGSyxXQUFXLEVBQUUsSUFBSTtJQUNqQkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFN0IsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0I2QixLQUFLLEVBQUUsY0FBYztRQUNyQkMsTUFBTSxFQUFFLENBQ047VUFDRW1DLElBQUksRUFBRTtZQUNKcEMsS0FBSyxFQUFFLGNBQWM7WUFDckI1QixJQUFJLEVBQUUsU0FBUztZQUNmaUUsR0FBRyxFQUFFLGdCQUFnQjtZQUNyQkMsS0FBSyxFQUFFLGdCQUFnQjtZQUN2QmpFLE1BQU0sRUFBRSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUM7WUFDNUJrRSxNQUFNLEVBQUUsS0FBSztZQUNiQyxRQUFRLEVBQUUsS0FBSztZQUNmQyxLQUFLLEVBQUU7VUFDVCxDQUFDO1VBQ0R2QyxLQUFLLEVBQUU7WUFDTHdDLElBQUksRUFBRTtjQUNKQyxNQUFNLEVBQUUsQ0FDTjtnQkFDRUMsWUFBWSxFQUFFO2tCQUNaLGdCQUFnQixFQUFFO2dCQUNwQjtjQUNGLENBQUMsRUFDRDtnQkFDRUEsWUFBWSxFQUFFO2tCQUNaLGdCQUFnQixFQUFFO2dCQUNwQjtjQUNGLENBQUMsQ0FDRjtjQUNEQyxvQkFBb0IsRUFBRTtZQUN4QjtVQUNGLENBQUM7VUFDREMsTUFBTSxFQUFFO1lBQ05DLEtBQUssRUFBRTtVQUNUO1FBQ0YsQ0FBQyxDQUNGO1FBQ0Q3QyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRXRDLEdBQUcsRUFBRSxxQ0FBcUM7RUFDMUNDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsZ0JBQWdCO0lBQ3ZCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsZ0JBQWdCO01BQ3ZCSSxJQUFJLEVBQUUsS0FBSztNQUNYQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLEtBQUs7UUFDWEUsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxPQUFPLEVBQUU7TUFDWCxDQUFDO01BQ0RNLElBQUksRUFBRSxDQUNKO1FBQUVDLEVBQUUsRUFBRSxHQUFHO1FBQUVDLE9BQU8sRUFBRSxJQUFJO1FBQUViLElBQUksRUFBRSxPQUFPO1FBQUVjLE1BQU0sRUFBRSxRQUFRO1FBQUViLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFVyxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiYixJQUFJLEVBQUUsT0FBTztRQUNiYyxNQUFNLEVBQUUsU0FBUztRQUNqQmIsTUFBTSxFQUFFO1VBQUVjLEtBQUssRUFBRSxlQUFlO1VBQUVDLElBQUksRUFBRSxDQUFDO1VBQUVDLEtBQUssRUFBRSxNQUFNO1VBQUVDLE9BQU8sRUFBRTtRQUFJO01BQ3pFLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkssV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTdCLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CNkIsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxDQUNOO1VBQ0VtQyxJQUFJLEVBQUU7WUFDSnBDLEtBQUssRUFBRSxjQUFjO1lBQ3JCdUMsTUFBTSxFQUFFLEtBQUs7WUFDYkMsUUFBUSxFQUFFLEtBQUs7WUFDZkMsS0FBSyxFQUFFLElBQUk7WUFDWHJFLElBQUksRUFBRSxRQUFRO1lBQ2RpRSxHQUFHLEVBQUUsZ0JBQWdCO1lBQ3JCQyxLQUFLLEVBQUUsVUFBVTtZQUNqQmpFLE1BQU0sRUFBRTtjQUNONkIsS0FBSyxFQUFFLFVBQVU7Y0FDakI5QixJQUFJLEVBQUU7WUFDUjtVQUNGLENBQUM7VUFDRDhCLEtBQUssRUFBRTtZQUNMOEMsS0FBSyxFQUFFO2NBQ0wsZ0JBQWdCLEVBQUU7Z0JBQ2hCOUMsS0FBSyxFQUFFLFVBQVU7Z0JBQ2pCOUIsSUFBSSxFQUFFO2NBQ1I7WUFDRjtVQUNGLENBQUM7VUFDRDBFLE1BQU0sRUFBRTtZQUNOQyxLQUFLLEVBQUU7VUFDVDtRQUNGLENBQUMsQ0FDRjtRQUNEN0MsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0V0QyxHQUFHLEVBQUUsb0NBQW9DO0VBQ3pDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGVBQWU7SUFDdEJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxlQUFlO01BQ3RCSSxJQUFJLEVBQUUsS0FBSztNQUNYQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLEtBQUs7UUFDWEUsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxPQUFPLEVBQUU7TUFDWCxDQUFDO01BQ0RNLElBQUksRUFBRSxDQUNKO1FBQUVDLEVBQUUsRUFBRSxHQUFHO1FBQUVDLE9BQU8sRUFBRSxJQUFJO1FBQUViLElBQUksRUFBRSxPQUFPO1FBQUVjLE1BQU0sRUFBRSxRQUFRO1FBQUViLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFVyxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiYixJQUFJLEVBQUUsT0FBTztRQUNiYyxNQUFNLEVBQUUsU0FBUztRQUNqQmIsTUFBTSxFQUFFO1VBQUVjLEtBQUssRUFBRSxlQUFlO1VBQUVDLElBQUksRUFBRSxDQUFDO1VBQUVDLEtBQUssRUFBRSxNQUFNO1VBQUVDLE9BQU8sRUFBRTtRQUFJO01BQ3pFLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkssV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTdCLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CNkIsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxDQUNOO1VBQ0VtQyxJQUFJLEVBQUU7WUFDSnBDLEtBQUssRUFBRSxjQUFjO1lBQ3JCdUMsTUFBTSxFQUFFLEtBQUs7WUFDYkMsUUFBUSxFQUFFLEtBQUs7WUFDZkMsS0FBSyxFQUFFLElBQUk7WUFDWHJFLElBQUksRUFBRSxRQUFRO1lBQ2RpRSxHQUFHLEVBQUUsZ0JBQWdCO1lBQ3JCQyxLQUFLLEVBQUUsU0FBUztZQUNoQmpFLE1BQU0sRUFBRTtjQUNONkIsS0FBSyxFQUFFLFNBQVM7Y0FDaEI5QixJQUFJLEVBQUU7WUFDUjtVQUNGLENBQUM7VUFDRDhCLEtBQUssRUFBRTtZQUNMOEMsS0FBSyxFQUFFO2NBQ0wsZ0JBQWdCLEVBQUU7Z0JBQ2hCOUMsS0FBSyxFQUFFLFNBQVM7Z0JBQ2hCOUIsSUFBSSxFQUFFO2NBQ1I7WUFDRjtVQUNGLENBQUM7VUFDRDBFLE1BQU0sRUFBRTtZQUNOQyxLQUFLLEVBQUU7VUFDVDtRQUNGLENBQUMsQ0FDRjtRQUNEN0MsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0V0QyxHQUFHLEVBQUUscUNBQXFDO0VBQzFDc0MsS0FBSyxFQUFFLGVBQWU7RUFDdEJyQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGdCQUFnQjtNQUN2QkksSUFBSSxFQUFFLE9BQU87TUFDYkMsTUFBTSxFQUFFO1FBQ040RSxPQUFPLEVBQUUsRUFBRTtRQUNYQyxlQUFlLEVBQUUsS0FBSztRQUN0QkMscUJBQXFCLEVBQUUsS0FBSztRQUM1QkMsSUFBSSxFQUFFO1VBQUVDLFdBQVcsRUFBRSxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFPLENBQUM7UUFDM0NDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsU0FBUyxFQUFFO01BQ2IsQ0FBQztNQUNEMUUsSUFBSSxFQUFFLENBQ0o7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRWIsSUFBSSxFQUFFLE9BQU87UUFBRWMsTUFBTSxFQUFFLFFBQVE7UUFBRWIsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VXLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JiLElBQUksRUFBRSxPQUFPO1FBQ2JjLE1BQU0sRUFBRSxRQUFRO1FBQ2hCYixNQUFNLEVBQUU7VUFDTmMsS0FBSyxFQUFFLGVBQWU7VUFDdEJJLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qk4sSUFBSSxFQUFFLEVBQUU7VUFDUkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWm9FLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0UxRSxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiYixJQUFJLEVBQUUsT0FBTztRQUNiYyxNQUFNLEVBQUUsUUFBUTtRQUNoQmIsTUFBTSxFQUFFO1VBQ05jLEtBQUssRUFBRSxrQkFBa0I7VUFDekJJLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qk4sSUFBSSxFQUFFLEVBQUU7VUFDUkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWm9FLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGL0QsV0FBVyxFQUFFekIsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUJ3RixHQUFHLEVBQUU7UUFBRXRGLE1BQU0sRUFBRTtVQUFFK0UsSUFBSSxFQUFFO1lBQUVDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLFNBQVMsRUFBRTtVQUFPO1FBQUU7TUFBRTtJQUNqRSxDQUFDLENBQUM7SUFDRjFELFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTdCLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CNkIsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxFQUFFO1FBQ1ZDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsQ0FDRjtBQUFBeUQsT0FBQSxDQUFBQyxPQUFBLEdBQUFoRyxRQUFBO0FBQUFpRyxNQUFBLENBQUFGLE9BQUEsR0FBQUEsT0FBQSxDQUFBQyxPQUFBIn0=