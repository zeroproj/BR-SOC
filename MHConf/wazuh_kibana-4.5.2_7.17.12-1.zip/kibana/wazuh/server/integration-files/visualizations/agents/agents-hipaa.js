"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Agents/HIPAA visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Agents-HIPAA-Burbles',
  _source: {
    title: 'HIPAA requirements',
    visState: JSON.stringify({
      title: 'HIPAA requirements',
      type: 'line',
      params: {
        type: 'line',
        grid: {
          categoryLines: true,
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: false,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'date',
              params: {
                pattern: 'YYYY-MM-DD HH:mm'
              }
            },
            params: {
              date: true,
              interval: 'PT12H',
              format: 'YYYY-MM-DD HH:mm',
              bounds: {
                min: '2019-07-24T10:27:37.970Z',
                max: '2019-08-23T10:27:37.970Z'
              }
            },
            aggType: 'date_histogram'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          z: [{
            accessor: 3,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        },
        radiusRatio: 20
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-30d',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {},
          customLabel: 'Timestampt'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.hipaa',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'count',
        schema: 'radius',
        params: {}
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-HIPAA-Distributed-By-Level',
  _source: {
    title: 'Requirements distribution by level',
    visState: JSON.stringify({
      title: 'Requirements distribution by level',
      type: 'histogram',
      params: {
        type: 'histogram',
        grid: {
          categoryLines: true,
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {
          show: false
        },
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'number',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        },
        orderBucketsBySum: true
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.hipaa',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Level'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-HIPAA-Most-Common',
  _source: {
    title: 'Most common alerts',
    visState: JSON.stringify({
      title: 'Most common alerts',
      type: 'tagcloud',
      params: {
        scale: 'linear',
        orientation: 'single',
        minFontSize: 15,
        maxFontSize: 25,
        showLabel: true,
        metric: {
          type: 'vis_dimension',
          accessor: 1,
          format: {
            id: 'string',
            params: {}
          }
        },
        bucket: {
          type: 'vis_dimension',
          accessor: 0,
          format: {
            id: 'terms',
            params: {
              id: 'string',
              otherBucketLabel: 'Other',
              missingBucketLabel: 'Missing'
            }
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.hipaa',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-HIPAA-top-10',
  _source: {
    title: 'Top 10 requirements',
    visState: JSON.stringify({
      title: 'Top 10 requirements',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.hipaa',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-HIPAA-Requirements-Stacked-Overtime',
  _source: {
    title: 'Requirements over time',
    visState: JSON.stringify({
      title: 'Requirements over time',
      type: 'histogram',
      params: {
        type: 'histogram',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {
          show: false
        },
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'date',
              params: {
                pattern: 'YYYY-MM-DD HH:mm'
              }
            },
            params: {
              date: true,
              interval: 'PT1H',
              format: 'YYYY-MM-DD HH:mm',
              bounds: {
                min: '2019-08-19T09:19:10.911Z',
                max: '2019-08-23T09:19:10.911Z'
              }
            },
            aggType: 'date_histogram'
          },
          y: [{
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-4d',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {},
          customLabel: 'Timestampt'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.hipaa',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-HIPAA-Last-alerts',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'Alerts summary',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: 3,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum',
        dimensions: {
          metrics: [{
            accessor: 3,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }, {
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'number',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }, {
            accessor: 2,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.hipaa',
          orderBy: '1',
          order: 'desc',
          size: 20,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Rule level'
        }
      }, {
        id: '5',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          orderBy: '1',
          order: 'desc',
          size: 200,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Description'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl9zb3VyY2UiLCJ0aXRsZSIsInZpc1N0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsInR5cGUiLCJwYXJhbXMiLCJncmlkIiwiY2F0ZWdvcnlMaW5lcyIsInZhbHVlQXhpcyIsImNhdGVnb3J5QXhlcyIsImlkIiwicG9zaXRpb24iLCJzaG93Iiwic3R5bGUiLCJzY2FsZSIsImxhYmVscyIsImZpbHRlciIsInRydW5jYXRlIiwidmFsdWVBeGVzIiwibmFtZSIsIm1vZGUiLCJyb3RhdGUiLCJ0ZXh0Iiwic2VyaWVzUGFyYW1zIiwiZGF0YSIsImxhYmVsIiwiZHJhd0xpbmVzQmV0d2VlblBvaW50cyIsInNob3dDaXJjbGVzIiwiYWRkVG9vbHRpcCIsImFkZExlZ2VuZCIsImxlZ2VuZFBvc2l0aW9uIiwidGltZXMiLCJhZGRUaW1lTWFya2VyIiwiZGltZW5zaW9ucyIsIngiLCJhY2Nlc3NvciIsImZvcm1hdCIsInBhdHRlcm4iLCJkYXRlIiwiaW50ZXJ2YWwiLCJib3VuZHMiLCJtaW4iLCJtYXgiLCJhZ2dUeXBlIiwieSIsInoiLCJzZXJpZXMiLCJvdGhlckJ1Y2tldExhYmVsIiwibWlzc2luZ0J1Y2tldExhYmVsIiwicmFkaXVzUmF0aW8iLCJhZ2dzIiwiZW5hYmxlZCIsInNjaGVtYSIsImZpZWxkIiwidGltZVJhbmdlIiwiZnJvbSIsInRvIiwidXNlTm9ybWFsaXplZEVzSW50ZXJ2YWwiLCJkcm9wX3BhcnRpYWxzIiwibWluX2RvY19jb3VudCIsImV4dGVuZGVkX2JvdW5kcyIsImN1c3RvbUxhYmVsIiwib3JkZXJCeSIsIm9yZGVyIiwic2l6ZSIsIm90aGVyQnVja2V0IiwibWlzc2luZ0J1Y2tldCIsInVpU3RhdGVKU09OIiwiZGVzY3JpcHRpb24iLCJ2ZXJzaW9uIiwia2liYW5hU2F2ZWRPYmplY3RNZXRhIiwic2VhcmNoU291cmNlSlNPTiIsImluZGV4IiwicXVlcnkiLCJsYW5ndWFnZSIsIl90eXBlIiwib3JkZXJCdWNrZXRzQnlTdW0iLCJvcmllbnRhdGlvbiIsIm1pbkZvbnRTaXplIiwibWF4Rm9udFNpemUiLCJzaG93TGFiZWwiLCJtZXRyaWMiLCJidWNrZXQiLCJpc0RvbnV0IiwidmFsdWVzIiwibGFzdF9sZXZlbCIsImJ1Y2tldHMiLCJwZXJQYWdlIiwic2hvd1BhcnRpYWxSb3dzIiwic2hvd01ldHJpY3NBdEFsbExldmVscyIsInNvcnQiLCJjb2x1bW5JbmRleCIsImRpcmVjdGlvbiIsInNob3dUb3RhbCIsInNob3dUb29sYmFyIiwidG90YWxGdW5jIiwibWV0cmljcyIsInZpcyIsImV4cG9ydHMiLCJkZWZhdWx0IiwibW9kdWxlIl0sInNvdXJjZXMiOlsiYWdlbnRzLWhpcGFhLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBhcHAgLSBNb2R1bGUgZm9yIEFnZW50cy9ISVBBQSB2aXN1YWxpemF0aW9uc1xuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IFtcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtSElQQUEtQnVyYmxlcycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdISVBBQSByZXF1aXJlbWVudHMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdISVBBQSByZXF1aXJlbWVudHMnLFxuICAgICAgICB0eXBlOiAnbGluZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdsaW5lJyxcbiAgICAgICAgICBncmlkOiB7IGNhdGVnb3J5TGluZXM6IHRydWUsIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgcm90YXRlOiAwLCBmaWx0ZXI6IGZhbHNlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdDb3VudCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogJ3RydWUnLFxuICAgICAgICAgICAgICB0eXBlOiAnbGluZScsXG4gICAgICAgICAgICAgIG1vZGU6ICdub3JtYWwnLFxuICAgICAgICAgICAgICBkYXRhOiB7IGxhYmVsOiAnQ291bnQnLCBpZDogJzEnIH0sXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogZmFsc2UsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICB4OiB7XG4gICAgICAgICAgICAgIGFjY2Vzc29yOiAwLFxuICAgICAgICAgICAgICBmb3JtYXQ6IHsgaWQ6ICdkYXRlJywgcGFyYW1zOiB7IHBhdHRlcm46ICdZWVlZLU1NLUREIEhIOm1tJyB9IH0sXG4gICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgIGRhdGU6IHRydWUsXG4gICAgICAgICAgICAgICAgaW50ZXJ2YWw6ICdQVDEySCcsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiAnWVlZWS1NTS1ERCBISDptbScsXG4gICAgICAgICAgICAgICAgYm91bmRzOiB7IG1pbjogJzIwMTktMDctMjRUMTA6Mjc6MzcuOTcwWicsIG1heDogJzIwMTktMDgtMjNUMTA6Mjc6MzcuOTcwWicgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgYWdnVHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB5OiBbeyBhY2Nlc3NvcjogMiwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9LCBhZ2dUeXBlOiAnY291bnQnIH1dLFxuICAgICAgICAgICAgejogW3sgYWNjZXNzb3I6IDMsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9XSxcbiAgICAgICAgICAgIHNlcmllczogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDEsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICByYWRpdXNSYXRpbzogMjAsXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXG4gICAgICAgICAgICAgIHRpbWVSYW5nZTogeyBmcm9tOiAnbm93LTMwZCcsIHRvOiAnbm93JyB9LFxuICAgICAgICAgICAgICB1c2VOb3JtYWxpemVkRXNJbnRlcnZhbDogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJ2YWw6ICdhdXRvJyxcbiAgICAgICAgICAgICAgZHJvcF9wYXJ0aWFsczogZmFsc2UsXG4gICAgICAgICAgICAgIG1pbl9kb2NfY291bnQ6IDEsXG4gICAgICAgICAgICAgIGV4dGVuZGVkX2JvdW5kczoge30sXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnVGltZXN0YW1wdCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5oaXBhYScsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUmVxdWlyZW1lbnQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHsgaWQ6ICc0JywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAncmFkaXVzJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUhJUEFBLURpc3RyaWJ1dGVkLUJ5LUxldmVsJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1JlcXVpcmVtZW50cyBkaXN0cmlidXRpb24gYnkgbGV2ZWwnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdSZXF1aXJlbWVudHMgZGlzdHJpYnV0aW9uIGJ5IGxldmVsJyxcbiAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgIGdyaWQ6IHsgY2F0ZWdvcnlMaW5lczogdHJ1ZSwgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnIH0sXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnQ2F0ZWdvcnlBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2JvdHRvbScsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIGZpbHRlcjogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnbGVmdCcsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicsIG1vZGU6ICdub3JtYWwnIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCByb3RhdGU6IDAsIGZpbHRlcjogZmFsc2UsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ0NvdW50JyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaG93OiAndHJ1ZScsXG4gICAgICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgICAgICBtb2RlOiAnc3RhY2tlZCcsXG4gICAgICAgICAgICAgIGRhdGE6IHsgbGFiZWw6ICdDb3VudCcsIGlkOiAnMScgfSxcbiAgICAgICAgICAgICAgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IGZhbHNlIH0sXG4gICAgICAgICAgZGltZW5zaW9uczoge1xuICAgICAgICAgICAgeDoge1xuICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcbiAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7IGlkOiAnc3RyaW5nJywgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJywgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB5OiBbeyBhY2Nlc3NvcjogMiwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9LCBhZ2dUeXBlOiAnY291bnQnIH1dLFxuICAgICAgICAgICAgc2VyaWVzOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMSxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnbnVtYmVyJyxcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIG9yZGVyQnVja2V0c0J5U3VtOiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmhpcGFhJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSZXF1aXJlbWVudCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnTGV2ZWwnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUhJUEFBLU1vc3QtQ29tbW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ01vc3QgY29tbW9uIGFsZXJ0cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ01vc3QgY29tbW9uIGFsZXJ0cycsXG4gICAgICAgIHR5cGU6ICd0YWdjbG91ZCcsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHNjYWxlOiAnbGluZWFyJyxcbiAgICAgICAgICBvcmllbnRhdGlvbjogJ3NpbmdsZScsXG4gICAgICAgICAgbWluRm9udFNpemU6IDE1LFxuICAgICAgICAgIG1heEZvbnRTaXplOiAyNSxcbiAgICAgICAgICBzaG93TGFiZWw6IHRydWUsXG4gICAgICAgICAgbWV0cmljOiB7IHR5cGU6ICd2aXNfZGltZW5zaW9uJywgYWNjZXNzb3I6IDEsIGZvcm1hdDogeyBpZDogJ3N0cmluZycsIHBhcmFtczoge30gfSB9LFxuICAgICAgICAgIGJ1Y2tldDoge1xuICAgICAgICAgICAgdHlwZTogJ3Zpc19kaW1lbnNpb24nLFxuICAgICAgICAgICAgYWNjZXNzb3I6IDAsXG4gICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgIHBhcmFtczogeyBpZDogJ3N0cmluZycsIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuaGlwYWEnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1JlcXVpcmVtZW50JyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1ISVBBQS10b3AtMTAnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIDEwIHJlcXVpcmVtZW50cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1RvcCAxMCByZXF1aXJlbWVudHMnLFxuICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogdHJ1ZSxcbiAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogZmFsc2UsIHZhbHVlczogdHJ1ZSwgbGFzdF9sZXZlbDogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIG1ldHJpYzogeyBhY2Nlc3NvcjogMSwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9LCBhZ2dUeXBlOiAnY291bnQnIH0sXG4gICAgICAgICAgICBidWNrZXRzOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmhpcGFhJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUmVxdWlyZW1lbnQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUhJUEFBLVJlcXVpcmVtZW50cy1TdGFja2VkLU92ZXJ0aW1lJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1JlcXVpcmVtZW50cyBvdmVyIHRpbWUnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdSZXF1aXJlbWVudHMgb3ZlciB0aW1lJyxcbiAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgIGdyaWQ6IHsgY2F0ZWdvcnlMaW5lczogZmFsc2UgfSxcbiAgICAgICAgICBjYXRlZ29yeUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdDYXRlZ29yeUF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICdjYXRlZ29yeScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgZmlsdGVyOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJywgbW9kZTogJ25vcm1hbCcgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIHJvdGF0ZTogMCwgZmlsdGVyOiBmYWxzZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZTogeyB0ZXh0OiAnQ291bnQnIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNob3c6ICd0cnVlJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXG4gICAgICAgICAgICAgIG1vZGU6ICdzdGFja2VkJyxcbiAgICAgICAgICAgICAgZGF0YTogeyBsYWJlbDogJ0NvdW50JywgaWQ6ICcxJyB9LFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogZmFsc2UgfSxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICB4OiB7XG4gICAgICAgICAgICAgIGFjY2Vzc29yOiAwLFxuICAgICAgICAgICAgICBmb3JtYXQ6IHsgaWQ6ICdkYXRlJywgcGFyYW1zOiB7IHBhdHRlcm46ICdZWVlZLU1NLUREIEhIOm1tJyB9IH0sXG4gICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgIGRhdGU6IHRydWUsXG4gICAgICAgICAgICAgICAgaW50ZXJ2YWw6ICdQVDFIJyxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6ICdZWVlZLU1NLUREIEhIOm1tJyxcbiAgICAgICAgICAgICAgICBib3VuZHM6IHsgbWluOiAnMjAxOS0wOC0xOVQwOToxOToxMC45MTFaJywgbWF4OiAnMjAxOS0wOC0yM1QwOToxOToxMC45MTFaJyB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBhZ2dUeXBlOiAnZGF0ZV9oaXN0b2dyYW0nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHk6IFt7IGFjY2Vzc29yOiAxLCBmb3JtYXQ6IHsgaWQ6ICdudW1iZXInIH0sIHBhcmFtczoge30sIGFnZ1R5cGU6ICdjb3VudCcgfV0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAndGltZXN0YW1wJyxcbiAgICAgICAgICAgICAgdGltZVJhbmdlOiB7IGZyb206ICdub3ctNGQnLCB0bzogJ25vdycgfSxcbiAgICAgICAgICAgICAgdXNlTm9ybWFsaXplZEVzSW50ZXJ2YWw6IHRydWUsXG4gICAgICAgICAgICAgIGludGVydmFsOiAnYXV0bycsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1RpbWVzdGFtcHQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuaGlwYWEnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1JlcXVpcmVtZW50JyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1ISVBBQS1MYXN0LWFsZXJ0cycsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0FsZXJ0cyBzdW1tYXJ5JyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBwZXJQYWdlOiAxMCxcbiAgICAgICAgICBzaG93UGFydGlhbFJvd3M6IGZhbHNlLFxuICAgICAgICAgIHNob3dNZXRyaWNzQXRBbGxMZXZlbHM6IGZhbHNlLFxuICAgICAgICAgIHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0sXG4gICAgICAgICAgc2hvd1RvdGFsOiBmYWxzZSxcbiAgICAgICAgICBzaG93VG9vbGJhcjogdHJ1ZSxcbiAgICAgICAgICB0b3RhbEZ1bmM6ICdzdW0nLFxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIG1ldHJpY3M6IFt7IGFjY2Vzc29yOiAzLCBmb3JtYXQ6IHsgaWQ6ICdudW1iZXInIH0sIHBhcmFtczoge30sIGFnZ1R5cGU6ICdjb3VudCcgfV0sXG4gICAgICAgICAgICBidWNrZXRzOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDEsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ251bWJlcicsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAyLFxuICAgICAgICAgICAgICAgIGZvcm1hdDoge1xuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6ICdzdHJpbmcnLFxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5oaXBhYScsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMjAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1JlcXVpcmVtZW50JyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzQnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUnVsZSBsZXZlbCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICc1JyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuZGVzY3JpcHRpb24nLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDIwMCxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnRGVzY3JpcHRpb24nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxuICAgICAgfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbl07XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWQSxJQUFBQSxRQUFBLEdBV2UsQ0FDYjtFQUNFQyxHQUFHLEVBQUUsZ0NBQWdDO0VBQ3JDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLG9CQUFvQjtJQUMzQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLG9CQUFvQjtNQUMzQkksSUFBSSxFQUFFLE1BQU07TUFDWkMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxNQUFNO1FBQ1pFLElBQUksRUFBRTtVQUFFQyxhQUFhLEVBQUUsSUFBSTtVQUFFQyxTQUFTLEVBQUU7UUFBYyxDQUFDO1FBQ3ZEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFQyxFQUFFLEVBQUUsZ0JBQWdCO1VBQ3BCTixJQUFJLEVBQUUsVUFBVTtVQUNoQk8sUUFBUSxFQUFFLFFBQVE7VUFDbEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEMsS0FBSyxFQUFFO1lBQUVWLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekJXLE1BQU0sRUFBRTtZQUFFSCxJQUFJLEVBQUUsSUFBSTtZQUFFSSxNQUFNLEVBQUUsSUFBSTtZQUFFQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQ25EakIsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRGtCLFNBQVMsRUFBRSxDQUNUO1VBQ0VSLEVBQUUsRUFBRSxhQUFhO1VBQ2pCUyxJQUFJLEVBQUUsWUFBWTtVQUNsQmYsSUFBSSxFQUFFLE9BQU87VUFDYk8sUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEMsS0FBSyxFQUFFO1lBQUVWLElBQUksRUFBRSxRQUFRO1lBQUVnQixJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pDTCxNQUFNLEVBQUU7WUFBRUgsSUFBSSxFQUFFLElBQUk7WUFBRVMsTUFBTSxFQUFFLENBQUM7WUFBRUwsTUFBTSxFQUFFLEtBQUs7WUFBRUMsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUMvRGpCLEtBQUssRUFBRTtZQUFFc0IsSUFBSSxFQUFFO1VBQVE7UUFDekIsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0VYLElBQUksRUFBRSxNQUFNO1VBQ1pSLElBQUksRUFBRSxNQUFNO1VBQ1pnQixJQUFJLEVBQUUsUUFBUTtVQUNkSSxJQUFJLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRWYsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQ0YsU0FBUyxFQUFFLGFBQWE7VUFDeEJrQixzQkFBc0IsRUFBRSxLQUFLO1VBQzdCQyxXQUFXLEVBQUU7UUFDZixDQUFDLENBQ0Y7UUFDREMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQkMsVUFBVSxFQUFFO1VBQ1ZDLENBQUMsRUFBRTtZQUNEQyxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FBRTFCLEVBQUUsRUFBRSxNQUFNO2NBQUVMLE1BQU0sRUFBRTtnQkFBRWdDLE9BQU8sRUFBRTtjQUFtQjtZQUFFLENBQUM7WUFDL0RoQyxNQUFNLEVBQUU7Y0FDTmlDLElBQUksRUFBRSxJQUFJO2NBQ1ZDLFFBQVEsRUFBRSxPQUFPO2NBQ2pCSCxNQUFNLEVBQUUsa0JBQWtCO2NBQzFCSSxNQUFNLEVBQUU7Z0JBQUVDLEdBQUcsRUFBRSwwQkFBMEI7Z0JBQUVDLEdBQUcsRUFBRTtjQUEyQjtZQUM3RSxDQUFDO1lBQ0RDLE9BQU8sRUFBRTtVQUNYLENBQUM7VUFDREMsQ0FBQyxFQUFFLENBQUM7WUFBRVQsUUFBUSxFQUFFLENBQUM7WUFBRUMsTUFBTSxFQUFFO2NBQUUxQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVMLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRXNDLE9BQU8sRUFBRTtVQUFRLENBQUMsQ0FBQztVQUM1RUUsQ0FBQyxFQUFFLENBQUM7WUFBRVYsUUFBUSxFQUFFLENBQUM7WUFBRUMsTUFBTSxFQUFFO2NBQUUxQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVMLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRXNDLE9BQU8sRUFBRTtVQUFRLENBQUMsQ0FBQztVQUM1RUcsTUFBTSxFQUFFLENBQ047WUFDRVgsUUFBUSxFQUFFLENBQUM7WUFDWEMsTUFBTSxFQUFFO2NBQ04xQixFQUFFLEVBQUUsT0FBTztjQUNYTCxNQUFNLEVBQUU7Z0JBQ05LLEVBQUUsRUFBRSxRQUFRO2dCQUNacUMsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJDLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNEM0MsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWc0MsT0FBTyxFQUFFO1VBQ1gsQ0FBQztRQUVMLENBQUM7UUFDRE0sV0FBVyxFQUFFO01BQ2YsQ0FBQztNQUNEQyxJQUFJLEVBQUUsQ0FDSjtRQUFFeEMsRUFBRSxFQUFFLEdBQUc7UUFBRXlDLE9BQU8sRUFBRSxJQUFJO1FBQUUvQyxJQUFJLEVBQUUsT0FBTztRQUFFZ0QsTUFBTSxFQUFFLFFBQVE7UUFBRS9DLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFSyxFQUFFLEVBQUUsR0FBRztRQUNQeUMsT0FBTyxFQUFFLElBQUk7UUFDYi9DLElBQUksRUFBRSxnQkFBZ0I7UUFDdEJnRCxNQUFNLEVBQUUsU0FBUztRQUNqQi9DLE1BQU0sRUFBRTtVQUNOZ0QsS0FBSyxFQUFFLFdBQVc7VUFDbEJDLFNBQVMsRUFBRTtZQUFFQyxJQUFJLEVBQUUsU0FBUztZQUFFQyxFQUFFLEVBQUU7VUFBTSxDQUFDO1VBQ3pDQyx1QkFBdUIsRUFBRSxJQUFJO1VBQzdCbEIsUUFBUSxFQUFFLE1BQU07VUFDaEJtQixhQUFhLEVBQUUsS0FBSztVQUNwQkMsYUFBYSxFQUFFLENBQUM7VUFDaEJDLGVBQWUsRUFBRSxDQUFDLENBQUM7VUFDbkJDLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0VuRCxFQUFFLEVBQUUsR0FBRztRQUNQeUMsT0FBTyxFQUFFLElBQUk7UUFDYi9DLElBQUksRUFBRSxPQUFPO1FBQ2JnRCxNQUFNLEVBQUUsT0FBTztRQUNmL0MsTUFBTSxFQUFFO1VBQ05nRCxLQUFLLEVBQUUsWUFBWTtVQUNuQlMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsV0FBVyxFQUFFLEtBQUs7VUFDbEJsQixnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCbUIsYUFBYSxFQUFFLEtBQUs7VUFDcEJsQixrQkFBa0IsRUFBRSxTQUFTO1VBQzdCYSxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUFFbkQsRUFBRSxFQUFFLEdBQUc7UUFBRXlDLE9BQU8sRUFBRSxJQUFJO1FBQUUvQyxJQUFJLEVBQUUsT0FBTztRQUFFZ0QsTUFBTSxFQUFFLFFBQVE7UUFBRS9DLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQztJQUUzRSxDQUFDLENBQUM7SUFDRjhELFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUVyRSxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQnFFLEtBQUssRUFBRSxjQUFjO1FBQ3JCeEQsTUFBTSxFQUFFLEVBQUU7UUFDVnlELEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFN0UsR0FBRyxFQUFFLDZDQUE2QztFQUNsREMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxvQ0FBb0M7SUFDM0NDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxvQ0FBb0M7TUFDM0NJLElBQUksRUFBRSxXQUFXO01BQ2pCQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLFdBQVc7UUFDakJFLElBQUksRUFBRTtVQUFFQyxhQUFhLEVBQUUsSUFBSTtVQUFFQyxTQUFTLEVBQUU7UUFBYyxDQUFDO1FBQ3ZEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFQyxFQUFFLEVBQUUsZ0JBQWdCO1VBQ3BCTixJQUFJLEVBQUUsVUFBVTtVQUNoQk8sUUFBUSxFQUFFLFFBQVE7VUFDbEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEMsS0FBSyxFQUFFO1lBQUVWLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekJXLE1BQU0sRUFBRTtZQUFFSCxJQUFJLEVBQUUsSUFBSTtZQUFFSSxNQUFNLEVBQUUsSUFBSTtZQUFFQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQ25EakIsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRGtCLFNBQVMsRUFBRSxDQUNUO1VBQ0VSLEVBQUUsRUFBRSxhQUFhO1VBQ2pCUyxJQUFJLEVBQUUsWUFBWTtVQUNsQmYsSUFBSSxFQUFFLE9BQU87VUFDYk8sUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEMsS0FBSyxFQUFFO1lBQUVWLElBQUksRUFBRSxRQUFRO1lBQUVnQixJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pDTCxNQUFNLEVBQUU7WUFBRUgsSUFBSSxFQUFFLElBQUk7WUFBRVMsTUFBTSxFQUFFLENBQUM7WUFBRUwsTUFBTSxFQUFFLEtBQUs7WUFBRUMsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUMvRGpCLEtBQUssRUFBRTtZQUFFc0IsSUFBSSxFQUFFO1VBQVE7UUFDekIsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0VYLElBQUksRUFBRSxNQUFNO1VBQ1pSLElBQUksRUFBRSxXQUFXO1VBQ2pCZ0IsSUFBSSxFQUFFLFNBQVM7VUFDZkksSUFBSSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVmLEVBQUUsRUFBRTtVQUFJLENBQUM7VUFDakNGLFNBQVMsRUFBRSxhQUFhO1VBQ3hCa0Isc0JBQXNCLEVBQUUsSUFBSTtVQUM1QkMsV0FBVyxFQUFFO1FBQ2YsQ0FBQyxDQUNGO1FBQ0RDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QkMsS0FBSyxFQUFFLEVBQUU7UUFDVEMsYUFBYSxFQUFFLEtBQUs7UUFDcEJqQixNQUFNLEVBQUU7VUFBRUgsSUFBSSxFQUFFO1FBQU0sQ0FBQztRQUN2QnFCLFVBQVUsRUFBRTtVQUNWQyxDQUFDLEVBQUU7WUFDREMsUUFBUSxFQUFFLENBQUM7WUFDWEMsTUFBTSxFQUFFO2NBQ04xQixFQUFFLEVBQUUsT0FBTztjQUNYTCxNQUFNLEVBQUU7Z0JBQUVLLEVBQUUsRUFBRSxRQUFRO2dCQUFFcUMsZ0JBQWdCLEVBQUUsT0FBTztnQkFBRUMsa0JBQWtCLEVBQUU7Y0FBVTtZQUNuRixDQUFDO1lBQ0QzQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZzQyxPQUFPLEVBQUU7VUFDWCxDQUFDO1VBQ0RDLENBQUMsRUFBRSxDQUFDO1lBQUVULFFBQVEsRUFBRSxDQUFDO1lBQUVDLE1BQU0sRUFBRTtjQUFFMUIsRUFBRSxFQUFFO1lBQVMsQ0FBQztZQUFFTCxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQUVzQyxPQUFPLEVBQUU7VUFBUSxDQUFDLENBQUM7VUFDNUVHLE1BQU0sRUFBRSxDQUNOO1lBQ0VYLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUNOMUIsRUFBRSxFQUFFLE9BQU87Y0FDWEwsTUFBTSxFQUFFO2dCQUNOSyxFQUFFLEVBQUUsUUFBUTtnQkFDWnFDLGdCQUFnQixFQUFFLE9BQU87Z0JBQ3pCQyxrQkFBa0IsRUFBRTtjQUN0QjtZQUNGLENBQUM7WUFDRDNDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDVnNDLE9BQU8sRUFBRTtVQUNYLENBQUM7UUFFTCxDQUFDO1FBQ0RpQyxpQkFBaUIsRUFBRTtNQUNyQixDQUFDO01BQ0QxQixJQUFJLEVBQUUsQ0FDSjtRQUFFeEMsRUFBRSxFQUFFLEdBQUc7UUFBRXlDLE9BQU8sRUFBRSxJQUFJO1FBQUUvQyxJQUFJLEVBQUUsT0FBTztRQUFFZ0QsTUFBTSxFQUFFLFFBQVE7UUFBRS9DLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFSyxFQUFFLEVBQUUsR0FBRztRQUNQeUMsT0FBTyxFQUFFLElBQUk7UUFDYi9DLElBQUksRUFBRSxPQUFPO1FBQ2JnRCxNQUFNLEVBQUUsU0FBUztRQUNqQi9DLE1BQU0sRUFBRTtVQUNOZ0QsS0FBSyxFQUFFLFlBQVk7VUFDbkJTLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxDQUFDO1VBQ1BDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCbEIsZ0JBQWdCLEVBQUUsT0FBTztVQUN6Qm1CLGFBQWEsRUFBRSxLQUFLO1VBQ3BCbEIsa0JBQWtCLEVBQUUsU0FBUztVQUM3QmEsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDLEVBQ0Q7UUFDRW5ELEVBQUUsRUFBRSxHQUFHO1FBQ1B5QyxPQUFPLEVBQUUsSUFBSTtRQUNiL0MsSUFBSSxFQUFFLE9BQU87UUFDYmdELE1BQU0sRUFBRSxPQUFPO1FBQ2YvQyxNQUFNLEVBQUU7VUFDTmdELEtBQUssRUFBRSxZQUFZO1VBQ25CUyxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQmxCLGdCQUFnQixFQUFFLE9BQU87VUFDekJtQixhQUFhLEVBQUUsS0FBSztVQUNwQmxCLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JhLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGTSxXQUFXLEVBQUUsSUFBSTtJQUNqQkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFckUsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0JxRSxLQUFLLEVBQUUsY0FBYztRQUNyQnhELE1BQU0sRUFBRSxFQUFFO1FBQ1Z5RCxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRTdFLEdBQUcsRUFBRSxvQ0FBb0M7RUFDekNDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsb0JBQW9CO0lBQzNCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsb0JBQW9CO01BQzNCSSxJQUFJLEVBQUUsVUFBVTtNQUNoQkMsTUFBTSxFQUFFO1FBQ05TLEtBQUssRUFBRSxRQUFRO1FBQ2YrRCxXQUFXLEVBQUUsUUFBUTtRQUNyQkMsV0FBVyxFQUFFLEVBQUU7UUFDZkMsV0FBVyxFQUFFLEVBQUU7UUFDZkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsTUFBTSxFQUFFO1VBQUU3RSxJQUFJLEVBQUUsZUFBZTtVQUFFK0IsUUFBUSxFQUFFLENBQUM7VUFBRUMsTUFBTSxFQUFFO1lBQUUxQixFQUFFLEVBQUUsUUFBUTtZQUFFTCxNQUFNLEVBQUUsQ0FBQztVQUFFO1FBQUUsQ0FBQztRQUNwRjZFLE1BQU0sRUFBRTtVQUNOOUUsSUFBSSxFQUFFLGVBQWU7VUFDckIrQixRQUFRLEVBQUUsQ0FBQztVQUNYQyxNQUFNLEVBQUU7WUFDTjFCLEVBQUUsRUFBRSxPQUFPO1lBQ1hMLE1BQU0sRUFBRTtjQUFFSyxFQUFFLEVBQUUsUUFBUTtjQUFFcUMsZ0JBQWdCLEVBQUUsT0FBTztjQUFFQyxrQkFBa0IsRUFBRTtZQUFVO1VBQ25GO1FBQ0Y7TUFDRixDQUFDO01BQ0RFLElBQUksRUFBRSxDQUNKO1FBQUV4QyxFQUFFLEVBQUUsR0FBRztRQUFFeUMsT0FBTyxFQUFFLElBQUk7UUFBRS9DLElBQUksRUFBRSxPQUFPO1FBQUVnRCxNQUFNLEVBQUUsUUFBUTtRQUFFL0MsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VLLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QyxPQUFPLEVBQUUsSUFBSTtRQUNiL0MsSUFBSSxFQUFFLE9BQU87UUFDYmdELE1BQU0sRUFBRSxTQUFTO1FBQ2pCL0MsTUFBTSxFQUFFO1VBQ05nRCxLQUFLLEVBQUUsWUFBWTtVQUNuQlMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsV0FBVyxFQUFFLEtBQUs7VUFDbEJsQixnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCbUIsYUFBYSxFQUFFLEtBQUs7VUFDcEJsQixrQkFBa0IsRUFBRSxTQUFTO1VBQzdCYSxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRk0sV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXJFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CcUUsS0FBSyxFQUFFLGNBQWM7UUFDckJ4RCxNQUFNLEVBQUUsRUFBRTtRQUNWeUQsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0U3RSxHQUFHLEVBQUUsK0JBQStCO0VBQ3BDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHFCQUFxQjtJQUM1QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHFCQUFxQjtNQUM1QkksSUFBSSxFQUFFLEtBQUs7TUFDWEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1h3QixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJxRCxPQUFPLEVBQUUsSUFBSTtRQUNicEUsTUFBTSxFQUFFO1VBQUVILElBQUksRUFBRSxLQUFLO1VBQUV3RSxNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFcEUsUUFBUSxFQUFFO1FBQUksQ0FBQztRQUN0RWdCLFVBQVUsRUFBRTtVQUNWZ0QsTUFBTSxFQUFFO1lBQUU5QyxRQUFRLEVBQUUsQ0FBQztZQUFFQyxNQUFNLEVBQUU7Y0FBRTFCLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFBRUwsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUFFc0MsT0FBTyxFQUFFO1VBQVEsQ0FBQztVQUMvRTJDLE9BQU8sRUFBRSxDQUNQO1lBQ0VuRCxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FDTjFCLEVBQUUsRUFBRSxPQUFPO2NBQ1hMLE1BQU0sRUFBRTtnQkFDTkssRUFBRSxFQUFFLFFBQVE7Z0JBQ1pxQyxnQkFBZ0IsRUFBRSxPQUFPO2dCQUN6QkMsa0JBQWtCLEVBQUU7Y0FDdEI7WUFDRixDQUFDO1lBQ0QzQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZzQyxPQUFPLEVBQUU7VUFDWCxDQUFDO1FBRUw7TUFDRixDQUFDO01BQ0RPLElBQUksRUFBRSxDQUNKO1FBQUV4QyxFQUFFLEVBQUUsR0FBRztRQUFFeUMsT0FBTyxFQUFFLElBQUk7UUFBRS9DLElBQUksRUFBRSxPQUFPO1FBQUVnRCxNQUFNLEVBQUUsUUFBUTtRQUFFL0MsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VLLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QyxPQUFPLEVBQUUsSUFBSTtRQUNiL0MsSUFBSSxFQUFFLE9BQU87UUFDYmdELE1BQU0sRUFBRSxTQUFTO1FBQ2pCL0MsTUFBTSxFQUFFO1VBQ05nRCxLQUFLLEVBQUUsWUFBWTtVQUNuQlMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEVBQUU7VUFDUkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJsQixnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCbUIsYUFBYSxFQUFFLEtBQUs7VUFDcEJsQixrQkFBa0IsRUFBRSxTQUFTO1VBQzdCYSxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRk0sV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXJFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CcUUsS0FBSyxFQUFFLGNBQWM7UUFDckJ4RCxNQUFNLEVBQUUsRUFBRTtRQUNWeUQsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0U3RSxHQUFHLEVBQUUsc0RBQXNEO0VBQzNEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHdCQUF3QjtJQUMvQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHdCQUF3QjtNQUMvQkksSUFBSSxFQUFFLFdBQVc7TUFDakJDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsV0FBVztRQUNqQkUsSUFBSSxFQUFFO1VBQUVDLGFBQWEsRUFBRTtRQUFNLENBQUM7UUFDOUJFLFlBQVksRUFBRSxDQUNaO1VBQ0VDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJOLElBQUksRUFBRSxVQUFVO1VBQ2hCTyxRQUFRLEVBQUUsUUFBUTtVQUNsQkMsSUFBSSxFQUFFLElBQUk7VUFDVkMsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUQyxLQUFLLEVBQUU7WUFBRVYsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6QlcsTUFBTSxFQUFFO1lBQUVILElBQUksRUFBRSxJQUFJO1lBQUVJLE1BQU0sRUFBRSxJQUFJO1lBQUVDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDbkRqQixLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEa0IsU0FBUyxFQUFFLENBQ1Q7VUFDRVIsRUFBRSxFQUFFLGFBQWE7VUFDakJTLElBQUksRUFBRSxZQUFZO1VBQ2xCZixJQUFJLEVBQUUsT0FBTztVQUNiTyxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsSUFBSSxFQUFFLElBQUk7VUFDVkMsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUQyxLQUFLLEVBQUU7WUFBRVYsSUFBSSxFQUFFLFFBQVE7WUFBRWdCLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekNMLE1BQU0sRUFBRTtZQUFFSCxJQUFJLEVBQUUsSUFBSTtZQUFFUyxNQUFNLEVBQUUsQ0FBQztZQUFFTCxNQUFNLEVBQUUsS0FBSztZQUFFQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQy9EakIsS0FBSyxFQUFFO1lBQUVzQixJQUFJLEVBQUU7VUFBUTtRQUN6QixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVgsSUFBSSxFQUFFLE1BQU07VUFDWlIsSUFBSSxFQUFFLFdBQVc7VUFDakJnQixJQUFJLEVBQUUsU0FBUztVQUNmSSxJQUFJLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRWYsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQ0YsU0FBUyxFQUFFLGFBQWE7VUFDeEJrQixzQkFBc0IsRUFBRSxJQUFJO1VBQzVCQyxXQUFXLEVBQUU7UUFDZixDQUFDLENBQ0Y7UUFDREMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQmpCLE1BQU0sRUFBRTtVQUFFSCxJQUFJLEVBQUU7UUFBTSxDQUFDO1FBQ3ZCcUIsVUFBVSxFQUFFO1VBQ1ZDLENBQUMsRUFBRTtZQUNEQyxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FBRTFCLEVBQUUsRUFBRSxNQUFNO2NBQUVMLE1BQU0sRUFBRTtnQkFBRWdDLE9BQU8sRUFBRTtjQUFtQjtZQUFFLENBQUM7WUFDL0RoQyxNQUFNLEVBQUU7Y0FDTmlDLElBQUksRUFBRSxJQUFJO2NBQ1ZDLFFBQVEsRUFBRSxNQUFNO2NBQ2hCSCxNQUFNLEVBQUUsa0JBQWtCO2NBQzFCSSxNQUFNLEVBQUU7Z0JBQUVDLEdBQUcsRUFBRSwwQkFBMEI7Z0JBQUVDLEdBQUcsRUFBRTtjQUEyQjtZQUM3RSxDQUFDO1lBQ0RDLE9BQU8sRUFBRTtVQUNYLENBQUM7VUFDREMsQ0FBQyxFQUFFLENBQUM7WUFBRVQsUUFBUSxFQUFFLENBQUM7WUFBRUMsTUFBTSxFQUFFO2NBQUUxQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVMLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRXNDLE9BQU8sRUFBRTtVQUFRLENBQUM7UUFDN0U7TUFDRixDQUFDO01BQ0RPLElBQUksRUFBRSxDQUNKO1FBQUV4QyxFQUFFLEVBQUUsR0FBRztRQUFFeUMsT0FBTyxFQUFFLElBQUk7UUFBRS9DLElBQUksRUFBRSxPQUFPO1FBQUVnRCxNQUFNLEVBQUUsUUFBUTtRQUFFL0MsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VLLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QyxPQUFPLEVBQUUsSUFBSTtRQUNiL0MsSUFBSSxFQUFFLGdCQUFnQjtRQUN0QmdELE1BQU0sRUFBRSxTQUFTO1FBQ2pCL0MsTUFBTSxFQUFFO1VBQ05nRCxLQUFLLEVBQUUsV0FBVztVQUNsQkMsU0FBUyxFQUFFO1lBQUVDLElBQUksRUFBRSxRQUFRO1lBQUVDLEVBQUUsRUFBRTtVQUFNLENBQUM7VUFDeENDLHVCQUF1QixFQUFFLElBQUk7VUFDN0JsQixRQUFRLEVBQUUsTUFBTTtVQUNoQm1CLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxhQUFhLEVBQUUsQ0FBQztVQUNoQkMsZUFBZSxFQUFFLENBQUMsQ0FBQztVQUNuQkMsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDLEVBQ0Q7UUFDRW5ELEVBQUUsRUFBRSxHQUFHO1FBQ1B5QyxPQUFPLEVBQUUsSUFBSTtRQUNiL0MsSUFBSSxFQUFFLE9BQU87UUFDYmdELE1BQU0sRUFBRSxPQUFPO1FBQ2YvQyxNQUFNLEVBQUU7VUFDTmdELEtBQUssRUFBRSxZQUFZO1VBQ25CUyxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQmxCLGdCQUFnQixFQUFFLE9BQU87VUFDekJtQixhQUFhLEVBQUUsS0FBSztVQUNwQmxCLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JhLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGTSxXQUFXLEVBQUUsSUFBSTtJQUNqQkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFckUsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0JxRSxLQUFLLEVBQUUsY0FBYztRQUNyQnhELE1BQU0sRUFBRSxFQUFFO1FBQ1Z5RCxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRTdFLEdBQUcsRUFBRSxvQ0FBb0M7RUFDekM2RSxLQUFLLEVBQUUsZUFBZTtFQUN0QjVFLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsZ0JBQWdCO0lBQ3ZCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsZ0JBQWdCO01BQ3ZCSSxJQUFJLEVBQUUsT0FBTztNQUNiQyxNQUFNLEVBQUU7UUFDTmtGLE9BQU8sRUFBRSxFQUFFO1FBQ1hDLGVBQWUsRUFBRSxLQUFLO1FBQ3RCQyxzQkFBc0IsRUFBRSxLQUFLO1FBQzdCQyxJQUFJLEVBQUU7VUFBRUMsV0FBVyxFQUFFLENBQUM7VUFBRUMsU0FBUyxFQUFFO1FBQU8sQ0FBQztRQUMzQ0MsU0FBUyxFQUFFLEtBQUs7UUFDaEJDLFdBQVcsRUFBRSxJQUFJO1FBQ2pCQyxTQUFTLEVBQUUsS0FBSztRQUNoQjlELFVBQVUsRUFBRTtVQUNWK0QsT0FBTyxFQUFFLENBQUM7WUFBRTdELFFBQVEsRUFBRSxDQUFDO1lBQUVDLE1BQU0sRUFBRTtjQUFFMUIsRUFBRSxFQUFFO1lBQVMsQ0FBQztZQUFFTCxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQUVzQyxPQUFPLEVBQUU7VUFBUSxDQUFDLENBQUM7VUFDbEYyQyxPQUFPLEVBQUUsQ0FDUDtZQUNFbkQsUUFBUSxFQUFFLENBQUM7WUFDWEMsTUFBTSxFQUFFO2NBQ04xQixFQUFFLEVBQUUsT0FBTztjQUNYTCxNQUFNLEVBQUU7Z0JBQ05LLEVBQUUsRUFBRSxRQUFRO2dCQUNacUMsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJDLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNEM0MsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWc0MsT0FBTyxFQUFFO1VBQ1gsQ0FBQyxFQUNEO1lBQ0VSLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUNOMUIsRUFBRSxFQUFFLE9BQU87Y0FDWEwsTUFBTSxFQUFFO2dCQUNOSyxFQUFFLEVBQUUsUUFBUTtnQkFDWnFDLGdCQUFnQixFQUFFLE9BQU87Z0JBQ3pCQyxrQkFBa0IsRUFBRTtjQUN0QjtZQUNGLENBQUM7WUFDRDNDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDVnNDLE9BQU8sRUFBRTtVQUNYLENBQUMsRUFDRDtZQUNFUixRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FDTjFCLEVBQUUsRUFBRSxPQUFPO2NBQ1hMLE1BQU0sRUFBRTtnQkFDTkssRUFBRSxFQUFFLFFBQVE7Z0JBQ1pxQyxnQkFBZ0IsRUFBRSxPQUFPO2dCQUN6QkMsa0JBQWtCLEVBQUU7Y0FDdEI7WUFDRixDQUFDO1lBQ0QzQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZzQyxPQUFPLEVBQUU7VUFDWCxDQUFDO1FBRUw7TUFDRixDQUFDO01BQ0RPLElBQUksRUFBRSxDQUNKO1FBQUV4QyxFQUFFLEVBQUUsR0FBRztRQUFFeUMsT0FBTyxFQUFFLElBQUk7UUFBRS9DLElBQUksRUFBRSxPQUFPO1FBQUVnRCxNQUFNLEVBQUUsUUFBUTtRQUFFL0MsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VLLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QyxPQUFPLEVBQUUsSUFBSTtRQUNiL0MsSUFBSSxFQUFFLE9BQU87UUFDYmdELE1BQU0sRUFBRSxRQUFRO1FBQ2hCL0MsTUFBTSxFQUFFO1VBQ05nRCxLQUFLLEVBQUUsWUFBWTtVQUNuQlMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEVBQUU7VUFDUkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJsQixnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCbUIsYUFBYSxFQUFFLEtBQUs7VUFDcEJsQixrQkFBa0IsRUFBRSxTQUFTO1VBQzdCYSxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFbkQsRUFBRSxFQUFFLEdBQUc7UUFDUHlDLE9BQU8sRUFBRSxJQUFJO1FBQ2IvQyxJQUFJLEVBQUUsT0FBTztRQUNiZ0QsTUFBTSxFQUFFLFFBQVE7UUFDaEIvQyxNQUFNLEVBQUU7VUFDTmdELEtBQUssRUFBRSxZQUFZO1VBQ25CUyxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQmxCLGdCQUFnQixFQUFFLE9BQU87VUFDekJtQixhQUFhLEVBQUUsS0FBSztVQUNwQmxCLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JhLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0VuRCxFQUFFLEVBQUUsR0FBRztRQUNQeUMsT0FBTyxFQUFFLElBQUk7UUFDYi9DLElBQUksRUFBRSxPQUFPO1FBQ2JnRCxNQUFNLEVBQUUsUUFBUTtRQUNoQi9DLE1BQU0sRUFBRTtVQUNOZ0QsS0FBSyxFQUFFLGtCQUFrQjtVQUN6QlMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEdBQUc7VUFDVEMsV0FBVyxFQUFFLEtBQUs7VUFDbEJsQixnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCbUIsYUFBYSxFQUFFLEtBQUs7VUFDcEJsQixrQkFBa0IsRUFBRSxTQUFTO1VBQzdCYSxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRk0sV0FBVyxFQUFFakUsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUI4RixHQUFHLEVBQUU7UUFBRTVGLE1BQU0sRUFBRTtVQUFFcUYsSUFBSSxFQUFFO1lBQUVDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLFNBQVMsRUFBRTtVQUFPO1FBQUU7TUFBRTtJQUNqRSxDQUFDLENBQUM7SUFDRnhCLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXJFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CcUUsS0FBSyxFQUFFLGNBQWM7UUFDckJ4RCxNQUFNLEVBQUUsRUFBRTtRQUNWeUQsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxDQUNGO0FBQUF3QixPQUFBLENBQUFDLE9BQUEsR0FBQXRHLFFBQUE7QUFBQXVHLE1BQUEsQ0FBQUYsT0FBQSxHQUFBQSxPQUFBLENBQUFDLE9BQUEifQ==