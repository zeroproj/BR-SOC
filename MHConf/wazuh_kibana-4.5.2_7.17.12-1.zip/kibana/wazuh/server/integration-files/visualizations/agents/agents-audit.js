"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Agents/Audit visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Agents-Audit-New-files-metric',
  _source: {
    title: 'New files metric',
    visState: JSON.stringify({
      title: 'New files metric',
      type: 'metric',
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'gauge',
        gauge: {
          verticalSplit: false,
          autoExtend: false,
          percentageMode: false,
          gaugeType: 'Metric',
          gaugeStyle: 'Full',
          backStyle: 'Full',
          orientation: 'vertical',
          colorSchema: 'Green to Red',
          gaugeColorMode: 'None',
          useRange: false,
          colorsRange: [{
            from: 0,
            to: 100
          }],
          invertColors: false,
          labels: {
            show: true,
            color: 'black'
          },
          scale: {
            show: false,
            labels: false,
            color: '#333',
            width: 2
          },
          type: 'simple',
          style: {
            fontSize: 20,
            bgColor: false,
            labelColor: false,
            subText: ''
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'New files'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            negate: false,
            disabled: false,
            alias: null,
            type: 'phrase',
            key: 'rule.id',
            value: '80790',
            params: {
              query: '80790',
              type: 'phrase'
            }
          },
          query: {
            match: {
              'rule.id': {
                query: '80790',
                type: 'phrase'
              }
            }
          },
          $state: {
            store: 'appState'
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-Audit-Read-files-metric',
  _source: {
    title: 'Read files metric',
    visState: JSON.stringify({
      title: 'Read files metric',
      type: 'metric',
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'gauge',
        gauge: {
          verticalSplit: false,
          autoExtend: false,
          percentageMode: false,
          gaugeType: 'Metric',
          gaugeStyle: 'Full',
          backStyle: 'Full',
          orientation: 'vertical',
          colorSchema: 'Green to Red',
          gaugeColorMode: 'None',
          useRange: false,
          colorsRange: [{
            from: 0,
            to: 100
          }],
          invertColors: false,
          labels: {
            show: true,
            color: 'black'
          },
          scale: {
            show: false,
            labels: false,
            color: '#333',
            width: 2
          },
          type: 'simple',
          style: {
            fontSize: 20,
            bgColor: false,
            labelColor: false,
            subText: ''
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'Read files'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            negate: false,
            disabled: false,
            alias: null,
            type: 'phrase',
            key: 'rule.id',
            value: '80784',
            params: {
              query: '80784',
              type: 'phrase'
            }
          },
          query: {
            match: {
              'rule.id': {
                query: '80784',
                type: 'phrase'
              }
            }
          },
          $state: {
            store: 'appState'
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-Audit-Modified-files-metric',
  _source: {
    title: 'Modified files metric',
    visState: JSON.stringify({
      title: 'Modified files metric',
      type: 'metric',
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'gauge',
        gauge: {
          verticalSplit: false,
          autoExtend: false,
          percentageMode: false,
          gaugeType: 'Metric',
          gaugeStyle: 'Full',
          backStyle: 'Full',
          orientation: 'vertical',
          colorSchema: 'Green to Red',
          gaugeColorMode: 'None',
          useRange: false,
          colorsRange: [{
            from: 0,
            to: 100
          }],
          invertColors: false,
          labels: {
            show: true,
            color: 'black'
          },
          scale: {
            show: false,
            labels: false,
            color: '#333',
            width: 2
          },
          type: 'simple',
          style: {
            fontSize: 20,
            bgColor: false,
            labelColor: false,
            subText: ''
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'Modified files'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            type: 'phrases',
            key: 'rule.id',
            value: '80781, 80787',
            params: ['80781', '80787'],
            negate: false,
            disabled: false,
            alias: null
          },
          query: {
            bool: {
              should: [{
                match_phrase: {
                  'rule.id': '80781'
                }
              }, {
                match_phrase: {
                  'rule.id': '80787'
                }
              }],
              minimum_should_match: 1
            }
          },
          $state: {
            store: 'appState'
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-Audit-Removed-files-metric',
  _source: {
    title: 'Removed files metric',
    visState: JSON.stringify({
      title: 'Removed files metric',
      type: 'metric',
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'gauge',
        gauge: {
          verticalSplit: false,
          autoExtend: false,
          percentageMode: false,
          gaugeType: 'Metric',
          gaugeStyle: 'Full',
          backStyle: 'Full',
          orientation: 'vertical',
          colorSchema: 'Green to Red',
          gaugeColorMode: 'None',
          useRange: false,
          colorsRange: [{
            from: 0,
            to: 100
          }],
          invertColors: false,
          labels: {
            show: true,
            color: 'black'
          },
          scale: {
            show: false,
            labels: false,
            color: '#333',
            width: 2
          },
          type: 'simple',
          style: {
            fontSize: 20,
            bgColor: false,
            labelColor: false,
            subText: ''
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'Removed files'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            negate: false,
            disabled: false,
            alias: null,
            type: 'phrase',
            key: 'rule.id',
            value: '80791',
            params: {
              query: '80791',
              type: 'phrase'
            }
          },
          query: {
            match: {
              'rule.id': {
                query: '80791',
                type: 'phrase'
              }
            }
          },
          $state: {
            store: 'appState'
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-Audit-Groups',
  _source: {
    title: 'Groups',
    visState: JSON.stringify({
      title: 'Groups',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.groups',
          size: 5,
          order: 'desc',
          orderBy: '1'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-Audit-Files',
  _source: {
    title: 'Files',
    visState: JSON.stringify({
      title: 'Files',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.audit.file.name',
          size: 5,
          order: 'desc',
          orderBy: '1'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-Audit-Alerts-over-time',
  _source: {
    title: 'Alerts over time',
    visState: JSON.stringify({
      title: 'Alerts over time',
      type: 'area',
      params: {
        type: 'area',
        grid: {
          categoryLines: true,
          style: {
            color: '#eee'
          },
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'area',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'cardinal',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.description',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-1h',
            to: 'now',
            mode: 'quick'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          time_zone: 'Europe/Berlin',
          drop_partials: false,
          customInterval: '2h',
          min_doc_count: 1,
          extended_bounds: {}
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-Audit-Commands',
  _source: {
    title: 'Commands',
    visState: JSON.stringify({
      title: 'Commands',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.audit.command',
          size: 5,
          order: 'desc',
          orderBy: '1'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Agents-Audit-Last-alerts',
  _type: 'visualization',
  _source: {
    title: 'Last alerts',
    visState: JSON.stringify({
      title: 'Last alerts',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMeticsAtAllLevels: false,
        sort: {
          columnIndex: 3,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 50,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Event'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'data.audit.exe',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 10,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Command'
        }
      }, {
        id: '5',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'data.audit.type',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 5,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Type'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl9zb3VyY2UiLCJ0aXRsZSIsInZpc1N0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsInR5cGUiLCJwYXJhbXMiLCJhZGRUb29sdGlwIiwiYWRkTGVnZW5kIiwiZ2F1Z2UiLCJ2ZXJ0aWNhbFNwbGl0IiwiYXV0b0V4dGVuZCIsInBlcmNlbnRhZ2VNb2RlIiwiZ2F1Z2VUeXBlIiwiZ2F1Z2VTdHlsZSIsImJhY2tTdHlsZSIsIm9yaWVudGF0aW9uIiwiY29sb3JTY2hlbWEiLCJnYXVnZUNvbG9yTW9kZSIsInVzZVJhbmdlIiwiY29sb3JzUmFuZ2UiLCJmcm9tIiwidG8iLCJpbnZlcnRDb2xvcnMiLCJsYWJlbHMiLCJzaG93IiwiY29sb3IiLCJzY2FsZSIsIndpZHRoIiwic3R5bGUiLCJmb250U2l6ZSIsImJnQ29sb3IiLCJsYWJlbENvbG9yIiwic3ViVGV4dCIsImFnZ3MiLCJpZCIsImVuYWJsZWQiLCJzY2hlbWEiLCJjdXN0b21MYWJlbCIsInVpU3RhdGVKU09OIiwidmlzIiwiZGVmYXVsdENvbG9ycyIsImRlc2NyaXB0aW9uIiwidmVyc2lvbiIsImtpYmFuYVNhdmVkT2JqZWN0TWV0YSIsInNlYXJjaFNvdXJjZUpTT04iLCJpbmRleCIsImZpbHRlciIsIm1ldGEiLCJuZWdhdGUiLCJkaXNhYmxlZCIsImFsaWFzIiwia2V5IiwidmFsdWUiLCJxdWVyeSIsIm1hdGNoIiwiJHN0YXRlIiwic3RvcmUiLCJsYW5ndWFnZSIsIl90eXBlIiwiYm9vbCIsInNob3VsZCIsIm1hdGNoX3BocmFzZSIsIm1pbmltdW1fc2hvdWxkX21hdGNoIiwibGVnZW5kUG9zaXRpb24iLCJpc0RvbnV0IiwiZmllbGQiLCJzaXplIiwib3JkZXIiLCJvcmRlckJ5IiwiZ3JpZCIsImNhdGVnb3J5TGluZXMiLCJ2YWx1ZUF4aXMiLCJjYXRlZ29yeUF4ZXMiLCJwb3NpdGlvbiIsInRydW5jYXRlIiwidmFsdWVBeGVzIiwibmFtZSIsIm1vZGUiLCJyb3RhdGUiLCJ0ZXh0Iiwic2VyaWVzUGFyYW1zIiwiZGF0YSIsImxhYmVsIiwiZHJhd0xpbmVzQmV0d2VlblBvaW50cyIsInNob3dDaXJjbGVzIiwiaW50ZXJwb2xhdGUiLCJ0aW1lcyIsImFkZFRpbWVNYXJrZXIiLCJvdGhlckJ1Y2tldCIsIm90aGVyQnVja2V0TGFiZWwiLCJtaXNzaW5nQnVja2V0IiwibWlzc2luZ0J1Y2tldExhYmVsIiwidGltZVJhbmdlIiwidXNlTm9ybWFsaXplZEVzSW50ZXJ2YWwiLCJpbnRlcnZhbCIsInRpbWVfem9uZSIsImRyb3BfcGFydGlhbHMiLCJjdXN0b21JbnRlcnZhbCIsIm1pbl9kb2NfY291bnQiLCJleHRlbmRlZF9ib3VuZHMiLCJwZXJQYWdlIiwic2hvd1BhcnRpYWxSb3dzIiwic2hvd01ldGljc0F0QWxsTGV2ZWxzIiwic29ydCIsImNvbHVtbkluZGV4IiwiZGlyZWN0aW9uIiwic2hvd1RvdGFsIiwic2hvd1Rvb2xiYXIiLCJ0b3RhbEZ1bmMiLCJleHBvcnRzIiwiZGVmYXVsdCIsIm1vZHVsZSJdLCJzb3VyY2VzIjpbImFnZW50cy1hdWRpdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gTW9kdWxlIGZvciBBZ2VudHMvQXVkaXQgdmlzdWFsaXphdGlvbnNcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXG4gKlxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxuICovXG5leHBvcnQgZGVmYXVsdCBbXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUF1ZGl0LU5ldy1maWxlcy1tZXRyaWMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnTmV3IGZpbGVzIG1ldHJpYycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ05ldyBmaWxlcyBtZXRyaWMnLFxuICAgICAgICB0eXBlOiAnbWV0cmljJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIHR5cGU6ICdnYXVnZScsXG4gICAgICAgICAgZ2F1Z2U6IHtcbiAgICAgICAgICAgIHZlcnRpY2FsU3BsaXQ6IGZhbHNlLFxuICAgICAgICAgICAgYXV0b0V4dGVuZDogZmFsc2UsXG4gICAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXG4gICAgICAgICAgICBnYXVnZVR5cGU6ICdNZXRyaWMnLFxuICAgICAgICAgICAgZ2F1Z2VTdHlsZTogJ0Z1bGwnLFxuICAgICAgICAgICAgYmFja1N0eWxlOiAnRnVsbCcsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogJ3ZlcnRpY2FsJyxcbiAgICAgICAgICAgIGNvbG9yU2NoZW1hOiAnR3JlZW4gdG8gUmVkJyxcbiAgICAgICAgICAgIGdhdWdlQ29sb3JNb2RlOiAnTm9uZScsXG4gICAgICAgICAgICB1c2VSYW5nZTogZmFsc2UsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW3sgZnJvbTogMCwgdG86IDEwMCB9XSxcbiAgICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgY29sb3I6ICdibGFjaycgfSxcbiAgICAgICAgICAgIHNjYWxlOiB7IHNob3c6IGZhbHNlLCBsYWJlbHM6IGZhbHNlLCBjb2xvcjogJyMzMzMnLCB3aWR0aDogMiB9LFxuICAgICAgICAgICAgdHlwZTogJ3NpbXBsZScsXG4gICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMjAsIGJnQ29sb3I6IGZhbHNlLCBsYWJlbENvbG9yOiBmYWxzZSwgc3ViVGV4dDogJycgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICAgIHBhcmFtczogeyBjdXN0b21MYWJlbDogJ05ldyBmaWxlcycgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoeyB2aXM6IHsgZGVmYXVsdENvbG9yczogeyAnMCAtIDEwMCc6ICdyZ2IoMCwxMDQsNTUpJyB9IH0gfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG1ldGE6IHtcbiAgICAgICAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgICAgICAgbmVnYXRlOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBkaXNhYmxlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgYWxpYXM6IG51bGwsXG4gICAgICAgICAgICAgICAgdHlwZTogJ3BocmFzZScsXG4gICAgICAgICAgICAgICAga2V5OiAncnVsZS5pZCcsXG4gICAgICAgICAgICAgICAgdmFsdWU6ICc4MDc5MCcsXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICBxdWVyeTogJzgwNzkwJyxcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2UnLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgbWF0Y2g6IHtcbiAgICAgICAgICAgICAgICAgICdydWxlLmlkJzoge1xuICAgICAgICAgICAgICAgICAgICBxdWVyeTogJzgwNzkwJyxcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3BocmFzZScsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICRzdGF0ZToge1xuICAgICAgICAgICAgICAgIHN0b3JlOiAnYXBwU3RhdGUnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUF1ZGl0LVJlYWQtZmlsZXMtbWV0cmljJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1JlYWQgZmlsZXMgbWV0cmljJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnUmVhZCBmaWxlcyBtZXRyaWMnLFxuICAgICAgICB0eXBlOiAnbWV0cmljJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIHR5cGU6ICdnYXVnZScsXG4gICAgICAgICAgZ2F1Z2U6IHtcbiAgICAgICAgICAgIHZlcnRpY2FsU3BsaXQ6IGZhbHNlLFxuICAgICAgICAgICAgYXV0b0V4dGVuZDogZmFsc2UsXG4gICAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXG4gICAgICAgICAgICBnYXVnZVR5cGU6ICdNZXRyaWMnLFxuICAgICAgICAgICAgZ2F1Z2VTdHlsZTogJ0Z1bGwnLFxuICAgICAgICAgICAgYmFja1N0eWxlOiAnRnVsbCcsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogJ3ZlcnRpY2FsJyxcbiAgICAgICAgICAgIGNvbG9yU2NoZW1hOiAnR3JlZW4gdG8gUmVkJyxcbiAgICAgICAgICAgIGdhdWdlQ29sb3JNb2RlOiAnTm9uZScsXG4gICAgICAgICAgICB1c2VSYW5nZTogZmFsc2UsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW3sgZnJvbTogMCwgdG86IDEwMCB9XSxcbiAgICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgY29sb3I6ICdibGFjaycgfSxcbiAgICAgICAgICAgIHNjYWxlOiB7IHNob3c6IGZhbHNlLCBsYWJlbHM6IGZhbHNlLCBjb2xvcjogJyMzMzMnLCB3aWR0aDogMiB9LFxuICAgICAgICAgICAgdHlwZTogJ3NpbXBsZScsXG4gICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMjAsIGJnQ29sb3I6IGZhbHNlLCBsYWJlbENvbG9yOiBmYWxzZSwgc3ViVGV4dDogJycgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICAgIHBhcmFtczogeyBjdXN0b21MYWJlbDogJ1JlYWQgZmlsZXMnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHsgdmlzOiB7IGRlZmF1bHRDb2xvcnM6IHsgJzAgLSAxMDAnOiAncmdiKDAsMTA0LDU1KScgfSB9IH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBtZXRhOiB7XG4gICAgICAgICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgICAgICAgIG5lZ2F0ZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGFsaWFzOiBudWxsLFxuICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2UnLFxuICAgICAgICAgICAgICAgIGtleTogJ3J1bGUuaWQnLFxuICAgICAgICAgICAgICAgIHZhbHVlOiAnODA3ODQnLFxuICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgcXVlcnk6ICc4MDc4NCcsXG4gICAgICAgICAgICAgICAgICB0eXBlOiAncGhyYXNlJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgIG1hdGNoOiB7XG4gICAgICAgICAgICAgICAgICAncnVsZS5pZCc6IHtcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk6ICc4MDc4NCcsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2UnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAkc3RhdGU6IHtcbiAgICAgICAgICAgICAgICBzdG9yZTogJ2FwcFN0YXRlJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1BdWRpdC1Nb2RpZmllZC1maWxlcy1tZXRyaWMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnTW9kaWZpZWQgZmlsZXMgbWV0cmljJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnTW9kaWZpZWQgZmlsZXMgbWV0cmljJyxcbiAgICAgICAgdHlwZTogJ21ldHJpYycsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiBmYWxzZSxcbiAgICAgICAgICB0eXBlOiAnZ2F1Z2UnLFxuICAgICAgICAgIGdhdWdlOiB7XG4gICAgICAgICAgICB2ZXJ0aWNhbFNwbGl0OiBmYWxzZSxcbiAgICAgICAgICAgIGF1dG9FeHRlbmQ6IGZhbHNlLFxuICAgICAgICAgICAgcGVyY2VudGFnZU1vZGU6IGZhbHNlLFxuICAgICAgICAgICAgZ2F1Z2VUeXBlOiAnTWV0cmljJyxcbiAgICAgICAgICAgIGdhdWdlU3R5bGU6ICdGdWxsJyxcbiAgICAgICAgICAgIGJhY2tTdHlsZTogJ0Z1bGwnLFxuICAgICAgICAgICAgb3JpZW50YXRpb246ICd2ZXJ0aWNhbCcsXG4gICAgICAgICAgICBjb2xvclNjaGVtYTogJ0dyZWVuIHRvIFJlZCcsXG4gICAgICAgICAgICBnYXVnZUNvbG9yTW9kZTogJ05vbmUnLFxuICAgICAgICAgICAgdXNlUmFuZ2U6IGZhbHNlLFxuICAgICAgICAgICAgY29sb3JzUmFuZ2U6IFt7IGZyb206IDAsIHRvOiAxMDAgfV0sXG4gICAgICAgICAgICBpbnZlcnRDb2xvcnM6IGZhbHNlLFxuICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIGNvbG9yOiAnYmxhY2snIH0sXG4gICAgICAgICAgICBzY2FsZTogeyBzaG93OiBmYWxzZSwgbGFiZWxzOiBmYWxzZSwgY29sb3I6ICcjMzMzJywgd2lkdGg6IDIgfSxcbiAgICAgICAgICAgIHR5cGU6ICdzaW1wbGUnLFxuICAgICAgICAgICAgc3R5bGU6IHsgZm9udFNpemU6IDIwLCBiZ0NvbG9yOiBmYWxzZSwgbGFiZWxDb2xvcjogZmFsc2UsIHN1YlRleHQ6ICcnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgICBwYXJhbXM6IHsgY3VzdG9tTGFiZWw6ICdNb2RpZmllZCBmaWxlcycgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoeyB2aXM6IHsgZGVmYXVsdENvbG9yczogeyAnMCAtIDEwMCc6ICdyZ2IoMCwxMDQsNTUpJyB9IH0gfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG1ldGE6IHtcbiAgICAgICAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgICAgICAgdHlwZTogJ3BocmFzZXMnLFxuICAgICAgICAgICAgICAgIGtleTogJ3J1bGUuaWQnLFxuICAgICAgICAgICAgICAgIHZhbHVlOiAnODA3ODEsIDgwNzg3JyxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IFsnODA3ODEnLCAnODA3ODcnXSxcbiAgICAgICAgICAgICAgICBuZWdhdGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBhbGlhczogbnVsbCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcXVlcnk6IHtcbiAgICAgICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgICAgICBzaG91bGQ6IFtcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIG1hdGNoX3BocmFzZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ3J1bGUuaWQnOiAnODA3ODEnLFxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICBtYXRjaF9waHJhc2U6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdydWxlLmlkJzogJzgwNzg3JyxcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgIG1pbmltdW1fc2hvdWxkX21hdGNoOiAxLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICRzdGF0ZToge1xuICAgICAgICAgICAgICAgIHN0b3JlOiAnYXBwU3RhdGUnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUF1ZGl0LVJlbW92ZWQtZmlsZXMtbWV0cmljJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1JlbW92ZWQgZmlsZXMgbWV0cmljJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnUmVtb3ZlZCBmaWxlcyBtZXRyaWMnLFxuICAgICAgICB0eXBlOiAnbWV0cmljJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIHR5cGU6ICdnYXVnZScsXG4gICAgICAgICAgZ2F1Z2U6IHtcbiAgICAgICAgICAgIHZlcnRpY2FsU3BsaXQ6IGZhbHNlLFxuICAgICAgICAgICAgYXV0b0V4dGVuZDogZmFsc2UsXG4gICAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXG4gICAgICAgICAgICBnYXVnZVR5cGU6ICdNZXRyaWMnLFxuICAgICAgICAgICAgZ2F1Z2VTdHlsZTogJ0Z1bGwnLFxuICAgICAgICAgICAgYmFja1N0eWxlOiAnRnVsbCcsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogJ3ZlcnRpY2FsJyxcbiAgICAgICAgICAgIGNvbG9yU2NoZW1hOiAnR3JlZW4gdG8gUmVkJyxcbiAgICAgICAgICAgIGdhdWdlQ29sb3JNb2RlOiAnTm9uZScsXG4gICAgICAgICAgICB1c2VSYW5nZTogZmFsc2UsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW3sgZnJvbTogMCwgdG86IDEwMCB9XSxcbiAgICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgY29sb3I6ICdibGFjaycgfSxcbiAgICAgICAgICAgIHNjYWxlOiB7IHNob3c6IGZhbHNlLCBsYWJlbHM6IGZhbHNlLCBjb2xvcjogJyMzMzMnLCB3aWR0aDogMiB9LFxuICAgICAgICAgICAgdHlwZTogJ3NpbXBsZScsXG4gICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMjAsIGJnQ29sb3I6IGZhbHNlLCBsYWJlbENvbG9yOiBmYWxzZSwgc3ViVGV4dDogJycgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICAgIHBhcmFtczogeyBjdXN0b21MYWJlbDogJ1JlbW92ZWQgZmlsZXMnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHsgdmlzOiB7IGRlZmF1bHRDb2xvcnM6IHsgJzAgLSAxMDAnOiAncmdiKDAsMTA0LDU1KScgfSB9IH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBtZXRhOiB7XG4gICAgICAgICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgICAgICAgIG5lZ2F0ZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGFsaWFzOiBudWxsLFxuICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2UnLFxuICAgICAgICAgICAgICAgIGtleTogJ3J1bGUuaWQnLFxuICAgICAgICAgICAgICAgIHZhbHVlOiAnODA3OTEnLFxuICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgcXVlcnk6ICc4MDc5MScsXG4gICAgICAgICAgICAgICAgICB0eXBlOiAncGhyYXNlJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgIG1hdGNoOiB7XG4gICAgICAgICAgICAgICAgICAncnVsZS5pZCc6IHtcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk6ICc4MDc5MScsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2UnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAkc3RhdGU6IHtcbiAgICAgICAgICAgICAgICBzdG9yZTogJ2FwcFN0YXRlJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1BdWRpdC1Hcm91cHMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnR3JvdXBzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnR3JvdXBzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczogeyBmaWVsZDogJ3J1bGUuZ3JvdXBzJywgc2l6ZTogNSwgb3JkZXI6ICdkZXNjJywgb3JkZXJCeTogJzEnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1BdWRpdC1GaWxlcycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdGaWxlcycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0ZpbGVzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczogeyBmaWVsZDogJ2RhdGEuYXVkaXQuZmlsZS5uYW1lJywgc2l6ZTogNSwgb3JkZXI6ICdkZXNjJywgb3JkZXJCeTogJzEnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1BdWRpdC1BbGVydHMtb3Zlci10aW1lJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0FsZXJ0cyBvdmVyIHRpbWUnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydHMgb3ZlciB0aW1lJyxcbiAgICAgICAgdHlwZTogJ2FyZWEnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgZ3JpZDogeyBjYXRlZ29yeUxpbmVzOiB0cnVlLCBzdHlsZTogeyBjb2xvcjogJyNlZWUnIH0sIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJywgbW9kZTogJ25vcm1hbCcgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIHJvdGF0ZTogMCwgZmlsdGVyOiBmYWxzZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZTogeyB0ZXh0OiAnQ291bnQnIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNob3c6ICd0cnVlJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2FyZWEnLFxuICAgICAgICAgICAgICBtb2RlOiAnc3RhY2tlZCcsXG4gICAgICAgICAgICAgIGRhdGE6IHsgbGFiZWw6ICdDb3VudCcsIGlkOiAnMScgfSxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgc2hvd0NpcmNsZXM6IHRydWUsXG4gICAgICAgICAgICAgIGludGVycG9sYXRlOiAnY2FyZGluYWwnLFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgdGltZXM6IFtdLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5kZXNjcmlwdGlvbicsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnZGF0ZV9oaXN0b2dyYW0nLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICd0aW1lc3RhbXAnLFxuICAgICAgICAgICAgICB0aW1lUmFuZ2U6IHsgZnJvbTogJ25vdy0xaCcsIHRvOiAnbm93JywgbW9kZTogJ3F1aWNrJyB9LFxuICAgICAgICAgICAgICB1c2VOb3JtYWxpemVkRXNJbnRlcnZhbDogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJ2YWw6ICdhdXRvJyxcbiAgICAgICAgICAgICAgdGltZV96b25lOiAnRXVyb3BlL0JlcmxpbicsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBjdXN0b21JbnRlcnZhbDogJzJoJyxcbiAgICAgICAgICAgICAgbWluX2RvY19jb3VudDogMSxcbiAgICAgICAgICAgICAgZXh0ZW5kZWRfYm91bmRzOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLUFnZW50cy1BdWRpdC1Db21tYW5kcycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdDb21tYW5kcycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0NvbW1hbmRzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczogeyBmaWVsZDogJ2RhdGEuYXVkaXQuY29tbWFuZCcsIHNpemU6IDUsIG9yZGVyOiAnZGVzYycsIG9yZGVyQnk6ICcxJyB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtQWdlbnRzLUF1ZGl0LUxhc3QtYWxlcnRzJyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnTGFzdCBhbGVydHMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdMYXN0IGFsZXJ0cycsXG4gICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDEwLFxuICAgICAgICAgIHNob3dQYXJ0aWFsUm93czogZmFsc2UsXG4gICAgICAgICAgc2hvd01ldGljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgc2hvd1Rvb2xiYXI6IHRydWUsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmRlc2NyaXB0aW9uJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDUwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnRXZlbnQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmF1ZGl0LmV4ZScsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0NvbW1hbmQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmF1ZGl0LnR5cGUnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1R5cGUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxuICAgICAgfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbl07XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWQSxJQUFBQSxRQUFBLEdBV2UsQ0FDYjtFQUNFQyxHQUFHLEVBQUUseUNBQXlDO0VBQzlDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGtCQUFrQjtJQUN6QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGtCQUFrQjtNQUN6QkksSUFBSSxFQUFFLFFBQVE7TUFDZEMsTUFBTSxFQUFFO1FBQ05DLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsS0FBSztRQUNoQkgsSUFBSSxFQUFFLE9BQU87UUFDYkksS0FBSyxFQUFFO1VBQ0xDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxVQUFVLEVBQUUsS0FBSztVQUNqQkMsY0FBYyxFQUFFLEtBQUs7VUFDckJDLFNBQVMsRUFBRSxRQUFRO1VBQ25CQyxVQUFVLEVBQUUsTUFBTTtVQUNsQkMsU0FBUyxFQUFFLE1BQU07VUFDakJDLFdBQVcsRUFBRSxVQUFVO1VBQ3ZCQyxXQUFXLEVBQUUsY0FBYztVQUMzQkMsY0FBYyxFQUFFLE1BQU07VUFDdEJDLFFBQVEsRUFBRSxLQUFLO1VBQ2ZDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLElBQUksRUFBRSxDQUFDO1lBQUVDLEVBQUUsRUFBRTtVQUFJLENBQUMsQ0FBQztVQUNuQ0MsWUFBWSxFQUFFLEtBQUs7VUFDbkJDLE1BQU0sRUFBRTtZQUFFQyxJQUFJLEVBQUUsSUFBSTtZQUFFQyxLQUFLLEVBQUU7VUFBUSxDQUFDO1VBQ3RDQyxLQUFLLEVBQUU7WUFBRUYsSUFBSSxFQUFFLEtBQUs7WUFBRUQsTUFBTSxFQUFFLEtBQUs7WUFBRUUsS0FBSyxFQUFFLE1BQU07WUFBRUUsS0FBSyxFQUFFO1VBQUUsQ0FBQztVQUM5RHZCLElBQUksRUFBRSxRQUFRO1VBQ2R3QixLQUFLLEVBQUU7WUFBRUMsUUFBUSxFQUFFLEVBQUU7WUFBRUMsT0FBTyxFQUFFLEtBQUs7WUFBRUMsVUFBVSxFQUFFLEtBQUs7WUFBRUMsT0FBTyxFQUFFO1VBQUc7UUFDeEU7TUFDRixDQUFDO01BQ0RDLElBQUksRUFBRSxDQUNKO1FBQ0VDLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2IvQixJQUFJLEVBQUUsT0FBTztRQUNiZ0MsTUFBTSxFQUFFLFFBQVE7UUFDaEIvQixNQUFNLEVBQUU7VUFBRWdDLFdBQVcsRUFBRTtRQUFZO01BQ3JDLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFcEMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFBRW9DLEdBQUcsRUFBRTtRQUFFQyxhQUFhLEVBQUU7VUFBRSxTQUFTLEVBQUU7UUFBZ0I7TUFBRTtJQUFFLENBQUMsQ0FBQztJQUN2RkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFMUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0IwQyxLQUFLLEVBQUUsY0FBYztRQUNyQkMsTUFBTSxFQUFFLENBQ047VUFDRUMsSUFBSSxFQUFFO1lBQ0pGLEtBQUssRUFBRSxjQUFjO1lBQ3JCRyxNQUFNLEVBQUUsS0FBSztZQUNiQyxRQUFRLEVBQUUsS0FBSztZQUNmQyxLQUFLLEVBQUUsSUFBSTtZQUNYOUMsSUFBSSxFQUFFLFFBQVE7WUFDZCtDLEdBQUcsRUFBRSxTQUFTO1lBQ2RDLEtBQUssRUFBRSxPQUFPO1lBQ2QvQyxNQUFNLEVBQUU7Y0FDTmdELEtBQUssRUFBRSxPQUFPO2NBQ2RqRCxJQUFJLEVBQUU7WUFDUjtVQUNGLENBQUM7VUFDRGlELEtBQUssRUFBRTtZQUNMQyxLQUFLLEVBQUU7Y0FDTCxTQUFTLEVBQUU7Z0JBQ1RELEtBQUssRUFBRSxPQUFPO2dCQUNkakQsSUFBSSxFQUFFO2NBQ1I7WUFDRjtVQUNGLENBQUM7VUFDRG1ELE1BQU0sRUFBRTtZQUNOQyxLQUFLLEVBQUU7VUFDVDtRQUNGLENBQUMsQ0FDRjtRQUNESCxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUksUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRTVELEdBQUcsRUFBRSwwQ0FBMEM7RUFDL0NDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsbUJBQW1CO0lBQzFCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsbUJBQW1CO01BQzFCSSxJQUFJLEVBQUUsUUFBUTtNQUNkQyxNQUFNLEVBQUU7UUFDTkMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxLQUFLLEVBQUU7VUFDTEMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLFVBQVUsRUFBRSxLQUFLO1VBQ2pCQyxjQUFjLEVBQUUsS0FBSztVQUNyQkMsU0FBUyxFQUFFLFFBQVE7VUFDbkJDLFVBQVUsRUFBRSxNQUFNO1VBQ2xCQyxTQUFTLEVBQUUsTUFBTTtVQUNqQkMsV0FBVyxFQUFFLFVBQVU7VUFDdkJDLFdBQVcsRUFBRSxjQUFjO1VBQzNCQyxjQUFjLEVBQUUsTUFBTTtVQUN0QkMsUUFBUSxFQUFFLEtBQUs7VUFDZkMsV0FBVyxFQUFFLENBQUM7WUFBRUMsSUFBSSxFQUFFLENBQUM7WUFBRUMsRUFBRSxFQUFFO1VBQUksQ0FBQyxDQUFDO1VBQ25DQyxZQUFZLEVBQUUsS0FBSztVQUNuQkMsTUFBTSxFQUFFO1lBQUVDLElBQUksRUFBRSxJQUFJO1lBQUVDLEtBQUssRUFBRTtVQUFRLENBQUM7VUFDdENDLEtBQUssRUFBRTtZQUFFRixJQUFJLEVBQUUsS0FBSztZQUFFRCxNQUFNLEVBQUUsS0FBSztZQUFFRSxLQUFLLEVBQUUsTUFBTTtZQUFFRSxLQUFLLEVBQUU7VUFBRSxDQUFDO1VBQzlEdkIsSUFBSSxFQUFFLFFBQVE7VUFDZHdCLEtBQUssRUFBRTtZQUFFQyxRQUFRLEVBQUUsRUFBRTtZQUFFQyxPQUFPLEVBQUUsS0FBSztZQUFFQyxVQUFVLEVBQUUsS0FBSztZQUFFQyxPQUFPLEVBQUU7VUFBRztRQUN4RTtNQUNGLENBQUM7TUFDREMsSUFBSSxFQUFFLENBQ0o7UUFDRUMsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYi9CLElBQUksRUFBRSxPQUFPO1FBQ2JnQyxNQUFNLEVBQUUsUUFBUTtRQUNoQi9CLE1BQU0sRUFBRTtVQUFFZ0MsV0FBVyxFQUFFO1FBQWE7TUFDdEMsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGQyxXQUFXLEVBQUVwQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUFFb0MsR0FBRyxFQUFFO1FBQUVDLGFBQWEsRUFBRTtVQUFFLFNBQVMsRUFBRTtRQUFnQjtNQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQ3ZGQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUUxQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjBDLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxNQUFNLEVBQUUsQ0FDTjtVQUNFQyxJQUFJLEVBQUU7WUFDSkYsS0FBSyxFQUFFLGNBQWM7WUFDckJHLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRSxLQUFLO1lBQ2ZDLEtBQUssRUFBRSxJQUFJO1lBQ1g5QyxJQUFJLEVBQUUsUUFBUTtZQUNkK0MsR0FBRyxFQUFFLFNBQVM7WUFDZEMsS0FBSyxFQUFFLE9BQU87WUFDZC9DLE1BQU0sRUFBRTtjQUNOZ0QsS0FBSyxFQUFFLE9BQU87Y0FDZGpELElBQUksRUFBRTtZQUNSO1VBQ0YsQ0FBQztVQUNEaUQsS0FBSyxFQUFFO1lBQ0xDLEtBQUssRUFBRTtjQUNMLFNBQVMsRUFBRTtnQkFDVEQsS0FBSyxFQUFFLE9BQU87Z0JBQ2RqRCxJQUFJLEVBQUU7Y0FDUjtZQUNGO1VBQ0YsQ0FBQztVQUNEbUQsTUFBTSxFQUFFO1lBQ05DLEtBQUssRUFBRTtVQUNUO1FBQ0YsQ0FBQyxDQUNGO1FBQ0RILEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFSSxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFNUQsR0FBRyxFQUFFLDhDQUE4QztFQUNuREMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSx1QkFBdUI7SUFDOUJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSx1QkFBdUI7TUFDOUJJLElBQUksRUFBRSxRQUFRO01BQ2RDLE1BQU0sRUFBRTtRQUNOQyxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLEtBQUs7UUFDaEJILElBQUksRUFBRSxPQUFPO1FBQ2JJLEtBQUssRUFBRTtVQUNMQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsVUFBVSxFQUFFLEtBQUs7VUFDakJDLGNBQWMsRUFBRSxLQUFLO1VBQ3JCQyxTQUFTLEVBQUUsUUFBUTtVQUNuQkMsVUFBVSxFQUFFLE1BQU07VUFDbEJDLFNBQVMsRUFBRSxNQUFNO1VBQ2pCQyxXQUFXLEVBQUUsVUFBVTtVQUN2QkMsV0FBVyxFQUFFLGNBQWM7VUFDM0JDLGNBQWMsRUFBRSxNQUFNO1VBQ3RCQyxRQUFRLEVBQUUsS0FBSztVQUNmQyxXQUFXLEVBQUUsQ0FBQztZQUFFQyxJQUFJLEVBQUUsQ0FBQztZQUFFQyxFQUFFLEVBQUU7VUFBSSxDQUFDLENBQUM7VUFDbkNDLFlBQVksRUFBRSxLQUFLO1VBQ25CQyxNQUFNLEVBQUU7WUFBRUMsSUFBSSxFQUFFLElBQUk7WUFBRUMsS0FBSyxFQUFFO1VBQVEsQ0FBQztVQUN0Q0MsS0FBSyxFQUFFO1lBQUVGLElBQUksRUFBRSxLQUFLO1lBQUVELE1BQU0sRUFBRSxLQUFLO1lBQUVFLEtBQUssRUFBRSxNQUFNO1lBQUVFLEtBQUssRUFBRTtVQUFFLENBQUM7VUFDOUR2QixJQUFJLEVBQUUsUUFBUTtVQUNkd0IsS0FBSyxFQUFFO1lBQUVDLFFBQVEsRUFBRSxFQUFFO1lBQUVDLE9BQU8sRUFBRSxLQUFLO1lBQUVDLFVBQVUsRUFBRSxLQUFLO1lBQUVDLE9BQU8sRUFBRTtVQUFHO1FBQ3hFO01BQ0YsQ0FBQztNQUNEQyxJQUFJLEVBQUUsQ0FDSjtRQUNFQyxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiL0IsSUFBSSxFQUFFLE9BQU87UUFDYmdDLE1BQU0sRUFBRSxRQUFRO1FBQ2hCL0IsTUFBTSxFQUFFO1VBQUVnQyxXQUFXLEVBQUU7UUFBaUI7TUFDMUMsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGQyxXQUFXLEVBQUVwQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUFFb0MsR0FBRyxFQUFFO1FBQUVDLGFBQWEsRUFBRTtVQUFFLFNBQVMsRUFBRTtRQUFnQjtNQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQ3ZGQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUUxQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjBDLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxNQUFNLEVBQUUsQ0FDTjtVQUNFQyxJQUFJLEVBQUU7WUFDSkYsS0FBSyxFQUFFLGNBQWM7WUFDckJ6QyxJQUFJLEVBQUUsU0FBUztZQUNmK0MsR0FBRyxFQUFFLFNBQVM7WUFDZEMsS0FBSyxFQUFFLGNBQWM7WUFDckIvQyxNQUFNLEVBQUUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO1lBQzFCMkMsTUFBTSxFQUFFLEtBQUs7WUFDYkMsUUFBUSxFQUFFLEtBQUs7WUFDZkMsS0FBSyxFQUFFO1VBQ1QsQ0FBQztVQUNERyxLQUFLLEVBQUU7WUFDTE0sSUFBSSxFQUFFO2NBQ0pDLE1BQU0sRUFBRSxDQUNOO2dCQUNFQyxZQUFZLEVBQUU7a0JBQ1osU0FBUyxFQUFFO2dCQUNiO2NBQ0YsQ0FBQyxFQUNEO2dCQUNFQSxZQUFZLEVBQUU7a0JBQ1osU0FBUyxFQUFFO2dCQUNiO2NBQ0YsQ0FBQyxDQUNGO2NBQ0RDLG9CQUFvQixFQUFFO1lBQ3hCO1VBQ0YsQ0FBQztVQUNEUCxNQUFNLEVBQUU7WUFDTkMsS0FBSyxFQUFFO1VBQ1Q7UUFDRixDQUFDLENBQ0Y7UUFDREgsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVJLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0U1RCxHQUFHLEVBQUUsNkNBQTZDO0VBQ2xEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHNCQUFzQjtJQUM3QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHNCQUFzQjtNQUM3QkksSUFBSSxFQUFFLFFBQVE7TUFDZEMsTUFBTSxFQUFFO1FBQ05DLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsS0FBSztRQUNoQkgsSUFBSSxFQUFFLE9BQU87UUFDYkksS0FBSyxFQUFFO1VBQ0xDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxVQUFVLEVBQUUsS0FBSztVQUNqQkMsY0FBYyxFQUFFLEtBQUs7VUFDckJDLFNBQVMsRUFBRSxRQUFRO1VBQ25CQyxVQUFVLEVBQUUsTUFBTTtVQUNsQkMsU0FBUyxFQUFFLE1BQU07VUFDakJDLFdBQVcsRUFBRSxVQUFVO1VBQ3ZCQyxXQUFXLEVBQUUsY0FBYztVQUMzQkMsY0FBYyxFQUFFLE1BQU07VUFDdEJDLFFBQVEsRUFBRSxLQUFLO1VBQ2ZDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLElBQUksRUFBRSxDQUFDO1lBQUVDLEVBQUUsRUFBRTtVQUFJLENBQUMsQ0FBQztVQUNuQ0MsWUFBWSxFQUFFLEtBQUs7VUFDbkJDLE1BQU0sRUFBRTtZQUFFQyxJQUFJLEVBQUUsSUFBSTtZQUFFQyxLQUFLLEVBQUU7VUFBUSxDQUFDO1VBQ3RDQyxLQUFLLEVBQUU7WUFBRUYsSUFBSSxFQUFFLEtBQUs7WUFBRUQsTUFBTSxFQUFFLEtBQUs7WUFBRUUsS0FBSyxFQUFFLE1BQU07WUFBRUUsS0FBSyxFQUFFO1VBQUUsQ0FBQztVQUM5RHZCLElBQUksRUFBRSxRQUFRO1VBQ2R3QixLQUFLLEVBQUU7WUFBRUMsUUFBUSxFQUFFLEVBQUU7WUFBRUMsT0FBTyxFQUFFLEtBQUs7WUFBRUMsVUFBVSxFQUFFLEtBQUs7WUFBRUMsT0FBTyxFQUFFO1VBQUc7UUFDeEU7TUFDRixDQUFDO01BQ0RDLElBQUksRUFBRSxDQUNKO1FBQ0VDLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2IvQixJQUFJLEVBQUUsT0FBTztRQUNiZ0MsTUFBTSxFQUFFLFFBQVE7UUFDaEIvQixNQUFNLEVBQUU7VUFBRWdDLFdBQVcsRUFBRTtRQUFnQjtNQUN6QyxDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZDLFdBQVcsRUFBRXBDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQUVvQyxHQUFHLEVBQUU7UUFBRUMsYUFBYSxFQUFFO1VBQUUsU0FBUyxFQUFFO1FBQWdCO01BQUU7SUFBRSxDQUFDLENBQUM7SUFDdkZDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTFDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CMEMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxDQUNOO1VBQ0VDLElBQUksRUFBRTtZQUNKRixLQUFLLEVBQUUsY0FBYztZQUNyQkcsTUFBTSxFQUFFLEtBQUs7WUFDYkMsUUFBUSxFQUFFLEtBQUs7WUFDZkMsS0FBSyxFQUFFLElBQUk7WUFDWDlDLElBQUksRUFBRSxRQUFRO1lBQ2QrQyxHQUFHLEVBQUUsU0FBUztZQUNkQyxLQUFLLEVBQUUsT0FBTztZQUNkL0MsTUFBTSxFQUFFO2NBQ05nRCxLQUFLLEVBQUUsT0FBTztjQUNkakQsSUFBSSxFQUFFO1lBQ1I7VUFDRixDQUFDO1VBQ0RpRCxLQUFLLEVBQUU7WUFDTEMsS0FBSyxFQUFFO2NBQ0wsU0FBUyxFQUFFO2dCQUNURCxLQUFLLEVBQUUsT0FBTztnQkFDZGpELElBQUksRUFBRTtjQUNSO1lBQ0Y7VUFDRixDQUFDO1VBQ0RtRCxNQUFNLEVBQUU7WUFDTkMsS0FBSyxFQUFFO1VBQ1Q7UUFDRixDQUFDLENBQ0Y7UUFDREgsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVJLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0U1RCxHQUFHLEVBQUUsK0JBQStCO0VBQ3BDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLFFBQVE7SUFDZkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLFFBQVE7TUFDZkksSUFBSSxFQUFFLEtBQUs7TUFDWEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1hFLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmd0QsY0FBYyxFQUFFLE9BQU87UUFDdkJDLE9BQU8sRUFBRTtNQUNYLENBQUM7TUFDRC9CLElBQUksRUFBRSxDQUNKO1FBQUVDLEVBQUUsRUFBRSxHQUFHO1FBQUVDLE9BQU8sRUFBRSxJQUFJO1FBQUUvQixJQUFJLEVBQUUsT0FBTztRQUFFZ0MsTUFBTSxFQUFFLFFBQVE7UUFBRS9CLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFNkIsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYi9CLElBQUksRUFBRSxPQUFPO1FBQ2JnQyxNQUFNLEVBQUUsU0FBUztRQUNqQi9CLE1BQU0sRUFBRTtVQUFFNEQsS0FBSyxFQUFFLGFBQWE7VUFBRUMsSUFBSSxFQUFFLENBQUM7VUFBRUMsS0FBSyxFQUFFLE1BQU07VUFBRUMsT0FBTyxFQUFFO1FBQUk7TUFDdkUsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGOUIsV0FBVyxFQUFFLElBQUk7SUFDakJHLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTFDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CMEMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxFQUFFO1FBQ1ZPLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFSSxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFNUQsR0FBRyxFQUFFLDhCQUE4QjtFQUNuQ0MsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxPQUFPO0lBQ2RDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxPQUFPO01BQ2RJLElBQUksRUFBRSxLQUFLO01BQ1hDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYRSxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZndELGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxPQUFPLEVBQUU7TUFDWCxDQUFDO01BQ0QvQixJQUFJLEVBQUUsQ0FDSjtRQUFFQyxFQUFFLEVBQUUsR0FBRztRQUFFQyxPQUFPLEVBQUUsSUFBSTtRQUFFL0IsSUFBSSxFQUFFLE9BQU87UUFBRWdDLE1BQU0sRUFBRSxRQUFRO1FBQUUvQixNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRTZCLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2IvQixJQUFJLEVBQUUsT0FBTztRQUNiZ0MsTUFBTSxFQUFFLFNBQVM7UUFDakIvQixNQUFNLEVBQUU7VUFBRTRELEtBQUssRUFBRSxzQkFBc0I7VUFBRUMsSUFBSSxFQUFFLENBQUM7VUFBRUMsS0FBSyxFQUFFLE1BQU07VUFBRUMsT0FBTyxFQUFFO1FBQUk7TUFDaEYsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGOUIsV0FBVyxFQUFFLElBQUk7SUFDakJHLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTFDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CMEMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxFQUFFO1FBQ1ZPLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFSSxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFNUQsR0FBRyxFQUFFLHlDQUF5QztFQUM5Q0MsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxrQkFBa0I7SUFDekJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxrQkFBa0I7TUFDekJJLElBQUksRUFBRSxNQUFNO01BQ1pDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsTUFBTTtRQUNaaUUsSUFBSSxFQUFFO1VBQUVDLGFBQWEsRUFBRSxJQUFJO1VBQUUxQyxLQUFLLEVBQUU7WUFBRUgsS0FBSyxFQUFFO1VBQU8sQ0FBQztVQUFFOEMsU0FBUyxFQUFFO1FBQWMsQ0FBQztRQUNqRkMsWUFBWSxFQUFFLENBQ1o7VUFDRXRDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEI5QixJQUFJLEVBQUUsVUFBVTtVQUNoQnFFLFFBQVEsRUFBRSxRQUFRO1VBQ2xCakQsSUFBSSxFQUFFLElBQUk7VUFDVkksS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNURixLQUFLLEVBQUU7WUFBRXRCLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekJtQixNQUFNLEVBQUU7WUFBRUMsSUFBSSxFQUFFLElBQUk7WUFBRWtELFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDckMxRSxLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEMkUsU0FBUyxFQUFFLENBQ1Q7VUFDRXpDLEVBQUUsRUFBRSxhQUFhO1VBQ2pCMEMsSUFBSSxFQUFFLFlBQVk7VUFDbEJ4RSxJQUFJLEVBQUUsT0FBTztVQUNicUUsUUFBUSxFQUFFLE1BQU07VUFDaEJqRCxJQUFJLEVBQUUsSUFBSTtVQUNWSSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RGLEtBQUssRUFBRTtZQUFFdEIsSUFBSSxFQUFFLFFBQVE7WUFBRXlFLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekN0RCxNQUFNLEVBQUU7WUFBRUMsSUFBSSxFQUFFLElBQUk7WUFBRXNELE1BQU0sRUFBRSxDQUFDO1lBQUVoQyxNQUFNLEVBQUUsS0FBSztZQUFFNEIsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUMvRDFFLEtBQUssRUFBRTtZQUFFK0UsSUFBSSxFQUFFO1VBQVE7UUFDekIsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0V4RCxJQUFJLEVBQUUsTUFBTTtVQUNacEIsSUFBSSxFQUFFLE1BQU07VUFDWnlFLElBQUksRUFBRSxTQUFTO1VBQ2ZJLElBQUksRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFaEQsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQ2lELHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFdBQVcsRUFBRSxJQUFJO1VBQ2pCQyxXQUFXLEVBQUUsVUFBVTtVQUN2QmQsU0FBUyxFQUFFO1FBQ2IsQ0FBQyxDQUNGO1FBQ0RqRSxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZndELGNBQWMsRUFBRSxPQUFPO1FBQ3ZCdUIsS0FBSyxFQUFFLEVBQUU7UUFDVEMsYUFBYSxFQUFFO01BQ2pCLENBQUM7TUFDRHRELElBQUksRUFBRSxDQUNKO1FBQUVDLEVBQUUsRUFBRSxHQUFHO1FBQUVDLE9BQU8sRUFBRSxJQUFJO1FBQUUvQixJQUFJLEVBQUUsT0FBTztRQUFFZ0MsTUFBTSxFQUFFLFFBQVE7UUFBRS9CLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFNkIsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYi9CLElBQUksRUFBRSxPQUFPO1FBQ2JnQyxNQUFNLEVBQUUsT0FBTztRQUNmL0IsTUFBTSxFQUFFO1VBQ040RCxLQUFLLEVBQUUsa0JBQWtCO1VBQ3pCQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNab0IsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUMsRUFDRDtRQUNFekQsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYi9CLElBQUksRUFBRSxnQkFBZ0I7UUFDdEJnQyxNQUFNLEVBQUUsU0FBUztRQUNqQi9CLE1BQU0sRUFBRTtVQUNONEQsS0FBSyxFQUFFLFdBQVc7VUFDbEIyQixTQUFTLEVBQUU7WUFBRXhFLElBQUksRUFBRSxRQUFRO1lBQUVDLEVBQUUsRUFBRSxLQUFLO1lBQUV3RCxJQUFJLEVBQUU7VUFBUSxDQUFDO1VBQ3ZEZ0IsdUJBQXVCLEVBQUUsSUFBSTtVQUM3QkMsUUFBUSxFQUFFLE1BQU07VUFDaEJDLFNBQVMsRUFBRSxlQUFlO1VBQzFCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsY0FBYyxFQUFFLElBQUk7VUFDcEJDLGFBQWEsRUFBRSxDQUFDO1VBQ2hCQyxlQUFlLEVBQUUsQ0FBQztRQUNwQjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRjdELFdBQVcsRUFBRSxJQUFJO0lBQ2pCRyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUUxQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjBDLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxNQUFNLEVBQUUsRUFBRTtRQUNWTyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUksUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRTVELEdBQUcsRUFBRSxpQ0FBaUM7RUFDdENDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsVUFBVTtJQUNqQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLFVBQVU7TUFDakJJLElBQUksRUFBRSxLQUFLO01BQ1hDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYRSxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZndELGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxPQUFPLEVBQUU7TUFDWCxDQUFDO01BQ0QvQixJQUFJLEVBQUUsQ0FDSjtRQUFFQyxFQUFFLEVBQUUsR0FBRztRQUFFQyxPQUFPLEVBQUUsSUFBSTtRQUFFL0IsSUFBSSxFQUFFLE9BQU87UUFBRWdDLE1BQU0sRUFBRSxRQUFRO1FBQUUvQixNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRTZCLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2IvQixJQUFJLEVBQUUsT0FBTztRQUNiZ0MsTUFBTSxFQUFFLFNBQVM7UUFDakIvQixNQUFNLEVBQUU7VUFBRTRELEtBQUssRUFBRSxvQkFBb0I7VUFBRUMsSUFBSSxFQUFFLENBQUM7VUFBRUMsS0FBSyxFQUFFLE1BQU07VUFBRUMsT0FBTyxFQUFFO1FBQUk7TUFDOUUsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGOUIsV0FBVyxFQUFFLElBQUk7SUFDakJHLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFDZDtJQUNKO0VBQ0YsQ0FBQztFQUNEYyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRTVELEdBQUcsRUFBRSxvQ0FBb0M7RUFDekM0RCxLQUFLLEVBQUUsZUFBZTtFQUN0QjNELE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsYUFBYTtJQUNwQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGFBQWE7TUFDcEJJLElBQUksRUFBRSxPQUFPO01BQ2JDLE1BQU0sRUFBRTtRQUNOK0YsT0FBTyxFQUFFLEVBQUU7UUFDWEMsZUFBZSxFQUFFLEtBQUs7UUFDdEJDLHFCQUFxQixFQUFFLEtBQUs7UUFDNUJDLElBQUksRUFBRTtVQUFFQyxXQUFXLEVBQUUsQ0FBQztVQUFFQyxTQUFTLEVBQUU7UUFBTyxDQUFDO1FBQzNDQyxTQUFTLEVBQUUsS0FBSztRQUNoQkMsV0FBVyxFQUFFLElBQUk7UUFDakJDLFNBQVMsRUFBRTtNQUNiLENBQUM7TUFDRDNFLElBQUksRUFBRSxDQUNKO1FBQUVDLEVBQUUsRUFBRSxHQUFHO1FBQUVDLE9BQU8sRUFBRSxJQUFJO1FBQUUvQixJQUFJLEVBQUUsT0FBTztRQUFFZ0MsTUFBTSxFQUFFLFFBQVE7UUFBRS9CLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFNkIsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYi9CLElBQUksRUFBRSxPQUFPO1FBQ2JnQyxNQUFNLEVBQUUsUUFBUTtRQUNoQi9CLE1BQU0sRUFBRTtVQUNONEQsS0FBSyxFQUFFLGtCQUFrQjtVQUN6QnVCLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3QnpCLElBQUksRUFBRSxFQUFFO1VBQ1JDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1ovQixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFSCxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiL0IsSUFBSSxFQUFFLE9BQU87UUFDYmdDLE1BQU0sRUFBRSxRQUFRO1FBQ2hCL0IsTUFBTSxFQUFFO1VBQ040RCxLQUFLLEVBQUUsZ0JBQWdCO1VBQ3ZCdUIsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCekIsSUFBSSxFQUFFLEVBQUU7VUFDUkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWi9CLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0VILEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2IvQixJQUFJLEVBQUUsT0FBTztRQUNiZ0MsTUFBTSxFQUFFLFFBQVE7UUFDaEIvQixNQUFNLEVBQUU7VUFDTjRELEtBQUssRUFBRSxpQkFBaUI7VUFDeEJ1QixXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0J6QixJQUFJLEVBQUUsQ0FBQztVQUNQQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaL0IsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZDLFdBQVcsRUFBRXBDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQzFCb0MsR0FBRyxFQUFFO1FBQUVsQyxNQUFNLEVBQUU7VUFBRWtHLElBQUksRUFBRTtZQUFFQyxXQUFXLEVBQUUsQ0FBQztZQUFFQyxTQUFTLEVBQUU7VUFBTztRQUFFO01BQUU7SUFDakUsQ0FBQyxDQUFDO0lBQ0ZoRSxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUUxQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjBDLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxNQUFNLEVBQUUsRUFBRTtRQUNWTyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUksUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLENBQ0Y7QUFBQW9ELE9BQUEsQ0FBQUMsT0FBQSxHQUFBakgsUUFBQTtBQUFBa0gsTUFBQSxDQUFBRixPQUFBLEdBQUFBLE9BQUEsQ0FBQUMsT0FBQSJ9