"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Overview/TSC visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Overview-TSC-Requirements-over-time',
  _source: {
    title: 'Requirements over time',
    visState: JSON.stringify({
      title: 'Alerts by action over time',
      type: 'area',
      params: {
        type: 'area',
        grid: {
          categoryLines: true,
          style: {
            color: '#eee'
          },
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'area',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'cardinal',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-24h',
            to: 'now',
            mode: 'quick'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          time_zone: 'Europe/Berlin',
          drop_partials: false,
          customInterval: '2h',
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.tsc',
          size: '5',
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          language: 'lucene',
          query: ''
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-TSC-Requirements-Agents-heatmap',
  _type: 'visualization',
  _source: {
    title: 'TSC requirements heatmap',
    visState: JSON.stringify({
      title: 'TSC requirements heatmap',
      type: 'heatmap',
      params: {
        type: 'heatmap',
        addTooltip: true,
        addLegend: true,
        enableHover: false,
        legendPosition: 'right',
        times: [],
        colorsNumber: 10,
        colorSchema: 'Greens',
        setColorRange: false,
        colorsRange: [],
        invertColors: false,
        percentageMode: false,
        valueAxes: [{
          show: false,
          id: 'ValueAxis-1',
          type: 'value',
          scale: {
            type: 'linear',
            defaultYExtents: false
          },
          labels: {
            show: false,
            rotate: 0,
            overwriteColor: false,
            color: '#555'
          }
        }]
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.tsc',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirements'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'agent.name',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agents'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 13': 'rgb(247,252,245)',
          '13 - 26': 'rgb(233,247,228)',
          '26 - 39': 'rgb(211,238,205)',
          '39 - 52': 'rgb(184,227,177)',
          '52 - 65': 'rgb(152,213,148)',
          '65 - 78': 'rgb(116,196,118)',
          '78 - 91': 'rgb(75,176,98)',
          '91 - 104': 'rgb(47,152,79)',
          '104 - 117': 'rgb(21,127,59)',
          '117 - 130': 'rgb(0,100,40)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-TSC-requirements',
  _source: {
    title: 'TSC requirements',
    visState: JSON.stringify({
      title: 'TSC requirements',
      type: 'line',
      params: {
        type: 'line',
        grid: {
          categoryLines: true,
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: false,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'date',
              params: {
                pattern: 'YYYY-MM-DD'
              }
            },
            params: {
              date: true,
              interval: 'P1D',
              format: 'YYYY-MM-DD'
            },
            aggType: 'date_histogram'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          z: [{
            accessor: 3,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        },
        radiusRatio: 50
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-1h',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.tsc',
          orderBy: '1',
          order: 'desc',
          size: 50,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'count',
        schema: 'radius',
        params: {}
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-TSC-Agents',
  _source: {
    title: 'Agents',
    visState: JSON.stringify({
      title: 'Agents',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: false
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'agent.name',
          size: 10,
          order: 'desc',
          orderBy: '1'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-TSC-Requirements-by-agent',
  _source: {
    title: 'Requirements by agent',
    visState: JSON.stringify({
      title: 'Requirements by agent',
      type: 'histogram',
      params: {
        type: 'histogram',
        grid: {
          categoryLines: false,
          style: {
            color: '#eee'
          }
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100,
            rotate: 0
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        radiusRatio: 51
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.tsc',
          size: 5,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Requirements'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'agent.name',
          size: 5,
          order: 'desc',
          orderBy: '1'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-TSC-Last-alerts',
  _type: 'visualization',
  _source: {
    title: 'Last alerts',
    visState: JSON.stringify({
      title: 'Last alerts',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMeticsAtAllLevels: false,
        sort: {
          columnIndex: null,
          direction: null
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'agent.name',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 50,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Agent name'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.tsc',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 10,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Requirement'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 10,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Rule description'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-TSC-Alerts-summary',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'Alerts summary',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMeticsAtAllLevels: false,
        sort: {
          columnIndex: 3,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'agent.name',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 50,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Agent name'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.tsc',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 10,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Requirement'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 10,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Rule description'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl9zb3VyY2UiLCJ0aXRsZSIsInZpc1N0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsInR5cGUiLCJwYXJhbXMiLCJncmlkIiwiY2F0ZWdvcnlMaW5lcyIsInN0eWxlIiwiY29sb3IiLCJ2YWx1ZUF4aXMiLCJjYXRlZ29yeUF4ZXMiLCJpZCIsInBvc2l0aW9uIiwic2hvdyIsInNjYWxlIiwibGFiZWxzIiwiZmlsdGVyIiwidHJ1bmNhdGUiLCJ2YWx1ZUF4ZXMiLCJuYW1lIiwibW9kZSIsInJvdGF0ZSIsInRleHQiLCJzZXJpZXNQYXJhbXMiLCJkYXRhIiwibGFiZWwiLCJkcmF3TGluZXNCZXR3ZWVuUG9pbnRzIiwic2hvd0NpcmNsZXMiLCJpbnRlcnBvbGF0ZSIsImFkZFRvb2x0aXAiLCJhZGRMZWdlbmQiLCJsZWdlbmRQb3NpdGlvbiIsInRpbWVzIiwiYWRkVGltZU1hcmtlciIsImFnZ3MiLCJlbmFibGVkIiwic2NoZW1hIiwiZmllbGQiLCJ0aW1lUmFuZ2UiLCJmcm9tIiwidG8iLCJ1c2VOb3JtYWxpemVkRXNJbnRlcnZhbCIsImludGVydmFsIiwidGltZV96b25lIiwiZHJvcF9wYXJ0aWFscyIsImN1c3RvbUludGVydmFsIiwibWluX2RvY19jb3VudCIsImV4dGVuZGVkX2JvdW5kcyIsInNpemUiLCJvcmRlciIsIm9yZGVyQnkiLCJvdGhlckJ1Y2tldCIsIm90aGVyQnVja2V0TGFiZWwiLCJtaXNzaW5nQnVja2V0IiwibWlzc2luZ0J1Y2tldExhYmVsIiwidWlTdGF0ZUpTT04iLCJkZXNjcmlwdGlvbiIsInZlcnNpb24iLCJraWJhbmFTYXZlZE9iamVjdE1ldGEiLCJzZWFyY2hTb3VyY2VKU09OIiwiaW5kZXgiLCJxdWVyeSIsImxhbmd1YWdlIiwiX3R5cGUiLCJlbmFibGVIb3ZlciIsImNvbG9yc051bWJlciIsImNvbG9yU2NoZW1hIiwic2V0Q29sb3JSYW5nZSIsImNvbG9yc1JhbmdlIiwiaW52ZXJ0Q29sb3JzIiwicGVyY2VudGFnZU1vZGUiLCJkZWZhdWx0WUV4dGVudHMiLCJvdmVyd3JpdGVDb2xvciIsImN1c3RvbUxhYmVsIiwidmlzIiwiZGVmYXVsdENvbG9ycyIsImRpbWVuc2lvbnMiLCJ4IiwiYWNjZXNzb3IiLCJmb3JtYXQiLCJwYXR0ZXJuIiwiZGF0ZSIsImFnZ1R5cGUiLCJ5IiwieiIsInNlcmllcyIsInJhZGl1c1JhdGlvIiwiaXNEb251dCIsInBlclBhZ2UiLCJzaG93UGFydGlhbFJvd3MiLCJzaG93TWV0aWNzQXRBbGxMZXZlbHMiLCJzb3J0IiwiY29sdW1uSW5kZXgiLCJkaXJlY3Rpb24iLCJzaG93VG90YWwiLCJzaG93VG9vbGJhciIsInRvdGFsRnVuYyIsImV4cG9ydHMiLCJkZWZhdWx0IiwibW9kdWxlIl0sInNvdXJjZXMiOlsib3ZlcnZpZXctdHNjLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBhcHAgLSBNb2R1bGUgZm9yIE92ZXJ2aWV3L1RTQyB2aXN1YWxpemF0aW9uc1xuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IFtcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1UU0MtUmVxdWlyZW1lbnRzLW92ZXItdGltZScsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdSZXF1aXJlbWVudHMgb3ZlciB0aW1lJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQWxlcnRzIGJ5IGFjdGlvbiBvdmVyIHRpbWUnLFxuICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdhcmVhJyxcbiAgICAgICAgICBncmlkOiB7IGNhdGVnb3J5TGluZXM6IHRydWUsIHN0eWxlOiB7IGNvbG9yOiAnI2VlZScgfSwgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnIH0sXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnQ2F0ZWdvcnlBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2JvdHRvbScsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIGZpbHRlcjogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnbGVmdCcsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicsIG1vZGU6ICdub3JtYWwnIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCByb3RhdGU6IDAsIGZpbHRlcjogZmFsc2UsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ0NvdW50JyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaG93OiAndHJ1ZScsXG4gICAgICAgICAgICAgIHR5cGU6ICdhcmVhJyxcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxuICAgICAgICAgICAgICBkYXRhOiB7IGxhYmVsOiAnQ291bnQnLCBpZDogJzEnIH0sXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgICBpbnRlcnBvbGF0ZTogJ2NhcmRpbmFsJyxcbiAgICAgICAgICAgICAgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAndGltZXN0YW1wJyxcbiAgICAgICAgICAgICAgdGltZVJhbmdlOiB7IGZyb206ICdub3ctMjRoJywgdG86ICdub3cnLCBtb2RlOiAncXVpY2snIH0sXG4gICAgICAgICAgICAgIHVzZU5vcm1hbGl6ZWRFc0ludGVydmFsOiB0cnVlLFxuICAgICAgICAgICAgICBpbnRlcnZhbDogJ2F1dG8nLFxuICAgICAgICAgICAgICB0aW1lX3pvbmU6ICdFdXJvcGUvQmVybGluJyxcbiAgICAgICAgICAgICAgZHJvcF9wYXJ0aWFsczogZmFsc2UsXG4gICAgICAgICAgICAgIGN1c3RvbUludGVydmFsOiAnMmgnLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUudHNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogJzUnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IGxhbmd1YWdlOiAnbHVjZW5lJywgcXVlcnk6ICcnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctVFNDLVJlcXVpcmVtZW50cy1BZ2VudHMtaGVhdG1hcCcsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1RTQyByZXF1aXJlbWVudHMgaGVhdG1hcCcsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1RTQyByZXF1aXJlbWVudHMgaGVhdG1hcCcsXG4gICAgICAgIHR5cGU6ICdoZWF0bWFwJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ2hlYXRtYXAnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGVuYWJsZUhvdmVyOiBmYWxzZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgY29sb3JzTnVtYmVyOiAxMCxcbiAgICAgICAgICBjb2xvclNjaGVtYTogJ0dyZWVucycsXG4gICAgICAgICAgc2V0Q29sb3JSYW5nZTogZmFsc2UsXG4gICAgICAgICAgY29sb3JzUmFuZ2U6IFtdLFxuICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgcGVyY2VudGFnZU1vZGU6IGZhbHNlLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBkZWZhdWx0WUV4dGVudHM6IGZhbHNlIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiBmYWxzZSwgcm90YXRlOiAwLCBvdmVyd3JpdGVDb2xvcjogZmFsc2UsIGNvbG9yOiAnIzU1NScgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS50c2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1JlcXVpcmVtZW50cycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnYWdlbnQubmFtZScsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnQWdlbnRzJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdmlzOiB7XG4gICAgICAgICAgZGVmYXVsdENvbG9yczoge1xuICAgICAgICAgICAgJzAgLSAxMyc6ICdyZ2IoMjQ3LDI1MiwyNDUpJyxcbiAgICAgICAgICAgICcxMyAtIDI2JzogJ3JnYigyMzMsMjQ3LDIyOCknLFxuICAgICAgICAgICAgJzI2IC0gMzknOiAncmdiKDIxMSwyMzgsMjA1KScsXG4gICAgICAgICAgICAnMzkgLSA1Mic6ICdyZ2IoMTg0LDIyNywxNzcpJyxcbiAgICAgICAgICAgICc1MiAtIDY1JzogJ3JnYigxNTIsMjEzLDE0OCknLFxuICAgICAgICAgICAgJzY1IC0gNzgnOiAncmdiKDExNiwxOTYsMTE4KScsXG4gICAgICAgICAgICAnNzggLSA5MSc6ICdyZ2IoNzUsMTc2LDk4KScsXG4gICAgICAgICAgICAnOTEgLSAxMDQnOiAncmdiKDQ3LDE1Miw3OSknLFxuICAgICAgICAgICAgJzEwNCAtIDExNyc6ICdyZ2IoMjEsMTI3LDU5KScsXG4gICAgICAgICAgICAnMTE3IC0gMTMwJzogJ3JnYigwLDEwMCw0MCknLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LVRTQy1yZXF1aXJlbWVudHMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVFNDIHJlcXVpcmVtZW50cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1RTQyByZXF1aXJlbWVudHMnLFxuICAgICAgICB0eXBlOiAnbGluZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdsaW5lJyxcbiAgICAgICAgICBncmlkOiB7IGNhdGVnb3J5TGluZXM6IHRydWUsIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgcm90YXRlOiAwLCBmaWx0ZXI6IGZhbHNlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdDb3VudCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogJ3RydWUnLFxuICAgICAgICAgICAgICB0eXBlOiAnbGluZScsXG4gICAgICAgICAgICAgIG1vZGU6ICdub3JtYWwnLFxuICAgICAgICAgICAgICBkYXRhOiB7IGxhYmVsOiAnQ291bnQnLCBpZDogJzEnIH0sXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogZmFsc2UsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICB4OiB7XG4gICAgICAgICAgICAgIGFjY2Vzc29yOiAwLFxuICAgICAgICAgICAgICBmb3JtYXQ6IHsgaWQ6ICdkYXRlJywgcGFyYW1zOiB7IHBhdHRlcm46ICdZWVlZLU1NLUREJyB9IH0sXG4gICAgICAgICAgICAgIHBhcmFtczogeyBkYXRlOiB0cnVlLCBpbnRlcnZhbDogJ1AxRCcsIGZvcm1hdDogJ1lZWVktTU0tREQnIH0sXG4gICAgICAgICAgICAgIGFnZ1R5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgeTogW3sgYWNjZXNzb3I6IDIsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9XSxcbiAgICAgICAgICAgIHo6IFt7IGFjY2Vzc29yOiAzLCBmb3JtYXQ6IHsgaWQ6ICdudW1iZXInIH0sIHBhcmFtczoge30sIGFnZ1R5cGU6ICdjb3VudCcgfV0sXG4gICAgICAgICAgICBzZXJpZXM6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAxLFxuICAgICAgICAgICAgICAgIGZvcm1hdDoge1xuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6ICdzdHJpbmcnLFxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcmFkaXVzUmF0aW86IDUwLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnZGF0ZV9oaXN0b2dyYW0nLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICd0aW1lc3RhbXAnLFxuICAgICAgICAgICAgICB0aW1lUmFuZ2U6IHsgZnJvbTogJ25vdy0xaCcsIHRvOiAnbm93JyB9LFxuICAgICAgICAgICAgICB1c2VOb3JtYWxpemVkRXNJbnRlcnZhbDogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJ2YWw6ICdhdXRvJyxcbiAgICAgICAgICAgICAgZHJvcF9wYXJ0aWFsczogZmFsc2UsXG4gICAgICAgICAgICAgIG1pbl9kb2NfY291bnQ6IDEsXG4gICAgICAgICAgICAgIGV4dGVuZGVkX2JvdW5kczoge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS50c2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7IGlkOiAnNCcsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ3JhZGl1cycsIHBhcmFtczoge30gfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LVRTQy1BZ2VudHMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWdlbnRzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQWdlbnRzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHsgZmllbGQ6ICdhZ2VudC5uYW1lJywgc2l6ZTogMTAsIG9yZGVyOiAnZGVzYycsIG9yZGVyQnk6ICcxJyB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1UU0MtUmVxdWlyZW1lbnRzLWJ5LWFnZW50JyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1JlcXVpcmVtZW50cyBieSBhZ2VudCcsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1JlcXVpcmVtZW50cyBieSBhZ2VudCcsXG4gICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICBncmlkOiB7IGNhdGVnb3J5TGluZXM6IGZhbHNlLCBzdHlsZTogeyBjb2xvcjogJyNlZWUnIH0gfSxcbiAgICAgICAgICBjYXRlZ29yeUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdDYXRlZ29yeUF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICdjYXRlZ29yeScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgZmlsdGVyOiB0cnVlLCB0cnVuY2F0ZTogMTAwLCByb3RhdGU6IDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgcm90YXRlOiAwLCBmaWx0ZXI6IGZhbHNlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdDb3VudCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogJ3RydWUnLFxuICAgICAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxuICAgICAgICAgICAgICBkYXRhOiB7IGxhYmVsOiAnQ291bnQnLCBpZDogJzEnIH0sXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgc2hvd0NpcmNsZXM6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgdGltZXM6IFtdLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICAgIHJhZGl1c1JhdGlvOiA1MSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS50c2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUmVxdWlyZW1lbnRzJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdncm91cCcsXG4gICAgICAgICAgICBwYXJhbXM6IHsgZmllbGQ6ICdhZ2VudC5uYW1lJywgc2l6ZTogNSwgb3JkZXI6ICdkZXNjJywgb3JkZXJCeTogJzEnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LVRTQy1MYXN0LWFsZXJ0cycsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0xhc3QgYWxlcnRzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnTGFzdCBhbGVydHMnLFxuICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBwZXJQYWdlOiAxMCxcbiAgICAgICAgICBzaG93UGFydGlhbFJvd3M6IGZhbHNlLFxuICAgICAgICAgIHNob3dNZXRpY3NBdEFsbExldmVsczogZmFsc2UsXG4gICAgICAgICAgc29ydDogeyBjb2x1bW5JbmRleDogbnVsbCwgZGlyZWN0aW9uOiBudWxsIH0sXG4gICAgICAgICAgc2hvd1RvdGFsOiBmYWxzZSxcbiAgICAgICAgICBzaG93VG9vbGJhcjogdHJ1ZSxcbiAgICAgICAgICB0b3RhbEZ1bmM6ICdzdW0nLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2FnZW50Lm5hbWUnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgc2l6ZTogNTAsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBZ2VudCBuYW1lJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS50c2MnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSZXF1aXJlbWVudCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICc0JyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuZGVzY3JpcHRpb24nLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSdWxlIGRlc2NyaXB0aW9uJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdmlzOiB7IHBhcmFtczogeyBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9IH0gfSxcbiAgICAgIH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctVFNDLUFsZXJ0cy1zdW1tYXJ5JyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydHMgc3VtbWFyeScsXG4gICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDEwLFxuICAgICAgICAgIHNob3dQYXJ0aWFsUm93czogZmFsc2UsXG4gICAgICAgICAgc2hvd01ldGljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgc2hvd1Rvb2xiYXI6IHRydWUsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdhZ2VudC5uYW1lJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDUwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnQWdlbnQgbmFtZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUudHNjJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUmVxdWlyZW1lbnQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmRlc2NyaXB0aW9uJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUnVsZSBkZXNjcmlwdGlvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuXTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVZBLElBQUFBLFFBQUEsR0FXZSxDQUNiO0VBQ0VDLEdBQUcsRUFBRSwrQ0FBK0M7RUFDcERDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsd0JBQXdCO0lBQy9CQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsNEJBQTRCO01BQ25DSSxJQUFJLEVBQUUsTUFBTTtNQUNaQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLE1BQU07UUFDWkUsSUFBSSxFQUFFO1VBQUVDLGFBQWEsRUFBRSxJQUFJO1VBQUVDLEtBQUssRUFBRTtZQUFFQyxLQUFLLEVBQUU7VUFBTyxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFjLENBQUM7UUFDakZDLFlBQVksRUFBRSxDQUNaO1VBQ0VDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJSLElBQUksRUFBRSxVQUFVO1VBQ2hCUyxRQUFRLEVBQUUsUUFBUTtVQUNsQkMsSUFBSSxFQUFFLElBQUk7VUFDVk4sS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTyxLQUFLLEVBQUU7WUFBRVgsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6QlksTUFBTSxFQUFFO1lBQUVGLElBQUksRUFBRSxJQUFJO1lBQUVHLE1BQU0sRUFBRSxJQUFJO1lBQUVDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDbkRsQixLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEbUIsU0FBUyxFQUFFLENBQ1Q7VUFDRVAsRUFBRSxFQUFFLGFBQWE7VUFDakJRLElBQUksRUFBRSxZQUFZO1VBQ2xCaEIsSUFBSSxFQUFFLE9BQU87VUFDYlMsUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZOLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVE8sS0FBSyxFQUFFO1lBQUVYLElBQUksRUFBRSxRQUFRO1lBQUVpQixJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pDTCxNQUFNLEVBQUU7WUFBRUYsSUFBSSxFQUFFLElBQUk7WUFBRVEsTUFBTSxFQUFFLENBQUM7WUFBRUwsTUFBTSxFQUFFLEtBQUs7WUFBRUMsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUMvRGxCLEtBQUssRUFBRTtZQUFFdUIsSUFBSSxFQUFFO1VBQVE7UUFDekIsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0VWLElBQUksRUFBRSxNQUFNO1VBQ1pWLElBQUksRUFBRSxNQUFNO1VBQ1ppQixJQUFJLEVBQUUsU0FBUztVQUNmSSxJQUFJLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRWQsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQ2Usc0JBQXNCLEVBQUUsSUFBSTtVQUM1QkMsV0FBVyxFQUFFLElBQUk7VUFDakJDLFdBQVcsRUFBRSxVQUFVO1VBQ3ZCbkIsU0FBUyxFQUFFO1FBQ2IsQ0FBQyxDQUNGO1FBQ0RvQixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJDLEtBQUssRUFBRSxFQUFFO1FBQ1RDLGFBQWEsRUFBRTtNQUNqQixDQUFDO01BQ0RDLElBQUksRUFBRSxDQUNKO1FBQUV2QixFQUFFLEVBQUUsR0FBRztRQUFFd0IsT0FBTyxFQUFFLElBQUk7UUFBRWhDLElBQUksRUFBRSxPQUFPO1FBQUVpQyxNQUFNLEVBQUUsUUFBUTtRQUFFaEMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VPLEVBQUUsRUFBRSxHQUFHO1FBQ1B3QixPQUFPLEVBQUUsSUFBSTtRQUNiaEMsSUFBSSxFQUFFLGdCQUFnQjtRQUN0QmlDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCaEMsTUFBTSxFQUFFO1VBQ05pQyxLQUFLLEVBQUUsV0FBVztVQUNsQkMsU0FBUyxFQUFFO1lBQUVDLElBQUksRUFBRSxTQUFTO1lBQUVDLEVBQUUsRUFBRSxLQUFLO1lBQUVwQixJQUFJLEVBQUU7VUFBUSxDQUFDO1VBQ3hEcUIsdUJBQXVCLEVBQUUsSUFBSTtVQUM3QkMsUUFBUSxFQUFFLE1BQU07VUFDaEJDLFNBQVMsRUFBRSxlQUFlO1VBQzFCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsY0FBYyxFQUFFLElBQUk7VUFDcEJDLGFBQWEsRUFBRSxDQUFDO1VBQ2hCQyxlQUFlLEVBQUUsQ0FBQztRQUNwQjtNQUNGLENBQUMsRUFDRDtRQUNFcEMsRUFBRSxFQUFFLEdBQUc7UUFDUHdCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLE9BQU87UUFDZmhDLE1BQU0sRUFBRTtVQUNOaUMsS0FBSyxFQUFFLFVBQVU7VUFDakJXLElBQUksRUFBRSxHQUFHO1VBQ1RDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEI7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZDLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUUxRCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjBELEtBQUssRUFBRSxjQUFjO1FBQ3JCNUMsTUFBTSxFQUFFLEVBQUU7UUFDVjZDLEtBQUssRUFBRTtVQUFFQyxRQUFRLEVBQUUsUUFBUTtVQUFFRCxLQUFLLEVBQUU7UUFBRztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RFLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFbEUsR0FBRyxFQUFFLG9EQUFvRDtFQUN6RGtFLEtBQUssRUFBRSxlQUFlO0VBQ3RCakUsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSwwQkFBMEI7SUFDakNDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSwwQkFBMEI7TUFDakNJLElBQUksRUFBRSxTQUFTO01BQ2ZDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsU0FBUztRQUNmMEIsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZrQyxXQUFXLEVBQUUsS0FBSztRQUNsQmpDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUaUMsWUFBWSxFQUFFLEVBQUU7UUFDaEJDLFdBQVcsRUFBRSxRQUFRO1FBQ3JCQyxhQUFhLEVBQUUsS0FBSztRQUNwQkMsV0FBVyxFQUFFLEVBQUU7UUFDZkMsWUFBWSxFQUFFLEtBQUs7UUFDbkJDLGNBQWMsRUFBRSxLQUFLO1FBQ3JCcEQsU0FBUyxFQUFFLENBQ1Q7VUFDRUwsSUFBSSxFQUFFLEtBQUs7VUFDWEYsRUFBRSxFQUFFLGFBQWE7VUFDakJSLElBQUksRUFBRSxPQUFPO1VBQ2JXLEtBQUssRUFBRTtZQUFFWCxJQUFJLEVBQUUsUUFBUTtZQUFFb0UsZUFBZSxFQUFFO1VBQU0sQ0FBQztVQUNqRHhELE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsS0FBSztZQUFFUSxNQUFNLEVBQUUsQ0FBQztZQUFFbUQsY0FBYyxFQUFFLEtBQUs7WUFBRWhFLEtBQUssRUFBRTtVQUFPO1FBQ3pFLENBQUM7TUFFTCxDQUFDO01BQ0QwQixJQUFJLEVBQUUsQ0FDSjtRQUFFdkIsRUFBRSxFQUFFLEdBQUc7UUFBRXdCLE9BQU8sRUFBRSxJQUFJO1FBQUVoQyxJQUFJLEVBQUUsT0FBTztRQUFFaUMsTUFBTSxFQUFFLFFBQVE7UUFBRWhDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFTyxFQUFFLEVBQUUsR0FBRztRQUNQd0IsT0FBTyxFQUFFLElBQUk7UUFDYmhDLElBQUksRUFBRSxPQUFPO1FBQ2JpQyxNQUFNLEVBQUUsU0FBUztRQUNqQmhDLE1BQU0sRUFBRTtVQUNOaUMsS0FBSyxFQUFFLFVBQVU7VUFDakJXLElBQUksRUFBRSxDQUFDO1VBQ1BDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qm1CLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0U5RCxFQUFFLEVBQUUsR0FBRztRQUNQd0IsT0FBTyxFQUFFLElBQUk7UUFDYmhDLElBQUksRUFBRSxPQUFPO1FBQ2JpQyxNQUFNLEVBQUUsT0FBTztRQUNmaEMsTUFBTSxFQUFFO1VBQ05pQyxLQUFLLEVBQUUsWUFBWTtVQUNuQlcsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCbUIsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZsQixXQUFXLEVBQUV0RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUMxQndFLEdBQUcsRUFBRTtRQUNIQyxhQUFhLEVBQUU7VUFDYixRQUFRLEVBQUUsa0JBQWtCO1VBQzVCLFNBQVMsRUFBRSxrQkFBa0I7VUFDN0IsU0FBUyxFQUFFLGtCQUFrQjtVQUM3QixTQUFTLEVBQUUsa0JBQWtCO1VBQzdCLFNBQVMsRUFBRSxrQkFBa0I7VUFDN0IsU0FBUyxFQUFFLGtCQUFrQjtVQUM3QixTQUFTLEVBQUUsZ0JBQWdCO1VBQzNCLFVBQVUsRUFBRSxnQkFBZ0I7VUFDNUIsV0FBVyxFQUFFLGdCQUFnQjtVQUM3QixXQUFXLEVBQUU7UUFDZjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0ZuQixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUUxRCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjBELEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVMsQ0FBQztRQUN4QzlDLE1BQU0sRUFBRTtNQUNWLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0VuQixHQUFHLEVBQUUscUNBQXFDO0VBQzFDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGtCQUFrQjtJQUN6QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGtCQUFrQjtNQUN6QkksSUFBSSxFQUFFLE1BQU07TUFDWkMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxNQUFNO1FBQ1pFLElBQUksRUFBRTtVQUFFQyxhQUFhLEVBQUUsSUFBSTtVQUFFRyxTQUFTLEVBQUU7UUFBYyxDQUFDO1FBQ3ZEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFQyxFQUFFLEVBQUUsZ0JBQWdCO1VBQ3BCUixJQUFJLEVBQUUsVUFBVTtVQUNoQlMsUUFBUSxFQUFFLFFBQVE7VUFDbEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZOLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVE8sS0FBSyxFQUFFO1lBQUVYLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekJZLE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsSUFBSTtZQUFFRyxNQUFNLEVBQUUsSUFBSTtZQUFFQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQ25EbEIsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRG1CLFNBQVMsRUFBRSxDQUNUO1VBQ0VQLEVBQUUsRUFBRSxhQUFhO1VBQ2pCUSxJQUFJLEVBQUUsWUFBWTtVQUNsQmhCLElBQUksRUFBRSxPQUFPO1VBQ2JTLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTixLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RPLEtBQUssRUFBRTtZQUFFWCxJQUFJLEVBQUUsUUFBUTtZQUFFaUIsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6Q0wsTUFBTSxFQUFFO1lBQUVGLElBQUksRUFBRSxJQUFJO1lBQUVRLE1BQU0sRUFBRSxDQUFDO1lBQUVMLE1BQU0sRUFBRSxLQUFLO1lBQUVDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDL0RsQixLQUFLLEVBQUU7WUFBRXVCLElBQUksRUFBRTtVQUFRO1FBQ3pCLENBQUMsQ0FDRjtRQUNEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFVixJQUFJLEVBQUUsTUFBTTtVQUNaVixJQUFJLEVBQUUsTUFBTTtVQUNaaUIsSUFBSSxFQUFFLFFBQVE7VUFDZEksSUFBSSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVkLEVBQUUsRUFBRTtVQUFJLENBQUM7VUFDakNGLFNBQVMsRUFBRSxhQUFhO1VBQ3hCaUIsc0JBQXNCLEVBQUUsS0FBSztVQUM3QkMsV0FBVyxFQUFFO1FBQ2YsQ0FBQyxDQUNGO1FBQ0RFLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QkMsS0FBSyxFQUFFLEVBQUU7UUFDVEMsYUFBYSxFQUFFLEtBQUs7UUFDcEIyQyxVQUFVLEVBQUU7VUFDVkMsQ0FBQyxFQUFFO1lBQ0RDLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUFFcEUsRUFBRSxFQUFFLE1BQU07Y0FBRVAsTUFBTSxFQUFFO2dCQUFFNEUsT0FBTyxFQUFFO2NBQWE7WUFBRSxDQUFDO1lBQ3pENUUsTUFBTSxFQUFFO2NBQUU2RSxJQUFJLEVBQUUsSUFBSTtjQUFFdkMsUUFBUSxFQUFFLEtBQUs7Y0FBRXFDLE1BQU0sRUFBRTtZQUFhLENBQUM7WUFDN0RHLE9BQU8sRUFBRTtVQUNYLENBQUM7VUFDREMsQ0FBQyxFQUFFLENBQUM7WUFBRUwsUUFBUSxFQUFFLENBQUM7WUFBRUMsTUFBTSxFQUFFO2NBQUVwRSxFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVQLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRThFLE9BQU8sRUFBRTtVQUFRLENBQUMsQ0FBQztVQUM1RUUsQ0FBQyxFQUFFLENBQUM7WUFBRU4sUUFBUSxFQUFFLENBQUM7WUFBRUMsTUFBTSxFQUFFO2NBQUVwRSxFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVQLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRThFLE9BQU8sRUFBRTtVQUFRLENBQUMsQ0FBQztVQUM1RUcsTUFBTSxFQUFFLENBQ047WUFDRVAsUUFBUSxFQUFFLENBQUM7WUFDWEMsTUFBTSxFQUFFO2NBQ05wRSxFQUFFLEVBQUUsT0FBTztjQUNYUCxNQUFNLEVBQUU7Z0JBQ05PLEVBQUUsRUFBRSxRQUFRO2dCQUNaeUMsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJFLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNEbEQsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWOEUsT0FBTyxFQUFFO1VBQ1gsQ0FBQztRQUVMLENBQUM7UUFDREksV0FBVyxFQUFFO01BQ2YsQ0FBQztNQUNEcEQsSUFBSSxFQUFFLENBQ0o7UUFBRXZCLEVBQUUsRUFBRSxHQUFHO1FBQUV3QixPQUFPLEVBQUUsSUFBSTtRQUFFaEMsSUFBSSxFQUFFLE9BQU87UUFBRWlDLE1BQU0sRUFBRSxRQUFRO1FBQUVoQyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRU8sRUFBRSxFQUFFLEdBQUc7UUFDUHdCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsZ0JBQWdCO1FBQ3RCaUMsTUFBTSxFQUFFLFNBQVM7UUFDakJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxXQUFXO1VBQ2xCQyxTQUFTLEVBQUU7WUFBRUMsSUFBSSxFQUFFLFFBQVE7WUFBRUMsRUFBRSxFQUFFO1VBQU0sQ0FBQztVQUN4Q0MsdUJBQXVCLEVBQUUsSUFBSTtVQUM3QkMsUUFBUSxFQUFFLE1BQU07VUFDaEJFLGFBQWEsRUFBRSxLQUFLO1VBQ3BCRSxhQUFhLEVBQUUsQ0FBQztVQUNoQkMsZUFBZSxFQUFFLENBQUM7UUFDcEI7TUFDRixDQUFDLEVBQ0Q7UUFDRXBDLEVBQUUsRUFBRSxHQUFHO1FBQ1B3QixPQUFPLEVBQUUsSUFBSTtRQUNiaEMsSUFBSSxFQUFFLE9BQU87UUFDYmlDLE1BQU0sRUFBRSxPQUFPO1FBQ2ZoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxVQUFVO1VBQ2pCYSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsRUFBRTtVQUNSRyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQyxFQUNEO1FBQUUzQyxFQUFFLEVBQUUsR0FBRztRQUFFd0IsT0FBTyxFQUFFLElBQUk7UUFBRWhDLElBQUksRUFBRSxPQUFPO1FBQUVpQyxNQUFNLEVBQUUsUUFBUTtRQUFFaEMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDO0lBRTNFLENBQUMsQ0FBQztJQUNGbUQsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTFELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CMEQsS0FBSyxFQUFFLGNBQWM7UUFDckI1QyxNQUFNLEVBQUUsRUFBRTtRQUNWNkMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VsRSxHQUFHLEVBQUUsK0JBQStCO0VBQ3BDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLFFBQVE7SUFDZkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLFFBQVE7TUFDZkksSUFBSSxFQUFFLEtBQUs7TUFDWEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1gwQixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJ3RCxPQUFPLEVBQUU7TUFDWCxDQUFDO01BQ0RyRCxJQUFJLEVBQUUsQ0FDSjtRQUFFdkIsRUFBRSxFQUFFLEdBQUc7UUFBRXdCLE9BQU8sRUFBRSxJQUFJO1FBQUVoQyxJQUFJLEVBQUUsT0FBTztRQUFFaUMsTUFBTSxFQUFFLFFBQVE7UUFBRWhDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFTyxFQUFFLEVBQUUsR0FBRztRQUNQd0IsT0FBTyxFQUFFLElBQUk7UUFDYmhDLElBQUksRUFBRSxPQUFPO1FBQ2JpQyxNQUFNLEVBQUUsU0FBUztRQUNqQmhDLE1BQU0sRUFBRTtVQUFFaUMsS0FBSyxFQUFFLFlBQVk7VUFBRVcsSUFBSSxFQUFFLEVBQUU7VUFBRUMsS0FBSyxFQUFFLE1BQU07VUFBRUMsT0FBTyxFQUFFO1FBQUk7TUFDdkUsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGSyxXQUFXLEVBQUUsSUFBSTtJQUNqQkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFMUQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0IwRCxLQUFLLEVBQUUsY0FBYztRQUNyQjVDLE1BQU0sRUFBRSxFQUFFO1FBQ1Y2QyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRWxFLEdBQUcsRUFBRSw4Q0FBOEM7RUFDbkRDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsdUJBQXVCO0lBQzlCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsdUJBQXVCO01BQzlCSSxJQUFJLEVBQUUsV0FBVztNQUNqQkMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxXQUFXO1FBQ2pCRSxJQUFJLEVBQUU7VUFBRUMsYUFBYSxFQUFFLEtBQUs7VUFBRUMsS0FBSyxFQUFFO1lBQUVDLEtBQUssRUFBRTtVQUFPO1FBQUUsQ0FBQztRQUN4REUsWUFBWSxFQUFFLENBQ1o7VUFDRUMsRUFBRSxFQUFFLGdCQUFnQjtVQUNwQlIsSUFBSSxFQUFFLFVBQVU7VUFDaEJTLFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTixLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RPLEtBQUssRUFBRTtZQUFFWCxJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pCWSxNQUFNLEVBQUU7WUFBRUYsSUFBSSxFQUFFLElBQUk7WUFBRUcsTUFBTSxFQUFFLElBQUk7WUFBRUMsUUFBUSxFQUFFLEdBQUc7WUFBRUksTUFBTSxFQUFFO1VBQUUsQ0FBQztVQUM5RHRCLEtBQUssRUFBRSxDQUFDO1FBQ1YsQ0FBQyxDQUNGO1FBQ0RtQixTQUFTLEVBQUUsQ0FDVDtVQUNFUCxFQUFFLEVBQUUsYUFBYTtVQUNqQlEsSUFBSSxFQUFFLFlBQVk7VUFDbEJoQixJQUFJLEVBQUUsT0FBTztVQUNiUyxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsSUFBSSxFQUFFLElBQUk7VUFDVk4sS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTyxLQUFLLEVBQUU7WUFBRVgsSUFBSSxFQUFFLFFBQVE7WUFBRWlCLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekNMLE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsSUFBSTtZQUFFUSxNQUFNLEVBQUUsQ0FBQztZQUFFTCxNQUFNLEVBQUUsS0FBSztZQUFFQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQy9EbEIsS0FBSyxFQUFFO1lBQUV1QixJQUFJLEVBQUU7VUFBUTtRQUN6QixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVYsSUFBSSxFQUFFLE1BQU07VUFDWlYsSUFBSSxFQUFFLFdBQVc7VUFDakJpQixJQUFJLEVBQUUsU0FBUztVQUNmSSxJQUFJLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRWQsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQ0YsU0FBUyxFQUFFLGFBQWE7VUFDeEJpQixzQkFBc0IsRUFBRSxJQUFJO1VBQzVCQyxXQUFXLEVBQUU7UUFDZixDQUFDLENBQ0Y7UUFDREUsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQnFELFdBQVcsRUFBRTtNQUNmLENBQUM7TUFDRHBELElBQUksRUFBRSxDQUNKO1FBQUV2QixFQUFFLEVBQUUsR0FBRztRQUFFd0IsT0FBTyxFQUFFLElBQUk7UUFBRWhDLElBQUksRUFBRSxPQUFPO1FBQUVpQyxNQUFNLEVBQUUsUUFBUTtRQUFFaEMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VPLEVBQUUsRUFBRSxHQUFHO1FBQ1B3QixPQUFPLEVBQUUsSUFBSTtRQUNiaEMsSUFBSSxFQUFFLE9BQU87UUFDYmlDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCaEMsTUFBTSxFQUFFO1VBQ05pQyxLQUFLLEVBQUUsVUFBVTtVQUNqQlcsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWnVCLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0U5RCxFQUFFLEVBQUUsR0FBRztRQUNQd0IsT0FBTyxFQUFFLElBQUk7UUFDYmhDLElBQUksRUFBRSxPQUFPO1FBQ2JpQyxNQUFNLEVBQUUsT0FBTztRQUNmaEMsTUFBTSxFQUFFO1VBQUVpQyxLQUFLLEVBQUUsWUFBWTtVQUFFVyxJQUFJLEVBQUUsQ0FBQztVQUFFQyxLQUFLLEVBQUUsTUFBTTtVQUFFQyxPQUFPLEVBQUU7UUFBSTtNQUN0RSxDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZLLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUUxRCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjBELEtBQUssRUFBRSxjQUFjO1FBQ3JCNUMsTUFBTSxFQUFFLEVBQUU7UUFDVjZDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFbEUsR0FBRyxFQUFFLG9DQUFvQztFQUN6Q2tFLEtBQUssRUFBRSxlQUFlO0VBQ3RCakUsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxhQUFhO0lBQ3BCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsYUFBYTtNQUNwQkksSUFBSSxFQUFFLE9BQU87TUFDYkMsTUFBTSxFQUFFO1FBQ05vRixPQUFPLEVBQUUsRUFBRTtRQUNYQyxlQUFlLEVBQUUsS0FBSztRQUN0QkMscUJBQXFCLEVBQUUsS0FBSztRQUM1QkMsSUFBSSxFQUFFO1VBQUVDLFdBQVcsRUFBRSxJQUFJO1VBQUVDLFNBQVMsRUFBRTtRQUFLLENBQUM7UUFDNUNDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsU0FBUyxFQUFFO01BQ2IsQ0FBQztNQUNEOUQsSUFBSSxFQUFFLENBQ0o7UUFBRXZCLEVBQUUsRUFBRSxHQUFHO1FBQUV3QixPQUFPLEVBQUUsSUFBSTtRQUFFaEMsSUFBSSxFQUFFLE9BQU87UUFBRWlDLE1BQU0sRUFBRSxRQUFRO1FBQUVoQyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRU8sRUFBRSxFQUFFLEdBQUc7UUFDUHdCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxZQUFZO1VBQ25CYyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JOLElBQUksRUFBRSxFQUFFO1VBQ1JDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1p1QixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFOUQsRUFBRSxFQUFFLEdBQUc7UUFDUHdCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxVQUFVO1VBQ2pCYyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JOLElBQUksRUFBRSxFQUFFO1VBQ1JDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1p1QixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFOUQsRUFBRSxFQUFFLEdBQUc7UUFDUHdCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxrQkFBa0I7VUFDekJjLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qk4sSUFBSSxFQUFFLEVBQUU7VUFDUkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWnVCLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGbEIsV0FBVyxFQUFFdEQsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUJ3RSxHQUFHLEVBQUU7UUFBRXRFLE1BQU0sRUFBRTtVQUFFdUYsSUFBSSxFQUFFO1lBQUVDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLFNBQVMsRUFBRTtVQUFPO1FBQUU7TUFBRTtJQUNqRSxDQUFDLENBQUM7SUFDRnJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTFELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CMEQsS0FBSyxFQUFFLGNBQWM7UUFDckI1QyxNQUFNLEVBQUUsRUFBRTtRQUNWNkMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0VqRSxHQUFHLEVBQUUsdUNBQXVDO0VBQzVDa0UsS0FBSyxFQUFFLGVBQWU7RUFDdEJqRSxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGdCQUFnQjtNQUN2QkksSUFBSSxFQUFFLE9BQU87TUFDYkMsTUFBTSxFQUFFO1FBQ05vRixPQUFPLEVBQUUsRUFBRTtRQUNYQyxlQUFlLEVBQUUsS0FBSztRQUN0QkMscUJBQXFCLEVBQUUsS0FBSztRQUM1QkMsSUFBSSxFQUFFO1VBQUVDLFdBQVcsRUFBRSxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFPLENBQUM7UUFDM0NDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsU0FBUyxFQUFFO01BQ2IsQ0FBQztNQUNEOUQsSUFBSSxFQUFFLENBQ0o7UUFBRXZCLEVBQUUsRUFBRSxHQUFHO1FBQUV3QixPQUFPLEVBQUUsSUFBSTtRQUFFaEMsSUFBSSxFQUFFLE9BQU87UUFBRWlDLE1BQU0sRUFBRSxRQUFRO1FBQUVoQyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRU8sRUFBRSxFQUFFLEdBQUc7UUFDUHdCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxZQUFZO1VBQ25CYyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JOLElBQUksRUFBRSxFQUFFO1VBQ1JDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1p1QixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFOUQsRUFBRSxFQUFFLEdBQUc7UUFDUHdCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxVQUFVO1VBQ2pCYyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JOLElBQUksRUFBRSxFQUFFO1VBQ1JDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1p1QixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFOUQsRUFBRSxFQUFFLEdBQUc7UUFDUHdCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxrQkFBa0I7VUFDekJjLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qk4sSUFBSSxFQUFFLEVBQUU7VUFDUkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWnVCLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGbEIsV0FBVyxFQUFFdEQsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUJ3RSxHQUFHLEVBQUU7UUFBRXRFLE1BQU0sRUFBRTtVQUFFdUYsSUFBSSxFQUFFO1lBQUVDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLFNBQVMsRUFBRTtVQUFPO1FBQUU7TUFBRTtJQUNqRSxDQUFDLENBQUM7SUFDRnJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTFELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CMEQsS0FBSyxFQUFFLGNBQWM7UUFDckI1QyxNQUFNLEVBQUUsRUFBRTtRQUNWNkMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxDQUNGO0FBQUFtQyxPQUFBLENBQUFDLE9BQUEsR0FBQXRHLFFBQUE7QUFBQXVHLE1BQUEsQ0FBQUYsT0FBQSxHQUFBQSxPQUFBLENBQUFDLE9BQUEifQ==