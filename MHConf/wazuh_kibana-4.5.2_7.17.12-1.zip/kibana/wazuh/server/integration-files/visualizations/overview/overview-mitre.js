"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Overview MITRE visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Overview-MITRE',
  _source: {
    title: 'Mitre attack count',
    visState: JSON.stringify({
      aggs: [{
        enabled: true,
        id: '1',
        params: {},
        schema: 'metric',
        type: 'count'
      }, {
        enabled: true,
        id: '2',
        params: {
          field: 'rule.mitre.id',
          customLabel: 'Attack ID',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          size: 244
        },
        schema: 'bucket',
        type: 'terms'
      }],
      params: {
        dimensions: {
          buckets: [],
          metrics: [{
            accessor: 0,
            aggType: 'count',
            format: {
              id: 'number'
            },
            params: {}
          }]
        },
        perPage: 10,
        percentageCol: '',
        showMetricsAtAllLevels: false,
        showPartialRows: false,
        showTotal: false,
        showToolbar: true,
        sort: {
          columnIndex: null,
          direction: null
        },
        totalFunc: 'sum'
      },
      title: 'mitre',
      type: 'table'
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          language: 'lucene',
          query: ''
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-MITRE-Alerts-Evolution',
  _source: {
    title: 'Mitre alerts evolution',
    visState: JSON.stringify({
      title: 'Alert Evolution',
      type: 'line',
      params: {
        type: 'line',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          showCircles: true,
          lineWidth: 2
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {},
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#34130C'
        },
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'date',
              params: {
                pattern: 'YYYY-MM-DD HH:mm'
              }
            },
            params: {
              date: true,
              interval: 'PT3H',
              format: 'YYYY-MM-DD HH:mm',
              bounds: {
                min: '2019-11-07T15:45:45.770Z',
                max: '2019-11-14T15:45:45.770Z'
              }
            },
            aggType: 'date_histogram'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-7d',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.mitre.technique',
          customLabel: 'Attack ID',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          language: 'lucene',
          query: ''
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-MITRE-Attacks-By-Agent',
  _source: {
    title: 'Mitre techniques by agent',
    visState: JSON.stringify({
      title: 'attack by agent',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        dimensions: {
          metric: {
            accessor: 0,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'agent.name',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.mitre.technique',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          language: 'lucene',
          query: ''
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-MITRE-Attacks-By-Technique',
  _source: {
    title: 'Attacks by technique',
    visState: JSON.stringify({
      title: 'Attacks by tactic',
      type: 'histogram',
      params: {
        type: 'histogram',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {
          show: false
        },
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#34130C'
        },
        dimensions: {
          x: null,
          y: [{
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.mitre.technique',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.mitre.tactic',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          language: 'lucene',
          query: ''
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-MITRE-Top-Tactics-By-Agent',
  _source: {
    title: 'Top tactics by agent',
    visState: JSON.stringify({
      title: 'Top tactics by agent - vertical',
      type: 'area',
      params: {
        addLegend: true,
        addTimeMarker: false,
        addTooltip: true,
        categoryAxes: [{
          id: 'CategoryAxis-1',
          labels: {
            filter: true,
            show: true,
            truncate: 10
          },
          position: 'bottom',
          scale: {
            type: 'linear'
          },
          show: true,
          style: {},
          title: {},
          type: 'category'
        }],
        dimensions: {
          x: {
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        },
        grid: {
          categoryLines: false,
          valueAxis: 'ValueAxis-1'
        },
        labels: {},
        legendPosition: 'right',
        seriesParams: [{
          data: {
            id: '1',
            label: 'Count'
          },
          drawLinesBetweenPoints: true,
          interpolate: 'linear',
          mode: 'normal',
          show: 'true',
          showCircles: true,
          type: 'histogram',
          valueAxis: 'ValueAxis-1'
        }],
        thresholdLine: {
          color: '#34130C',
          show: false,
          style: 'full',
          value: 10,
          width: 1
        },
        times: [],
        type: 'area',
        valueAxes: [{
          id: 'ValueAxis-1',
          labels: {
            filter: false,
            rotate: 0,
            show: true,
            truncate: 100
          },
          name: 'LeftAxis-1',
          position: 'left',
          scale: {
            mode: 'normal',
            type: 'linear'
          },
          show: true,
          style: {},
          title: {
            text: 'Count'
          },
          type: 'value'
        }]
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.mitre.tactic',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'agent.name',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          language: 'lucene',
          query: ''
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-MITRE-Top-Tactics',
  _source: {
    title: 'Top tactics',
    visState: JSON.stringify({
      title: 'Top tactics PIE2',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: false,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.mitre.tactic',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          language: 'lucene',
          query: ''
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-MITRE-Alerts-summary',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'Alerts summary',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMeticsAtAllLevels: false,
        sort: {
          columnIndex: 3,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.id',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 50,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Rule ID'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 20,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Description'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.level',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 12,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Level'
        }
      }]
    }),
    uiStateJSON: '{"vis":{"params":{"sort":{"columnIndex":3,"direction":"desc"}}}}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl9zb3VyY2UiLCJ0aXRsZSIsInZpc1N0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsImFnZ3MiLCJlbmFibGVkIiwiaWQiLCJwYXJhbXMiLCJzY2hlbWEiLCJ0eXBlIiwiZmllbGQiLCJjdXN0b21MYWJlbCIsIm1pc3NpbmdCdWNrZXQiLCJtaXNzaW5nQnVja2V0TGFiZWwiLCJvcmRlciIsIm9yZGVyQnkiLCJvdGhlckJ1Y2tldCIsIm90aGVyQnVja2V0TGFiZWwiLCJzaXplIiwiZGltZW5zaW9ucyIsImJ1Y2tldHMiLCJtZXRyaWNzIiwiYWNjZXNzb3IiLCJhZ2dUeXBlIiwiZm9ybWF0IiwicGVyUGFnZSIsInBlcmNlbnRhZ2VDb2wiLCJzaG93TWV0cmljc0F0QWxsTGV2ZWxzIiwic2hvd1BhcnRpYWxSb3dzIiwic2hvd1RvdGFsIiwic2hvd1Rvb2xiYXIiLCJzb3J0IiwiY29sdW1uSW5kZXgiLCJkaXJlY3Rpb24iLCJ0b3RhbEZ1bmMiLCJ1aVN0YXRlSlNPTiIsImRlc2NyaXB0aW9uIiwidmVyc2lvbiIsImtpYmFuYVNhdmVkT2JqZWN0TWV0YSIsInNlYXJjaFNvdXJjZUpTT04iLCJpbmRleCIsImZpbHRlciIsInF1ZXJ5IiwibGFuZ3VhZ2UiLCJfdHlwZSIsImdyaWQiLCJjYXRlZ29yeUxpbmVzIiwiY2F0ZWdvcnlBeGVzIiwicG9zaXRpb24iLCJzaG93Iiwic3R5bGUiLCJzY2FsZSIsImxhYmVscyIsInRydW5jYXRlIiwidmFsdWVBeGVzIiwibmFtZSIsIm1vZGUiLCJyb3RhdGUiLCJ0ZXh0Iiwic2VyaWVzUGFyYW1zIiwiZGF0YSIsImxhYmVsIiwidmFsdWVBeGlzIiwiZHJhd0xpbmVzQmV0d2VlblBvaW50cyIsInNob3dDaXJjbGVzIiwibGluZVdpZHRoIiwiYWRkVG9vbHRpcCIsImFkZExlZ2VuZCIsImxlZ2VuZFBvc2l0aW9uIiwidGltZXMiLCJhZGRUaW1lTWFya2VyIiwidGhyZXNob2xkTGluZSIsInZhbHVlIiwid2lkdGgiLCJjb2xvciIsIngiLCJwYXR0ZXJuIiwiZGF0ZSIsImludGVydmFsIiwiYm91bmRzIiwibWluIiwibWF4IiwieSIsInNlcmllcyIsInRpbWVSYW5nZSIsImZyb20iLCJ0byIsInVzZU5vcm1hbGl6ZWRFc0ludGVydmFsIiwiZHJvcF9wYXJ0aWFscyIsIm1pbl9kb2NfY291bnQiLCJleHRlbmRlZF9ib3VuZHMiLCJpc0RvbnV0IiwidmFsdWVzIiwibGFzdF9sZXZlbCIsIm1ldHJpYyIsImludGVycG9sYXRlIiwic2hvd01ldGljc0F0QWxsTGV2ZWxzIiwiZXhwb3J0cyIsImRlZmF1bHQiLCJtb2R1bGUiXSwic291cmNlcyI6WyJvdmVydmlldy1taXRyZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gTW9kdWxlIGZvciBPdmVydmlldyBNSVRSRSB2aXN1YWxpemF0aW9uc1xuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IFtcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1NSVRSRScsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdNaXRyZSBhdHRhY2sgY291bnQnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgZW5hYmxlZDogdHJ1ZSwgaWQ6ICcxJywgcGFyYW1zOiB7fSwgc2NoZW1hOiAnbWV0cmljJywgdHlwZTogJ2NvdW50JyB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5taXRyZS5pZCcsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnQXR0YWNrIElEJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgc2l6ZTogMjQ0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIGJ1Y2tldHM6IFtdLFxuICAgICAgICAgICAgbWV0cmljczogW3sgYWNjZXNzb3I6IDAsIGFnZ1R5cGU6ICdjb3VudCcsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSB9XSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHBlclBhZ2U6IDEwLFxuICAgICAgICAgIHBlcmNlbnRhZ2VDb2w6ICcnLFxuICAgICAgICAgIHNob3dNZXRyaWNzQXRBbGxMZXZlbHM6IGZhbHNlLFxuICAgICAgICAgIHNob3dQYXJ0aWFsUm93czogZmFsc2UsXG4gICAgICAgICAgc2hvd1RvdGFsOiBmYWxzZSxcbiAgICAgICAgICBzaG93VG9vbGJhcjogdHJ1ZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiBudWxsLCBkaXJlY3Rpb246IG51bGwgfSxcbiAgICAgICAgICB0b3RhbEZ1bmM6ICdzdW0nLFxuICAgICAgICB9LFxuICAgICAgICB0aXRsZTogJ21pdHJlJyxcbiAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBsYW5ndWFnZTogJ2x1Y2VuZScsIHF1ZXJ5OiAnJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU1JVFJFLUFsZXJ0cy1Fdm9sdXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnTWl0cmUgYWxlcnRzIGV2b2x1dGlvbicsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0FsZXJ0IEV2b2x1dGlvbicsXG4gICAgICAgIHR5cGU6ICdsaW5lJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICAgIGdyaWQ6IHsgY2F0ZWdvcnlMaW5lczogZmFsc2UgfSxcbiAgICAgICAgICBjYXRlZ29yeUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdDYXRlZ29yeUF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICdjYXRlZ29yeScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgZmlsdGVyOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJywgbW9kZTogJ25vcm1hbCcgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIHJvdGF0ZTogMCwgZmlsdGVyOiBmYWxzZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZTogeyB0ZXh0OiAnQ291bnQnIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNob3c6ICd0cnVlJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcbiAgICAgICAgICAgICAgZGF0YTogeyBsYWJlbDogJ0NvdW50JywgaWQ6ICcxJyB9LFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgICBsaW5lV2lkdGg6IDIsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgdGltZXM6IFtdLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICAgIGxhYmVsczoge30sXG4gICAgICAgICAgdGhyZXNob2xkTGluZTogeyBzaG93OiBmYWxzZSwgdmFsdWU6IDEwLCB3aWR0aDogMSwgc3R5bGU6ICdmdWxsJywgY29sb3I6ICcjMzQxMzBDJyB9LFxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIHg6IHtcbiAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXG4gICAgICAgICAgICAgIGZvcm1hdDogeyBpZDogJ2RhdGUnLCBwYXJhbXM6IHsgcGF0dGVybjogJ1lZWVktTU0tREQgSEg6bW0nIH0gfSxcbiAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgZGF0ZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBpbnRlcnZhbDogJ1BUM0gnLFxuICAgICAgICAgICAgICAgIGZvcm1hdDogJ1lZWVktTU0tREQgSEg6bW0nLFxuICAgICAgICAgICAgICAgIGJvdW5kczogeyBtaW46ICcyMDE5LTExLTA3VDE1OjQ1OjQ1Ljc3MFonLCBtYXg6ICcyMDE5LTExLTE0VDE1OjQ1OjQ1Ljc3MFonIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGFnZ1R5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgeTogW3sgYWNjZXNzb3I6IDIsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9XSxcbiAgICAgICAgICAgIHNlcmllczogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDEsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAndGltZXN0YW1wJyxcbiAgICAgICAgICAgICAgdGltZVJhbmdlOiB7IGZyb206ICdub3ctN2QnLCB0bzogJ25vdycgfSxcbiAgICAgICAgICAgICAgdXNlTm9ybWFsaXplZEVzSW50ZXJ2YWw6IHRydWUsXG4gICAgICAgICAgICAgIGludGVydmFsOiAnYXV0bycsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubWl0cmUudGVjaG5pcXVlJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBdHRhY2sgSUQnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IGxhbmd1YWdlOiAnbHVjZW5lJywgcXVlcnk6ICcnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctTUlUUkUtQXR0YWNrcy1CeS1BZ2VudCcsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdNaXRyZSB0ZWNobmlxdWVzIGJ5IGFnZW50JyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnYXR0YWNrIGJ5IGFnZW50JyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IGZhbHNlLCB2YWx1ZXM6IHRydWUsIGxhc3RfbGV2ZWw6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICBtZXRyaWM6IHsgYWNjZXNzb3I6IDAsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2FnZW50Lm5hbWUnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5taXRyZS50ZWNobmlxdWUnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IGxhbmd1YWdlOiAnbHVjZW5lJywgcXVlcnk6ICcnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctTUlUUkUtQXR0YWNrcy1CeS1UZWNobmlxdWUnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQXR0YWNrcyBieSB0ZWNobmlxdWUnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBdHRhY2tzIGJ5IHRhY3RpYycsXG4gICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICBncmlkOiB7IGNhdGVnb3J5TGluZXM6IGZhbHNlIH0sXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnQ2F0ZWdvcnlBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2JvdHRvbScsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIGZpbHRlcjogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnbGVmdCcsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicsIG1vZGU6ICdub3JtYWwnIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCByb3RhdGU6IDAsIGZpbHRlcjogZmFsc2UsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ0NvdW50JyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaG93OiAndHJ1ZScsXG4gICAgICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgICAgICBtb2RlOiAnc3RhY2tlZCcsXG4gICAgICAgICAgICAgIGRhdGE6IHsgbGFiZWw6ICdDb3VudCcsIGlkOiAnMScgfSxcbiAgICAgICAgICAgICAgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IGZhbHNlIH0sXG4gICAgICAgICAgdGhyZXNob2xkTGluZTogeyBzaG93OiBmYWxzZSwgdmFsdWU6IDEwLCB3aWR0aDogMSwgc3R5bGU6ICdmdWxsJywgY29sb3I6ICcjMzQxMzBDJyB9LFxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIHg6IG51bGwsXG4gICAgICAgICAgICB5OiBbeyBhY2Nlc3NvcjogMSwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9LCBhZ2dUeXBlOiAnY291bnQnIH1dLFxuICAgICAgICAgICAgc2VyaWVzOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5taXRyZS50ZWNobmlxdWUnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5taXRyZS50YWN0aWMnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IGxhbmd1YWdlOiAnbHVjZW5lJywgcXVlcnk6ICcnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctTUlUUkUtVG9wLVRhY3RpY3MtQnktQWdlbnQnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIHRhY3RpY3MgYnkgYWdlbnQnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdUb3AgdGFjdGljcyBieSBhZ2VudCAtIHZlcnRpY2FsJyxcbiAgICAgICAgdHlwZTogJ2FyZWEnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBjYXRlZ29yeUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdDYXRlZ29yeUF4aXMtMScsXG4gICAgICAgICAgICAgIGxhYmVsczogeyBmaWx0ZXI6IHRydWUsIHNob3c6IHRydWUsIHRydW5jYXRlOiAxMCB9LFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2JvdHRvbScsXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIHg6IHtcbiAgICAgICAgICAgICAgYWNjZXNzb3I6IDEsXG4gICAgICAgICAgICAgIGZvcm1hdDoge1xuICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgIHBhcmFtczogeyBpZDogJ3N0cmluZycsIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgeTogW3sgYWNjZXNzb3I6IDIsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9XSxcbiAgICAgICAgICAgIHNlcmllczogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBncmlkOiB7IGNhdGVnb3J5TGluZXM6IGZhbHNlLCB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScgfSxcbiAgICAgICAgICBsYWJlbHM6IHt9LFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBkYXRhOiB7IGlkOiAnMScsIGxhYmVsOiAnQ291bnQnIH0sXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIGludGVycG9sYXRlOiAnbGluZWFyJyxcbiAgICAgICAgICAgICAgbW9kZTogJ25vcm1hbCcsXG4gICAgICAgICAgICAgIHNob3c6ICd0cnVlJyxcbiAgICAgICAgICAgICAgc2hvd0NpcmNsZXM6IHRydWUsXG4gICAgICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdGhyZXNob2xkTGluZTogeyBjb2xvcjogJyMzNDEzMEMnLCBzaG93OiBmYWxzZSwgc3R5bGU6ICdmdWxsJywgdmFsdWU6IDEwLCB3aWR0aDogMSB9LFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgZmlsdGVyOiBmYWxzZSwgcm90YXRlOiAwLCBzaG93OiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0xJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgbW9kZTogJ25vcm1hbCcsIHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ0NvdW50JyB9LFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5taXRyZS50YWN0aWMnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnYWdlbnQubmFtZScsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgbGFuZ3VhZ2U6ICdsdWNlbmUnLCBxdWVyeTogJycgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1NSVRSRS1Ub3AtVGFjdGljcycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdUb3AgdGFjdGljcycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1RvcCB0YWN0aWNzIFBJRTInLFxuICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogZmFsc2UsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IGZhbHNlLCB2YWx1ZXM6IHRydWUsIGxhc3RfbGV2ZWw6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICBtZXRyaWM6IHsgYWNjZXNzb3I6IDEsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9LFxuICAgICAgICAgICAgYnVja2V0czogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5taXRyZS50YWN0aWMnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBsYW5ndWFnZTogJ2x1Y2VuZScsIHF1ZXJ5OiAnJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU1JVFJFLUFsZXJ0cy1zdW1tYXJ5JyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydHMgc3VtbWFyeScsXG4gICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDEwLFxuICAgICAgICAgIHNob3dQYXJ0aWFsUm93czogZmFsc2UsXG4gICAgICAgICAgc2hvd01ldGljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgc2hvd1Rvb2xiYXI6IHRydWUsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmlkJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDUwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUnVsZSBJRCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuZGVzY3JpcHRpb24nLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgc2l6ZTogMjAsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdEZXNjcmlwdGlvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICc0JyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTIsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdMZXZlbCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne1widmlzXCI6e1wicGFyYW1zXCI6e1wic29ydFwiOntcImNvbHVtbkluZGV4XCI6MyxcImRpcmVjdGlvblwiOlwiZGVzY1wifX19fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbl07XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWQSxJQUFBQSxRQUFBLEdBV2UsQ0FDYjtFQUNFQyxHQUFHLEVBQUUsMEJBQTBCO0VBQy9CQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLG9CQUFvQjtJQUMzQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkMsSUFBSSxFQUFFLENBQ0o7UUFBRUMsT0FBTyxFQUFFLElBQUk7UUFBRUMsRUFBRSxFQUFFLEdBQUc7UUFBRUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUFFQyxNQUFNLEVBQUUsUUFBUTtRQUFFQyxJQUFJLEVBQUU7TUFBUSxDQUFDLEVBQ3ZFO1FBQ0VKLE9BQU8sRUFBRSxJQUFJO1FBQ2JDLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE1BQU0sRUFBRTtVQUNORyxLQUFLLEVBQUUsZUFBZTtVQUN0QkMsV0FBVyxFQUFFLFdBQVc7VUFDeEJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsSUFBSSxFQUFFO1FBQ1IsQ0FBQztRQUNEVixNQUFNLEVBQUUsUUFBUTtRQUNoQkMsSUFBSSxFQUFFO01BQ1IsQ0FBQyxDQUNGO01BQ0RGLE1BQU0sRUFBRTtRQUNOWSxVQUFVLEVBQUU7VUFDVkMsT0FBTyxFQUFFLEVBQUU7VUFDWEMsT0FBTyxFQUFFLENBQUM7WUFBRUMsUUFBUSxFQUFFLENBQUM7WUFBRUMsT0FBTyxFQUFFLE9BQU87WUFBRUMsTUFBTSxFQUFFO2NBQUVsQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVDLE1BQU0sRUFBRSxDQUFDO1VBQUUsQ0FBQztRQUNuRixDQUFDO1FBQ0RrQixPQUFPLEVBQUUsRUFBRTtRQUNYQyxhQUFhLEVBQUUsRUFBRTtRQUNqQkMsc0JBQXNCLEVBQUUsS0FBSztRQUM3QkMsZUFBZSxFQUFFLEtBQUs7UUFDdEJDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsSUFBSSxFQUFFO1VBQUVDLFdBQVcsRUFBRSxJQUFJO1VBQUVDLFNBQVMsRUFBRTtRQUFLLENBQUM7UUFDNUNDLFNBQVMsRUFBRTtNQUNiLENBQUM7TUFDRGxDLEtBQUssRUFBRSxPQUFPO01BQ2RTLElBQUksRUFBRTtJQUNSLENBQUMsQ0FBQztJQUNGMEIsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXJDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CcUMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxFQUFFO1FBQ1ZDLEtBQUssRUFBRTtVQUFFQyxRQUFRLEVBQUUsUUFBUTtVQUFFRCxLQUFLLEVBQUU7UUFBRztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RFLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFOUMsR0FBRyxFQUFFLDJDQUEyQztFQUNoREMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSx3QkFBd0I7SUFDL0JDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxpQkFBaUI7TUFDeEJTLElBQUksRUFBRSxNQUFNO01BQ1pGLE1BQU0sRUFBRTtRQUNORSxJQUFJLEVBQUUsTUFBTTtRQUNab0MsSUFBSSxFQUFFO1VBQUVDLGFBQWEsRUFBRTtRQUFNLENBQUM7UUFDOUJDLFlBQVksRUFBRSxDQUNaO1VBQ0V6QyxFQUFFLEVBQUUsZ0JBQWdCO1VBQ3BCRyxJQUFJLEVBQUUsVUFBVTtVQUNoQnVDLFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RDLEtBQUssRUFBRTtZQUFFMUMsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6QjJDLE1BQU0sRUFBRTtZQUFFSCxJQUFJLEVBQUUsSUFBSTtZQUFFUixNQUFNLEVBQUUsSUFBSTtZQUFFWSxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQ25EckQsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRHNELFNBQVMsRUFBRSxDQUNUO1VBQ0VoRCxFQUFFLEVBQUUsYUFBYTtVQUNqQmlELElBQUksRUFBRSxZQUFZO1VBQ2xCOUMsSUFBSSxFQUFFLE9BQU87VUFDYnVDLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxJQUFJLEVBQUUsSUFBSTtVQUNWQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RDLEtBQUssRUFBRTtZQUFFMUMsSUFBSSxFQUFFLFFBQVE7WUFBRStDLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekNKLE1BQU0sRUFBRTtZQUFFSCxJQUFJLEVBQUUsSUFBSTtZQUFFUSxNQUFNLEVBQUUsQ0FBQztZQUFFaEIsTUFBTSxFQUFFLEtBQUs7WUFBRVksUUFBUSxFQUFFO1VBQUksQ0FBQztVQUMvRHJELEtBQUssRUFBRTtZQUFFMEQsSUFBSSxFQUFFO1VBQVE7UUFDekIsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0VWLElBQUksRUFBRSxNQUFNO1VBQ1p4QyxJQUFJLEVBQUUsTUFBTTtVQUNaK0MsSUFBSSxFQUFFLFFBQVE7VUFDZEksSUFBSSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUV2RCxFQUFFLEVBQUU7VUFBSSxDQUFDO1VBQ2pDd0QsU0FBUyxFQUFFLGFBQWE7VUFDeEJDLHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFdBQVcsRUFBRSxJQUFJO1VBQ2pCQyxTQUFTLEVBQUU7UUFDYixDQUFDLENBQ0Y7UUFDREMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQmxCLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVm1CLGFBQWEsRUFBRTtVQUFFdEIsSUFBSSxFQUFFLEtBQUs7VUFBRXVCLEtBQUssRUFBRSxFQUFFO1VBQUVDLEtBQUssRUFBRSxDQUFDO1VBQUV2QixLQUFLLEVBQUUsTUFBTTtVQUFFd0IsS0FBSyxFQUFFO1FBQVUsQ0FBQztRQUNwRnZELFVBQVUsRUFBRTtVQUNWd0QsQ0FBQyxFQUFFO1lBQ0RyRCxRQUFRLEVBQUUsQ0FBQztZQUNYRSxNQUFNLEVBQUU7Y0FBRWxCLEVBQUUsRUFBRSxNQUFNO2NBQUVDLE1BQU0sRUFBRTtnQkFBRXFFLE9BQU8sRUFBRTtjQUFtQjtZQUFFLENBQUM7WUFDL0RyRSxNQUFNLEVBQUU7Y0FDTnNFLElBQUksRUFBRSxJQUFJO2NBQ1ZDLFFBQVEsRUFBRSxNQUFNO2NBQ2hCdEQsTUFBTSxFQUFFLGtCQUFrQjtjQUMxQnVELE1BQU0sRUFBRTtnQkFBRUMsR0FBRyxFQUFFLDBCQUEwQjtnQkFBRUMsR0FBRyxFQUFFO2NBQTJCO1lBQzdFLENBQUM7WUFDRDFELE9BQU8sRUFBRTtVQUNYLENBQUM7VUFDRDJELENBQUMsRUFBRSxDQUFDO1lBQUU1RCxRQUFRLEVBQUUsQ0FBQztZQUFFRSxNQUFNLEVBQUU7Y0FBRWxCLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFBRUMsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUFFZ0IsT0FBTyxFQUFFO1VBQVEsQ0FBQyxDQUFDO1VBQzVFNEQsTUFBTSxFQUFFLENBQ047WUFDRTdELFFBQVEsRUFBRSxDQUFDO1lBQ1hFLE1BQU0sRUFBRTtjQUNObEIsRUFBRSxFQUFFLE9BQU87Y0FDWEMsTUFBTSxFQUFFO2dCQUNORCxFQUFFLEVBQUUsUUFBUTtnQkFDWlcsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJKLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNETixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZnQixPQUFPLEVBQUU7VUFDWCxDQUFDO1FBRUw7TUFDRixDQUFDO01BQ0RuQixJQUFJLEVBQUUsQ0FDSjtRQUFFRSxFQUFFLEVBQUUsR0FBRztRQUFFRCxPQUFPLEVBQUUsSUFBSTtRQUFFSSxJQUFJLEVBQUUsT0FBTztRQUFFRCxNQUFNLEVBQUUsUUFBUTtRQUFFRCxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRUQsRUFBRSxFQUFFLEdBQUc7UUFDUEQsT0FBTyxFQUFFLElBQUk7UUFDYkksSUFBSSxFQUFFLGdCQUFnQjtRQUN0QkQsTUFBTSxFQUFFLFNBQVM7UUFDakJELE1BQU0sRUFBRTtVQUNORyxLQUFLLEVBQUUsV0FBVztVQUNsQjBFLFNBQVMsRUFBRTtZQUFFQyxJQUFJLEVBQUUsUUFBUTtZQUFFQyxFQUFFLEVBQUU7VUFBTSxDQUFDO1VBQ3hDQyx1QkFBdUIsRUFBRSxJQUFJO1VBQzdCVCxRQUFRLEVBQUUsTUFBTTtVQUNoQlUsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGFBQWEsRUFBRSxDQUFDO1VBQ2hCQyxlQUFlLEVBQUUsQ0FBQztRQUNwQjtNQUNGLENBQUMsRUFDRDtRQUNFcEYsRUFBRSxFQUFFLEdBQUc7UUFDUEQsT0FBTyxFQUFFLElBQUk7UUFDYkksSUFBSSxFQUFFLE9BQU87UUFDYkQsTUFBTSxFQUFFLE9BQU87UUFDZkQsTUFBTSxFQUFFO1VBQ05HLEtBQUssRUFBRSxzQkFBc0I7VUFDN0JDLFdBQVcsRUFBRSxXQUFXO1VBQ3hCSSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiSSxJQUFJLEVBQUUsQ0FBQztVQUNQRixXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkwsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGc0IsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXJDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CcUMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxFQUFFO1FBQ1ZDLEtBQUssRUFBRTtVQUFFQyxRQUFRLEVBQUUsUUFBUTtVQUFFRCxLQUFLLEVBQUU7UUFBRztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RFLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFOUMsR0FBRyxFQUFFLDJDQUEyQztFQUNoREMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSwyQkFBMkI7SUFDbENDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxpQkFBaUI7TUFDeEJTLElBQUksRUFBRSxLQUFLO01BQ1hGLE1BQU0sRUFBRTtRQUNORSxJQUFJLEVBQUUsS0FBSztRQUNYeUQsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCdUIsT0FBTyxFQUFFLElBQUk7UUFDYnZDLE1BQU0sRUFBRTtVQUFFSCxJQUFJLEVBQUUsS0FBSztVQUFFMkMsTUFBTSxFQUFFLElBQUk7VUFBRUMsVUFBVSxFQUFFLElBQUk7VUFBRXhDLFFBQVEsRUFBRTtRQUFJLENBQUM7UUFDdEVsQyxVQUFVLEVBQUU7VUFDVjJFLE1BQU0sRUFBRTtZQUFFeEUsUUFBUSxFQUFFLENBQUM7WUFBRUUsTUFBTSxFQUFFO2NBQUVsQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRWdCLE9BQU8sRUFBRTtVQUFRO1FBQ2hGO01BQ0YsQ0FBQztNQUNEbkIsSUFBSSxFQUFFLENBQ0o7UUFBRUUsRUFBRSxFQUFFLEdBQUc7UUFBRUQsT0FBTyxFQUFFLElBQUk7UUFBRUksSUFBSSxFQUFFLE9BQU87UUFBRUQsTUFBTSxFQUFFLFFBQVE7UUFBRUQsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VELEVBQUUsRUFBRSxHQUFHO1FBQ1BELE9BQU8sRUFBRSxJQUFJO1FBQ2JJLElBQUksRUFBRSxPQUFPO1FBQ2JELE1BQU0sRUFBRSxTQUFTO1FBQ2pCRCxNQUFNLEVBQUU7VUFDTkcsS0FBSyxFQUFFLFlBQVk7VUFDbkJLLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JJLElBQUksRUFBRSxDQUFDO1VBQ1BGLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCTCxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEI7TUFDRixDQUFDLEVBQ0Q7UUFDRVAsRUFBRSxFQUFFLEdBQUc7UUFDUEQsT0FBTyxFQUFFLElBQUk7UUFDYkksSUFBSSxFQUFFLE9BQU87UUFDYkQsTUFBTSxFQUFFLFNBQVM7UUFDakJELE1BQU0sRUFBRTtVQUNORyxLQUFLLEVBQUUsc0JBQXNCO1VBQzdCSyxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiSSxJQUFJLEVBQUUsQ0FBQztVQUNQRixXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkwsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGc0IsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXJDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CcUMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxFQUFFO1FBQ1ZDLEtBQUssRUFBRTtVQUFFQyxRQUFRLEVBQUUsUUFBUTtVQUFFRCxLQUFLLEVBQUU7UUFBRztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RFLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFOUMsR0FBRyxFQUFFLCtDQUErQztFQUNwREMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxzQkFBc0I7SUFDN0JDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxtQkFBbUI7TUFDMUJTLElBQUksRUFBRSxXQUFXO01BQ2pCRixNQUFNLEVBQUU7UUFDTkUsSUFBSSxFQUFFLFdBQVc7UUFDakJvQyxJQUFJLEVBQUU7VUFBRUMsYUFBYSxFQUFFO1FBQU0sQ0FBQztRQUM5QkMsWUFBWSxFQUFFLENBQ1o7VUFDRXpDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJHLElBQUksRUFBRSxVQUFVO1VBQ2hCdUMsUUFBUSxFQUFFLFFBQVE7VUFDbEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEMsS0FBSyxFQUFFO1lBQUUxQyxJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pCMkMsTUFBTSxFQUFFO1lBQUVILElBQUksRUFBRSxJQUFJO1lBQUVSLE1BQU0sRUFBRSxJQUFJO1lBQUVZLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDbkRyRCxLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEc0QsU0FBUyxFQUFFLENBQ1Q7VUFDRWhELEVBQUUsRUFBRSxhQUFhO1VBQ2pCaUQsSUFBSSxFQUFFLFlBQVk7VUFDbEI5QyxJQUFJLEVBQUUsT0FBTztVQUNidUMsUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEMsS0FBSyxFQUFFO1lBQUUxQyxJQUFJLEVBQUUsUUFBUTtZQUFFK0MsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6Q0osTUFBTSxFQUFFO1lBQUVILElBQUksRUFBRSxJQUFJO1lBQUVRLE1BQU0sRUFBRSxDQUFDO1lBQUVoQixNQUFNLEVBQUUsS0FBSztZQUFFWSxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQy9EckQsS0FBSyxFQUFFO1lBQUUwRCxJQUFJLEVBQUU7VUFBUTtRQUN6QixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVYsSUFBSSxFQUFFLE1BQU07VUFDWnhDLElBQUksRUFBRSxXQUFXO1VBQ2pCK0MsSUFBSSxFQUFFLFNBQVM7VUFDZkksSUFBSSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUV2RCxFQUFFLEVBQUU7VUFBSSxDQUFDO1VBQ2pDd0QsU0FBUyxFQUFFLGFBQWE7VUFDeEJDLHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFdBQVcsRUFBRTtRQUNmLENBQUMsQ0FDRjtRQUNERSxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJDLEtBQUssRUFBRSxFQUFFO1FBQ1RDLGFBQWEsRUFBRSxLQUFLO1FBQ3BCbEIsTUFBTSxFQUFFO1VBQUVILElBQUksRUFBRTtRQUFNLENBQUM7UUFDdkJzQixhQUFhLEVBQUU7VUFBRXRCLElBQUksRUFBRSxLQUFLO1VBQUV1QixLQUFLLEVBQUUsRUFBRTtVQUFFQyxLQUFLLEVBQUUsQ0FBQztVQUFFdkIsS0FBSyxFQUFFLE1BQU07VUFBRXdCLEtBQUssRUFBRTtRQUFVLENBQUM7UUFDcEZ2RCxVQUFVLEVBQUU7VUFDVndELENBQUMsRUFBRSxJQUFJO1VBQ1BPLENBQUMsRUFBRSxDQUFDO1lBQUU1RCxRQUFRLEVBQUUsQ0FBQztZQUFFRSxNQUFNLEVBQUU7Y0FBRWxCLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFBRUMsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUFFZ0IsT0FBTyxFQUFFO1VBQVEsQ0FBQyxDQUFDO1VBQzVFNEQsTUFBTSxFQUFFLENBQ047WUFDRTdELFFBQVEsRUFBRSxDQUFDO1lBQ1hFLE1BQU0sRUFBRTtjQUNObEIsRUFBRSxFQUFFLE9BQU87Y0FDWEMsTUFBTSxFQUFFO2dCQUNORCxFQUFFLEVBQUUsUUFBUTtnQkFDWlcsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJKLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNETixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZnQixPQUFPLEVBQUU7VUFDWCxDQUFDO1FBRUw7TUFDRixDQUFDO01BQ0RuQixJQUFJLEVBQUUsQ0FDSjtRQUFFRSxFQUFFLEVBQUUsR0FBRztRQUFFRCxPQUFPLEVBQUUsSUFBSTtRQUFFSSxJQUFJLEVBQUUsT0FBTztRQUFFRCxNQUFNLEVBQUUsUUFBUTtRQUFFRCxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRUQsRUFBRSxFQUFFLEdBQUc7UUFDUEQsT0FBTyxFQUFFLElBQUk7UUFDYkksSUFBSSxFQUFFLE9BQU87UUFDYkQsTUFBTSxFQUFFLE9BQU87UUFDZkQsTUFBTSxFQUFFO1VBQ05HLEtBQUssRUFBRSxzQkFBc0I7VUFDN0JLLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JJLElBQUksRUFBRSxDQUFDO1VBQ1BGLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCTCxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEI7TUFDRixDQUFDLEVBQ0Q7UUFDRVAsRUFBRSxFQUFFLEdBQUc7UUFDUEQsT0FBTyxFQUFFLElBQUk7UUFDYkksSUFBSSxFQUFFLE9BQU87UUFDYkQsTUFBTSxFQUFFLFNBQVM7UUFDakJELE1BQU0sRUFBRTtVQUNORyxLQUFLLEVBQUUsbUJBQW1CO1VBQzFCSyxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiSSxJQUFJLEVBQUUsQ0FBQztVQUNQRixXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkwsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGc0IsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXJDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CcUMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxFQUFFO1FBQ1ZDLEtBQUssRUFBRTtVQUFFQyxRQUFRLEVBQUUsUUFBUTtVQUFFRCxLQUFLLEVBQUU7UUFBRztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RFLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFOUMsR0FBRyxFQUFFLCtDQUErQztFQUNwREMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxzQkFBc0I7SUFDN0JDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxpQ0FBaUM7TUFDeENTLElBQUksRUFBRSxNQUFNO01BQ1pGLE1BQU0sRUFBRTtRQUNONEQsU0FBUyxFQUFFLElBQUk7UUFDZkcsYUFBYSxFQUFFLEtBQUs7UUFDcEJKLFVBQVUsRUFBRSxJQUFJO1FBQ2hCbkIsWUFBWSxFQUFFLENBQ1o7VUFDRXpDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEI4QyxNQUFNLEVBQUU7WUFBRVgsTUFBTSxFQUFFLElBQUk7WUFBRVEsSUFBSSxFQUFFLElBQUk7WUFBRUksUUFBUSxFQUFFO1VBQUcsQ0FBQztVQUNsREwsUUFBUSxFQUFFLFFBQVE7VUFDbEJHLEtBQUssRUFBRTtZQUFFMUMsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6QndDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVGxELEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVFMsSUFBSSxFQUFFO1FBQ1IsQ0FBQyxDQUNGO1FBQ0RVLFVBQVUsRUFBRTtVQUNWd0QsQ0FBQyxFQUFFO1lBQ0RyRCxRQUFRLEVBQUUsQ0FBQztZQUNYRSxNQUFNLEVBQUU7Y0FDTmxCLEVBQUUsRUFBRSxPQUFPO2NBQ1hDLE1BQU0sRUFBRTtnQkFBRUQsRUFBRSxFQUFFLFFBQVE7Z0JBQUVXLGdCQUFnQixFQUFFLE9BQU87Z0JBQUVKLGtCQUFrQixFQUFFO2NBQVU7WUFDbkYsQ0FBQztZQUNETixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZnQixPQUFPLEVBQUU7VUFDWCxDQUFDO1VBQ0QyRCxDQUFDLEVBQUUsQ0FBQztZQUFFNUQsUUFBUSxFQUFFLENBQUM7WUFBRUUsTUFBTSxFQUFFO2NBQUVsQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRWdCLE9BQU8sRUFBRTtVQUFRLENBQUMsQ0FBQztVQUM1RTRELE1BQU0sRUFBRSxDQUNOO1lBQ0U3RCxRQUFRLEVBQUUsQ0FBQztZQUNYRSxNQUFNLEVBQUU7Y0FDTmxCLEVBQUUsRUFBRSxPQUFPO2NBQ1hDLE1BQU0sRUFBRTtnQkFDTkQsRUFBRSxFQUFFLFFBQVE7Z0JBQ1pXLGdCQUFnQixFQUFFLE9BQU87Z0JBQ3pCSixrQkFBa0IsRUFBRTtjQUN0QjtZQUNGLENBQUM7WUFDRE4sTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWZ0IsT0FBTyxFQUFFO1VBQ1gsQ0FBQztRQUVMLENBQUM7UUFDRHNCLElBQUksRUFBRTtVQUFFQyxhQUFhLEVBQUUsS0FBSztVQUFFZ0IsU0FBUyxFQUFFO1FBQWMsQ0FBQztRQUN4RFYsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWZ0IsY0FBYyxFQUFFLE9BQU87UUFDdkJULFlBQVksRUFBRSxDQUNaO1VBQ0VDLElBQUksRUFBRTtZQUFFdEQsRUFBRSxFQUFFLEdBQUc7WUFBRXVELEtBQUssRUFBRTtVQUFRLENBQUM7VUFDakNFLHNCQUFzQixFQUFFLElBQUk7VUFDNUJnQyxXQUFXLEVBQUUsUUFBUTtVQUNyQnZDLElBQUksRUFBRSxRQUFRO1VBQ2RQLElBQUksRUFBRSxNQUFNO1VBQ1plLFdBQVcsRUFBRSxJQUFJO1VBQ2pCdkQsSUFBSSxFQUFFLFdBQVc7VUFDakJxRCxTQUFTLEVBQUU7UUFDYixDQUFDLENBQ0Y7UUFDRFMsYUFBYSxFQUFFO1VBQUVHLEtBQUssRUFBRSxTQUFTO1VBQUV6QixJQUFJLEVBQUUsS0FBSztVQUFFQyxLQUFLLEVBQUUsTUFBTTtVQUFFc0IsS0FBSyxFQUFFLEVBQUU7VUFBRUMsS0FBSyxFQUFFO1FBQUUsQ0FBQztRQUNwRkosS0FBSyxFQUFFLEVBQUU7UUFDVDVELElBQUksRUFBRSxNQUFNO1FBQ1o2QyxTQUFTLEVBQUUsQ0FDVDtVQUNFaEQsRUFBRSxFQUFFLGFBQWE7VUFDakI4QyxNQUFNLEVBQUU7WUFBRVgsTUFBTSxFQUFFLEtBQUs7WUFBRWdCLE1BQU0sRUFBRSxDQUFDO1lBQUVSLElBQUksRUFBRSxJQUFJO1lBQUVJLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDL0RFLElBQUksRUFBRSxZQUFZO1VBQ2xCUCxRQUFRLEVBQUUsTUFBTTtVQUNoQkcsS0FBSyxFQUFFO1lBQUVLLElBQUksRUFBRSxRQUFRO1lBQUUvQyxJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pDd0MsSUFBSSxFQUFFLElBQUk7VUFDVkMsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUbEQsS0FBSyxFQUFFO1lBQUUwRCxJQUFJLEVBQUU7VUFBUSxDQUFDO1VBQ3hCakQsSUFBSSxFQUFFO1FBQ1IsQ0FBQztNQUVMLENBQUM7TUFDREwsSUFBSSxFQUFFLENBQ0o7UUFBRUUsRUFBRSxFQUFFLEdBQUc7UUFBRUQsT0FBTyxFQUFFLElBQUk7UUFBRUksSUFBSSxFQUFFLE9BQU87UUFBRUQsTUFBTSxFQUFFLFFBQVE7UUFBRUQsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VELEVBQUUsRUFBRSxHQUFHO1FBQ1BELE9BQU8sRUFBRSxJQUFJO1FBQ2JJLElBQUksRUFBRSxPQUFPO1FBQ2JELE1BQU0sRUFBRSxPQUFPO1FBQ2ZELE1BQU0sRUFBRTtVQUNORyxLQUFLLEVBQUUsbUJBQW1CO1VBQzFCSyxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiSSxJQUFJLEVBQUUsQ0FBQztVQUNQRixXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkwsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQyxFQUNEO1FBQ0VQLEVBQUUsRUFBRSxHQUFHO1FBQ1BELE9BQU8sRUFBRSxJQUFJO1FBQ2JJLElBQUksRUFBRSxPQUFPO1FBQ2JELE1BQU0sRUFBRSxTQUFTO1FBQ2pCRCxNQUFNLEVBQUU7VUFDTkcsS0FBSyxFQUFFLFlBQVk7VUFDbkJLLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JJLElBQUksRUFBRSxDQUFDO1VBQ1BGLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCTCxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEI7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZzQixXQUFXLEVBQUUsSUFBSTtJQUNqQkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFckMsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0JxQyxLQUFLLEVBQUUsY0FBYztRQUNyQkMsTUFBTSxFQUFFLEVBQUU7UUFDVkMsS0FBSyxFQUFFO1VBQUVDLFFBQVEsRUFBRSxRQUFRO1VBQUVELEtBQUssRUFBRTtRQUFHO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREUsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0U5QyxHQUFHLEVBQUUsc0NBQXNDO0VBQzNDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGFBQWE7SUFDcEJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxrQkFBa0I7TUFDekJTLElBQUksRUFBRSxLQUFLO01BQ1hGLE1BQU0sRUFBRTtRQUNORSxJQUFJLEVBQUUsS0FBSztRQUNYeUQsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCdUIsT0FBTyxFQUFFLEtBQUs7UUFDZHZDLE1BQU0sRUFBRTtVQUFFSCxJQUFJLEVBQUUsS0FBSztVQUFFMkMsTUFBTSxFQUFFLElBQUk7VUFBRUMsVUFBVSxFQUFFLElBQUk7VUFBRXhDLFFBQVEsRUFBRTtRQUFJLENBQUM7UUFDdEVsQyxVQUFVLEVBQUU7VUFDVjJFLE1BQU0sRUFBRTtZQUFFeEUsUUFBUSxFQUFFLENBQUM7WUFBRUUsTUFBTSxFQUFFO2NBQUVsQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRWdCLE9BQU8sRUFBRTtVQUFRLENBQUM7VUFDL0VILE9BQU8sRUFBRSxDQUNQO1lBQ0VFLFFBQVEsRUFBRSxDQUFDO1lBQ1hFLE1BQU0sRUFBRTtjQUNObEIsRUFBRSxFQUFFLE9BQU87Y0FDWEMsTUFBTSxFQUFFO2dCQUNORCxFQUFFLEVBQUUsUUFBUTtnQkFDWlcsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJKLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNETixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZnQixPQUFPLEVBQUU7VUFDWCxDQUFDO1FBRUw7TUFDRixDQUFDO01BQ0RuQixJQUFJLEVBQUUsQ0FDSjtRQUFFRSxFQUFFLEVBQUUsR0FBRztRQUFFRCxPQUFPLEVBQUUsSUFBSTtRQUFFSSxJQUFJLEVBQUUsT0FBTztRQUFFRCxNQUFNLEVBQUUsUUFBUTtRQUFFRCxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRUQsRUFBRSxFQUFFLEdBQUc7UUFDUEQsT0FBTyxFQUFFLElBQUk7UUFDYkksSUFBSSxFQUFFLE9BQU87UUFDYkQsTUFBTSxFQUFFLFNBQVM7UUFDakJELE1BQU0sRUFBRTtVQUNORyxLQUFLLEVBQUUsbUJBQW1CO1VBQzFCSyxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiSSxJQUFJLEVBQUUsRUFBRTtVQUNSRixXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkwsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGc0IsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXJDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CcUMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLE1BQU0sRUFBRSxFQUFFO1FBQ1ZDLEtBQUssRUFBRTtVQUFFQyxRQUFRLEVBQUUsUUFBUTtVQUFFRCxLQUFLLEVBQUU7UUFBRztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RFLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFOUMsR0FBRyxFQUFFLHlDQUF5QztFQUM5QzhDLEtBQUssRUFBRSxlQUFlO0VBQ3RCN0MsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxnQkFBZ0I7TUFDdkJTLElBQUksRUFBRSxPQUFPO01BQ2JGLE1BQU0sRUFBRTtRQUNOa0IsT0FBTyxFQUFFLEVBQUU7UUFDWEcsZUFBZSxFQUFFLEtBQUs7UUFDdEJvRSxxQkFBcUIsRUFBRSxLQUFLO1FBQzVCakUsSUFBSSxFQUFFO1VBQUVDLFdBQVcsRUFBRSxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFPLENBQUM7UUFDM0NKLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkksU0FBUyxFQUFFO01BQ2IsQ0FBQztNQUNEOUIsSUFBSSxFQUFFLENBQ0o7UUFBRUUsRUFBRSxFQUFFLEdBQUc7UUFBRUQsT0FBTyxFQUFFLElBQUk7UUFBRUksSUFBSSxFQUFFLE9BQU87UUFBRUQsTUFBTSxFQUFFLFFBQVE7UUFBRUQsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VELEVBQUUsRUFBRSxHQUFHO1FBQ1BELE9BQU8sRUFBRSxJQUFJO1FBQ2JJLElBQUksRUFBRSxPQUFPO1FBQ2JELE1BQU0sRUFBRSxRQUFRO1FBQ2hCRCxNQUFNLEVBQUU7VUFDTkcsS0FBSyxFQUFFLFNBQVM7VUFDaEJNLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCTCxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3QkssSUFBSSxFQUFFLEVBQUU7VUFDUkosS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkosV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDLEVBQ0Q7UUFDRUwsRUFBRSxFQUFFLEdBQUc7UUFDUEQsT0FBTyxFQUFFLElBQUk7UUFDYkksSUFBSSxFQUFFLE9BQU87UUFDYkQsTUFBTSxFQUFFLFFBQVE7UUFDaEJELE1BQU0sRUFBRTtVQUNORyxLQUFLLEVBQUUsa0JBQWtCO1VBQ3pCTSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkwsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JLLElBQUksRUFBRSxFQUFFO1VBQ1JKLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1pKLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0VMLEVBQUUsRUFBRSxHQUFHO1FBQ1BELE9BQU8sRUFBRSxJQUFJO1FBQ2JJLElBQUksRUFBRSxPQUFPO1FBQ2JELE1BQU0sRUFBRSxRQUFRO1FBQ2hCRCxNQUFNLEVBQUU7VUFDTkcsS0FBSyxFQUFFLFlBQVk7VUFDbkJNLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCTCxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3QkssSUFBSSxFQUFFLEVBQUU7VUFDUkosS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkosV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0Z3QixXQUFXLEVBQUUsa0VBQWtFO0lBQy9FQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUVyQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQnFDLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxNQUFNLEVBQUUsRUFBRTtRQUNWQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLENBQ0Y7QUFBQXNELE9BQUEsQ0FBQUMsT0FBQSxHQUFBckcsUUFBQTtBQUFBc0csTUFBQSxDQUFBRixPQUFBLEdBQUFBLE9BQUEsQ0FBQUMsT0FBQSJ9