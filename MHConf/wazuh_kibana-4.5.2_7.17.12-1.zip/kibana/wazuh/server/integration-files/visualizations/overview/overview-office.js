"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _constants = require("../../../../common/constants");
/*
 * Wazuh app - Module for Overview/General visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Overview-Office-Agents-status',
  _source: {
    title: 'Agents status',
    visState: JSON.stringify({
      title: 'Agents Status',
      type: 'histogram',
      params: {
        type: 'histogram',
        grid: {
          categoryLines: false,
          style: {
            color: '#eee'
          }
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          mode: 'normal',
          type: 'line',
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'cardinal',
          lineWidth: 3.5,
          data: {
            id: '4',
            label: 'Unique count of id'
          },
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false
      },
      aggs: [{
        id: '2',
        enabled: true,
        type: 'date_histogram',
        interval: '1ms',
        schema: 'segment',
        params: {
          field: 'timestamp',
          interval: '1ms',
          customInterval: '2h',
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'status',
          size: 5,
          order: 'desc',
          orderBy: '_term'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'cardinality',
        schema: 'metric',
        params: {
          field: 'id'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        colors: {
          active: _constants.UI_COLOR_AGENT_STATUS.active,
          disconnected: _constants.UI_COLOR_AGENT_STATUS.disconnected,
          pending: _constants.UI_COLOR_AGENT_STATUS.pending,
          never_connected: _constants.UI_COLOR_AGENT_STATUS.never_connected
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-monitoring',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Metric-Alerts',
  _source: {
    title: 'Metric alerts',
    visState: JSON.stringify({
      title: 'Metric Alerts',
      type: 'metric',
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'gauge',
        gauge: {
          verticalSplit: false,
          autoExtend: false,
          percentageMode: false,
          gaugeType: 'Metric',
          gaugeStyle: 'Full',
          backStyle: 'Full',
          orientation: 'vertical',
          colorSchema: 'Green to Red',
          gaugeColorMode: 'None',
          useRange: false,
          colorsRange: [{
            from: 0,
            to: 100
          }],
          invertColors: false,
          labels: {
            show: true,
            color: 'black'
          },
          scale: {
            show: false,
            labels: false,
            color: '#333',
            width: 2
          },
          type: 'simple',
          style: {
            fontSize: 20,
            bgColor: false,
            labelColor: false,
            subText: ''
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'Alerts'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Metric-Max-Rule-Level',
  _source: {
    title: 'Max Rule Level',
    visState: JSON.stringify({
      title: 'Max Rule Level',
      type: 'metric',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'max',
        params: {
          field: 'rule.level',
          customLabel: 'Max Rule Level'
        },
        schema: 'metric'
      }],
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'metric',
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'Labels',
          colorsRange: [{
            from: 0,
            to: 7
          }, {
            from: 7,
            to: 10
          }, {
            from: 10,
            to: 20
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 26
          }
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Metric-Suspicious-Downloads',
  _source: {
    title: 'Suspicious Downloads',
    visState: JSON.stringify({
      title: 'Suspicious Downloads Count',
      type: 'metric',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'filters',
        params: {
          filters: [{
            input: {
              query: 'rule.id: "91724"',
              language: 'kuery'
            },
            label: 'Suspicious Downloads'
          }]
        },
        schema: 'group'
      }],
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'metric',
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'Labels',
          colorsRange: [{
            from: 0,
            to: 1
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 26
          }
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Metric-Malware-Alerts',
  _source: {
    title: 'Malware Alerts',
    visState: JSON.stringify({
      title: 'Malware Alerts Count',
      type: 'metric',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'filters',
        params: {
          filters: [{
            input: {
              query: 'rule.id: "91556" or rule.id: "91575" or rule.id: "91700" ',
              language: 'kuery'
            },
            label: 'Malware Alerts'
          }]
        },
        schema: 'group'
      }],
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'metric',
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'None',
          colorsRange: [{
            from: 0,
            to: 10000
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 26
          }
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Metric-FullAccess-Permissions',
  _source: {
    title: 'Full Access Permissions',
    visState: JSON.stringify({
      title: 'Full Access Permission Count',
      type: 'metric',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'filters',
        params: {
          filters: [{
            input: {
              query: 'rule.id: "91725"',
              language: 'kuery'
            },
            label: 'Full Access Permissions'
          }]
        },
        schema: 'group'
      }],
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'metric',
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'None',
          colorsRange: [{
            from: 0,
            to: 10000
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 26
          }
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Level-12-Alerts',
  _source: {
    title: 'Level 12 alerts',
    visState: JSON.stringify({
      title: 'Count Level 12 Alerts',
      type: 'metric',
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'gauge',
        gauge: {
          verticalSplit: false,
          autoExtend: false,
          percentageMode: false,
          gaugeType: 'Metric',
          gaugeStyle: 'Full',
          backStyle: 'Full',
          orientation: 'vertical',
          colorSchema: 'Green to Red',
          gaugeColorMode: 'None',
          useRange: false,
          colorsRange: [{
            from: 0,
            to: 100
          }],
          invertColors: false,
          labels: {
            show: true,
            color: 'black'
          },
          scale: {
            show: false,
            labels: false,
            color: '#333',
            width: 2
          },
          type: 'simple',
          style: {
            fontSize: 20,
            bgColor: false,
            labelColor: false,
            subText: ''
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'Level 12 or above alerts'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          $state: {
            store: 'appState'
          },
          meta: {
            alias: null,
            disabled: false,
            index: 'wazuh-alerts',
            key: 'rule.level',
            negate: false,
            params: {
              gte: 12,
              lt: null
            },
            type: 'range',
            value: '12 to +∞'
          },
          range: {
            'rule.level': {
              gte: 12,
              lt: null
            }
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Authentication-failure',
  _source: {
    title: 'Authentication failure',
    visState: JSON.stringify({
      title: 'Count Authentication Failure',
      type: 'metric',
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'gauge',
        gauge: {
          verticalSplit: false,
          autoExtend: false,
          percentageMode: false,
          gaugeType: 'Metric',
          gaugeStyle: 'Full',
          backStyle: 'Full',
          orientation: 'vertical',
          colorSchema: 'Green to Red',
          gaugeColorMode: 'None',
          useRange: false,
          colorsRange: [{
            from: 0,
            to: 100
          }],
          invertColors: false,
          labels: {
            show: true,
            color: 'black'
          },
          scale: {
            show: false,
            labels: false,
            color: '#333',
            width: 2
          },
          type: 'simple',
          style: {
            fontSize: 20,
            bgColor: false,
            labelColor: false,
            subText: ''
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'Authentication failure'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            type: 'phrases',
            key: 'rule.groups',
            value: 'win_authentication_failed, authentication_failed, authentication_failures',
            params: ['win_authentication_failed', 'authentication_failed', 'authentication_failures'],
            negate: false,
            disabled: false,
            alias: null
          },
          query: {
            bool: {
              should: [{
                match_phrase: {
                  'rule.groups': 'win_authentication_failed'
                }
              }, {
                match_phrase: {
                  'rule.groups': 'authentication_failed'
                }
              }, {
                match_phrase: {
                  'rule.groups': 'authentication_failures'
                }
              }],
              minimum_should_match: 1
            }
          },
          $state: {
            store: 'appState'
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Authentication-success',
  _source: {
    title: 'Authentication success',
    visState: JSON.stringify({
      title: 'Count Authentication Success',
      type: 'metric',
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'gauge',
        gauge: {
          verticalSplit: false,
          autoExtend: false,
          percentageMode: false,
          gaugeType: 'Metric',
          gaugeStyle: 'Full',
          backStyle: 'Full',
          orientation: 'vertical',
          colorSchema: 'Green to Red',
          gaugeColorMode: 'None',
          useRange: false,
          colorsRange: [{
            from: 0,
            to: 100
          }],
          invertColors: false,
          labels: {
            show: true,
            color: 'black'
          },
          scale: {
            show: false,
            labels: false,
            color: '#333',
            width: 2
          },
          type: 'simple',
          style: {
            fontSize: 20,
            bgColor: false,
            labelColor: false,
            subText: ''
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'Authentication success'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 100': 'rgb(0,104,55)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            negate: false,
            disabled: false,
            alias: null,
            type: 'phrase',
            key: 'rule.groups',
            value: 'authentication_success',
            params: {
              query: 'authentication_success',
              type: 'phrase'
            }
          },
          query: {
            match: {
              'rule.groups': {
                query: 'authentication_success',
                type: 'phrase'
              }
            }
          },
          $state: {
            store: 'appState'
          }
        }],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Alert-Level-Evolution',
  _source: {
    title: 'Alert level evolution',
    visState: JSON.stringify({
      title: 'Alert level evolution',
      type: 'area',
      params: {
        type: 'area',
        grid: {
          categoryLines: true,
          style: {
            color: '#eee'
          },
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'area',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'cardinal',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-24h',
            to: 'now',
            mode: 'quick'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          time_zone: 'Europe/Berlin',
          drop_partials: false,
          customInterval: '2h',
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.level',
          size: '15',
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-Office-Alerts-summary',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'Alerts summary',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMeticsAtAllLevels: false,
        sort: {
          columnIndex: 3,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.id',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 1000,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Rule ID'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 20,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Description'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.level',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 12,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Level'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Metric-Stats',
  _type: 'visualization',
  _source: {
    title: 'Stats',
    visState: JSON.stringify({
      title: 'Metric Stats',
      type: 'metric',
      aggs: [{
        id: '2',
        enabled: true,
        type: 'count',
        params: {
          customLabel: 'Total Alerts'
        },
        schema: 'metric'
      }, {
        id: '1',
        enabled: true,
        type: 'top_hits',
        params: {
          field: 'rule.level',
          aggregate: 'concat',
          size: 1,
          sortField: 'rule.level',
          sortOrder: 'desc',
          customLabel: 'Max rule level detected'
        },
        schema: 'metric'
      }],
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'metric',
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'None',
          colorsRange: [{
            from: 0,
            to: 10000
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 60
          }
        }
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-IPs-By-User-Table',
  _type: 'visualization',
  _source: {
    title: 'Registered IPs for User',
    visState: JSON.stringify({
      title: 'Registered IPs for User',
      type: 'table',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.Actor.ID',
          orderBy: '_key',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Top Users'
        },
        schema: 'bucket'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'agent.id',
          orderBy: '_key',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agent ID'
        },
        schema: 'bucket'
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        params: {
          field: 'agent.name',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agent name'
        },
        schema: 'bucket'
      }],
      params: {
        perPage: 5,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: null,
          direction: null
        },
        showTotal: false,
        totalFunc: 'sum',
        percentageCol: ''
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-User-Operation-Level-Table',
  _type: 'visualization',
  _source: {
    title: 'User Operations',
    visState: JSON.stringify({
      title: 'User Operation Level',
      type: 'table',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.UserId',
          orderBy: '1',
          order: 'desc',
          size: 500,
          otherBucket: true,
          otherBucketLabel: 'Others',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Users'
        },
        schema: 'bucket'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.Operation',
          orderBy: '1',
          order: 'desc',
          size: 100,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Operation'
        },
        schema: 'bucket'
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 20,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Rule level'
        },
        schema: 'bucket'
      }],
      params: {
        perPage: 5,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: null,
          direction: null
        },
        showTotal: false,
        totalFunc: 'sum',
        percentageCol: ''
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Client-IP-Operation-Level-Table',
  _type: 'visualization',
  _source: {
    title: 'Client IP Operations',
    visState: JSON.stringify({
      title: 'Client IP Operation Level',
      type: 'table',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.ClientIP',
          orderBy: '1',
          order: 'desc',
          size: 500,
          otherBucket: true,
          otherBucketLabel: 'Others',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Client IP address'
        },
        schema: 'bucket'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.Operation',
          orderBy: '1',
          order: 'desc',
          size: 100,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Operation'
        },
        schema: 'bucket'
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 20,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Rule level'
        },
        schema: 'bucket'
      }],
      params: {
        perPage: 5,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: null,
          direction: null
        },
        showTotal: false,
        totalFunc: 'sum',
        percentageCol: ''
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Top-Events-Pie',
  _type: 'visualization',
  _source: {
    title: 'Top Events',
    visState: JSON.stringify({
      title: 'Cake',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: false,
        type: 'terms',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.description',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: false,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        row: true
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Alerts-Evolution-By-User',
  _type: 'visualization',
  _source: {
    title: 'Alerts evolution over time',
    visState: JSON.stringify({
      title: 'Alerts evolution over time',
      type: 'line',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-1y',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          scaleMetricValues: false,
          interval: 'h',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.Actor.ID',
          orderBy: '1',
          order: 'asc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'line',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          interpolate: 'linear',
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {},
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        }
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-User-By-Operation-Result',
  _type: 'visualization',
  _source: {
    title: 'User by Operation result',
    visState: JSON.stringify({
      title: 'User By Operation result',
      type: 'table',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.Operation',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Operation'
        },
        schema: 'bucket'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.UserId',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'User'
        },
        schema: 'bucket'
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.ResultStatus',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Result Status'
        },
        schema: 'bucket'
      }],
      params: {
        perPage: 5,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: null,
          direction: null
        },
        showTotal: false,
        totalFunc: 'sum',
        percentageCol: ''
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Rule-Description-Level-Table',
  _type: 'visualization',
  _source: {
    title: 'Rule Description by Level',
    visState: JSON.stringify({
      title: 'Rule Description Level Table',
      type: 'table',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.description',
          orderBy: '1',
          order: 'desc',
          size: 500,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Rule Description'
        },
        schema: 'bucket'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 20,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Rule Level'
        },
        schema: 'bucket'
      }],
      params: {
        perPage: 5,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: null,
          direction: null
        },
        showTotal: false,
        totalFunc: 'sum',
        percentageCol: ''
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Severity-By-User-Histogram',
  _type: 'visualization',
  _source: {
    title: 'Severity by user',
    visState: JSON.stringify({
      title: 'Severity by User',
      type: 'histogram',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.level',
          orderBy: '_key',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Severity'
        },
        schema: 'segment'
      }],
      params: {
        type: 'histogram',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {
          show: false
        },
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        }
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Rule-Level-Histogram',
  _type: 'visualization',
  _source: {
    title: 'Rule level histrogram',
    visState: JSON.stringify({
      title: 'Rule level histogram',
      type: 'area',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now/w',
            to: 'now/w'
          },
          useNormalizedEsInterval: true,
          scaleMetricValues: false,
          interval: '3h',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'area',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100,
            rotate: 0
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          showCircles: true,
          interpolate: 'linear',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        },
        labels: {}
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-IPs-By-User-Barchart',
  _type: 'visualization',
  _source: {
    title: 'IPs by user',
    visState: JSON.stringify({
      title: 'IPs by User',
      type: 'horizontal_bar',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.ClientIP',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'IP'
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.UserId',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'histogram',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 200
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 75,
            filter: true,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {},
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        }
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Severity-By-User-Barchart',
  _type: 'visualization',
  _source: {
    title: 'Severity by user',
    visState: JSON.stringify({
      title: 'Severity By User Barchart',
      type: 'histogram',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: true,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.UserId',
          orderBy: '1',
          order: 'desc',
          size: 20,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'histogram',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {
          show: false
        },
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        }
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Top-Users-By-Subscription-Barchart',
  _type: 'visualization',
  _source: {
    title: 'Top User By Subscription',
    visState: JSON.stringify({
      title: 'Top User By Subscription',
      type: 'histogram',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.UserId',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.Subscription',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'histogram',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100,
            rotate: 0
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {
          show: false
        },
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        }
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Location',
  _type: 'visualization',
  _source: {
    title: 'Geolocation map',
    visState: JSON.stringify({
      title: 'Geolocation map',
      type: 'tile_map',
      params: {
        colorSchema: 'Green to Red',
        mapType: 'Scaled Circle Markers',
        isDesaturated: false,
        addTooltip: true,
        heatClusterSize: 1.5,
        legendPosition: 'bottomright',
        mapZoom: 1,
        mapCenter: [0, 0],
        wms: {
          enabled: false,
          options: {
            format: 'image/png',
            transparent: true
          }
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          geohash: {
            accessor: 0,
            format: {
              id: 'string'
            },
            params: {
              precision: 2,
              useGeocentroid: true
            },
            aggType: 'geohash_grid'
          },
          geocentroid: {
            accessor: 2,
            format: {
              id: 'string'
            },
            params: {},
            aggType: 'geo_centroid'
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'geohash_grid',
        schema: 'segment',
        params: {
          field: 'GeoLocation.location',
          autoPrecision: true,
          precision: 2,
          useGeocentroid: true,
          isFilteredByCollar: true,
          mapZoom: 1,
          mapCenter: [0, 0]
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      mapZoom: 2,
      mapCenter: [38.685509760012025, -31.816406250000004]
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Country-Tag-Cloud',
  _type: 'visualization',
  _source: {
    title: 'Country of origin',
    visState: JSON.stringify({
      title: 'Country tag cloud',
      type: 'tagcloud',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'GeoLocation.country_name',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }],
      params: {
        scale: 'linear',
        orientation: 'right angled',
        minFontSize: 18,
        maxFontSize: 72,
        showLabel: false
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Alerts-Evolution-By-UserID',
  _type: 'visualization',
  _source: {
    title: 'Alerts by user',
    visState: JSON.stringify({
      title: 'Alerts evolution over time',
      type: 'line',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {
          customLabel: 'Alerts'
        },
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-1w',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          scaleMetricValues: false,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.UserId',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'User ID'
        },
        schema: 'group'
      }],
      params: {
        type: 'line',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Alerts'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Alerts',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          interpolate: 'linear',
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {},
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        },
        row: true
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Top-Users',
  _type: 'visualization',
  _source: {
    title: 'Top Office Users',
    visState: JSON.stringify({
      title: 'Alerts by user',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.UserId',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Office-Top-Operations',
  _type: 'visualization',
  _source: {
    title: 'Top Operations',
    visState: JSON.stringify({
      title: 'Top Operations',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.office365.Operation',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Operation'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9kZWZhdWx0IiwiX2lkIiwiX3NvdXJjZSIsInRpdGxlIiwidmlzU3RhdGUiLCJKU09OIiwic3RyaW5naWZ5IiwidHlwZSIsInBhcmFtcyIsImdyaWQiLCJjYXRlZ29yeUxpbmVzIiwic3R5bGUiLCJjb2xvciIsImNhdGVnb3J5QXhlcyIsImlkIiwicG9zaXRpb24iLCJzaG93Iiwic2NhbGUiLCJsYWJlbHMiLCJmaWx0ZXIiLCJ0cnVuY2F0ZSIsInZhbHVlQXhlcyIsIm5hbWUiLCJtb2RlIiwicm90YXRlIiwidGV4dCIsInNlcmllc1BhcmFtcyIsImRyYXdMaW5lc0JldHdlZW5Qb2ludHMiLCJzaG93Q2lyY2xlcyIsImludGVycG9sYXRlIiwibGluZVdpZHRoIiwiZGF0YSIsImxhYmVsIiwidmFsdWVBeGlzIiwiYWRkVG9vbHRpcCIsImFkZExlZ2VuZCIsImxlZ2VuZFBvc2l0aW9uIiwidGltZXMiLCJhZGRUaW1lTWFya2VyIiwiYWdncyIsImVuYWJsZWQiLCJpbnRlcnZhbCIsInNjaGVtYSIsImZpZWxkIiwiY3VzdG9tSW50ZXJ2YWwiLCJtaW5fZG9jX2NvdW50IiwiZXh0ZW5kZWRfYm91bmRzIiwic2l6ZSIsIm9yZGVyIiwib3JkZXJCeSIsInVpU3RhdGVKU09OIiwidmlzIiwiY29sb3JzIiwiYWN0aXZlIiwiVUlfQ09MT1JfQUdFTlRfU1RBVFVTIiwiZGlzY29ubmVjdGVkIiwicGVuZGluZyIsIm5ldmVyX2Nvbm5lY3RlZCIsImRlc2NyaXB0aW9uIiwidmVyc2lvbiIsImtpYmFuYVNhdmVkT2JqZWN0TWV0YSIsInNlYXJjaFNvdXJjZUpTT04iLCJpbmRleCIsInF1ZXJ5IiwibGFuZ3VhZ2UiLCJfdHlwZSIsImdhdWdlIiwidmVydGljYWxTcGxpdCIsImF1dG9FeHRlbmQiLCJwZXJjZW50YWdlTW9kZSIsImdhdWdlVHlwZSIsImdhdWdlU3R5bGUiLCJiYWNrU3R5bGUiLCJvcmllbnRhdGlvbiIsImNvbG9yU2NoZW1hIiwiZ2F1Z2VDb2xvck1vZGUiLCJ1c2VSYW5nZSIsImNvbG9yc1JhbmdlIiwiZnJvbSIsInRvIiwiaW52ZXJ0Q29sb3JzIiwid2lkdGgiLCJmb250U2l6ZSIsImJnQ29sb3IiLCJsYWJlbENvbG9yIiwic3ViVGV4dCIsImN1c3RvbUxhYmVsIiwiZGVmYXVsdENvbG9ycyIsIm1ldHJpYyIsInVzZVJhbmdlcyIsIm1ldHJpY0NvbG9yTW9kZSIsImJnRmlsbCIsImZpbHRlcnMiLCJpbnB1dCIsIiRzdGF0ZSIsInN0b3JlIiwibWV0YSIsImFsaWFzIiwiZGlzYWJsZWQiLCJrZXkiLCJuZWdhdGUiLCJndGUiLCJsdCIsInZhbHVlIiwicmFuZ2UiLCJib29sIiwic2hvdWxkIiwibWF0Y2hfcGhyYXNlIiwibWluaW11bV9zaG91bGRfbWF0Y2giLCJtYXRjaCIsInRpbWVSYW5nZSIsInVzZU5vcm1hbGl6ZWRFc0ludGVydmFsIiwidGltZV96b25lIiwiZHJvcF9wYXJ0aWFscyIsIm90aGVyQnVja2V0Iiwib3RoZXJCdWNrZXRMYWJlbCIsIm1pc3NpbmdCdWNrZXQiLCJtaXNzaW5nQnVja2V0TGFiZWwiLCJwZXJQYWdlIiwic2hvd1BhcnRpYWxSb3dzIiwic2hvd01ldGljc0F0QWxsTGV2ZWxzIiwic29ydCIsImNvbHVtbkluZGV4IiwiZGlyZWN0aW9uIiwic2hvd1RvdGFsIiwic2hvd1Rvb2xiYXIiLCJ0b3RhbEZ1bmMiLCJhZ2dyZWdhdGUiLCJzb3J0RmllbGQiLCJzb3J0T3JkZXIiLCJzaG93TWV0cmljc0F0QWxsTGV2ZWxzIiwicGVyY2VudGFnZUNvbCIsImlzRG9udXQiLCJ2YWx1ZXMiLCJsYXN0X2xldmVsIiwicm93Iiwic2NhbGVNZXRyaWNWYWx1ZXMiLCJ0aHJlc2hvbGRMaW5lIiwibWFwVHlwZSIsImlzRGVzYXR1cmF0ZWQiLCJoZWF0Q2x1c3RlclNpemUiLCJtYXBab29tIiwibWFwQ2VudGVyIiwid21zIiwib3B0aW9ucyIsImZvcm1hdCIsInRyYW5zcGFyZW50IiwiZGltZW5zaW9ucyIsImFjY2Vzc29yIiwiYWdnVHlwZSIsImdlb2hhc2giLCJwcmVjaXNpb24iLCJ1c2VHZW9jZW50cm9pZCIsImdlb2NlbnRyb2lkIiwiYXV0b1ByZWNpc2lvbiIsImlzRmlsdGVyZWRCeUNvbGxhciIsIm1pbkZvbnRTaXplIiwibWF4Rm9udFNpemUiLCJzaG93TGFiZWwiLCJleHBvcnRzIiwiZGVmYXVsdCIsIm1vZHVsZSJdLCJzb3VyY2VzIjpbIm92ZXJ2aWV3LW9mZmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gTW9kdWxlIGZvciBPdmVydmlldy9HZW5lcmFsIHZpc3VhbGl6YXRpb25zXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxuICpcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbjsgZWl0aGVyIHZlcnNpb24gMiBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogRmluZCBtb3JlIGluZm9ybWF0aW9uIGFib3V0IHRoaXMgb24gdGhlIExJQ0VOU0UgZmlsZS5cbiAqL1xuaW1wb3J0IHsgVUlfQ09MT1JfQUdFTlRfU1RBVFVTIH0gZnJvbSBcIi4uLy4uLy4uLy4uL2NvbW1vbi9jb25zdGFudHNcIjtcblxuZXhwb3J0IGRlZmF1bHQgW1xuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1BZ2VudHMtc3RhdHVzJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0FnZW50cyBzdGF0dXMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBZ2VudHMgU3RhdHVzJyxcbiAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgIGdyaWQ6IHsgY2F0ZWdvcnlMaW5lczogZmFsc2UsIHN0eWxlOiB7IGNvbG9yOiAnI2VlZScgfSB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgcm90YXRlOiAwLCBmaWx0ZXI6IGZhbHNlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdDb3VudCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgbW9kZTogJ25vcm1hbCcsXG4gICAgICAgICAgICAgIHR5cGU6ICdsaW5lJyxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgc2hvd0NpcmNsZXM6IHRydWUsXG4gICAgICAgICAgICAgIGludGVycG9sYXRlOiAnY2FyZGluYWwnLFxuICAgICAgICAgICAgICBsaW5lV2lkdGg6IDMuNSxcbiAgICAgICAgICAgICAgZGF0YTogeyBpZDogJzQnLCBsYWJlbDogJ1VuaXF1ZSBjb3VudCBvZiBpZCcgfSxcbiAgICAgICAgICAgICAgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIGludGVydmFsOiAnMW1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAndGltZXN0YW1wJyxcbiAgICAgICAgICAgICAgaW50ZXJ2YWw6ICcxbXMnLFxuICAgICAgICAgICAgICBjdXN0b21JbnRlcnZhbDogJzJoJyxcbiAgICAgICAgICAgICAgbWluX2RvY19jb3VudDogMSxcbiAgICAgICAgICAgICAgZXh0ZW5kZWRfYm91bmRzOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdncm91cCcsXG4gICAgICAgICAgICBwYXJhbXM6IHsgZmllbGQ6ICdzdGF0dXMnLCBzaXplOiA1LCBvcmRlcjogJ2Rlc2MnLCBvcmRlckJ5OiAnX3Rlcm0nIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzQnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjYXJkaW5hbGl0eScsXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7IGZpZWxkOiAnaWQnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdmlzOiB7IGNvbG9yczogeyBhY3RpdmU6IFVJX0NPTE9SX0FHRU5UX1NUQVRVUy5hY3RpdmUsIGRpc2Nvbm5lY3RlZDogVUlfQ09MT1JfQUdFTlRfU1RBVFVTLmRpc2Nvbm5lY3RlZCwgcGVuZGluZzogVUlfQ09MT1JfQUdFTlRfU1RBVFVTLnBlbmRpbmcsIG5ldmVyX2Nvbm5lY3RlZDogVUlfQ09MT1JfQUdFTlRfU1RBVFVTLm5ldmVyX2Nvbm5lY3RlZCB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtbW9uaXRvcmluZycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1NZXRyaWMtQWxlcnRzJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ01ldHJpYyBhbGVydHMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdNZXRyaWMgQWxlcnRzJyxcbiAgICAgICAgdHlwZTogJ21ldHJpYycsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiBmYWxzZSxcbiAgICAgICAgICB0eXBlOiAnZ2F1Z2UnLFxuICAgICAgICAgIGdhdWdlOiB7XG4gICAgICAgICAgICB2ZXJ0aWNhbFNwbGl0OiBmYWxzZSxcbiAgICAgICAgICAgIGF1dG9FeHRlbmQ6IGZhbHNlLFxuICAgICAgICAgICAgcGVyY2VudGFnZU1vZGU6IGZhbHNlLFxuICAgICAgICAgICAgZ2F1Z2VUeXBlOiAnTWV0cmljJyxcbiAgICAgICAgICAgIGdhdWdlU3R5bGU6ICdGdWxsJyxcbiAgICAgICAgICAgIGJhY2tTdHlsZTogJ0Z1bGwnLFxuICAgICAgICAgICAgb3JpZW50YXRpb246ICd2ZXJ0aWNhbCcsXG4gICAgICAgICAgICBjb2xvclNjaGVtYTogJ0dyZWVuIHRvIFJlZCcsXG4gICAgICAgICAgICBnYXVnZUNvbG9yTW9kZTogJ05vbmUnLFxuICAgICAgICAgICAgdXNlUmFuZ2U6IGZhbHNlLFxuICAgICAgICAgICAgY29sb3JzUmFuZ2U6IFt7IGZyb206IDAsIHRvOiAxMDAgfV0sXG4gICAgICAgICAgICBpbnZlcnRDb2xvcnM6IGZhbHNlLFxuICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIGNvbG9yOiAnYmxhY2snIH0sXG4gICAgICAgICAgICBzY2FsZTogeyBzaG93OiBmYWxzZSwgbGFiZWxzOiBmYWxzZSwgY29sb3I6ICcjMzMzJywgd2lkdGg6IDIgfSxcbiAgICAgICAgICAgIHR5cGU6ICdzaW1wbGUnLFxuICAgICAgICAgICAgc3R5bGU6IHsgZm9udFNpemU6IDIwLCBiZ0NvbG9yOiBmYWxzZSwgbGFiZWxDb2xvcjogZmFsc2UsIHN1YlRleHQ6ICcnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgICBwYXJhbXM6IHsgY3VzdG9tTGFiZWw6ICdBbGVydHMnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHsgdmlzOiB7IGRlZmF1bHRDb2xvcnM6IHsgJzAgLSAxMDAnOiAncmdiKDAsMTA0LDU1KScgfSB9IH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLU1ldHJpYy1NYXgtUnVsZS1MZXZlbCcsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdNYXggUnVsZSBMZXZlbCcsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ01heCBSdWxlIExldmVsJyxcbiAgICAgICAgdHlwZTogJ21ldHJpYycsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdtYXgnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnTWF4IFJ1bGUgTGV2ZWwnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIHR5cGU6ICdtZXRyaWMnLFxuICAgICAgICAgIG1ldHJpYzoge1xuICAgICAgICAgICAgcGVyY2VudGFnZU1vZGU6IGZhbHNlLFxuICAgICAgICAgICAgdXNlUmFuZ2VzOiBmYWxzZSxcbiAgICAgICAgICAgIGNvbG9yU2NoZW1hOiAnR3JlZW4gdG8gUmVkJyxcbiAgICAgICAgICAgIG1ldHJpY0NvbG9yTW9kZTogJ0xhYmVscycsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZnJvbTogMCxcbiAgICAgICAgICAgICAgICB0bzogNyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGZyb206IDcsXG4gICAgICAgICAgICAgICAgdG86IDEwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZnJvbTogMTAsXG4gICAgICAgICAgICAgICAgdG86IDIwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgICBzdHlsZToge1xuICAgICAgICAgICAgICBiZ0ZpbGw6ICcjMDAwJyxcbiAgICAgICAgICAgICAgYmdDb2xvcjogZmFsc2UsXG4gICAgICAgICAgICAgIGxhYmVsQ29sb3I6IGZhbHNlLFxuICAgICAgICAgICAgICBzdWJUZXh0OiAnJyxcbiAgICAgICAgICAgICAgZm9udFNpemU6IDI2LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoeyB2aXM6IHsgZGVmYXVsdENvbG9yczogeyAnMCAtIDEwMCc6ICdyZ2IoMCwxMDQsNTUpJyB9IH0gfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046XG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1PZmZpY2UtTWV0cmljLVN1c3BpY2lvdXMtRG93bmxvYWRzJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1N1c3BpY2lvdXMgRG93bmxvYWRzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnU3VzcGljaW91cyBEb3dubG9hZHMgQ291bnQnLFxuICAgICAgICB0eXBlOiAnbWV0cmljJyxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnZmlsdGVycycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmlsdGVyczogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGlucHV0OiB7XG4gICAgICAgICAgICAgICAgICAgIHF1ZXJ5OiAncnVsZS5pZDogXCI5MTcyNFwiJyxcbiAgICAgICAgICAgICAgICAgICAgbGFuZ3VhZ2U6ICdrdWVyeScsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgbGFiZWw6ICdTdXNwaWNpb3VzIERvd25sb2FkcycsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdncm91cCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIHR5cGU6ICdtZXRyaWMnLFxuICAgICAgICAgIG1ldHJpYzoge1xuICAgICAgICAgICAgcGVyY2VudGFnZU1vZGU6IGZhbHNlLFxuICAgICAgICAgICAgdXNlUmFuZ2VzOiBmYWxzZSxcbiAgICAgICAgICAgIGNvbG9yU2NoZW1hOiAnR3JlZW4gdG8gUmVkJyxcbiAgICAgICAgICAgIG1ldHJpY0NvbG9yTW9kZTogJ0xhYmVscycsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZnJvbTogMCxcbiAgICAgICAgICAgICAgICB0bzogMSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpbnZlcnRDb2xvcnM6IGZhbHNlLFxuICAgICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgICAgYmdGaWxsOiAnIzAwMCcsXG4gICAgICAgICAgICAgIGJnQ29sb3I6IGZhbHNlLFxuICAgICAgICAgICAgICBsYWJlbENvbG9yOiBmYWxzZSxcbiAgICAgICAgICAgICAgc3ViVGV4dDogJycsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiAyNixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHsgdmlzOiB7IGRlZmF1bHRDb2xvcnM6IHsgJzAgLSAxMDAnOiAncmdiKDAsMTA0LDU1KScgfSB9IH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLU1ldHJpYy1NYWx3YXJlLUFsZXJ0cycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdNYWx3YXJlIEFsZXJ0cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ01hbHdhcmUgQWxlcnRzIENvdW50JyxcbiAgICAgICAgdHlwZTogJ21ldHJpYycsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2ZpbHRlcnMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpbHRlcnM6IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBpbnB1dDoge1xuICAgICAgICAgICAgICAgICAgICBxdWVyeTogJ3J1bGUuaWQ6IFwiOTE1NTZcIiBvciBydWxlLmlkOiBcIjkxNTc1XCIgb3IgcnVsZS5pZDogXCI5MTcwMFwiICcsXG4gICAgICAgICAgICAgICAgICAgIGxhbmd1YWdlOiAna3VlcnknLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIGxhYmVsOiAnTWFsd2FyZSBBbGVydHMnLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiBmYWxzZSxcbiAgICAgICAgICB0eXBlOiAnbWV0cmljJyxcbiAgICAgICAgICBtZXRyaWM6IHtcbiAgICAgICAgICAgIHBlcmNlbnRhZ2VNb2RlOiBmYWxzZSxcbiAgICAgICAgICAgIHVzZVJhbmdlczogZmFsc2UsXG4gICAgICAgICAgICBjb2xvclNjaGVtYTogJ0dyZWVuIHRvIFJlZCcsXG4gICAgICAgICAgICBtZXRyaWNDb2xvck1vZGU6ICdOb25lJyxcbiAgICAgICAgICAgIGNvbG9yc1JhbmdlOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmcm9tOiAwLFxuICAgICAgICAgICAgICAgIHRvOiAxMDAwMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpbnZlcnRDb2xvcnM6IGZhbHNlLFxuICAgICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgICAgYmdGaWxsOiAnIzAwMCcsXG4gICAgICAgICAgICAgIGJnQ29sb3I6IGZhbHNlLFxuICAgICAgICAgICAgICBsYWJlbENvbG9yOiBmYWxzZSxcbiAgICAgICAgICAgICAgc3ViVGV4dDogJycsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiAyNixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHsgdmlzOiB7IGRlZmF1bHRDb2xvcnM6IHsgJzAgLSAxMDAnOiAncmdiKDAsMTA0LDU1KScgfSB9IH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLU1ldHJpYy1GdWxsQWNjZXNzLVBlcm1pc3Npb25zJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0Z1bGwgQWNjZXNzIFBlcm1pc3Npb25zJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnRnVsbCBBY2Nlc3MgUGVybWlzc2lvbiBDb3VudCcsXG4gICAgICAgIHR5cGU6ICdtZXRyaWMnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdmaWx0ZXJzJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWx0ZXJzOiBbXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgaW5wdXQ6IHtcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk6ICdydWxlLmlkOiBcIjkxNzI1XCInLFxuICAgICAgICAgICAgICAgICAgICBsYW5ndWFnZTogJ2t1ZXJ5JyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICBsYWJlbDogJ0Z1bGwgQWNjZXNzIFBlcm1pc3Npb25zJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogZmFsc2UsXG4gICAgICAgICAgdHlwZTogJ21ldHJpYycsXG4gICAgICAgICAgbWV0cmljOiB7XG4gICAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXG4gICAgICAgICAgICB1c2VSYW5nZXM6IGZhbHNlLFxuICAgICAgICAgICAgY29sb3JTY2hlbWE6ICdHcmVlbiB0byBSZWQnLFxuICAgICAgICAgICAgbWV0cmljQ29sb3JNb2RlOiAnTm9uZScsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZnJvbTogMCxcbiAgICAgICAgICAgICAgICB0bzogMTAwMDAsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgaW52ZXJ0Q29sb3JzOiBmYWxzZSxcbiAgICAgICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICAgIGJnRmlsbDogJyMwMDAnLFxuICAgICAgICAgICAgICBiZ0NvbG9yOiBmYWxzZSxcbiAgICAgICAgICAgICAgbGFiZWxDb2xvcjogZmFsc2UsXG4gICAgICAgICAgICAgIHN1YlRleHQ6ICcnLFxuICAgICAgICAgICAgICBmb250U2l6ZTogMjYsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7IHZpczogeyBkZWZhdWx0Q29sb3JzOiB7ICcwIC0gMTAwJzogJ3JnYigwLDEwNCw1NSknIH0gfSB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjpcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1MZXZlbC0xMi1BbGVydHMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnTGV2ZWwgMTIgYWxlcnRzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQ291bnQgTGV2ZWwgMTIgQWxlcnRzJyxcbiAgICAgICAgdHlwZTogJ21ldHJpYycsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiBmYWxzZSxcbiAgICAgICAgICB0eXBlOiAnZ2F1Z2UnLFxuICAgICAgICAgIGdhdWdlOiB7XG4gICAgICAgICAgICB2ZXJ0aWNhbFNwbGl0OiBmYWxzZSxcbiAgICAgICAgICAgIGF1dG9FeHRlbmQ6IGZhbHNlLFxuICAgICAgICAgICAgcGVyY2VudGFnZU1vZGU6IGZhbHNlLFxuICAgICAgICAgICAgZ2F1Z2VUeXBlOiAnTWV0cmljJyxcbiAgICAgICAgICAgIGdhdWdlU3R5bGU6ICdGdWxsJyxcbiAgICAgICAgICAgIGJhY2tTdHlsZTogJ0Z1bGwnLFxuICAgICAgICAgICAgb3JpZW50YXRpb246ICd2ZXJ0aWNhbCcsXG4gICAgICAgICAgICBjb2xvclNjaGVtYTogJ0dyZWVuIHRvIFJlZCcsXG4gICAgICAgICAgICBnYXVnZUNvbG9yTW9kZTogJ05vbmUnLFxuICAgICAgICAgICAgdXNlUmFuZ2U6IGZhbHNlLFxuICAgICAgICAgICAgY29sb3JzUmFuZ2U6IFt7IGZyb206IDAsIHRvOiAxMDAgfV0sXG4gICAgICAgICAgICBpbnZlcnRDb2xvcnM6IGZhbHNlLFxuICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIGNvbG9yOiAnYmxhY2snIH0sXG4gICAgICAgICAgICBzY2FsZTogeyBzaG93OiBmYWxzZSwgbGFiZWxzOiBmYWxzZSwgY29sb3I6ICcjMzMzJywgd2lkdGg6IDIgfSxcbiAgICAgICAgICAgIHR5cGU6ICdzaW1wbGUnLFxuICAgICAgICAgICAgc3R5bGU6IHsgZm9udFNpemU6IDIwLCBiZ0NvbG9yOiBmYWxzZSwgbGFiZWxDb2xvcjogZmFsc2UsIHN1YlRleHQ6ICcnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgICBwYXJhbXM6IHsgY3VzdG9tTGFiZWw6ICdMZXZlbCAxMiBvciBhYm92ZSBhbGVydHMnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHsgdmlzOiB7IGRlZmF1bHRDb2xvcnM6IHsgJzAgLSAxMDAnOiAncmdiKDAsMTA0LDU1KScgfSB9IH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAkc3RhdGU6IHtcbiAgICAgICAgICAgICAgICBzdG9yZTogJ2FwcFN0YXRlJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbWV0YToge1xuICAgICAgICAgICAgICAgIGFsaWFzOiBudWxsLFxuICAgICAgICAgICAgICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgICAgICAga2V5OiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgICAgbmVnYXRlOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgIGd0ZTogMTIsXG4gICAgICAgICAgICAgICAgICBsdDogbnVsbCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHR5cGU6ICdyYW5nZScsXG4gICAgICAgICAgICAgICAgdmFsdWU6ICcxMiB0byAr4oieJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcmFuZ2U6IHtcbiAgICAgICAgICAgICAgICAncnVsZS5sZXZlbCc6IHtcbiAgICAgICAgICAgICAgICAgIGd0ZTogMTIsXG4gICAgICAgICAgICAgICAgICBsdDogbnVsbCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLUF1dGhlbnRpY2F0aW9uLWZhaWx1cmUnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQXV0aGVudGljYXRpb24gZmFpbHVyZScsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0NvdW50IEF1dGhlbnRpY2F0aW9uIEZhaWx1cmUnLFxuICAgICAgICB0eXBlOiAnbWV0cmljJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIHR5cGU6ICdnYXVnZScsXG4gICAgICAgICAgZ2F1Z2U6IHtcbiAgICAgICAgICAgIHZlcnRpY2FsU3BsaXQ6IGZhbHNlLFxuICAgICAgICAgICAgYXV0b0V4dGVuZDogZmFsc2UsXG4gICAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXG4gICAgICAgICAgICBnYXVnZVR5cGU6ICdNZXRyaWMnLFxuICAgICAgICAgICAgZ2F1Z2VTdHlsZTogJ0Z1bGwnLFxuICAgICAgICAgICAgYmFja1N0eWxlOiAnRnVsbCcsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogJ3ZlcnRpY2FsJyxcbiAgICAgICAgICAgIGNvbG9yU2NoZW1hOiAnR3JlZW4gdG8gUmVkJyxcbiAgICAgICAgICAgIGdhdWdlQ29sb3JNb2RlOiAnTm9uZScsXG4gICAgICAgICAgICB1c2VSYW5nZTogZmFsc2UsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW3sgZnJvbTogMCwgdG86IDEwMCB9XSxcbiAgICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgY29sb3I6ICdibGFjaycgfSxcbiAgICAgICAgICAgIHNjYWxlOiB7IHNob3c6IGZhbHNlLCBsYWJlbHM6IGZhbHNlLCBjb2xvcjogJyMzMzMnLCB3aWR0aDogMiB9LFxuICAgICAgICAgICAgdHlwZTogJ3NpbXBsZScsXG4gICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMjAsIGJnQ29sb3I6IGZhbHNlLCBsYWJlbENvbG9yOiBmYWxzZSwgc3ViVGV4dDogJycgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICAgIHBhcmFtczogeyBjdXN0b21MYWJlbDogJ0F1dGhlbnRpY2F0aW9uIGZhaWx1cmUnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHsgdmlzOiB7IGRlZmF1bHRDb2xvcnM6IHsgJzAgLSAxMDAnOiAncmdiKDAsMTA0LDU1KScgfSB9IH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBtZXRhOiB7XG4gICAgICAgICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2VzJyxcbiAgICAgICAgICAgICAgICBrZXk6ICdydWxlLmdyb3VwcycsXG4gICAgICAgICAgICAgICAgdmFsdWU6ICd3aW5fYXV0aGVudGljYXRpb25fZmFpbGVkLCBhdXRoZW50aWNhdGlvbl9mYWlsZWQsIGF1dGhlbnRpY2F0aW9uX2ZhaWx1cmVzJyxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IFtcbiAgICAgICAgICAgICAgICAgICd3aW5fYXV0aGVudGljYXRpb25fZmFpbGVkJyxcbiAgICAgICAgICAgICAgICAgICdhdXRoZW50aWNhdGlvbl9mYWlsZWQnLFxuICAgICAgICAgICAgICAgICAgJ2F1dGhlbnRpY2F0aW9uX2ZhaWx1cmVzJyxcbiAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgICAgIG5lZ2F0ZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGFsaWFzOiBudWxsLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgICAgIGJvb2w6IHtcbiAgICAgICAgICAgICAgICAgIHNob3VsZDogW1xuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgbWF0Y2hfcGhyYXNlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAncnVsZS5ncm91cHMnOiAnd2luX2F1dGhlbnRpY2F0aW9uX2ZhaWxlZCcsXG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIG1hdGNoX3BocmFzZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ3J1bGUuZ3JvdXBzJzogJ2F1dGhlbnRpY2F0aW9uX2ZhaWxlZCcsXG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgIG1hdGNoX3BocmFzZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ3J1bGUuZ3JvdXBzJzogJ2F1dGhlbnRpY2F0aW9uX2ZhaWx1cmVzJyxcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgIG1pbmltdW1fc2hvdWxkX21hdGNoOiAxLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICRzdGF0ZToge1xuICAgICAgICAgICAgICAgIHN0b3JlOiAnYXBwU3RhdGUnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLUF1dGhlbnRpY2F0aW9uLXN1Y2Nlc3MnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQXV0aGVudGljYXRpb24gc3VjY2VzcycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0NvdW50IEF1dGhlbnRpY2F0aW9uIFN1Y2Nlc3MnLFxuICAgICAgICB0eXBlOiAnbWV0cmljJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIHR5cGU6ICdnYXVnZScsXG4gICAgICAgICAgZ2F1Z2U6IHtcbiAgICAgICAgICAgIHZlcnRpY2FsU3BsaXQ6IGZhbHNlLFxuICAgICAgICAgICAgYXV0b0V4dGVuZDogZmFsc2UsXG4gICAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXG4gICAgICAgICAgICBnYXVnZVR5cGU6ICdNZXRyaWMnLFxuICAgICAgICAgICAgZ2F1Z2VTdHlsZTogJ0Z1bGwnLFxuICAgICAgICAgICAgYmFja1N0eWxlOiAnRnVsbCcsXG4gICAgICAgICAgICBvcmllbnRhdGlvbjogJ3ZlcnRpY2FsJyxcbiAgICAgICAgICAgIGNvbG9yU2NoZW1hOiAnR3JlZW4gdG8gUmVkJyxcbiAgICAgICAgICAgIGdhdWdlQ29sb3JNb2RlOiAnTm9uZScsXG4gICAgICAgICAgICB1c2VSYW5nZTogZmFsc2UsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW3sgZnJvbTogMCwgdG86IDEwMCB9XSxcbiAgICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgY29sb3I6ICdibGFjaycgfSxcbiAgICAgICAgICAgIHNjYWxlOiB7IHNob3c6IGZhbHNlLCBsYWJlbHM6IGZhbHNlLCBjb2xvcjogJyMzMzMnLCB3aWR0aDogMiB9LFxuICAgICAgICAgICAgdHlwZTogJ3NpbXBsZScsXG4gICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMjAsIGJnQ29sb3I6IGZhbHNlLCBsYWJlbENvbG9yOiBmYWxzZSwgc3ViVGV4dDogJycgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICAgIHBhcmFtczogeyBjdXN0b21MYWJlbDogJ0F1dGhlbnRpY2F0aW9uIHN1Y2Nlc3MnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHsgdmlzOiB7IGRlZmF1bHRDb2xvcnM6IHsgJzAgLSAxMDAnOiAncmdiKDAsMTA0LDU1KScgfSB9IH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBtZXRhOiB7XG4gICAgICAgICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgICAgICAgIG5lZ2F0ZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGFsaWFzOiBudWxsLFxuICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2UnLFxuICAgICAgICAgICAgICAgIGtleTogJ3J1bGUuZ3JvdXBzJyxcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ2F1dGhlbnRpY2F0aW9uX3N1Y2Nlc3MnLFxuICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgcXVlcnk6ICdhdXRoZW50aWNhdGlvbl9zdWNjZXNzJyxcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdwaHJhc2UnLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICAgICAgbWF0Y2g6IHtcbiAgICAgICAgICAgICAgICAgICdydWxlLmdyb3Vwcyc6IHtcbiAgICAgICAgICAgICAgICAgICAgcXVlcnk6ICdhdXRoZW50aWNhdGlvbl9zdWNjZXNzJyxcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3BocmFzZScsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICRzdGF0ZToge1xuICAgICAgICAgICAgICAgIHN0b3JlOiAnYXBwU3RhdGUnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLUFsZXJ0LUxldmVsLUV2b2x1dGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdBbGVydCBsZXZlbCBldm9sdXRpb24nLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydCBsZXZlbCBldm9sdXRpb24nLFxuICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdhcmVhJyxcbiAgICAgICAgICBncmlkOiB7IGNhdGVnb3J5TGluZXM6IHRydWUsIHN0eWxlOiB7IGNvbG9yOiAnI2VlZScgfSwgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnIH0sXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnQ2F0ZWdvcnlBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2JvdHRvbScsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIGZpbHRlcjogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnbGVmdCcsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicsIG1vZGU6ICdub3JtYWwnIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCByb3RhdGU6IDAsIGZpbHRlcjogZmFsc2UsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ0NvdW50JyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaG93OiAndHJ1ZScsXG4gICAgICAgICAgICAgIHR5cGU6ICdhcmVhJyxcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxuICAgICAgICAgICAgICBkYXRhOiB7IGxhYmVsOiAnQ291bnQnLCBpZDogJzEnIH0sXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgICBpbnRlcnBvbGF0ZTogJ2NhcmRpbmFsJyxcbiAgICAgICAgICAgICAgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAndGltZXN0YW1wJyxcbiAgICAgICAgICAgICAgdGltZVJhbmdlOiB7IGZyb206ICdub3ctMjRoJywgdG86ICdub3cnLCBtb2RlOiAncXVpY2snIH0sXG4gICAgICAgICAgICAgIHVzZU5vcm1hbGl6ZWRFc0ludGVydmFsOiB0cnVlLFxuICAgICAgICAgICAgICBpbnRlcnZhbDogJ2F1dG8nLFxuICAgICAgICAgICAgICB0aW1lX3pvbmU6ICdFdXJvcGUvQmVybGluJyxcbiAgICAgICAgICAgICAgZHJvcF9wYXJ0aWFsczogZmFsc2UsXG4gICAgICAgICAgICAgIGN1c3RvbUludGVydmFsOiAnMmgnLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxuICAgICAgICAgICAgICBzaXplOiAnMTUnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLUFsZXJ0cy1zdW1tYXJ5JyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydHMgc3VtbWFyeScsXG4gICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDEwLFxuICAgICAgICAgIHNob3dQYXJ0aWFsUm93czogZmFsc2UsXG4gICAgICAgICAgc2hvd01ldGljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgc2hvd1Rvb2xiYXI6IHRydWUsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmlkJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDEwMDAsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSdWxlIElEJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5kZXNjcmlwdGlvbicsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBzaXplOiAyMCxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0Rlc2NyaXB0aW9uJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzQnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBzaXplOiAxMixcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0xldmVsJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdmlzOiB7IHBhcmFtczogeyBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9IH0gfSxcbiAgICAgIH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLU1ldHJpYy1TdGF0cycsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1N0YXRzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnTWV0cmljIFN0YXRzJyxcbiAgICAgICAgdHlwZTogJ21ldHJpYycsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdUb3RhbCBBbGVydHMnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0b3BfaGl0cycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmxldmVsJyxcbiAgICAgICAgICAgICAgYWdncmVnYXRlOiAnY29uY2F0JyxcbiAgICAgICAgICAgICAgc2l6ZTogMSxcbiAgICAgICAgICAgICAgc29ydEZpZWxkOiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgIHNvcnRPcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ01heCBydWxlIGxldmVsIGRldGVjdGVkJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiBmYWxzZSxcbiAgICAgICAgICB0eXBlOiAnbWV0cmljJyxcbiAgICAgICAgICBtZXRyaWM6IHtcbiAgICAgICAgICAgIHBlcmNlbnRhZ2VNb2RlOiBmYWxzZSxcbiAgICAgICAgICAgIHVzZVJhbmdlczogZmFsc2UsXG4gICAgICAgICAgICBjb2xvclNjaGVtYTogJ0dyZWVuIHRvIFJlZCcsXG4gICAgICAgICAgICBtZXRyaWNDb2xvck1vZGU6ICdOb25lJyxcbiAgICAgICAgICAgIGNvbG9yc1JhbmdlOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBmcm9tOiAwLFxuICAgICAgICAgICAgICAgIHRvOiAxMDAwMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBpbnZlcnRDb2xvcnM6IGZhbHNlLFxuICAgICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgICAgYmdGaWxsOiAnIzAwMCcsXG4gICAgICAgICAgICAgIGJnQ29sb3I6IGZhbHNlLFxuICAgICAgICAgICAgICBsYWJlbENvbG9yOiBmYWxzZSxcbiAgICAgICAgICAgICAgc3ViVGV4dDogJycsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiA2MCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1PZmZpY2UtSVBzLUJ5LVVzZXItVGFibGUnLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdSZWdpc3RlcmVkIElQcyBmb3IgVXNlcicsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1JlZ2lzdGVyZWQgSVBzIGZvciBVc2VyJyxcbiAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5vZmZpY2UzNjUuQWN0b3IuSUQnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnX2tleScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1RvcCBVc2VycycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2FnZW50LmlkJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJ19rZXknLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBZ2VudCBJRCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2FnZW50Lm5hbWUnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0FnZW50IG5hbWUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgcGVyUGFnZTogNSxcbiAgICAgICAgICBzaG93UGFydGlhbFJvd3M6IGZhbHNlLFxuICAgICAgICAgIHNob3dNZXRyaWNzQXRBbGxMZXZlbHM6IGZhbHNlLFxuICAgICAgICAgIHNvcnQ6IHtcbiAgICAgICAgICAgIGNvbHVtbkluZGV4OiBudWxsLFxuICAgICAgICAgICAgZGlyZWN0aW9uOiBudWxsLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgc2hvd1RvdGFsOiBmYWxzZSxcbiAgICAgICAgICB0b3RhbEZ1bmM6ICdzdW0nLFxuICAgICAgICAgIHBlcmNlbnRhZ2VDb2w6ICcnLFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1Vc2VyLU9wZXJhdGlvbi1MZXZlbC1UYWJsZScsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1VzZXIgT3BlcmF0aW9ucycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1VzZXIgT3BlcmF0aW9uIExldmVsJyxcbiAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5vZmZpY2UzNjUuVXNlcklkJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1MDAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiB0cnVlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXJzJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1VzZXJzJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5vZmZpY2UzNjUuT3BlcmF0aW9uJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiAxMDAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ09wZXJhdGlvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDIwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSdWxlIGxldmVsJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDUsXG4gICAgICAgICAgc2hvd1BhcnRpYWxSb3dzOiBmYWxzZSxcbiAgICAgICAgICBzaG93TWV0cmljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7XG4gICAgICAgICAgICBjb2x1bW5JbmRleDogbnVsbCxcbiAgICAgICAgICAgIGRpcmVjdGlvbjogbnVsbCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgICBwZXJjZW50YWdlQ29sOiAnJyxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1PZmZpY2UtQ2xpZW50LUlQLU9wZXJhdGlvbi1MZXZlbC1UYWJsZScsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0NsaWVudCBJUCBPcGVyYXRpb25zJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQ2xpZW50IElQIE9wZXJhdGlvbiBMZXZlbCcsXG4gICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEub2ZmaWNlMzY1LkNsaWVudElQJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1MDAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiB0cnVlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXJzJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0NsaWVudCBJUCBhZGRyZXNzJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5vZmZpY2UzNjUuT3BlcmF0aW9uJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiAxMDAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ09wZXJhdGlvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDIwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSdWxlIGxldmVsJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDUsXG4gICAgICAgICAgc2hvd1BhcnRpYWxSb3dzOiBmYWxzZSxcbiAgICAgICAgICBzaG93TWV0cmljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7XG4gICAgICAgICAgICBjb2x1bW5JbmRleDogbnVsbCxcbiAgICAgICAgICAgIGRpcmVjdGlvbjogbnVsbCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgICBwZXJjZW50YWdlQ29sOiAnJyxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1PZmZpY2UtVG9wLUV2ZW50cy1QaWUnLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdUb3AgRXZlbnRzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQ2FrZScsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogZmFsc2UsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmRlc2NyaXB0aW9uJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogZmFsc2UsXG4gICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlczogdHJ1ZSxcbiAgICAgICAgICAgIGxhc3RfbGV2ZWw6IHRydWUsXG4gICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcm93OiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1BbGVydHMtRXZvbHV0aW9uLUJ5LVVzZXInLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdBbGVydHMgZXZvbHV0aW9uIG92ZXIgdGltZScsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0FsZXJ0cyBldm9sdXRpb24gb3ZlciB0aW1lJyxcbiAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICd0aW1lc3RhbXAnLFxuICAgICAgICAgICAgICB0aW1lUmFuZ2U6IHtcbiAgICAgICAgICAgICAgICBmcm9tOiAnbm93LTF5JyxcbiAgICAgICAgICAgICAgICB0bzogJ25vdycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHVzZU5vcm1hbGl6ZWRFc0ludGVydmFsOiB0cnVlLFxuICAgICAgICAgICAgICBzY2FsZU1ldHJpY1ZhbHVlczogZmFsc2UsXG4gICAgICAgICAgICAgIGludGVydmFsOiAnaCcsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5vZmZpY2UzNjUuQWN0b3IuSUQnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnYXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdsaW5lJyxcbiAgICAgICAgICBncmlkOiB7XG4gICAgICAgICAgICBjYXRlZ29yeUxpbmVzOiBmYWxzZSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgICAgZmlsdGVyOiB0cnVlLFxuICAgICAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZToge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICAgIG1vZGU6ICdub3JtYWwnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICAgIHJvdGF0ZTogMCxcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7XG4gICAgICAgICAgICAgICAgdGV4dDogJ0NvdW50JyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcbiAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIGxhYmVsOiAnQ291bnQnLFxuICAgICAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgbGluZVdpZHRoOiAyLFxuICAgICAgICAgICAgICBpbnRlcnBvbGF0ZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgICBsYWJlbHM6IHt9LFxuICAgICAgICAgIHRocmVzaG9sZExpbmU6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWU6IDEwLFxuICAgICAgICAgICAgd2lkdGg6IDEsXG4gICAgICAgICAgICBzdHlsZTogJ2Z1bGwnLFxuICAgICAgICAgICAgY29sb3I6ICcjRTc2NjRDJyxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1Vc2VyLUJ5LU9wZXJhdGlvbi1SZXN1bHQnLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdVc2VyIGJ5IE9wZXJhdGlvbiByZXN1bHQnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdVc2VyIEJ5IE9wZXJhdGlvbiByZXN1bHQnLFxuICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLm9mZmljZTM2NS5PcGVyYXRpb24nLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdPcGVyYXRpb24nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLm9mZmljZTM2NS5Vc2VySWQnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdVc2VyJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICc0JyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5vZmZpY2UzNjUuUmVzdWx0U3RhdHVzJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUmVzdWx0IFN0YXR1cycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBwZXJQYWdlOiA1LFxuICAgICAgICAgIHNob3dQYXJ0aWFsUm93czogZmFsc2UsXG4gICAgICAgICAgc2hvd01ldHJpY3NBdEFsbExldmVsczogZmFsc2UsXG4gICAgICAgICAgc29ydDoge1xuICAgICAgICAgICAgY29sdW1uSW5kZXg6IG51bGwsXG4gICAgICAgICAgICBkaXJlY3Rpb246IG51bGwsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBzaG93VG90YWw6IGZhbHNlLFxuICAgICAgICAgIHRvdGFsRnVuYzogJ3N1bScsXG4gICAgICAgICAgcGVyY2VudGFnZUNvbDogJycsXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLVJ1bGUtRGVzY3JpcHRpb24tTGV2ZWwtVGFibGUnLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdSdWxlIERlc2NyaXB0aW9uIGJ5IExldmVsJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnUnVsZSBEZXNjcmlwdGlvbiBMZXZlbCBUYWJsZScsXG4gICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuZGVzY3JpcHRpb24nLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUwMCxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUnVsZSBEZXNjcmlwdGlvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDIwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSdWxlIExldmVsJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDUsXG4gICAgICAgICAgc2hvd1BhcnRpYWxSb3dzOiBmYWxzZSxcbiAgICAgICAgICBzaG93TWV0cmljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7XG4gICAgICAgICAgICBjb2x1bW5JbmRleDogbnVsbCxcbiAgICAgICAgICAgIGRpcmVjdGlvbjogbnVsbCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgICBwZXJjZW50YWdlQ29sOiAnJyxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1PZmZpY2UtU2V2ZXJpdHktQnktVXNlci1IaXN0b2dyYW0nLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdTZXZlcml0eSBieSB1c2VyJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnU2V2ZXJpdHkgYnkgVXNlcicsXG4gICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmxldmVsJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJ19rZXknLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnU2V2ZXJpdHknLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgIGdyaWQ6IHtcbiAgICAgICAgICAgIGNhdGVnb3J5TGluZXM6IGZhbHNlLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnQ2F0ZWdvcnlBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2JvdHRvbScsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnbGluZWFyJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IHRydWUsXG4gICAgICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgICAgbW9kZTogJ25vcm1hbCcsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgICAgcm90YXRlOiAwLFxuICAgICAgICAgICAgICAgIGZpbHRlcjogZmFsc2UsXG4gICAgICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgICAgICB0ZXh0OiAnQ291bnQnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxuICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgbGFiZWw6ICdDb3VudCcsXG4gICAgICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxuICAgICAgICAgICAgICBsaW5lV2lkdGg6IDIsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgdGhyZXNob2xkTGluZToge1xuICAgICAgICAgICAgc2hvdzogZmFsc2UsXG4gICAgICAgICAgICB2YWx1ZTogMTAsXG4gICAgICAgICAgICB3aWR0aDogMSxcbiAgICAgICAgICAgIHN0eWxlOiAnZnVsbCcsXG4gICAgICAgICAgICBjb2xvcjogJyNFNzY2NEMnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLVJ1bGUtTGV2ZWwtSGlzdG9ncmFtJyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnUnVsZSBsZXZlbCBoaXN0cm9ncmFtJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnUnVsZSBsZXZlbCBoaXN0b2dyYW0nLFxuICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXG4gICAgICAgICAgICAgIHRpbWVSYW5nZToge1xuICAgICAgICAgICAgICAgIGZyb206ICdub3cvdycsXG4gICAgICAgICAgICAgICAgdG86ICdub3cvdycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHVzZU5vcm1hbGl6ZWRFc0ludGVydmFsOiB0cnVlLFxuICAgICAgICAgICAgICBzY2FsZU1ldHJpY1ZhbHVlczogZmFsc2UsXG4gICAgICAgICAgICAgIGludGVydmFsOiAnM2gnLFxuICAgICAgICAgICAgICBkcm9wX3BhcnRpYWxzOiBmYWxzZSxcbiAgICAgICAgICAgICAgbWluX2RvY19jb3VudDogMSxcbiAgICAgICAgICAgICAgZXh0ZW5kZWRfYm91bmRzOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgZ3JpZDoge1xuICAgICAgICAgICAgY2F0ZWdvcnlMaW5lczogZmFsc2UsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBjYXRlZ29yeUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdDYXRlZ29yeUF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICdjYXRlZ29yeScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZToge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICAgIGZpbHRlcjogdHJ1ZSxcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgICAgICAgIHJvdGF0ZTogMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgICAgbW9kZTogJ25vcm1hbCcsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgICAgcm90YXRlOiAwLFxuICAgICAgICAgICAgICAgIGZpbHRlcjogZmFsc2UsXG4gICAgICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgICAgICB0ZXh0OiAnQ291bnQnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxuICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgbGFiZWw6ICdDb3VudCcsXG4gICAgICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgbGluZVdpZHRoOiAyLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJwb2xhdGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgdGltZXM6IFtdLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICAgIHRocmVzaG9sZExpbmU6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWU6IDEwLFxuICAgICAgICAgICAgd2lkdGg6IDEsXG4gICAgICAgICAgICBzdHlsZTogJ2Z1bGwnLFxuICAgICAgICAgICAgY29sb3I6ICcjRTc2NjRDJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGxhYmVsczoge30sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLUlQcy1CeS1Vc2VyLUJhcmNoYXJ0JyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnSVBzIGJ5IHVzZXInLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdJUHMgYnkgVXNlcicsXG4gICAgICAgIHR5cGU6ICdob3Jpem9udGFsX2JhcicsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEub2ZmaWNlMzY1LkNsaWVudElQJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdJUCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLm9mZmljZTM2NS5Vc2VySWQnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICBncmlkOiB7XG4gICAgICAgICAgICBjYXRlZ29yeUxpbmVzOiBmYWxzZSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZToge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICAgIHJvdGF0ZTogMCxcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHRydW5jYXRlOiAyMDAsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgICAgbW9kZTogJ25vcm1hbCcsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgICAgcm90YXRlOiA3NSxcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IHRydWUsXG4gICAgICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgICAgICB0ZXh0OiAnQ291bnQnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxuICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgbGFiZWw6ICdDb3VudCcsXG4gICAgICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxuICAgICAgICAgICAgICBsaW5lV2lkdGg6IDIsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgICBsYWJlbHM6IHt9LFxuICAgICAgICAgIHRocmVzaG9sZExpbmU6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWU6IDEwLFxuICAgICAgICAgICAgd2lkdGg6IDEsXG4gICAgICAgICAgICBzdHlsZTogJ2Z1bGwnLFxuICAgICAgICAgICAgY29sb3I6ICcjRTc2NjRDJyxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1TZXZlcml0eS1CeS1Vc2VyLUJhcmNoYXJ0JyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnU2V2ZXJpdHkgYnkgdXNlcicsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1NldmVyaXR5IEJ5IFVzZXIgQmFyY2hhcnQnLFxuICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IHRydWUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEub2ZmaWNlMzY1LlVzZXJJZCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMjAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICBncmlkOiB7XG4gICAgICAgICAgICBjYXRlZ29yeUxpbmVzOiBmYWxzZSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgICAgZmlsdGVyOiB0cnVlLFxuICAgICAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZToge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICAgIG1vZGU6ICdub3JtYWwnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICAgIHJvdGF0ZTogMCxcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7XG4gICAgICAgICAgICAgICAgdGV4dDogJ0NvdW50JyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXG4gICAgICAgICAgICAgIG1vZGU6ICdzdGFja2VkJyxcbiAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIGxhYmVsOiAnQ291bnQnLFxuICAgICAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgbGluZVdpZHRoOiAyLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHRocmVzaG9sZExpbmU6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWU6IDEwLFxuICAgICAgICAgICAgd2lkdGg6IDEsXG4gICAgICAgICAgICBzdHlsZTogJ2Z1bGwnLFxuICAgICAgICAgICAgY29sb3I6ICcjRTc2NjRDJyxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1Ub3AtVXNlcnMtQnktU3Vic2NyaXB0aW9uLUJhcmNoYXJ0JyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIFVzZXIgQnkgU3Vic2NyaXB0aW9uJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnVG9wIFVzZXIgQnkgU3Vic2NyaXB0aW9uJyxcbiAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEub2ZmaWNlMzY1LlVzZXJJZCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLm9mZmljZTM2NS5TdWJzY3JpcHRpb24nLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICBncmlkOiB7XG4gICAgICAgICAgICBjYXRlZ29yeUxpbmVzOiBmYWxzZSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgICAgZmlsdGVyOiB0cnVlLFxuICAgICAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgICAgICAgcm90YXRlOiAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnbGVmdCcsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnbGluZWFyJyxcbiAgICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgICByb3RhdGU6IDAsXG4gICAgICAgICAgICAgICAgZmlsdGVyOiBmYWxzZSxcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB0aXRsZToge1xuICAgICAgICAgICAgICAgIHRleHQ6ICdDb3VudCcsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgICAgICBtb2RlOiAnc3RhY2tlZCcsXG4gICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBsYWJlbDogJ0NvdW50JyxcbiAgICAgICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIGxpbmVXaWR0aDogMixcbiAgICAgICAgICAgICAgc2hvd0NpcmNsZXM6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgdGltZXM6IFtdLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgc2hvdzogZmFsc2UsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB0aHJlc2hvbGRMaW5lOiB7XG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlOiAxMCxcbiAgICAgICAgICAgIHdpZHRoOiAxLFxuICAgICAgICAgICAgc3R5bGU6ICdmdWxsJyxcbiAgICAgICAgICAgIGNvbG9yOiAnI0U3NjY0QycsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1PZmZpY2UtTG9jYXRpb24nLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdHZW9sb2NhdGlvbiBtYXAnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdHZW9sb2NhdGlvbiBtYXAnLFxuICAgICAgICB0eXBlOiAndGlsZV9tYXAnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBjb2xvclNjaGVtYTogJ0dyZWVuIHRvIFJlZCcsXG4gICAgICAgICAgbWFwVHlwZTogJ1NjYWxlZCBDaXJjbGUgTWFya2VycycsXG4gICAgICAgICAgaXNEZXNhdHVyYXRlZDogZmFsc2UsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBoZWF0Q2x1c3RlclNpemU6IDEuNSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ2JvdHRvbXJpZ2h0JyxcbiAgICAgICAgICBtYXBab29tOiAxLFxuICAgICAgICAgIG1hcENlbnRlcjogWzAsIDBdLFxuICAgICAgICAgIHdtczogeyBlbmFibGVkOiBmYWxzZSwgb3B0aW9uczogeyBmb3JtYXQ6ICdpbWFnZS9wbmcnLCB0cmFuc3BhcmVudDogdHJ1ZSB9IH0sXG4gICAgICAgICAgZGltZW5zaW9uczoge1xuICAgICAgICAgICAgbWV0cmljOiB7IGFjY2Vzc29yOiAxLCBmb3JtYXQ6IHsgaWQ6ICdudW1iZXInIH0sIHBhcmFtczoge30sIGFnZ1R5cGU6ICdjb3VudCcgfSxcbiAgICAgICAgICAgIGdlb2hhc2g6IHtcbiAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXG4gICAgICAgICAgICAgIGZvcm1hdDogeyBpZDogJ3N0cmluZycgfSxcbiAgICAgICAgICAgICAgcGFyYW1zOiB7IHByZWNpc2lvbjogMiwgdXNlR2VvY2VudHJvaWQ6IHRydWUgfSxcbiAgICAgICAgICAgICAgYWdnVHlwZTogJ2dlb2hhc2hfZ3JpZCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2VvY2VudHJvaWQ6IHtcbiAgICAgICAgICAgICAgYWNjZXNzb3I6IDIsXG4gICAgICAgICAgICAgIGZvcm1hdDogeyBpZDogJ3N0cmluZycgfSxcbiAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgYWdnVHlwZTogJ2dlb19jZW50cm9pZCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdnZW9oYXNoX2dyaWQnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdHZW9Mb2NhdGlvbi5sb2NhdGlvbicsXG4gICAgICAgICAgICAgIGF1dG9QcmVjaXNpb246IHRydWUsXG4gICAgICAgICAgICAgIHByZWNpc2lvbjogMixcbiAgICAgICAgICAgICAgdXNlR2VvY2VudHJvaWQ6IHRydWUsXG4gICAgICAgICAgICAgIGlzRmlsdGVyZWRCeUNvbGxhcjogdHJ1ZSxcbiAgICAgICAgICAgICAgbWFwWm9vbTogMSxcbiAgICAgICAgICAgICAgbWFwQ2VudGVyOiBbMCwgMF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIG1hcFpvb206IDIsXG4gICAgICAgIG1hcENlbnRlcjogWzM4LjY4NTUwOTc2MDAxMjAyNSwgLTMxLjgxNjQwNjI1MDAwMDAwNF0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1Db3VudHJ5LVRhZy1DbG91ZCcsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0NvdW50cnkgb2Ygb3JpZ2luJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQ291bnRyeSB0YWcgY2xvdWQnLFxuICAgICAgICB0eXBlOiAndGFnY2xvdWQnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdHZW9Mb2NhdGlvbi5jb3VudHJ5X25hbWUnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHNjYWxlOiAnbGluZWFyJyxcbiAgICAgICAgICBvcmllbnRhdGlvbjogJ3JpZ2h0IGFuZ2xlZCcsXG4gICAgICAgICAgbWluRm9udFNpemU6IDE4LFxuICAgICAgICAgIG1heEZvbnRTaXplOiA3MixcbiAgICAgICAgICBzaG93TGFiZWw6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9mZmljZS1BbGVydHMtRXZvbHV0aW9uLUJ5LVVzZXJJRCcsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0FsZXJ0cyBieSB1c2VyJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQWxlcnRzIGV2b2x1dGlvbiBvdmVyIHRpbWUnLFxuICAgICAgICB0eXBlOiAnbGluZScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBbGVydHMnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICd0aW1lc3RhbXAnLFxuICAgICAgICAgICAgICB0aW1lUmFuZ2U6IHtcbiAgICAgICAgICAgICAgICBmcm9tOiAnbm93LTF3JyxcbiAgICAgICAgICAgICAgICB0bzogJ25vdycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHVzZU5vcm1hbGl6ZWRFc0ludGVydmFsOiB0cnVlLFxuICAgICAgICAgICAgICBzY2FsZU1ldHJpY1ZhbHVlczogZmFsc2UsXG4gICAgICAgICAgICAgIGludGVydmFsOiAnYXV0bycsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5vZmZpY2UzNjUuVXNlcklkJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdVc2VyIElEJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdncm91cCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICAgIGdyaWQ6IHtcbiAgICAgICAgICAgIGNhdGVnb3J5TGluZXM6IGZhbHNlLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnQ2F0ZWdvcnlBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2JvdHRvbScsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnbGluZWFyJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgICBmaWx0ZXI6IHRydWUsXG4gICAgICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgICAgbW9kZTogJ25vcm1hbCcsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgICAgcm90YXRlOiAwLFxuICAgICAgICAgICAgICAgIGZpbHRlcjogZmFsc2UsXG4gICAgICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHtcbiAgICAgICAgICAgICAgICB0ZXh0OiAnQWxlcnRzJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcbiAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIGxhYmVsOiAnQWxlcnRzJyxcbiAgICAgICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIGxpbmVXaWR0aDogMixcbiAgICAgICAgICAgICAgaW50ZXJwb2xhdGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgICAgbGFiZWxzOiB7fSxcbiAgICAgICAgICB0aHJlc2hvbGRMaW5lOiB7XG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlOiAxMCxcbiAgICAgICAgICAgIHdpZHRoOiAxLFxuICAgICAgICAgICAgc3R5bGU6ICdmdWxsJyxcbiAgICAgICAgICAgIGNvbG9yOiAnI0U3NjY0QycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICByb3c6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLVRvcC1Vc2VycycsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1RvcCBPZmZpY2UgVXNlcnMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydHMgYnkgdXNlcicsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLm9mZmljZTM2NS5Vc2VySWQnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlczogdHJ1ZSxcbiAgICAgICAgICAgIGxhc3RfbGV2ZWw6IHRydWUsXG4gICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT2ZmaWNlLVRvcC1PcGVyYXRpb25zJyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIE9wZXJhdGlvbnMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdUb3AgT3BlcmF0aW9ucycsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLm9mZmljZTM2NS5PcGVyYXRpb24nLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ09wZXJhdGlvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogdHJ1ZSxcbiAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxuICAgICAgICAgICAgbGFzdF9sZXZlbDogdHJ1ZSxcbiAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbl07XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQVdBLElBQUFBLFVBQUEsR0FBQUMsT0FBQTtBQVhBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWQSxJQUFBQyxRQUFBLEdBYWUsQ0FDYjtFQUNFQyxHQUFHLEVBQUUseUNBQXlDO0VBQzlDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGVBQWU7SUFDdEJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxlQUFlO01BQ3RCSSxJQUFJLEVBQUUsV0FBVztNQUNqQkMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxXQUFXO1FBQ2pCRSxJQUFJLEVBQUU7VUFBRUMsYUFBYSxFQUFFLEtBQUs7VUFBRUMsS0FBSyxFQUFFO1lBQUVDLEtBQUssRUFBRTtVQUFPO1FBQUUsQ0FBQztRQUN4REMsWUFBWSxFQUFFLENBQ1o7VUFDRUMsRUFBRSxFQUFFLGdCQUFnQjtVQUNwQlAsSUFBSSxFQUFFLFVBQVU7VUFDaEJRLFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUFFVixJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pCVyxNQUFNLEVBQUU7WUFBRUYsSUFBSSxFQUFFLElBQUk7WUFBRUcsTUFBTSxFQUFFLElBQUk7WUFBRUMsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUNuRGpCLEtBQUssRUFBRSxDQUFDO1FBQ1YsQ0FBQyxDQUNGO1FBQ0RrQixTQUFTLEVBQUUsQ0FDVDtVQUNFUCxFQUFFLEVBQUUsYUFBYTtVQUNqQlEsSUFBSSxFQUFFLFlBQVk7VUFDbEJmLElBQUksRUFBRSxPQUFPO1VBQ2JRLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUFFVixJQUFJLEVBQUUsUUFBUTtZQUFFZ0IsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6Q0wsTUFBTSxFQUFFO1lBQUVGLElBQUksRUFBRSxJQUFJO1lBQUVRLE1BQU0sRUFBRSxDQUFDO1lBQUVMLE1BQU0sRUFBRSxLQUFLO1lBQUVDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDL0RqQixLQUFLLEVBQUU7WUFBRXNCLElBQUksRUFBRTtVQUFRO1FBQ3pCLENBQUMsQ0FDRjtRQUNEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFVixJQUFJLEVBQUUsSUFBSTtVQUNWTyxJQUFJLEVBQUUsUUFBUTtVQUNkaEIsSUFBSSxFQUFFLE1BQU07VUFDWm9CLHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFdBQVcsRUFBRSxJQUFJO1VBQ2pCQyxXQUFXLEVBQUUsVUFBVTtVQUN2QkMsU0FBUyxFQUFFLEdBQUc7VUFDZEMsSUFBSSxFQUFFO1lBQUVqQixFQUFFLEVBQUUsR0FBRztZQUFFa0IsS0FBSyxFQUFFO1VBQXFCLENBQUM7VUFDOUNDLFNBQVMsRUFBRTtRQUNiLENBQUMsQ0FDRjtRQUNEQyxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJDLEtBQUssRUFBRSxFQUFFO1FBQ1RDLGFBQWEsRUFBRTtNQUNqQixDQUFDO01BQ0RDLElBQUksRUFBRSxDQUNKO1FBQ0V6QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxnQkFBZ0I7UUFDdEJrQyxRQUFRLEVBQUUsS0FBSztRQUNmQyxNQUFNLEVBQUUsU0FBUztRQUNqQmxDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLFdBQVc7VUFDbEJGLFFBQVEsRUFBRSxLQUFLO1VBQ2ZHLGNBQWMsRUFBRSxJQUFJO1VBQ3BCQyxhQUFhLEVBQUUsQ0FBQztVQUNoQkMsZUFBZSxFQUFFLENBQUM7UUFDcEI7TUFDRixDQUFDLEVBQ0Q7UUFDRWhDLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYm1DLE1BQU0sRUFBRSxPQUFPO1FBQ2ZsQyxNQUFNLEVBQUU7VUFBRW1DLEtBQUssRUFBRSxRQUFRO1VBQUVJLElBQUksRUFBRSxDQUFDO1VBQUVDLEtBQUssRUFBRSxNQUFNO1VBQUVDLE9BQU8sRUFBRTtRQUFRO01BQ3RFLENBQUMsRUFDRDtRQUNFbkMsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsYUFBYTtRQUNuQm1DLE1BQU0sRUFBRSxRQUFRO1FBQ2hCbEMsTUFBTSxFQUFFO1VBQUVtQyxLQUFLLEVBQUU7UUFBSztNQUN4QixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZPLFdBQVcsRUFBRTdDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQzFCNkMsR0FBRyxFQUFFO1FBQUVDLE1BQU0sRUFBRTtVQUFFQyxNQUFNLEVBQUVDLGdDQUFxQixDQUFDRCxNQUFNO1VBQUVFLFlBQVksRUFBRUQsZ0NBQXFCLENBQUNDLFlBQVk7VUFBRUMsT0FBTyxFQUFFRixnQ0FBcUIsQ0FBQ0UsT0FBTztVQUFFQyxlQUFlLEVBQUVILGdDQUFxQixDQUFDRztRQUFnQjtNQUFFO0lBQzVNLENBQUMsQ0FBQztJQUNGQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxrQkFBa0I7UUFDekIzQyxNQUFNLEVBQUUsRUFBRTtRQUNWNEMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VoRSxHQUFHLEVBQUUseUNBQXlDO0VBQzlDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGVBQWU7SUFDdEJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxlQUFlO01BQ3RCSSxJQUFJLEVBQUUsUUFBUTtNQUNkQyxNQUFNLEVBQUU7UUFDTjBCLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsS0FBSztRQUNoQjVCLElBQUksRUFBRSxPQUFPO1FBQ2IyRCxLQUFLLEVBQUU7VUFDTEMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLFVBQVUsRUFBRSxLQUFLO1VBQ2pCQyxjQUFjLEVBQUUsS0FBSztVQUNyQkMsU0FBUyxFQUFFLFFBQVE7VUFDbkJDLFVBQVUsRUFBRSxNQUFNO1VBQ2xCQyxTQUFTLEVBQUUsTUFBTTtVQUNqQkMsV0FBVyxFQUFFLFVBQVU7VUFDdkJDLFdBQVcsRUFBRSxjQUFjO1VBQzNCQyxjQUFjLEVBQUUsTUFBTTtVQUN0QkMsUUFBUSxFQUFFLEtBQUs7VUFDZkMsV0FBVyxFQUFFLENBQUM7WUFBRUMsSUFBSSxFQUFFLENBQUM7WUFBRUMsRUFBRSxFQUFFO1VBQUksQ0FBQyxDQUFDO1VBQ25DQyxZQUFZLEVBQUUsS0FBSztVQUNuQjlELE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsSUFBSTtZQUFFSixLQUFLLEVBQUU7VUFBUSxDQUFDO1VBQ3RDSyxLQUFLLEVBQUU7WUFBRUQsSUFBSSxFQUFFLEtBQUs7WUFBRUUsTUFBTSxFQUFFLEtBQUs7WUFBRU4sS0FBSyxFQUFFLE1BQU07WUFBRXFFLEtBQUssRUFBRTtVQUFFLENBQUM7VUFDOUQxRSxJQUFJLEVBQUUsUUFBUTtVQUNkSSxLQUFLLEVBQUU7WUFBRXVFLFFBQVEsRUFBRSxFQUFFO1lBQUVDLE9BQU8sRUFBRSxLQUFLO1lBQUVDLFVBQVUsRUFBRSxLQUFLO1lBQUVDLE9BQU8sRUFBRTtVQUFHO1FBQ3hFO01BQ0YsQ0FBQztNQUNEOUMsSUFBSSxFQUFFLENBQ0o7UUFDRXpCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYm1DLE1BQU0sRUFBRSxRQUFRO1FBQ2hCbEMsTUFBTSxFQUFFO1VBQUU4RSxXQUFXLEVBQUU7UUFBUztNQUNsQyxDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZwQyxXQUFXLEVBQUU3QyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUFFNkMsR0FBRyxFQUFFO1FBQUVvQyxhQUFhLEVBQUU7VUFBRSxTQUFTLEVBQUU7UUFBZ0I7TUFBRTtJQUFFLENBQUMsQ0FBQztJQUN2RjdCLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFDZDtJQUNKO0VBQ0YsQ0FBQztFQUNESSxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRWhFLEdBQUcsRUFBRSxpREFBaUQ7RUFDdERDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsZ0JBQWdCO0lBQ3ZCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsZ0JBQWdCO01BQ3ZCSSxJQUFJLEVBQUUsUUFBUTtNQUNkZ0MsSUFBSSxFQUFFLENBQ0o7UUFDRXpCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLEtBQUs7UUFDWEMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsWUFBWTtVQUNuQjJDLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRDVDLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNEbEMsTUFBTSxFQUFFO1FBQ04wQixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLEtBQUs7UUFDaEI1QixJQUFJLEVBQUUsUUFBUTtRQUNkaUYsTUFBTSxFQUFFO1VBQ05uQixjQUFjLEVBQUUsS0FBSztVQUNyQm9CLFNBQVMsRUFBRSxLQUFLO1VBQ2hCZixXQUFXLEVBQUUsY0FBYztVQUMzQmdCLGVBQWUsRUFBRSxRQUFRO1VBQ3pCYixXQUFXLEVBQUUsQ0FDWDtZQUNFQyxJQUFJLEVBQUUsQ0FBQztZQUNQQyxFQUFFLEVBQUU7VUFDTixDQUFDLEVBQ0Q7WUFDRUQsSUFBSSxFQUFFLENBQUM7WUFDUEMsRUFBRSxFQUFFO1VBQ04sQ0FBQyxFQUNEO1lBQ0VELElBQUksRUFBRSxFQUFFO1lBQ1JDLEVBQUUsRUFBRTtVQUNOLENBQUMsQ0FDRjtVQUNEN0QsTUFBTSxFQUFFO1lBQ05GLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRGdFLFlBQVksRUFBRSxLQUFLO1VBQ25CckUsS0FBSyxFQUFFO1lBQ0xnRixNQUFNLEVBQUUsTUFBTTtZQUNkUixPQUFPLEVBQUUsS0FBSztZQUNkQyxVQUFVLEVBQUUsS0FBSztZQUNqQkMsT0FBTyxFQUFFLEVBQUU7WUFDWEgsUUFBUSxFQUFFO1VBQ1o7UUFDRjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0ZoQyxXQUFXLEVBQUU3QyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUFFNkMsR0FBRyxFQUFFO1FBQUVvQyxhQUFhLEVBQUU7VUFBRSxTQUFTLEVBQUU7UUFBZ0I7TUFBRTtJQUFFLENBQUMsQ0FBQztJQUN2RjdCLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFDZDtJQUNKO0VBQ0YsQ0FBQztFQUNESSxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRWhFLEdBQUcsRUFBRSx1REFBdUQ7RUFDNURDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsc0JBQXNCO0lBQzdCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsNEJBQTRCO01BQ25DSSxJQUFJLEVBQUUsUUFBUTtNQUNkZ0MsSUFBSSxFQUFFLENBQ0o7UUFDRXpCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWa0MsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxTQUFTO1FBQ2ZDLE1BQU0sRUFBRTtVQUNOb0YsT0FBTyxFQUFFLENBQ1A7WUFDRUMsS0FBSyxFQUFFO2NBQ0w5QixLQUFLLEVBQUUsa0JBQWtCO2NBQ3pCQyxRQUFRLEVBQUU7WUFDWixDQUFDO1lBQ0RoQyxLQUFLLEVBQUU7VUFDVCxDQUFDO1FBRUwsQ0FBQztRQUNEVSxNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDRGxDLE1BQU0sRUFBRTtRQUNOMEIsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCNUIsSUFBSSxFQUFFLFFBQVE7UUFDZGlGLE1BQU0sRUFBRTtVQUNObkIsY0FBYyxFQUFFLEtBQUs7VUFDckJvQixTQUFTLEVBQUUsS0FBSztVQUNoQmYsV0FBVyxFQUFFLGNBQWM7VUFDM0JnQixlQUFlLEVBQUUsUUFBUTtVQUN6QmIsV0FBVyxFQUFFLENBQ1g7WUFDRUMsSUFBSSxFQUFFLENBQUM7WUFDUEMsRUFBRSxFQUFFO1VBQ04sQ0FBQyxDQUNGO1VBQ0Q3RCxNQUFNLEVBQUU7WUFDTkYsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEZ0UsWUFBWSxFQUFFLEtBQUs7VUFDbkJyRSxLQUFLLEVBQUU7WUFDTGdGLE1BQU0sRUFBRSxNQUFNO1lBQ2RSLE9BQU8sRUFBRSxLQUFLO1lBQ2RDLFVBQVUsRUFBRSxLQUFLO1lBQ2pCQyxPQUFPLEVBQUUsRUFBRTtZQUNYSCxRQUFRLEVBQUU7VUFDWjtRQUNGO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFDRmhDLFdBQVcsRUFBRTdDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQUU2QyxHQUFHLEVBQUU7UUFBRW9DLGFBQWEsRUFBRTtVQUFFLFNBQVMsRUFBRTtRQUFnQjtNQUFFO0lBQUUsQ0FBQyxDQUFDO0lBQ3ZGN0IsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUNkO0lBQ0o7RUFDRixDQUFDO0VBQ0RJLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFaEUsR0FBRyxFQUFFLGlEQUFpRDtFQUN0REMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxzQkFBc0I7TUFDN0JJLElBQUksRUFBRSxRQUFRO01BQ2RnQyxJQUFJLEVBQUUsQ0FDSjtRQUNFekIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZrQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLFNBQVM7UUFDZkMsTUFBTSxFQUFFO1VBQ05vRixPQUFPLEVBQUUsQ0FDUDtZQUNFQyxLQUFLLEVBQUU7Y0FDTDlCLEtBQUssRUFBRSwyREFBMkQ7Y0FDbEVDLFFBQVEsRUFBRTtZQUNaLENBQUM7WUFDRGhDLEtBQUssRUFBRTtVQUNULENBQUM7UUFFTCxDQUFDO1FBQ0RVLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNEbEMsTUFBTSxFQUFFO1FBQ04wQixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLEtBQUs7UUFDaEI1QixJQUFJLEVBQUUsUUFBUTtRQUNkaUYsTUFBTSxFQUFFO1VBQ05uQixjQUFjLEVBQUUsS0FBSztVQUNyQm9CLFNBQVMsRUFBRSxLQUFLO1VBQ2hCZixXQUFXLEVBQUUsY0FBYztVQUMzQmdCLGVBQWUsRUFBRSxNQUFNO1VBQ3ZCYixXQUFXLEVBQUUsQ0FDWDtZQUNFQyxJQUFJLEVBQUUsQ0FBQztZQUNQQyxFQUFFLEVBQUU7VUFDTixDQUFDLENBQ0Y7VUFDRDdELE1BQU0sRUFBRTtZQUNORixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RnRSxZQUFZLEVBQUUsS0FBSztVQUNuQnJFLEtBQUssRUFBRTtZQUNMZ0YsTUFBTSxFQUFFLE1BQU07WUFDZFIsT0FBTyxFQUFFLEtBQUs7WUFDZEMsVUFBVSxFQUFFLEtBQUs7WUFDakJDLE9BQU8sRUFBRSxFQUFFO1lBQ1hILFFBQVEsRUFBRTtVQUNaO1FBQ0Y7TUFDRjtJQUNGLENBQUMsQ0FBQztJQUNGaEMsV0FBVyxFQUFFN0MsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFBRTZDLEdBQUcsRUFBRTtRQUFFb0MsYUFBYSxFQUFFO1VBQUUsU0FBUyxFQUFFO1FBQWdCO01BQUU7SUFBRSxDQUFDLENBQUM7SUFDdkY3QixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQ2Q7SUFDSjtFQUNGLENBQUM7RUFDREksS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VoRSxHQUFHLEVBQUUseURBQXlEO0VBQzlEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHlCQUF5QjtJQUNoQ0MsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLDhCQUE4QjtNQUNyQ0ksSUFBSSxFQUFFLFFBQVE7TUFDZGdDLElBQUksRUFBRSxDQUNKO1FBQ0V6QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVmtDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsU0FBUztRQUNmQyxNQUFNLEVBQUU7VUFDTm9GLE9BQU8sRUFBRSxDQUNQO1lBQ0VDLEtBQUssRUFBRTtjQUNMOUIsS0FBSyxFQUFFLGtCQUFrQjtjQUN6QkMsUUFBUSxFQUFFO1lBQ1osQ0FBQztZQUNEaEMsS0FBSyxFQUFFO1VBQ1QsQ0FBQztRQUVMLENBQUM7UUFDRFUsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUNGO01BQ0RsQyxNQUFNLEVBQUU7UUFDTjBCLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsS0FBSztRQUNoQjVCLElBQUksRUFBRSxRQUFRO1FBQ2RpRixNQUFNLEVBQUU7VUFDTm5CLGNBQWMsRUFBRSxLQUFLO1VBQ3JCb0IsU0FBUyxFQUFFLEtBQUs7VUFDaEJmLFdBQVcsRUFBRSxjQUFjO1VBQzNCZ0IsZUFBZSxFQUFFLE1BQU07VUFDdkJiLFdBQVcsRUFBRSxDQUNYO1lBQ0VDLElBQUksRUFBRSxDQUFDO1lBQ1BDLEVBQUUsRUFBRTtVQUNOLENBQUMsQ0FDRjtVQUNEN0QsTUFBTSxFQUFFO1lBQ05GLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRGdFLFlBQVksRUFBRSxLQUFLO1VBQ25CckUsS0FBSyxFQUFFO1lBQ0xnRixNQUFNLEVBQUUsTUFBTTtZQUNkUixPQUFPLEVBQUUsS0FBSztZQUNkQyxVQUFVLEVBQUUsS0FBSztZQUNqQkMsT0FBTyxFQUFFLEVBQUU7WUFDWEgsUUFBUSxFQUFFO1VBQ1o7UUFDRjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0ZoQyxXQUFXLEVBQUU3QyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUFFNkMsR0FBRyxFQUFFO1FBQUVvQyxhQUFhLEVBQUU7VUFBRSxTQUFTLEVBQUU7UUFBZ0I7TUFBRTtJQUFFLENBQUMsQ0FBQztJQUN2RjdCLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFDZDtJQUNKO0VBQ0YsQ0FBQztFQUNESSxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRWhFLEdBQUcsRUFBRSwyQ0FBMkM7RUFDaERDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsaUJBQWlCO0lBQ3hCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsdUJBQXVCO01BQzlCSSxJQUFJLEVBQUUsUUFBUTtNQUNkQyxNQUFNLEVBQUU7UUFDTjBCLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsS0FBSztRQUNoQjVCLElBQUksRUFBRSxPQUFPO1FBQ2IyRCxLQUFLLEVBQUU7VUFDTEMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLFVBQVUsRUFBRSxLQUFLO1VBQ2pCQyxjQUFjLEVBQUUsS0FBSztVQUNyQkMsU0FBUyxFQUFFLFFBQVE7VUFDbkJDLFVBQVUsRUFBRSxNQUFNO1VBQ2xCQyxTQUFTLEVBQUUsTUFBTTtVQUNqQkMsV0FBVyxFQUFFLFVBQVU7VUFDdkJDLFdBQVcsRUFBRSxjQUFjO1VBQzNCQyxjQUFjLEVBQUUsTUFBTTtVQUN0QkMsUUFBUSxFQUFFLEtBQUs7VUFDZkMsV0FBVyxFQUFFLENBQUM7WUFBRUMsSUFBSSxFQUFFLENBQUM7WUFBRUMsRUFBRSxFQUFFO1VBQUksQ0FBQyxDQUFDO1VBQ25DQyxZQUFZLEVBQUUsS0FBSztVQUNuQjlELE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsSUFBSTtZQUFFSixLQUFLLEVBQUU7VUFBUSxDQUFDO1VBQ3RDSyxLQUFLLEVBQUU7WUFBRUQsSUFBSSxFQUFFLEtBQUs7WUFBRUUsTUFBTSxFQUFFLEtBQUs7WUFBRU4sS0FBSyxFQUFFLE1BQU07WUFBRXFFLEtBQUssRUFBRTtVQUFFLENBQUM7VUFDOUQxRSxJQUFJLEVBQUUsUUFBUTtVQUNkSSxLQUFLLEVBQUU7WUFBRXVFLFFBQVEsRUFBRSxFQUFFO1lBQUVDLE9BQU8sRUFBRSxLQUFLO1lBQUVDLFVBQVUsRUFBRSxLQUFLO1lBQUVDLE9BQU8sRUFBRTtVQUFHO1FBQ3hFO01BQ0YsQ0FBQztNQUNEOUMsSUFBSSxFQUFFLENBQ0o7UUFDRXpCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYm1DLE1BQU0sRUFBRSxRQUFRO1FBQ2hCbEMsTUFBTSxFQUFFO1VBQUU4RSxXQUFXLEVBQUU7UUFBMkI7TUFDcEQsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGcEMsV0FBVyxFQUFFN0MsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFBRTZDLEdBQUcsRUFBRTtRQUFFb0MsYUFBYSxFQUFFO1VBQUUsU0FBUyxFQUFFO1FBQWdCO01BQUU7SUFBRSxDQUFDLENBQUM7SUFDdkY3QixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCM0MsTUFBTSxFQUFFLENBQ047VUFDRTJFLE1BQU0sRUFBRTtZQUNOQyxLQUFLLEVBQUU7VUFDVCxDQUFDO1VBQ0RDLElBQUksRUFBRTtZQUNKQyxLQUFLLEVBQUUsSUFBSTtZQUNYQyxRQUFRLEVBQUUsS0FBSztZQUNmcEMsS0FBSyxFQUFFLGNBQWM7WUFDckJxQyxHQUFHLEVBQUUsWUFBWTtZQUNqQkMsTUFBTSxFQUFFLEtBQUs7WUFDYjVGLE1BQU0sRUFBRTtjQUNONkYsR0FBRyxFQUFFLEVBQUU7Y0FDUEMsRUFBRSxFQUFFO1lBQ04sQ0FBQztZQUNEL0YsSUFBSSxFQUFFLE9BQU87WUFDYmdHLEtBQUssRUFBRTtVQUNULENBQUM7VUFDREMsS0FBSyxFQUFFO1lBQ0wsWUFBWSxFQUFFO2NBQ1pILEdBQUcsRUFBRSxFQUFFO2NBQ1BDLEVBQUUsRUFBRTtZQUNOO1VBQ0Y7UUFDRixDQUFDLENBQ0Y7UUFDRHZDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFaEUsR0FBRyxFQUFFLGtEQUFrRDtFQUN2REMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSx3QkFBd0I7SUFDL0JDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSw4QkFBOEI7TUFDckNJLElBQUksRUFBRSxRQUFRO01BQ2RDLE1BQU0sRUFBRTtRQUNOMEIsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCNUIsSUFBSSxFQUFFLE9BQU87UUFDYjJELEtBQUssRUFBRTtVQUNMQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsVUFBVSxFQUFFLEtBQUs7VUFDakJDLGNBQWMsRUFBRSxLQUFLO1VBQ3JCQyxTQUFTLEVBQUUsUUFBUTtVQUNuQkMsVUFBVSxFQUFFLE1BQU07VUFDbEJDLFNBQVMsRUFBRSxNQUFNO1VBQ2pCQyxXQUFXLEVBQUUsVUFBVTtVQUN2QkMsV0FBVyxFQUFFLGNBQWM7VUFDM0JDLGNBQWMsRUFBRSxNQUFNO1VBQ3RCQyxRQUFRLEVBQUUsS0FBSztVQUNmQyxXQUFXLEVBQUUsQ0FBQztZQUFFQyxJQUFJLEVBQUUsQ0FBQztZQUFFQyxFQUFFLEVBQUU7VUFBSSxDQUFDLENBQUM7VUFDbkNDLFlBQVksRUFBRSxLQUFLO1VBQ25COUQsTUFBTSxFQUFFO1lBQUVGLElBQUksRUFBRSxJQUFJO1lBQUVKLEtBQUssRUFBRTtVQUFRLENBQUM7VUFDdENLLEtBQUssRUFBRTtZQUFFRCxJQUFJLEVBQUUsS0FBSztZQUFFRSxNQUFNLEVBQUUsS0FBSztZQUFFTixLQUFLLEVBQUUsTUFBTTtZQUFFcUUsS0FBSyxFQUFFO1VBQUUsQ0FBQztVQUM5RDFFLElBQUksRUFBRSxRQUFRO1VBQ2RJLEtBQUssRUFBRTtZQUFFdUUsUUFBUSxFQUFFLEVBQUU7WUFBRUMsT0FBTyxFQUFFLEtBQUs7WUFBRUMsVUFBVSxFQUFFLEtBQUs7WUFBRUMsT0FBTyxFQUFFO1VBQUc7UUFDeEU7TUFDRixDQUFDO01BQ0Q5QyxJQUFJLEVBQUUsQ0FDSjtRQUNFekIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNibUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJsQyxNQUFNLEVBQUU7VUFBRThFLFdBQVcsRUFBRTtRQUF5QjtNQUNsRCxDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZwQyxXQUFXLEVBQUU3QyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUFFNkMsR0FBRyxFQUFFO1FBQUVvQyxhQUFhLEVBQUU7VUFBRSxTQUFTLEVBQUU7UUFBZ0I7TUFBRTtJQUFFLENBQUMsQ0FBQztJQUN2RjdCLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXhELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cd0QsS0FBSyxFQUFFLGNBQWM7UUFDckIzQyxNQUFNLEVBQUUsQ0FDTjtVQUNFNkUsSUFBSSxFQUFFO1lBQ0psQyxLQUFLLEVBQUUsY0FBYztZQUNyQnZELElBQUksRUFBRSxTQUFTO1lBQ2Y0RixHQUFHLEVBQUUsYUFBYTtZQUNsQkksS0FBSyxFQUFFLDJFQUEyRTtZQUNsRi9GLE1BQU0sRUFBRSxDQUNOLDJCQUEyQixFQUMzQix1QkFBdUIsRUFDdkIseUJBQXlCLENBQzFCO1lBQ0Q0RixNQUFNLEVBQUUsS0FBSztZQUNiRixRQUFRLEVBQUUsS0FBSztZQUNmRCxLQUFLLEVBQUU7VUFDVCxDQUFDO1VBQ0RsQyxLQUFLLEVBQUU7WUFDTDBDLElBQUksRUFBRTtjQUNKQyxNQUFNLEVBQUUsQ0FDTjtnQkFDRUMsWUFBWSxFQUFFO2tCQUNaLGFBQWEsRUFBRTtnQkFDakI7Y0FDRixDQUFDLEVBQ0Q7Z0JBQ0VBLFlBQVksRUFBRTtrQkFDWixhQUFhLEVBQUU7Z0JBQ2pCO2NBQ0YsQ0FBQyxFQUNEO2dCQUNFQSxZQUFZLEVBQUU7a0JBQ1osYUFBYSxFQUFFO2dCQUNqQjtjQUNGLENBQUMsQ0FDRjtjQUNEQyxvQkFBb0IsRUFBRTtZQUN4QjtVQUNGLENBQUM7VUFDRGQsTUFBTSxFQUFFO1lBQ05DLEtBQUssRUFBRTtVQUNUO1FBQ0YsQ0FBQyxDQUNGO1FBQ0RoQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRWhFLEdBQUcsRUFBRSxrREFBa0Q7RUFDdkRDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsd0JBQXdCO0lBQy9CQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsOEJBQThCO01BQ3JDSSxJQUFJLEVBQUUsUUFBUTtNQUNkQyxNQUFNLEVBQUU7UUFDTjBCLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsS0FBSztRQUNoQjVCLElBQUksRUFBRSxPQUFPO1FBQ2IyRCxLQUFLLEVBQUU7VUFDTEMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLFVBQVUsRUFBRSxLQUFLO1VBQ2pCQyxjQUFjLEVBQUUsS0FBSztVQUNyQkMsU0FBUyxFQUFFLFFBQVE7VUFDbkJDLFVBQVUsRUFBRSxNQUFNO1VBQ2xCQyxTQUFTLEVBQUUsTUFBTTtVQUNqQkMsV0FBVyxFQUFFLFVBQVU7VUFDdkJDLFdBQVcsRUFBRSxjQUFjO1VBQzNCQyxjQUFjLEVBQUUsTUFBTTtVQUN0QkMsUUFBUSxFQUFFLEtBQUs7VUFDZkMsV0FBVyxFQUFFLENBQUM7WUFBRUMsSUFBSSxFQUFFLENBQUM7WUFBRUMsRUFBRSxFQUFFO1VBQUksQ0FBQyxDQUFDO1VBQ25DQyxZQUFZLEVBQUUsS0FBSztVQUNuQjlELE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsSUFBSTtZQUFFSixLQUFLLEVBQUU7VUFBUSxDQUFDO1VBQ3RDSyxLQUFLLEVBQUU7WUFBRUQsSUFBSSxFQUFFLEtBQUs7WUFBRUUsTUFBTSxFQUFFLEtBQUs7WUFBRU4sS0FBSyxFQUFFLE1BQU07WUFBRXFFLEtBQUssRUFBRTtVQUFFLENBQUM7VUFDOUQxRSxJQUFJLEVBQUUsUUFBUTtVQUNkSSxLQUFLLEVBQUU7WUFBRXVFLFFBQVEsRUFBRSxFQUFFO1lBQUVDLE9BQU8sRUFBRSxLQUFLO1lBQUVDLFVBQVUsRUFBRSxLQUFLO1lBQUVDLE9BQU8sRUFBRTtVQUFHO1FBQ3hFO01BQ0YsQ0FBQztNQUNEOUMsSUFBSSxFQUFFLENBQ0o7UUFDRXpCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYm1DLE1BQU0sRUFBRSxRQUFRO1FBQ2hCbEMsTUFBTSxFQUFFO1VBQUU4RSxXQUFXLEVBQUU7UUFBeUI7TUFDbEQsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGcEMsV0FBVyxFQUFFN0MsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFBRTZDLEdBQUcsRUFBRTtRQUFFb0MsYUFBYSxFQUFFO1VBQUUsU0FBUyxFQUFFO1FBQWdCO01BQUU7SUFBRSxDQUFDLENBQUM7SUFDdkY3QixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCM0MsTUFBTSxFQUFFLENBQ047VUFDRTZFLElBQUksRUFBRTtZQUNKbEMsS0FBSyxFQUFFLGNBQWM7WUFDckJzQyxNQUFNLEVBQUUsS0FBSztZQUNiRixRQUFRLEVBQUUsS0FBSztZQUNmRCxLQUFLLEVBQUUsSUFBSTtZQUNYMUYsSUFBSSxFQUFFLFFBQVE7WUFDZDRGLEdBQUcsRUFBRSxhQUFhO1lBQ2xCSSxLQUFLLEVBQUUsd0JBQXdCO1lBQy9CL0YsTUFBTSxFQUFFO2NBQ051RCxLQUFLLEVBQUUsd0JBQXdCO2NBQy9CeEQsSUFBSSxFQUFFO1lBQ1I7VUFDRixDQUFDO1VBQ0R3RCxLQUFLLEVBQUU7WUFDTDhDLEtBQUssRUFBRTtjQUNMLGFBQWEsRUFBRTtnQkFDYjlDLEtBQUssRUFBRSx3QkFBd0I7Z0JBQy9CeEQsSUFBSSxFQUFFO2NBQ1I7WUFDRjtVQUNGLENBQUM7VUFDRHVGLE1BQU0sRUFBRTtZQUNOQyxLQUFLLEVBQUU7VUFDVDtRQUNGLENBQUMsQ0FDRjtRQUNEaEMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VoRSxHQUFHLEVBQUUsaURBQWlEO0VBQ3REQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHVCQUF1QjtJQUM5QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHVCQUF1QjtNQUM5QkksSUFBSSxFQUFFLE1BQU07TUFDWkMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxNQUFNO1FBQ1pFLElBQUksRUFBRTtVQUFFQyxhQUFhLEVBQUUsSUFBSTtVQUFFQyxLQUFLLEVBQUU7WUFBRUMsS0FBSyxFQUFFO1VBQU8sQ0FBQztVQUFFcUIsU0FBUyxFQUFFO1FBQWMsQ0FBQztRQUNqRnBCLFlBQVksRUFBRSxDQUNaO1VBQ0VDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJQLElBQUksRUFBRSxVQUFVO1VBQ2hCUSxRQUFRLEVBQUUsUUFBUTtVQUNsQkMsSUFBSSxFQUFFLElBQUk7VUFDVkwsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTSxLQUFLLEVBQUU7WUFBRVYsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6QlcsTUFBTSxFQUFFO1lBQUVGLElBQUksRUFBRSxJQUFJO1lBQUVHLE1BQU0sRUFBRSxJQUFJO1lBQUVDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDbkRqQixLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEa0IsU0FBUyxFQUFFLENBQ1Q7VUFDRVAsRUFBRSxFQUFFLGFBQWE7VUFDakJRLElBQUksRUFBRSxZQUFZO1VBQ2xCZixJQUFJLEVBQUUsT0FBTztVQUNiUSxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsSUFBSSxFQUFFLElBQUk7VUFDVkwsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTSxLQUFLLEVBQUU7WUFBRVYsSUFBSSxFQUFFLFFBQVE7WUFBRWdCLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekNMLE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsSUFBSTtZQUFFUSxNQUFNLEVBQUUsQ0FBQztZQUFFTCxNQUFNLEVBQUUsS0FBSztZQUFFQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQy9EakIsS0FBSyxFQUFFO1lBQUVzQixJQUFJLEVBQUU7VUFBUTtRQUN6QixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVYsSUFBSSxFQUFFLE1BQU07VUFDWlQsSUFBSSxFQUFFLE1BQU07VUFDWmdCLElBQUksRUFBRSxTQUFTO1VBQ2ZRLElBQUksRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFbEIsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQ2Esc0JBQXNCLEVBQUUsSUFBSTtVQUM1QkMsV0FBVyxFQUFFLElBQUk7VUFDakJDLFdBQVcsRUFBRSxVQUFVO1VBQ3ZCSSxTQUFTLEVBQUU7UUFDYixDQUFDLENBQ0Y7UUFDREMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUU7TUFDakIsQ0FBQztNQUNEQyxJQUFJLEVBQUUsQ0FDSjtRQUFFekIsRUFBRSxFQUFFLEdBQUc7UUFBRTBCLE9BQU8sRUFBRSxJQUFJO1FBQUVqQyxJQUFJLEVBQUUsT0FBTztRQUFFbUMsTUFBTSxFQUFFLFFBQVE7UUFBRWxDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFTSxFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxnQkFBZ0I7UUFDdEJtQyxNQUFNLEVBQUUsU0FBUztRQUNqQmxDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLFdBQVc7VUFDbEJtRSxTQUFTLEVBQUU7WUFBRWhDLElBQUksRUFBRSxTQUFTO1lBQUVDLEVBQUUsRUFBRSxLQUFLO1lBQUV4RCxJQUFJLEVBQUU7VUFBUSxDQUFDO1VBQ3hEd0YsdUJBQXVCLEVBQUUsSUFBSTtVQUM3QnRFLFFBQVEsRUFBRSxNQUFNO1VBQ2hCdUUsU0FBUyxFQUFFLGVBQWU7VUFDMUJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCckUsY0FBYyxFQUFFLElBQUk7VUFDcEJDLGFBQWEsRUFBRSxDQUFDO1VBQ2hCQyxlQUFlLEVBQUUsQ0FBQztRQUNwQjtNQUNGLENBQUMsRUFDRDtRQUNFaEMsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNibUMsTUFBTSxFQUFFLE9BQU87UUFDZmxDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLFlBQVk7VUFDbkJJLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1ppRSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGbkUsV0FBVyxFQUFFLElBQUk7SUFDakJRLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXhELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cd0QsS0FBSyxFQUFFLGNBQWM7UUFDckIzQyxNQUFNLEVBQUUsRUFBRTtRQUNWNEMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VoRSxHQUFHLEVBQUUsMENBQTBDO0VBQy9DZ0UsS0FBSyxFQUFFLGVBQWU7RUFDdEIvRCxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGdCQUFnQjtNQUN2QkksSUFBSSxFQUFFLE9BQU87TUFDYkMsTUFBTSxFQUFFO1FBQ044RyxPQUFPLEVBQUUsRUFBRTtRQUNYQyxlQUFlLEVBQUUsS0FBSztRQUN0QkMscUJBQXFCLEVBQUUsS0FBSztRQUM1QkMsSUFBSSxFQUFFO1VBQUVDLFdBQVcsRUFBRSxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFPLENBQUM7UUFDM0NDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsU0FBUyxFQUFFO01BQ2IsQ0FBQztNQUNEdkYsSUFBSSxFQUFFLENBQ0o7UUFBRXpCLEVBQUUsRUFBRSxHQUFHO1FBQUUwQixPQUFPLEVBQUUsSUFBSTtRQUFFakMsSUFBSSxFQUFFLE9BQU87UUFBRW1DLE1BQU0sRUFBRSxRQUFRO1FBQUVsQyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRU0sRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNibUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJsQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxTQUFTO1VBQ2hCdUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCdEUsSUFBSSxFQUFFLElBQUk7VUFDVkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWnFDLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0V4RSxFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JtQyxNQUFNLEVBQUUsUUFBUTtRQUNoQmxDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLGtCQUFrQjtVQUN6QnVFLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3QnRFLElBQUksRUFBRSxFQUFFO1VBQ1JDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLE9BQU8sRUFBRSxHQUFHO1VBQ1pxQyxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFeEUsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNibUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJsQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxZQUFZO1VBQ25CdUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCdEUsSUFBSSxFQUFFLEVBQUU7VUFDUkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWnFDLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGcEMsV0FBVyxFQUFFN0MsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUI2QyxHQUFHLEVBQUU7UUFBRTNDLE1BQU0sRUFBRTtVQUFFaUgsSUFBSSxFQUFFO1lBQUVDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLFNBQVMsRUFBRTtVQUFPO1FBQUU7TUFBRTtJQUNqRSxDQUFDLENBQUM7SUFDRmpFLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXhELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cd0QsS0FBSyxFQUFFLGNBQWM7UUFDckIzQyxNQUFNLEVBQUUsRUFBRTtRQUNWNEMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0UvRCxHQUFHLEVBQUUsd0NBQXdDO0VBQzdDZ0UsS0FBSyxFQUFFLGVBQWU7RUFDdEIvRCxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLE9BQU87SUFDZEMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGNBQWM7TUFDckJJLElBQUksRUFBRSxRQUFRO01BQ2RnQyxJQUFJLEVBQUUsQ0FDSjtRQUNFekIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTjhFLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRDVDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsVUFBVTtRQUNoQkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsWUFBWTtVQUNuQm9GLFNBQVMsRUFBRSxRQUFRO1VBQ25CaEYsSUFBSSxFQUFFLENBQUM7VUFDUGlGLFNBQVMsRUFBRSxZQUFZO1VBQ3ZCQyxTQUFTLEVBQUUsTUFBTTtVQUNqQjNDLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRDVDLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNEbEMsTUFBTSxFQUFFO1FBQ04wQixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLEtBQUs7UUFDaEI1QixJQUFJLEVBQUUsUUFBUTtRQUNkaUYsTUFBTSxFQUFFO1VBQ05uQixjQUFjLEVBQUUsS0FBSztVQUNyQm9CLFNBQVMsRUFBRSxLQUFLO1VBQ2hCZixXQUFXLEVBQUUsY0FBYztVQUMzQmdCLGVBQWUsRUFBRSxNQUFNO1VBQ3ZCYixXQUFXLEVBQUUsQ0FDWDtZQUNFQyxJQUFJLEVBQUUsQ0FBQztZQUNQQyxFQUFFLEVBQUU7VUFDTixDQUFDLENBQ0Y7VUFDRDdELE1BQU0sRUFBRTtZQUNORixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RnRSxZQUFZLEVBQUUsS0FBSztVQUNuQnJFLEtBQUssRUFBRTtZQUNMZ0YsTUFBTSxFQUFFLE1BQU07WUFDZFIsT0FBTyxFQUFFLEtBQUs7WUFDZEMsVUFBVSxFQUFFLEtBQUs7WUFDakJDLE9BQU8sRUFBRSxFQUFFO1lBQ1hILFFBQVEsRUFBRTtVQUNaO1FBQ0Y7TUFDRjtJQUNGLENBQUMsQ0FBQztJQUNGaEMsV0FBVyxFQUFFLElBQUk7SUFDakJRLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXhELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cd0QsS0FBSyxFQUFFLGNBQWM7UUFDckIzQyxNQUFNLEVBQUUsRUFBRTtRQUNWNEMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0UvRCxHQUFHLEVBQUUsNkNBQTZDO0VBQ2xEZ0UsS0FBSyxFQUFFLGVBQWU7RUFDdEIvRCxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHlCQUF5QjtJQUNoQ0MsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHlCQUF5QjtNQUNoQ0ksSUFBSSxFQUFFLE9BQU87TUFDYmdDLElBQUksRUFBRSxDQUNKO1FBQ0V6QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVmtDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSx5QkFBeUI7VUFDaENNLE9BQU8sRUFBRSxNQUFNO1VBQ2ZELEtBQUssRUFBRSxNQUFNO1VBQ2JELElBQUksRUFBRSxDQUFDO1VBQ1BtRSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0IvQixXQUFXLEVBQUU7UUFDZixDQUFDO1FBQ0Q1QyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsVUFBVTtVQUNqQk0sT0FBTyxFQUFFLE1BQU07VUFDZkQsS0FBSyxFQUFFLE1BQU07VUFDYkQsSUFBSSxFQUFFLENBQUM7VUFDUG1FLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qi9CLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRDVDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxZQUFZO1VBQ25CTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsQ0FBQztVQUNQbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCL0IsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNENUMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUNGO01BQ0RsQyxNQUFNLEVBQUU7UUFDTjhHLE9BQU8sRUFBRSxDQUFDO1FBQ1ZDLGVBQWUsRUFBRSxLQUFLO1FBQ3RCVyxzQkFBc0IsRUFBRSxLQUFLO1FBQzdCVCxJQUFJLEVBQUU7VUFDSkMsV0FBVyxFQUFFLElBQUk7VUFDakJDLFNBQVMsRUFBRTtRQUNiLENBQUM7UUFDREMsU0FBUyxFQUFFLEtBQUs7UUFDaEJFLFNBQVMsRUFBRSxLQUFLO1FBQ2hCSyxhQUFhLEVBQUU7TUFDakI7SUFDRixDQUFDLENBQUM7SUFDRmpGLFdBQVcsRUFBRSxJQUFJO0lBQ2pCUSxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCM0MsTUFBTSxFQUFFLEVBQUU7UUFDVjRDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFL0QsR0FBRyxFQUFFLHNEQUFzRDtFQUMzRGdFLEtBQUssRUFBRSxlQUFlO0VBQ3RCL0QsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxpQkFBaUI7SUFDeEJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxzQkFBc0I7TUFDN0JJLElBQUksRUFBRSxPQUFPO01BQ2JnQyxJQUFJLEVBQUUsQ0FDSjtRQUNFekIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZrQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsdUJBQXVCO1VBQzlCTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsR0FBRztVQUNUbUUsV0FBVyxFQUFFLElBQUk7VUFDakJDLGdCQUFnQixFQUFFLFFBQVE7VUFDMUJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCL0IsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNENUMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLDBCQUEwQjtVQUNqQ00sT0FBTyxFQUFFLEdBQUc7VUFDWkQsS0FBSyxFQUFFLE1BQU07VUFDYkQsSUFBSSxFQUFFLEdBQUc7VUFDVG1FLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qi9CLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRDVDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxZQUFZO1VBQ25CTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsRUFBRTtVQUNSbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCL0IsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNENUMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUNGO01BQ0RsQyxNQUFNLEVBQUU7UUFDTjhHLE9BQU8sRUFBRSxDQUFDO1FBQ1ZDLGVBQWUsRUFBRSxLQUFLO1FBQ3RCVyxzQkFBc0IsRUFBRSxLQUFLO1FBQzdCVCxJQUFJLEVBQUU7VUFDSkMsV0FBVyxFQUFFLElBQUk7VUFDakJDLFNBQVMsRUFBRTtRQUNiLENBQUM7UUFDREMsU0FBUyxFQUFFLEtBQUs7UUFDaEJFLFNBQVMsRUFBRSxLQUFLO1FBQ2hCSyxhQUFhLEVBQUU7TUFDakI7SUFDRixDQUFDLENBQUM7SUFDRmpGLFdBQVcsRUFBRSxJQUFJO0lBQ2pCUSxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCM0MsTUFBTSxFQUFFLEVBQUU7UUFDVjRDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFL0QsR0FBRyxFQUFFLDJEQUEyRDtFQUNoRWdFLEtBQUssRUFBRSxlQUFlO0VBQ3RCL0QsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxzQkFBc0I7SUFDN0JDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSwyQkFBMkI7TUFDbENJLElBQUksRUFBRSxPQUFPO01BQ2JnQyxJQUFJLEVBQUUsQ0FDSjtRQUNFekIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZrQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUseUJBQXlCO1VBQ2hDTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsR0FBRztVQUNUbUUsV0FBVyxFQUFFLElBQUk7VUFDakJDLGdCQUFnQixFQUFFLFFBQVE7VUFDMUJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCL0IsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNENUMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLDBCQUEwQjtVQUNqQ00sT0FBTyxFQUFFLEdBQUc7VUFDWkQsS0FBSyxFQUFFLE1BQU07VUFDYkQsSUFBSSxFQUFFLEdBQUc7VUFDVG1FLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qi9CLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRDVDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxZQUFZO1VBQ25CTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsRUFBRTtVQUNSbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCL0IsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNENUMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUNGO01BQ0RsQyxNQUFNLEVBQUU7UUFDTjhHLE9BQU8sRUFBRSxDQUFDO1FBQ1ZDLGVBQWUsRUFBRSxLQUFLO1FBQ3RCVyxzQkFBc0IsRUFBRSxLQUFLO1FBQzdCVCxJQUFJLEVBQUU7VUFDSkMsV0FBVyxFQUFFLElBQUk7VUFDakJDLFNBQVMsRUFBRTtRQUNiLENBQUM7UUFDREMsU0FBUyxFQUFFLEtBQUs7UUFDaEJFLFNBQVMsRUFBRSxLQUFLO1FBQ2hCSyxhQUFhLEVBQUU7TUFDakI7SUFDRixDQUFDLENBQUM7SUFDRmpGLFdBQVcsRUFBRSxJQUFJO0lBQ2pCUSxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCM0MsTUFBTSxFQUFFLEVBQUU7UUFDVjRDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFL0QsR0FBRyxFQUFFLDBDQUEwQztFQUMvQ2dFLEtBQUssRUFBRSxlQUFlO0VBQ3RCL0QsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxZQUFZO0lBQ25CQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsTUFBTTtNQUNiSSxJQUFJLEVBQUUsS0FBSztNQUNYZ0MsSUFBSSxFQUFFLENBQ0o7UUFDRXpCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWa0MsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLEtBQUs7UUFDZGpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLFlBQVk7VUFDbkJNLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JELElBQUksRUFBRSxDQUFDO1VBQ1BtRSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCLENBQUM7UUFDRDNFLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxrQkFBa0I7VUFDekJNLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JELElBQUksRUFBRSxFQUFFO1VBQ1JtRSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCLENBQUM7UUFDRDNFLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNEbEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1gyQixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJnRyxPQUFPLEVBQUUsS0FBSztRQUNkbEgsTUFBTSxFQUFFO1VBQ05GLElBQUksRUFBRSxLQUFLO1VBQ1hxSCxNQUFNLEVBQUUsSUFBSTtVQUNaQyxVQUFVLEVBQUUsSUFBSTtVQUNoQmxILFFBQVEsRUFBRTtRQUNaLENBQUM7UUFDRG1ILEdBQUcsRUFBRTtNQUNQO0lBQ0YsQ0FBQyxDQUFDO0lBQ0ZyRixXQUFXLEVBQUUsSUFBSTtJQUNqQlEsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFeEQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0J3RCxLQUFLLEVBQUUsY0FBYztRQUNyQjNDLE1BQU0sRUFBRSxFQUFFO1FBQ1Y0QyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRS9ELEdBQUcsRUFBRSxvREFBb0Q7RUFDekRnRSxLQUFLLEVBQUUsZUFBZTtFQUN0Qi9ELE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsNEJBQTRCO0lBQ25DQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsNEJBQTRCO01BQ25DSSxJQUFJLEVBQUUsTUFBTTtNQUNaZ0MsSUFBSSxFQUFFLENBQ0o7UUFDRXpCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWa0MsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxnQkFBZ0I7UUFDdEJDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLFdBQVc7VUFDbEJtRSxTQUFTLEVBQUU7WUFDVGhDLElBQUksRUFBRSxRQUFRO1lBQ2RDLEVBQUUsRUFBRTtVQUNOLENBQUM7VUFDRGdDLHVCQUF1QixFQUFFLElBQUk7VUFDN0J5QixpQkFBaUIsRUFBRSxLQUFLO1VBQ3hCL0YsUUFBUSxFQUFFLEdBQUc7VUFDYndFLGFBQWEsRUFBRSxLQUFLO1VBQ3BCcEUsYUFBYSxFQUFFLENBQUM7VUFDaEJDLGVBQWUsRUFBRSxDQUFDO1FBQ3BCLENBQUM7UUFDREosTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLHlCQUF5QjtVQUNoQ00sT0FBTyxFQUFFLEdBQUc7VUFDWkQsS0FBSyxFQUFFLEtBQUs7VUFDWkQsSUFBSSxFQUFFLENBQUM7VUFDUG1FLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEIsQ0FBQztRQUNEM0UsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUNGO01BQ0RsQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLE1BQU07UUFDWkUsSUFBSSxFQUFFO1VBQ0pDLGFBQWEsRUFBRTtRQUNqQixDQUFDO1FBQ0RHLFlBQVksRUFBRSxDQUNaO1VBQ0VDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJQLElBQUksRUFBRSxVQUFVO1VBQ2hCUSxRQUFRLEVBQUUsUUFBUTtVQUNsQkMsSUFBSSxFQUFFLElBQUk7VUFDVkwsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTSxLQUFLLEVBQUU7WUFDTFYsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEVyxNQUFNLEVBQUU7WUFDTkYsSUFBSSxFQUFFLElBQUk7WUFDVkcsTUFBTSxFQUFFLElBQUk7WUFDWkMsUUFBUSxFQUFFO1VBQ1osQ0FBQztVQUNEakIsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRGtCLFNBQVMsRUFBRSxDQUNUO1VBQ0VQLEVBQUUsRUFBRSxhQUFhO1VBQ2pCUSxJQUFJLEVBQUUsWUFBWTtVQUNsQmYsSUFBSSxFQUFFLE9BQU87VUFDYlEsUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZMLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVE0sS0FBSyxFQUFFO1lBQ0xWLElBQUksRUFBRSxRQUFRO1lBQ2RnQixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RMLE1BQU0sRUFBRTtZQUNORixJQUFJLEVBQUUsSUFBSTtZQUNWUSxNQUFNLEVBQUUsQ0FBQztZQUNUTCxNQUFNLEVBQUUsS0FBSztZQUNiQyxRQUFRLEVBQUU7VUFDWixDQUFDO1VBQ0RqQixLQUFLLEVBQUU7WUFDTHNCLElBQUksRUFBRTtVQUNSO1FBQ0YsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0VWLElBQUksRUFBRSxJQUFJO1VBQ1ZULElBQUksRUFBRSxNQUFNO1VBQ1pnQixJQUFJLEVBQUUsUUFBUTtVQUNkUSxJQUFJLEVBQUU7WUFDSkMsS0FBSyxFQUFFLE9BQU87WUFDZGxCLEVBQUUsRUFBRTtVQUNOLENBQUM7VUFDRG1CLFNBQVMsRUFBRSxhQUFhO1VBQ3hCTixzQkFBc0IsRUFBRSxJQUFJO1VBQzVCRyxTQUFTLEVBQUUsQ0FBQztVQUNaRCxXQUFXLEVBQUUsUUFBUTtVQUNyQkQsV0FBVyxFQUFFO1FBQ2YsQ0FBQyxDQUNGO1FBQ0RNLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QkMsS0FBSyxFQUFFLEVBQUU7UUFDVEMsYUFBYSxFQUFFLEtBQUs7UUFDcEJwQixNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1Z1SCxhQUFhLEVBQUU7VUFDYnpILElBQUksRUFBRSxLQUFLO1VBQ1h1RixLQUFLLEVBQUUsRUFBRTtVQUNUdEIsS0FBSyxFQUFFLENBQUM7VUFDUnRFLEtBQUssRUFBRSxNQUFNO1VBQ2JDLEtBQUssRUFBRTtRQUNUO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFDRnNDLFdBQVcsRUFBRSxJQUFJO0lBQ2pCUSxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCM0MsTUFBTSxFQUFFLEVBQUU7UUFDVjRDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFL0QsR0FBRyxFQUFFLG9EQUFvRDtFQUN6RGdFLEtBQUssRUFBRSxlQUFlO0VBQ3RCL0QsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSwwQkFBMEI7SUFDakNDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSwwQkFBMEI7TUFDakNJLElBQUksRUFBRSxPQUFPO01BQ2JnQyxJQUFJLEVBQUUsQ0FDSjtRQUNFekIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZrQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsMEJBQTBCO1VBQ2pDTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsRUFBRTtVQUNSbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCL0IsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNENUMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLHVCQUF1QjtVQUM5Qk0sT0FBTyxFQUFFLEdBQUc7VUFDWkQsS0FBSyxFQUFFLE1BQU07VUFDYkQsSUFBSSxFQUFFLEVBQUU7VUFDUm1FLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qi9CLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRDVDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSw2QkFBNkI7VUFDcENNLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JELElBQUksRUFBRSxFQUFFO1VBQ1JtRSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0IvQixXQUFXLEVBQUU7UUFDZixDQUFDO1FBQ0Q1QyxNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDRGxDLE1BQU0sRUFBRTtRQUNOOEcsT0FBTyxFQUFFLENBQUM7UUFDVkMsZUFBZSxFQUFFLEtBQUs7UUFDdEJXLHNCQUFzQixFQUFFLEtBQUs7UUFDN0JULElBQUksRUFBRTtVQUNKQyxXQUFXLEVBQUUsSUFBSTtVQUNqQkMsU0FBUyxFQUFFO1FBQ2IsQ0FBQztRQUNEQyxTQUFTLEVBQUUsS0FBSztRQUNoQkUsU0FBUyxFQUFFLEtBQUs7UUFDaEJLLGFBQWEsRUFBRTtNQUNqQjtJQUNGLENBQUMsQ0FBQztJQUNGakYsV0FBVyxFQUFFLElBQUk7SUFDakJRLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXhELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cd0QsS0FBSyxFQUFFLGNBQWM7UUFDckIzQyxNQUFNLEVBQUUsRUFBRTtRQUNWNEMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0UvRCxHQUFHLEVBQUUsd0RBQXdEO0VBQzdEZ0UsS0FBSyxFQUFFLGVBQWU7RUFDdEIvRCxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLDJCQUEyQjtJQUNsQ0MsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLDhCQUE4QjtNQUNyQ0ksSUFBSSxFQUFFLE9BQU87TUFDYmdDLElBQUksRUFBRSxDQUNKO1FBQ0V6QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVmtDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxrQkFBa0I7VUFDekJNLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JELElBQUksRUFBRSxHQUFHO1VBQ1RtRSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0IvQixXQUFXLEVBQUU7UUFDZixDQUFDO1FBQ0Q1QyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsWUFBWTtVQUNuQk0sT0FBTyxFQUFFLEdBQUc7VUFDWkQsS0FBSyxFQUFFLE1BQU07VUFDYkQsSUFBSSxFQUFFLEVBQUU7VUFDUm1FLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qi9CLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRDVDLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNEbEMsTUFBTSxFQUFFO1FBQ044RyxPQUFPLEVBQUUsQ0FBQztRQUNWQyxlQUFlLEVBQUUsS0FBSztRQUN0Qlcsc0JBQXNCLEVBQUUsS0FBSztRQUM3QlQsSUFBSSxFQUFFO1VBQ0pDLFdBQVcsRUFBRSxJQUFJO1VBQ2pCQyxTQUFTLEVBQUU7UUFDYixDQUFDO1FBQ0RDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCRSxTQUFTLEVBQUUsS0FBSztRQUNoQkssYUFBYSxFQUFFO01BQ2pCO0lBQ0YsQ0FBQyxDQUFDO0lBQ0ZqRixXQUFXLEVBQUUsSUFBSTtJQUNqQlEsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFeEQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0J3RCxLQUFLLEVBQUUsY0FBYztRQUNyQjNDLE1BQU0sRUFBRSxFQUFFO1FBQ1Y0QyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRS9ELEdBQUcsRUFBRSxzREFBc0Q7RUFDM0RnRSxLQUFLLEVBQUUsZUFBZTtFQUN0Qi9ELE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsa0JBQWtCO0lBQ3pCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsa0JBQWtCO01BQ3pCSSxJQUFJLEVBQUUsV0FBVztNQUNqQmdDLElBQUksRUFBRSxDQUNKO1FBQ0V6QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVmtDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxZQUFZO1VBQ25CTSxPQUFPLEVBQUUsTUFBTTtVQUNmRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsRUFBRTtVQUNSbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCL0IsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNENUMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUNGO01BQ0RsQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLFdBQVc7UUFDakJFLElBQUksRUFBRTtVQUNKQyxhQUFhLEVBQUU7UUFDakIsQ0FBQztRQUNERyxZQUFZLEVBQUUsQ0FDWjtVQUNFQyxFQUFFLEVBQUUsZ0JBQWdCO1VBQ3BCUCxJQUFJLEVBQUUsVUFBVTtVQUNoQlEsUUFBUSxFQUFFLFFBQVE7VUFDbEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZMLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVE0sS0FBSyxFQUFFO1lBQ0xWLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRFcsTUFBTSxFQUFFO1lBQ05GLElBQUksRUFBRSxJQUFJO1lBQ1ZHLE1BQU0sRUFBRSxJQUFJO1lBQ1pDLFFBQVEsRUFBRTtVQUNaLENBQUM7VUFDRGpCLEtBQUssRUFBRSxDQUFDO1FBQ1YsQ0FBQyxDQUNGO1FBQ0RrQixTQUFTLEVBQUUsQ0FDVDtVQUNFUCxFQUFFLEVBQUUsYUFBYTtVQUNqQlEsSUFBSSxFQUFFLFlBQVk7VUFDbEJmLElBQUksRUFBRSxPQUFPO1VBQ2JRLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUNMVixJQUFJLEVBQUUsUUFBUTtZQUNkZ0IsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNETCxNQUFNLEVBQUU7WUFDTkYsSUFBSSxFQUFFLElBQUk7WUFDVlEsTUFBTSxFQUFFLENBQUM7WUFDVEwsTUFBTSxFQUFFLEtBQUs7WUFDYkMsUUFBUSxFQUFFO1VBQ1osQ0FBQztVQUNEakIsS0FBSyxFQUFFO1lBQ0xzQixJQUFJLEVBQUU7VUFDUjtRQUNGLENBQUMsQ0FDRjtRQUNEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFVixJQUFJLEVBQUUsSUFBSTtVQUNWVCxJQUFJLEVBQUUsV0FBVztVQUNqQmdCLElBQUksRUFBRSxTQUFTO1VBQ2ZRLElBQUksRUFBRTtZQUNKQyxLQUFLLEVBQUUsT0FBTztZQUNkbEIsRUFBRSxFQUFFO1VBQ04sQ0FBQztVQUNEbUIsU0FBUyxFQUFFLGFBQWE7VUFDeEJOLHNCQUFzQixFQUFFLElBQUk7VUFDNUJHLFNBQVMsRUFBRSxDQUFDO1VBQ1pGLFdBQVcsRUFBRTtRQUNmLENBQUMsQ0FDRjtRQUNETSxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJDLEtBQUssRUFBRSxFQUFFO1FBQ1RDLGFBQWEsRUFBRSxLQUFLO1FBQ3BCcEIsTUFBTSxFQUFFO1VBQ05GLElBQUksRUFBRTtRQUNSLENBQUM7UUFDRHlILGFBQWEsRUFBRTtVQUNiekgsSUFBSSxFQUFFLEtBQUs7VUFDWHVGLEtBQUssRUFBRSxFQUFFO1VBQ1R0QixLQUFLLEVBQUUsQ0FBQztVQUNSdEUsS0FBSyxFQUFFLE1BQU07VUFDYkMsS0FBSyxFQUFFO1FBQ1Q7TUFDRjtJQUNGLENBQUMsQ0FBQztJQUNGc0MsV0FBVyxFQUFFLElBQUk7SUFDakJRLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXhELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cd0QsS0FBSyxFQUFFLGNBQWM7UUFDckIzQyxNQUFNLEVBQUUsRUFBRTtRQUNWNEMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0UvRCxHQUFHLEVBQUUsZ0RBQWdEO0VBQ3JEZ0UsS0FBSyxFQUFFLGVBQWU7RUFDdEIvRCxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHVCQUF1QjtJQUM5QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHNCQUFzQjtNQUM3QkksSUFBSSxFQUFFLE1BQU07TUFDWmdDLElBQUksRUFBRSxDQUNKO1FBQ0V6QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVmtDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsZ0JBQWdCO1FBQ3RCQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxXQUFXO1VBQ2xCbUUsU0FBUyxFQUFFO1lBQ1RoQyxJQUFJLEVBQUUsT0FBTztZQUNiQyxFQUFFLEVBQUU7VUFDTixDQUFDO1VBQ0RnQyx1QkFBdUIsRUFBRSxJQUFJO1VBQzdCeUIsaUJBQWlCLEVBQUUsS0FBSztVQUN4Qi9GLFFBQVEsRUFBRSxJQUFJO1VBQ2R3RSxhQUFhLEVBQUUsS0FBSztVQUNwQnBFLGFBQWEsRUFBRSxDQUFDO1VBQ2hCQyxlQUFlLEVBQUUsQ0FBQztRQUNwQixDQUFDO1FBQ0RKLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxZQUFZO1VBQ25CTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsQ0FBQztVQUNQbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QixDQUFDO1FBQ0QzRSxNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDRGxDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsTUFBTTtRQUNaRSxJQUFJLEVBQUU7VUFDSkMsYUFBYSxFQUFFO1FBQ2pCLENBQUM7UUFDREcsWUFBWSxFQUFFLENBQ1o7VUFDRUMsRUFBRSxFQUFFLGdCQUFnQjtVQUNwQlAsSUFBSSxFQUFFLFVBQVU7VUFDaEJRLFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUNMVixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RXLE1BQU0sRUFBRTtZQUNORixJQUFJLEVBQUUsSUFBSTtZQUNWRyxNQUFNLEVBQUUsSUFBSTtZQUNaQyxRQUFRLEVBQUUsR0FBRztZQUNiSSxNQUFNLEVBQUU7VUFDVixDQUFDO1VBQ0RyQixLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEa0IsU0FBUyxFQUFFLENBQ1Q7VUFDRVAsRUFBRSxFQUFFLGFBQWE7VUFDakJRLElBQUksRUFBRSxZQUFZO1VBQ2xCZixJQUFJLEVBQUUsT0FBTztVQUNiUSxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsSUFBSSxFQUFFLElBQUk7VUFDVkwsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTSxLQUFLLEVBQUU7WUFDTFYsSUFBSSxFQUFFLFFBQVE7WUFDZGdCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDREwsTUFBTSxFQUFFO1lBQ05GLElBQUksRUFBRSxJQUFJO1lBQ1ZRLE1BQU0sRUFBRSxDQUFDO1lBQ1RMLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRTtVQUNaLENBQUM7VUFDRGpCLEtBQUssRUFBRTtZQUNMc0IsSUFBSSxFQUFFO1VBQ1I7UUFDRixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVYsSUFBSSxFQUFFLElBQUk7VUFDVlQsSUFBSSxFQUFFLFdBQVc7VUFDakJnQixJQUFJLEVBQUUsU0FBUztVQUNmUSxJQUFJLEVBQUU7WUFDSkMsS0FBSyxFQUFFLE9BQU87WUFDZGxCLEVBQUUsRUFBRTtVQUNOLENBQUM7VUFDRGEsc0JBQXNCLEVBQUUsSUFBSTtVQUM1QkcsU0FBUyxFQUFFLENBQUM7VUFDWkYsV0FBVyxFQUFFLElBQUk7VUFDakJDLFdBQVcsRUFBRSxRQUFRO1VBQ3JCSSxTQUFTLEVBQUU7UUFDYixDQUFDLENBQ0Y7UUFDREMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQm1HLGFBQWEsRUFBRTtVQUNiekgsSUFBSSxFQUFFLEtBQUs7VUFDWHVGLEtBQUssRUFBRSxFQUFFO1VBQ1R0QixLQUFLLEVBQUUsQ0FBQztVQUNSdEUsS0FBSyxFQUFFLE1BQU07VUFDYkMsS0FBSyxFQUFFO1FBQ1QsQ0FBQztRQUNETSxNQUFNLEVBQUUsQ0FBQztNQUNYO0lBQ0YsQ0FBQyxDQUFDO0lBQ0ZnQyxXQUFXLEVBQUUsSUFBSTtJQUNqQlEsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFeEQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0J3RCxLQUFLLEVBQUUsY0FBYztRQUNyQjNDLE1BQU0sRUFBRSxFQUFFO1FBQ1Y0QyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRS9ELEdBQUcsRUFBRSxnREFBZ0Q7RUFDckRnRSxLQUFLLEVBQUUsZUFBZTtFQUN0Qi9ELE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsYUFBYTtJQUNwQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGFBQWE7TUFDcEJJLElBQUksRUFBRSxnQkFBZ0I7TUFDdEJnQyxJQUFJLEVBQUUsQ0FDSjtRQUNFekIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZrQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUseUJBQXlCO1VBQ2hDTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsQ0FBQztVQUNQbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCL0IsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNENUMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLHVCQUF1QjtVQUM5Qk0sT0FBTyxFQUFFLEdBQUc7VUFDWkQsS0FBSyxFQUFFLE1BQU07VUFDYkQsSUFBSSxFQUFFLENBQUM7VUFDUG1FLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEIsQ0FBQztRQUNEM0UsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUNGO01BQ0RsQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLFdBQVc7UUFDakJFLElBQUksRUFBRTtVQUNKQyxhQUFhLEVBQUU7UUFDakIsQ0FBQztRQUNERyxZQUFZLEVBQUUsQ0FDWjtVQUNFQyxFQUFFLEVBQUUsZ0JBQWdCO1VBQ3BCUCxJQUFJLEVBQUUsVUFBVTtVQUNoQlEsUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZMLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVE0sS0FBSyxFQUFFO1lBQ0xWLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRFcsTUFBTSxFQUFFO1lBQ05GLElBQUksRUFBRSxJQUFJO1lBQ1ZRLE1BQU0sRUFBRSxDQUFDO1lBQ1RMLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRTtVQUNaLENBQUM7VUFDRGpCLEtBQUssRUFBRSxDQUFDO1FBQ1YsQ0FBQyxDQUNGO1FBQ0RrQixTQUFTLEVBQUUsQ0FDVDtVQUNFUCxFQUFFLEVBQUUsYUFBYTtVQUNqQlEsSUFBSSxFQUFFLFlBQVk7VUFDbEJmLElBQUksRUFBRSxPQUFPO1VBQ2JRLFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUNMVixJQUFJLEVBQUUsUUFBUTtZQUNkZ0IsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNETCxNQUFNLEVBQUU7WUFDTkYsSUFBSSxFQUFFLElBQUk7WUFDVlEsTUFBTSxFQUFFLEVBQUU7WUFDVkwsTUFBTSxFQUFFLElBQUk7WUFDWkMsUUFBUSxFQUFFO1VBQ1osQ0FBQztVQUNEakIsS0FBSyxFQUFFO1lBQ0xzQixJQUFJLEVBQUU7VUFDUjtRQUNGLENBQUMsQ0FDRjtRQUNEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFVixJQUFJLEVBQUUsSUFBSTtVQUNWVCxJQUFJLEVBQUUsV0FBVztVQUNqQmdCLElBQUksRUFBRSxTQUFTO1VBQ2ZRLElBQUksRUFBRTtZQUNKQyxLQUFLLEVBQUUsT0FBTztZQUNkbEIsRUFBRSxFQUFFO1VBQ04sQ0FBQztVQUNEbUIsU0FBUyxFQUFFLGFBQWE7VUFDeEJOLHNCQUFzQixFQUFFLElBQUk7VUFDNUJHLFNBQVMsRUFBRSxDQUFDO1VBQ1pGLFdBQVcsRUFBRTtRQUNmLENBQUMsQ0FDRjtRQUNETSxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJDLEtBQUssRUFBRSxFQUFFO1FBQ1RDLGFBQWEsRUFBRSxLQUFLO1FBQ3BCcEIsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWdUgsYUFBYSxFQUFFO1VBQ2J6SCxJQUFJLEVBQUUsS0FBSztVQUNYdUYsS0FBSyxFQUFFLEVBQUU7VUFDVHRCLEtBQUssRUFBRSxDQUFDO1VBQ1J0RSxLQUFLLEVBQUUsTUFBTTtVQUNiQyxLQUFLLEVBQUU7UUFDVDtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0ZzQyxXQUFXLEVBQUUsSUFBSTtJQUNqQlEsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFeEQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0J3RCxLQUFLLEVBQUUsY0FBYztRQUNyQjNDLE1BQU0sRUFBRSxFQUFFO1FBQ1Y0QyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRS9ELEdBQUcsRUFBRSxxREFBcUQ7RUFDMURnRSxLQUFLLEVBQUUsZUFBZTtFQUN0Qi9ELE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsa0JBQWtCO0lBQ3pCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsMkJBQTJCO01BQ2xDSSxJQUFJLEVBQUUsV0FBVztNQUNqQmdDLElBQUksRUFBRSxDQUNKO1FBQ0V6QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVmtDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSxZQUFZO1VBQ25CTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsQ0FBQztVQUNQbUUsV0FBVyxFQUFFLElBQUk7VUFDakJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QixDQUFDO1FBQ0QzRSxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsdUJBQXVCO1VBQzlCTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsRUFBRTtVQUNSbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QixDQUFDO1FBQ0QzRSxNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDRGxDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsV0FBVztRQUNqQkUsSUFBSSxFQUFFO1VBQ0pDLGFBQWEsRUFBRTtRQUNqQixDQUFDO1FBQ0RHLFlBQVksRUFBRSxDQUNaO1VBQ0VDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJQLElBQUksRUFBRSxVQUFVO1VBQ2hCUSxRQUFRLEVBQUUsUUFBUTtVQUNsQkMsSUFBSSxFQUFFLElBQUk7VUFDVkwsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTSxLQUFLLEVBQUU7WUFDTFYsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNEVyxNQUFNLEVBQUU7WUFDTkYsSUFBSSxFQUFFLElBQUk7WUFDVkcsTUFBTSxFQUFFLElBQUk7WUFDWkMsUUFBUSxFQUFFO1VBQ1osQ0FBQztVQUNEakIsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRGtCLFNBQVMsRUFBRSxDQUNUO1VBQ0VQLEVBQUUsRUFBRSxhQUFhO1VBQ2pCUSxJQUFJLEVBQUUsWUFBWTtVQUNsQmYsSUFBSSxFQUFFLE9BQU87VUFDYlEsUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZMLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVE0sS0FBSyxFQUFFO1lBQ0xWLElBQUksRUFBRSxRQUFRO1lBQ2RnQixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RMLE1BQU0sRUFBRTtZQUNORixJQUFJLEVBQUUsSUFBSTtZQUNWUSxNQUFNLEVBQUUsQ0FBQztZQUNUTCxNQUFNLEVBQUUsS0FBSztZQUNiQyxRQUFRLEVBQUU7VUFDWixDQUFDO1VBQ0RqQixLQUFLLEVBQUU7WUFDTHNCLElBQUksRUFBRTtVQUNSO1FBQ0YsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0VWLElBQUksRUFBRSxJQUFJO1VBQ1ZULElBQUksRUFBRSxXQUFXO1VBQ2pCZ0IsSUFBSSxFQUFFLFNBQVM7VUFDZlEsSUFBSSxFQUFFO1lBQ0pDLEtBQUssRUFBRSxPQUFPO1lBQ2RsQixFQUFFLEVBQUU7VUFDTixDQUFDO1VBQ0RtQixTQUFTLEVBQUUsYUFBYTtVQUN4Qk4sc0JBQXNCLEVBQUUsSUFBSTtVQUM1QkcsU0FBUyxFQUFFLENBQUM7VUFDWkYsV0FBVyxFQUFFO1FBQ2YsQ0FBQyxDQUNGO1FBQ0RNLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QkMsS0FBSyxFQUFFLEVBQUU7UUFDVEMsYUFBYSxFQUFFLEtBQUs7UUFDcEJwQixNQUFNLEVBQUU7VUFDTkYsSUFBSSxFQUFFO1FBQ1IsQ0FBQztRQUNEeUgsYUFBYSxFQUFFO1VBQ2J6SCxJQUFJLEVBQUUsS0FBSztVQUNYdUYsS0FBSyxFQUFFLEVBQUU7VUFDVHRCLEtBQUssRUFBRSxDQUFDO1VBQ1J0RSxLQUFLLEVBQUUsTUFBTTtVQUNiQyxLQUFLLEVBQUU7UUFDVDtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0ZzQyxXQUFXLEVBQUUsSUFBSTtJQUNqQlEsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFeEQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0J3RCxLQUFLLEVBQUUsY0FBYztRQUNyQjNDLE1BQU0sRUFBRSxFQUFFO1FBQ1Y0QyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRS9ELEdBQUcsRUFBRSw4REFBOEQ7RUFDbkVnRSxLQUFLLEVBQUUsZUFBZTtFQUN0Qi9ELE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsMEJBQTBCO0lBQ2pDQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsMEJBQTBCO01BQ2pDSSxJQUFJLEVBQUUsV0FBVztNQUNqQmdDLElBQUksRUFBRSxDQUNKO1FBQ0V6QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVmtDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSx1QkFBdUI7VUFDOUJNLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JELElBQUksRUFBRSxDQUFDO1VBQ1BtRSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCLENBQUM7UUFDRDNFLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSw2QkFBNkI7VUFDcENNLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JELElBQUksRUFBRSxDQUFDO1VBQ1BtRSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCLENBQUM7UUFDRDNFLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNEbEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxXQUFXO1FBQ2pCRSxJQUFJLEVBQUU7VUFDSkMsYUFBYSxFQUFFO1FBQ2pCLENBQUM7UUFDREcsWUFBWSxFQUFFLENBQ1o7VUFDRUMsRUFBRSxFQUFFLGdCQUFnQjtVQUNwQlAsSUFBSSxFQUFFLFVBQVU7VUFDaEJRLFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUNMVixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RXLE1BQU0sRUFBRTtZQUNORixJQUFJLEVBQUUsSUFBSTtZQUNWRyxNQUFNLEVBQUUsSUFBSTtZQUNaQyxRQUFRLEVBQUUsR0FBRztZQUNiSSxNQUFNLEVBQUU7VUFDVixDQUFDO1VBQ0RyQixLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEa0IsU0FBUyxFQUFFLENBQ1Q7VUFDRVAsRUFBRSxFQUFFLGFBQWE7VUFDakJRLElBQUksRUFBRSxZQUFZO1VBQ2xCZixJQUFJLEVBQUUsT0FBTztVQUNiUSxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsSUFBSSxFQUFFLElBQUk7VUFDVkwsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTSxLQUFLLEVBQUU7WUFDTFYsSUFBSSxFQUFFLFFBQVE7WUFDZGdCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDREwsTUFBTSxFQUFFO1lBQ05GLElBQUksRUFBRSxJQUFJO1lBQ1ZRLE1BQU0sRUFBRSxDQUFDO1lBQ1RMLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRTtVQUNaLENBQUM7VUFDRGpCLEtBQUssRUFBRTtZQUNMc0IsSUFBSSxFQUFFO1VBQ1I7UUFDRixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVYsSUFBSSxFQUFFLElBQUk7VUFDVlQsSUFBSSxFQUFFLFdBQVc7VUFDakJnQixJQUFJLEVBQUUsU0FBUztVQUNmUSxJQUFJLEVBQUU7WUFDSkMsS0FBSyxFQUFFLE9BQU87WUFDZGxCLEVBQUUsRUFBRTtVQUNOLENBQUM7VUFDRG1CLFNBQVMsRUFBRSxhQUFhO1VBQ3hCTixzQkFBc0IsRUFBRSxJQUFJO1VBQzVCRyxTQUFTLEVBQUUsQ0FBQztVQUNaRixXQUFXLEVBQUU7UUFDZixDQUFDLENBQ0Y7UUFDRE0sVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQnBCLE1BQU0sRUFBRTtVQUNORixJQUFJLEVBQUU7UUFDUixDQUFDO1FBQ0R5SCxhQUFhLEVBQUU7VUFDYnpILElBQUksRUFBRSxLQUFLO1VBQ1h1RixLQUFLLEVBQUUsRUFBRTtVQUNUdEIsS0FBSyxFQUFFLENBQUM7VUFDUnRFLEtBQUssRUFBRSxNQUFNO1VBQ2JDLEtBQUssRUFBRTtRQUNUO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFDRnNDLFdBQVcsRUFBRSxJQUFJO0lBQ2pCUSxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCM0MsTUFBTSxFQUFFLEVBQUU7UUFDVjRDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFL0QsR0FBRyxFQUFFLG9DQUFvQztFQUN6Q2dFLEtBQUssRUFBRSxlQUFlO0VBQ3RCL0QsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxpQkFBaUI7SUFDeEJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxpQkFBaUI7TUFDeEJJLElBQUksRUFBRSxVQUFVO01BQ2hCQyxNQUFNLEVBQUU7UUFDTmtFLFdBQVcsRUFBRSxjQUFjO1FBQzNCZ0UsT0FBTyxFQUFFLHVCQUF1QjtRQUNoQ0MsYUFBYSxFQUFFLEtBQUs7UUFDcEJ6RyxVQUFVLEVBQUUsSUFBSTtRQUNoQjBHLGVBQWUsRUFBRSxHQUFHO1FBQ3BCeEcsY0FBYyxFQUFFLGFBQWE7UUFDN0J5RyxPQUFPLEVBQUUsQ0FBQztRQUNWQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2pCQyxHQUFHLEVBQUU7VUFBRXZHLE9BQU8sRUFBRSxLQUFLO1VBQUV3RyxPQUFPLEVBQUU7WUFBRUMsTUFBTSxFQUFFLFdBQVc7WUFBRUMsV0FBVyxFQUFFO1VBQUs7UUFBRSxDQUFDO1FBQzVFQyxVQUFVLEVBQUU7VUFDVjNELE1BQU0sRUFBRTtZQUFFNEQsUUFBUSxFQUFFLENBQUM7WUFBRUgsTUFBTSxFQUFFO2NBQUVuSSxFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVOLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRTZJLE9BQU8sRUFBRTtVQUFRLENBQUM7VUFDL0VDLE9BQU8sRUFBRTtZQUNQRixRQUFRLEVBQUUsQ0FBQztZQUNYSCxNQUFNLEVBQUU7Y0FBRW5JLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFDeEJOLE1BQU0sRUFBRTtjQUFFK0ksU0FBUyxFQUFFLENBQUM7Y0FBRUMsY0FBYyxFQUFFO1lBQUssQ0FBQztZQUM5Q0gsT0FBTyxFQUFFO1VBQ1gsQ0FBQztVQUNESSxXQUFXLEVBQUU7WUFDWEwsUUFBUSxFQUFFLENBQUM7WUFDWEgsTUFBTSxFQUFFO2NBQUVuSSxFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQ3hCTixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1Y2SSxPQUFPLEVBQUU7VUFDWDtRQUNGO01BQ0YsQ0FBQztNQUNEOUcsSUFBSSxFQUFFLENBQ0o7UUFBRXpCLEVBQUUsRUFBRSxHQUFHO1FBQUUwQixPQUFPLEVBQUUsSUFBSTtRQUFFakMsSUFBSSxFQUFFLE9BQU87UUFBRW1DLE1BQU0sRUFBRSxRQUFRO1FBQUVsQyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRU0sRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsY0FBYztRQUNwQm1DLE1BQU0sRUFBRSxTQUFTO1FBQ2pCbEMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsc0JBQXNCO1VBQzdCK0csYUFBYSxFQUFFLElBQUk7VUFDbkJILFNBQVMsRUFBRSxDQUFDO1VBQ1pDLGNBQWMsRUFBRSxJQUFJO1VBQ3BCRyxrQkFBa0IsRUFBRSxJQUFJO1VBQ3hCZCxPQUFPLEVBQUUsQ0FBQztVQUNWQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUNsQjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRjVGLFdBQVcsRUFBRTdDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQzFCdUksT0FBTyxFQUFFLENBQUM7TUFDVkMsU0FBUyxFQUFFLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxrQkFBa0I7SUFDckQsQ0FBQyxDQUFDO0lBQ0ZwRixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVMsQ0FBQztRQUN4QzdDLE1BQU0sRUFBRTtNQUNWLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0VsQixHQUFHLEVBQUUsNkNBQTZDO0VBQ2xEZ0UsS0FBSyxFQUFFLGVBQWU7RUFDdEIvRCxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLG1CQUFtQjtJQUMxQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLG1CQUFtQjtNQUMxQkksSUFBSSxFQUFFLFVBQVU7TUFDaEJnQyxJQUFJLEVBQUUsQ0FDSjtRQUNFekIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZrQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsMEJBQTBCO1VBQ2pDTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsQ0FBQztVQUNQbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QixDQUFDO1FBQ0QzRSxNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDRGxDLE1BQU0sRUFBRTtRQUNOUyxLQUFLLEVBQUUsUUFBUTtRQUNmd0QsV0FBVyxFQUFFLGNBQWM7UUFDM0JtRixXQUFXLEVBQUUsRUFBRTtRQUNmQyxXQUFXLEVBQUUsRUFBRTtRQUNmQyxTQUFTLEVBQUU7TUFDYjtJQUNGLENBQUMsQ0FBQztJQUNGNUcsV0FBVyxFQUFFLElBQUk7SUFDakJRLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXhELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cd0QsS0FBSyxFQUFFLGNBQWM7UUFDckIzQyxNQUFNLEVBQUUsRUFBRTtRQUNWNEMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0UvRCxHQUFHLEVBQUUsc0RBQXNEO0VBQzNEZ0UsS0FBSyxFQUFFLGVBQWU7RUFDdEIvRCxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLDRCQUE0QjtNQUNuQ0ksSUFBSSxFQUFFLE1BQU07TUFDWmdDLElBQUksRUFBRSxDQUNKO1FBQ0V6QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRTtVQUNOOEUsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNENUMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxnQkFBZ0I7UUFDdEJDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLFdBQVc7VUFDbEJtRSxTQUFTLEVBQUU7WUFDVGhDLElBQUksRUFBRSxRQUFRO1lBQ2RDLEVBQUUsRUFBRTtVQUNOLENBQUM7VUFDRGdDLHVCQUF1QixFQUFFLElBQUk7VUFDN0J5QixpQkFBaUIsRUFBRSxLQUFLO1VBQ3hCL0YsUUFBUSxFQUFFLE1BQU07VUFDaEJ3RSxhQUFhLEVBQUUsS0FBSztVQUNwQnBFLGFBQWEsRUFBRSxDQUFDO1VBQ2hCQyxlQUFlLEVBQUUsQ0FBQztRQUNwQixDQUFDO1FBQ0RKLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFNUIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUU7VUFDTm1DLEtBQUssRUFBRSx1QkFBdUI7VUFDOUJNLE9BQU8sRUFBRSxHQUFHO1VBQ1pELEtBQUssRUFBRSxNQUFNO1VBQ2JELElBQUksRUFBRSxDQUFDO1VBQ1BtRSxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0IvQixXQUFXLEVBQUU7UUFDZixDQUFDO1FBQ0Q1QyxNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDRGxDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsTUFBTTtRQUNaRSxJQUFJLEVBQUU7VUFDSkMsYUFBYSxFQUFFO1FBQ2pCLENBQUM7UUFDREcsWUFBWSxFQUFFLENBQ1o7VUFDRUMsRUFBRSxFQUFFLGdCQUFnQjtVQUNwQlAsSUFBSSxFQUFFLFVBQVU7VUFDaEJRLFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUNMVixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0RXLE1BQU0sRUFBRTtZQUNORixJQUFJLEVBQUUsSUFBSTtZQUNWRyxNQUFNLEVBQUUsSUFBSTtZQUNaQyxRQUFRLEVBQUU7VUFDWixDQUFDO1VBQ0RqQixLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEa0IsU0FBUyxFQUFFLENBQ1Q7VUFDRVAsRUFBRSxFQUFFLGFBQWE7VUFDakJRLElBQUksRUFBRSxZQUFZO1VBQ2xCZixJQUFJLEVBQUUsT0FBTztVQUNiUSxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsSUFBSSxFQUFFLElBQUk7VUFDVkwsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUTSxLQUFLLEVBQUU7WUFDTFYsSUFBSSxFQUFFLFFBQVE7WUFDZGdCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDREwsTUFBTSxFQUFFO1lBQ05GLElBQUksRUFBRSxJQUFJO1lBQ1ZRLE1BQU0sRUFBRSxDQUFDO1lBQ1RMLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRTtVQUNaLENBQUM7VUFDRGpCLEtBQUssRUFBRTtZQUNMc0IsSUFBSSxFQUFFO1VBQ1I7UUFDRixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVYsSUFBSSxFQUFFLElBQUk7VUFDVlQsSUFBSSxFQUFFLE1BQU07VUFDWmdCLElBQUksRUFBRSxRQUFRO1VBQ2RRLElBQUksRUFBRTtZQUNKQyxLQUFLLEVBQUUsUUFBUTtZQUNmbEIsRUFBRSxFQUFFO1VBQ04sQ0FBQztVQUNEbUIsU0FBUyxFQUFFLGFBQWE7VUFDeEJOLHNCQUFzQixFQUFFLElBQUk7VUFDNUJHLFNBQVMsRUFBRSxDQUFDO1VBQ1pELFdBQVcsRUFBRSxRQUFRO1VBQ3JCRCxXQUFXLEVBQUU7UUFDZixDQUFDLENBQ0Y7UUFDRE0sVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQnBCLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVnVILGFBQWEsRUFBRTtVQUNiekgsSUFBSSxFQUFFLEtBQUs7VUFDWHVGLEtBQUssRUFBRSxFQUFFO1VBQ1R0QixLQUFLLEVBQUUsQ0FBQztVQUNSdEUsS0FBSyxFQUFFLE1BQU07VUFDYkMsS0FBSyxFQUFFO1FBQ1QsQ0FBQztRQUNEMkgsR0FBRyxFQUFFO01BQ1A7SUFDRixDQUFDLENBQUM7SUFDRnJGLFdBQVcsRUFBRSxJQUFJO0lBQ2pCUSxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCM0MsTUFBTSxFQUFFLEVBQUU7UUFDVjRDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFL0QsR0FBRyxFQUFFLHFDQUFxQztFQUMxQ2dFLEtBQUssRUFBRSxlQUFlO0VBQ3RCL0QsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxrQkFBa0I7SUFDekJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxnQkFBZ0I7TUFDdkJJLElBQUksRUFBRSxLQUFLO01BQ1hnQyxJQUFJLEVBQUUsQ0FDSjtRQUNFekIsRUFBRSxFQUFFLEdBQUc7UUFDUDBCLE9BQU8sRUFBRSxJQUFJO1FBQ2JqQyxJQUFJLEVBQUUsT0FBTztRQUNiQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZrQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRTVCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFO1VBQ05tQyxLQUFLLEVBQUUsdUJBQXVCO1VBQzlCTSxPQUFPLEVBQUUsR0FBRztVQUNaRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxJQUFJLEVBQUUsQ0FBQztVQUNQbUUsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QixDQUFDO1FBQ0QzRSxNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDRGxDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYMkIsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCZ0csT0FBTyxFQUFFLElBQUk7UUFDYmxILE1BQU0sRUFBRTtVQUNORixJQUFJLEVBQUUsS0FBSztVQUNYcUgsTUFBTSxFQUFFLElBQUk7VUFDWkMsVUFBVSxFQUFFLElBQUk7VUFDaEJsSCxRQUFRLEVBQUU7UUFDWjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0Y4QixXQUFXLEVBQUUsSUFBSTtJQUNqQlEsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFeEQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0J3RCxLQUFLLEVBQUUsY0FBYztRQUNyQjNDLE1BQU0sRUFBRSxFQUFFO1FBQ1Y0QyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRS9ELEdBQUcsRUFBRSwwQ0FBMEM7RUFDL0NnRSxLQUFLLEVBQUUsZUFBZTtFQUN0Qi9ELE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsZ0JBQWdCO0lBQ3ZCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsZ0JBQWdCO01BQ3ZCSSxJQUFJLEVBQUUsS0FBSztNQUNYZ0MsSUFBSSxFQUFFLENBQ0o7UUFDRXpCLEVBQUUsRUFBRSxHQUFHO1FBQ1AwQixPQUFPLEVBQUUsSUFBSTtRQUNiakMsSUFBSSxFQUFFLE9BQU87UUFDYkMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWa0MsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0U1QixFQUFFLEVBQUUsR0FBRztRQUNQMEIsT0FBTyxFQUFFLElBQUk7UUFDYmpDLElBQUksRUFBRSxPQUFPO1FBQ2JDLE1BQU0sRUFBRTtVQUNObUMsS0FBSyxFQUFFLDBCQUEwQjtVQUNqQ00sT0FBTyxFQUFFLEdBQUc7VUFDWkQsS0FBSyxFQUFFLE1BQU07VUFDYkQsSUFBSSxFQUFFLENBQUM7VUFDUG1FLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3Qi9CLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRDVDLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNEbEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1gyQixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJnRyxPQUFPLEVBQUUsSUFBSTtRQUNibEgsTUFBTSxFQUFFO1VBQ05GLElBQUksRUFBRSxLQUFLO1VBQ1hxSCxNQUFNLEVBQUUsSUFBSTtVQUNaQyxVQUFVLEVBQUUsSUFBSTtVQUNoQmxILFFBQVEsRUFBRTtRQUNaO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFDRjhCLFdBQVcsRUFBRSxJQUFJO0lBQ2pCUSxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUV4RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQndELEtBQUssRUFBRSxjQUFjO1FBQ3JCM0MsTUFBTSxFQUFFLEVBQUU7UUFDVjRDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsQ0FDRjtBQUFBK0YsT0FBQSxDQUFBQyxPQUFBLEdBQUFoSyxRQUFBO0FBQUFpSyxNQUFBLENBQUFGLE9BQUEsR0FBQUEsT0FBQSxDQUFBQyxPQUFBIn0=