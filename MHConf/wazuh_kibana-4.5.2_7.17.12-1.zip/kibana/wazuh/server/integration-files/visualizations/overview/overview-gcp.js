"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Overview/GCP visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [
// NUEVO DASHBOARD

{
  _id: 'Wazuh-App-Overview-GCP-Alerts-Evolution-By-AuthAnswer',
  _source: {
    title: 'Events over time by auth answer',
    visState: JSON.stringify({
      title: 'Alert evolution by auth result',
      type: 'area',
      params: {
        type: 'area',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'area',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'linear',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#34130C'
        },
        labels: {},
        dimensions: {
          x: null,
          y: [{
            accessor: 0,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          useNormalizedEsInterval: true,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'data.gcp.jsonPayload.authAnswer',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GCP-Top-vmInstances-By-ResponseCode',
  _source: {
    title: 'Top instances by response code',
    visState: JSON.stringify({
      title: 'Top VM instances by response code',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }, {
            accessor: 2,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.gcp.jsonPayload.vmInstanceName',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'VM Instance Name'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.gcp.jsonPayload.responseCode',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Response Code'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GCP-Top-ResourceType-By-Project-Id',
  _source: {
    title: 'Resource type by project id',
    visState: JSON.stringify({
      title: 'Top resource type by project',
      type: 'horizontal_bar',
      params: {
        addLegend: true,
        addTimeMarker: false,
        addTooltip: true,
        categoryAxes: [{
          id: 'CategoryAxis-1',
          labels: {
            filter: false,
            rotate: 0,
            show: true,
            truncate: 200
          },
          position: 'bottom',
          scale: {
            type: 'linear'
          },
          show: true,
          style: {},
          title: {},
          type: 'category'
        }],
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        },
        grid: {
          categoryLines: false
        },
        labels: {},
        legendPosition: 'right',
        seriesParams: [{
          data: {
            id: '1',
            label: 'Count'
          },
          drawLinesBetweenPoints: true,
          mode: 'normal',
          show: true,
          showCircles: true,
          type: 'histogram',
          valueAxis: 'ValueAxis-1'
        }],
        times: [],
        type: 'histogram',
        valueAxes: [{
          id: 'ValueAxis-1',
          labels: {
            filter: true,
            rotate: 75,
            show: true,
            truncate: 100
          },
          name: 'LeftAxis-2',
          position: 'left',
          scale: {
            mode: 'normal',
            type: 'linear'
          },
          show: true,
          style: {},
          title: {
            text: 'Count'
          },
          type: 'value'
        }]
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.gcp.resource.labels.project_id',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Project ID'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'data.gcp.resource.type',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Resource type'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GCP-Top-ProjectId-By-SourceType',
  _source: {
    title: 'Top project id by sourcetype',
    visState: JSON.stringify({
      title: 'top project id by source type',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }, {
            accessor: 2,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }, {
            accessor: 4,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.gcp.resource.labels.location',
          customLabel: 'Location',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.gcp.resource.labels.project_id',
          customLabel: 'Project ID',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.gcp.resource.labels.source_type',
          customLabel: 'Source type',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GCP-Map-By-SourceIp',
  _source: {
    title: 'Top 5 Map by source ip',
    visState: JSON.stringify({
      title: 'Map GCP source IP',
      type: 'tile_map',
      params: {
        colorSchema: 'Green to Red',
        mapType: 'Scaled Circle Markers',
        isDesaturated: false,
        addTooltip: true,
        heatClusterSize: 1.5,
        legendPosition: 'bottomright',
        mapZoom: 2,
        mapCenter: [0, 0],
        wms: {
          enabled: false,
          options: {
            format: 'image/png',
            transparent: true
          }
        },
        dimensions: {
          metric: {
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          geohash: {
            accessor: 1,
            format: {
              id: 'string'
            },
            params: {
              precision: 2,
              useGeocentroid: true
            },
            aggType: 'geohash_grid'
          },
          geocentroid: {
            accessor: 3,
            format: {
              id: 'string'
            },
            params: {},
            aggType: 'geo_centroid'
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'geohash_grid',
        schema: 'segment',
        params: {
          field: 'GeoLocation.location',
          autoPrecision: true,
          precision: 2,
          useGeocentroid: true,
          isFilteredByCollar: true,
          mapZoom: 3,
          mapCenter: {
            lon: 1.3183593750000002,
            lat: 18.06231230454674
          },
          mapBounds: {
            bottom_right: {
              lat: -50.736455137010644,
              lon: 125.68359375000001
            },
            top_left: {
              lat: 68.72044056989829,
              lon: -123.04687500000001
            }
          }
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GCP-Alerts-summary',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'Alerts summary',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMeticsAtAllLevels: false,
        sort: {
          columnIndex: 3,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.id',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 50,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Rule ID'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 100,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Description'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.level',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          size: 12,
          order: 'desc',
          orderBy: '1',
          customLabel: 'Level'
        }
      }]
    }),
    uiStateJSON: '{"vis":{"params":{"sort":{"columnIndex":3,"direction":"desc"}}}}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl9zb3VyY2UiLCJ0aXRsZSIsInZpc1N0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsInR5cGUiLCJwYXJhbXMiLCJncmlkIiwiY2F0ZWdvcnlMaW5lcyIsImNhdGVnb3J5QXhlcyIsImlkIiwicG9zaXRpb24iLCJzaG93Iiwic3R5bGUiLCJzY2FsZSIsImxhYmVscyIsImZpbHRlciIsInRydW5jYXRlIiwidmFsdWVBeGVzIiwibmFtZSIsIm1vZGUiLCJyb3RhdGUiLCJ0ZXh0Iiwic2VyaWVzUGFyYW1zIiwiZGF0YSIsImxhYmVsIiwiZHJhd0xpbmVzQmV0d2VlblBvaW50cyIsInNob3dDaXJjbGVzIiwiaW50ZXJwb2xhdGUiLCJ2YWx1ZUF4aXMiLCJhZGRUb29sdGlwIiwiYWRkTGVnZW5kIiwibGVnZW5kUG9zaXRpb24iLCJ0aW1lcyIsImFkZFRpbWVNYXJrZXIiLCJ0aHJlc2hvbGRMaW5lIiwidmFsdWUiLCJ3aWR0aCIsImNvbG9yIiwiZGltZW5zaW9ucyIsIngiLCJ5IiwiYWNjZXNzb3IiLCJmb3JtYXQiLCJhZ2dUeXBlIiwiYWdncyIsImVuYWJsZWQiLCJzY2hlbWEiLCJmaWVsZCIsInVzZU5vcm1hbGl6ZWRFc0ludGVydmFsIiwiaW50ZXJ2YWwiLCJkcm9wX3BhcnRpYWxzIiwibWluX2RvY19jb3VudCIsImV4dGVuZGVkX2JvdW5kcyIsIm9yZGVyQnkiLCJvcmRlciIsInNpemUiLCJvdGhlckJ1Y2tldCIsIm90aGVyQnVja2V0TGFiZWwiLCJtaXNzaW5nQnVja2V0IiwibWlzc2luZ0J1Y2tldExhYmVsIiwidWlTdGF0ZUpTT04iLCJkZXNjcmlwdGlvbiIsInZlcnNpb24iLCJraWJhbmFTYXZlZE9iamVjdE1ldGEiLCJzZWFyY2hTb3VyY2VKU09OIiwiaW5kZXgiLCJxdWVyeSIsImxhbmd1YWdlIiwiX3R5cGUiLCJpc0RvbnV0IiwidmFsdWVzIiwibGFzdF9sZXZlbCIsIm1ldHJpYyIsImJ1Y2tldHMiLCJjdXN0b21MYWJlbCIsInNlcmllcyIsImNvbG9yU2NoZW1hIiwibWFwVHlwZSIsImlzRGVzYXR1cmF0ZWQiLCJoZWF0Q2x1c3RlclNpemUiLCJtYXBab29tIiwibWFwQ2VudGVyIiwid21zIiwib3B0aW9ucyIsInRyYW5zcGFyZW50IiwiZ2VvaGFzaCIsInByZWNpc2lvbiIsInVzZUdlb2NlbnRyb2lkIiwiZ2VvY2VudHJvaWQiLCJhdXRvUHJlY2lzaW9uIiwiaXNGaWx0ZXJlZEJ5Q29sbGFyIiwibG9uIiwibGF0IiwibWFwQm91bmRzIiwiYm90dG9tX3JpZ2h0IiwidG9wX2xlZnQiLCJwZXJQYWdlIiwic2hvd1BhcnRpYWxSb3dzIiwic2hvd01ldGljc0F0QWxsTGV2ZWxzIiwic29ydCIsImNvbHVtbkluZGV4IiwiZGlyZWN0aW9uIiwic2hvd1RvdGFsIiwic2hvd1Rvb2xiYXIiLCJ0b3RhbEZ1bmMiLCJleHBvcnRzIiwiZGVmYXVsdCIsIm1vZHVsZSJdLCJzb3VyY2VzIjpbIm92ZXJ2aWV3LWdjcC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gTW9kdWxlIGZvciBPdmVydmlldy9HQ1AgdmlzdWFsaXphdGlvbnNcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXG4gKlxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxuICovXG5leHBvcnQgZGVmYXVsdCBbXG4gIC8vIE5VRVZPIERBU0hCT0FSRFxuXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR0NQLUFsZXJ0cy1Fdm9sdXRpb24tQnktQXV0aEFuc3dlcicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdFdmVudHMgb3ZlciB0aW1lIGJ5IGF1dGggYW5zd2VyJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQWxlcnQgZXZvbHV0aW9uIGJ5IGF1dGggcmVzdWx0JyxcbiAgICAgICAgdHlwZTogJ2FyZWEnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgZ3JpZDogeyBjYXRlZ29yeUxpbmVzOiBmYWxzZSB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgcm90YXRlOiAwLCBmaWx0ZXI6IGZhbHNlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdDb3VudCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogJ3RydWUnLFxuICAgICAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgICAgIG1vZGU6ICdzdGFja2VkJyxcbiAgICAgICAgICAgICAgZGF0YTogeyBsYWJlbDogJ0NvdW50JywgaWQ6ICcxJyB9LFxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJwb2xhdGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgdGltZXM6IFtdLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICAgIHRocmVzaG9sZExpbmU6IHsgc2hvdzogZmFsc2UsIHZhbHVlOiAxMCwgd2lkdGg6IDEsIHN0eWxlOiAnZnVsbCcsIGNvbG9yOiAnIzM0MTMwQycgfSxcbiAgICAgICAgICBsYWJlbHM6IHt9LFxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIHg6IG51bGwsXG4gICAgICAgICAgICB5OiBbeyBhY2Nlc3NvcjogMCwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9LCBhZ2dUeXBlOiAnY291bnQnIH1dLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXG4gICAgICAgICAgICAgIHVzZU5vcm1hbGl6ZWRFc0ludGVydmFsOiB0cnVlLFxuICAgICAgICAgICAgICBpbnRlcnZhbDogJ2F1dG8nLFxuICAgICAgICAgICAgICBkcm9wX3BhcnRpYWxzOiBmYWxzZSxcbiAgICAgICAgICAgICAgbWluX2RvY19jb3VudDogMSxcbiAgICAgICAgICAgICAgZXh0ZW5kZWRfYm91bmRzOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdncm91cCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdjcC5qc29uUGF5bG9hZC5hdXRoQW5zd2VyJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdDUC1Ub3Atdm1JbnN0YW5jZXMtQnktUmVzcG9uc2VDb2RlJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1RvcCBpbnN0YW5jZXMgYnkgcmVzcG9uc2UgY29kZScsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1RvcCBWTSBpbnN0YW5jZXMgYnkgcmVzcG9uc2UgY29kZScsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICAgIGxhYmVsczogeyBzaG93OiBmYWxzZSwgdmFsdWVzOiB0cnVlLCBsYXN0X2xldmVsOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgZGltZW5zaW9uczoge1xuICAgICAgICAgICAgbWV0cmljOiB7IGFjY2Vzc29yOiAxLCBmb3JtYXQ6IHsgaWQ6ICdudW1iZXInIH0sIHBhcmFtczoge30sIGFnZ1R5cGU6ICdjb3VudCcgfSxcbiAgICAgICAgICAgIGJ1Y2tldHM6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAwLFxuICAgICAgICAgICAgICAgIGZvcm1hdDoge1xuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6ICdzdHJpbmcnLFxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMixcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdjcC5qc29uUGF5bG9hZC52bUluc3RhbmNlTmFtZScsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnVk0gSW5zdGFuY2UgTmFtZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdjcC5qc29uUGF5bG9hZC5yZXNwb25zZUNvZGUnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1Jlc3BvbnNlIENvZGUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR0NQLVRvcC1SZXNvdXJjZVR5cGUtQnktUHJvamVjdC1JZCcsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdSZXNvdXJjZSB0eXBlIGJ5IHByb2plY3QgaWQnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdUb3AgcmVzb3VyY2UgdHlwZSBieSBwcm9qZWN0JyxcbiAgICAgICAgdHlwZTogJ2hvcml6b250YWxfYmFyJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnQ2F0ZWdvcnlBeGlzLTEnLFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgZmlsdGVyOiBmYWxzZSwgcm90YXRlOiAwLCBzaG93OiB0cnVlLCB0cnVuY2F0ZTogMjAwIH0sXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicgfSxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICAgIHR5cGU6ICdjYXRlZ29yeScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgZGltZW5zaW9uczoge1xuICAgICAgICAgICAgeDoge1xuICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcbiAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7IGlkOiAnc3RyaW5nJywgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJywgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB5OiBbeyBhY2Nlc3NvcjogMiwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9LCBhZ2dUeXBlOiAnY291bnQnIH1dLFxuICAgICAgICAgICAgc2VyaWVzOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMSxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGdyaWQ6IHsgY2F0ZWdvcnlMaW5lczogZmFsc2UgfSxcbiAgICAgICAgICBsYWJlbHM6IHt9LFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBkYXRhOiB7IGlkOiAnMScsIGxhYmVsOiAnQ291bnQnIH0sXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIG1vZGU6ICdub3JtYWwnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgZmlsdGVyOiB0cnVlLCByb3RhdGU6IDc1LCBzaG93OiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0yJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgbW9kZTogJ25vcm1hbCcsIHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ0NvdW50JyB9LFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdjcC5yZXNvdXJjZS5sYWJlbHMucHJvamVjdF9pZCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUHJvamVjdCBJRCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5nY3AucmVzb3VyY2UudHlwZScsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUmVzb3VyY2UgdHlwZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HQ1AtVG9wLVByb2plY3RJZC1CeS1Tb3VyY2VUeXBlJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1RvcCBwcm9qZWN0IGlkIGJ5IHNvdXJjZXR5cGUnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICd0b3AgcHJvamVjdCBpZCBieSBzb3VyY2UgdHlwZScsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICAgIGxhYmVsczogeyBzaG93OiBmYWxzZSwgdmFsdWVzOiB0cnVlLCBsYXN0X2xldmVsOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgZGltZW5zaW9uczoge1xuICAgICAgICAgICAgbWV0cmljOiB7IGFjY2Vzc29yOiAxLCBmb3JtYXQ6IHsgaWQ6ICdudW1iZXInIH0sIHBhcmFtczoge30sIGFnZ1R5cGU6ICdjb3VudCcgfSxcbiAgICAgICAgICAgIGJ1Y2tldHM6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAwLFxuICAgICAgICAgICAgICAgIGZvcm1hdDoge1xuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6ICdzdHJpbmcnLFxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMixcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDQsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5nY3AucmVzb3VyY2UubGFiZWxzLmxvY2F0aW9uJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdMb2NhdGlvbicsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdjcC5yZXNvdXJjZS5sYWJlbHMucHJvamVjdF9pZCcsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUHJvamVjdCBJRCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdjcC5yZXNvdXJjZS5sYWJlbHMuc291cmNlX3R5cGUnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1NvdXJjZSB0eXBlJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdDUC1NYXAtQnktU291cmNlSXAnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIDUgTWFwIGJ5IHNvdXJjZSBpcCcsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ01hcCBHQ1Agc291cmNlIElQJyxcbiAgICAgICAgdHlwZTogJ3RpbGVfbWFwJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgY29sb3JTY2hlbWE6ICdHcmVlbiB0byBSZWQnLFxuICAgICAgICAgIG1hcFR5cGU6ICdTY2FsZWQgQ2lyY2xlIE1hcmtlcnMnLFxuICAgICAgICAgIGlzRGVzYXR1cmF0ZWQ6IGZhbHNlLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgaGVhdENsdXN0ZXJTaXplOiAxLjUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdib3R0b21yaWdodCcsXG4gICAgICAgICAgbWFwWm9vbTogMixcbiAgICAgICAgICBtYXBDZW50ZXI6IFswLCAwXSxcbiAgICAgICAgICB3bXM6IHsgZW5hYmxlZDogZmFsc2UsIG9wdGlvbnM6IHsgZm9ybWF0OiAnaW1hZ2UvcG5nJywgdHJhbnNwYXJlbnQ6IHRydWUgfSB9LFxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIG1ldHJpYzogeyBhY2Nlc3NvcjogMiwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9LCBhZ2dUeXBlOiAnY291bnQnIH0sXG4gICAgICAgICAgICBnZW9oYXNoOiB7XG4gICAgICAgICAgICAgIGFjY2Vzc29yOiAxLFxuICAgICAgICAgICAgICBmb3JtYXQ6IHsgaWQ6ICdzdHJpbmcnIH0sXG4gICAgICAgICAgICAgIHBhcmFtczogeyBwcmVjaXNpb246IDIsIHVzZUdlb2NlbnRyb2lkOiB0cnVlIH0sXG4gICAgICAgICAgICAgIGFnZ1R5cGU6ICdnZW9oYXNoX2dyaWQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdlb2NlbnRyb2lkOiB7XG4gICAgICAgICAgICAgIGFjY2Vzc29yOiAzLFxuICAgICAgICAgICAgICBmb3JtYXQ6IHsgaWQ6ICdzdHJpbmcnIH0sXG4gICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgIGFnZ1R5cGU6ICdnZW9fY2VudHJvaWQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnZ2VvaGFzaF9ncmlkJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnR2VvTG9jYXRpb24ubG9jYXRpb24nLFxuICAgICAgICAgICAgICBhdXRvUHJlY2lzaW9uOiB0cnVlLFxuICAgICAgICAgICAgICBwcmVjaXNpb246IDIsXG4gICAgICAgICAgICAgIHVzZUdlb2NlbnRyb2lkOiB0cnVlLFxuICAgICAgICAgICAgICBpc0ZpbHRlcmVkQnlDb2xsYXI6IHRydWUsXG4gICAgICAgICAgICAgIG1hcFpvb206IDMsXG4gICAgICAgICAgICAgIG1hcENlbnRlcjogeyBsb246IDEuMzE4MzU5Mzc1MDAwMDAwMiwgbGF0OiAxOC4wNjIzMTIzMDQ1NDY3NCB9LFxuICAgICAgICAgICAgICBtYXBCb3VuZHM6IHtcbiAgICAgICAgICAgICAgICBib3R0b21fcmlnaHQ6IHsgbGF0OiAtNTAuNzM2NDU1MTM3MDEwNjQ0LCBsb246IDEyNS42ODM1OTM3NTAwMDAwMSB9LFxuICAgICAgICAgICAgICAgIHRvcF9sZWZ0OiB7IGxhdDogNjguNzIwNDQwNTY5ODk4MjksIGxvbjogLTEyMy4wNDY4NzUwMDAwMDAwMSB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR0NQLUFsZXJ0cy1zdW1tYXJ5JyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydHMgc3VtbWFyeScsXG4gICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDEwLFxuICAgICAgICAgIHNob3dQYXJ0aWFsUm93czogZmFsc2UsXG4gICAgICAgICAgc2hvd01ldGljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgc2hvd1Rvb2xiYXI6IHRydWUsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmlkJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDUwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUnVsZSBJRCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuZGVzY3JpcHRpb24nLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnRGVzY3JpcHRpb24nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmxldmVsJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIHNpemU6IDEyLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnTGV2ZWwnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3tcInZpc1wiOntcInBhcmFtc1wiOntcInNvcnRcIjp7XCJjb2x1bW5JbmRleFwiOjMsXCJkaXJlY3Rpb25cIjpcImRlc2NcIn19fX0nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG5dO1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBVkEsSUFBQUEsUUFBQSxHQVdlO0FBQ2I7O0FBRUE7RUFDRUMsR0FBRyxFQUFFLHVEQUF1RDtFQUM1REMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxpQ0FBaUM7SUFDeENDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxnQ0FBZ0M7TUFDdkNJLElBQUksRUFBRSxNQUFNO01BQ1pDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsTUFBTTtRQUNaRSxJQUFJLEVBQUU7VUFBRUMsYUFBYSxFQUFFO1FBQU0sQ0FBQztRQUM5QkMsWUFBWSxFQUFFLENBQ1o7VUFDRUMsRUFBRSxFQUFFLGdCQUFnQjtVQUNwQkwsSUFBSSxFQUFFLFVBQVU7VUFDaEJNLFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RDLEtBQUssRUFBRTtZQUFFVCxJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pCVSxNQUFNLEVBQUU7WUFBRUgsSUFBSSxFQUFFLElBQUk7WUFBRUksTUFBTSxFQUFFLElBQUk7WUFBRUMsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUNuRGhCLEtBQUssRUFBRSxDQUFDO1FBQ1YsQ0FBQyxDQUNGO1FBQ0RpQixTQUFTLEVBQUUsQ0FDVDtVQUNFUixFQUFFLEVBQUUsYUFBYTtVQUNqQlMsSUFBSSxFQUFFLFlBQVk7VUFDbEJkLElBQUksRUFBRSxPQUFPO1VBQ2JNLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxJQUFJLEVBQUUsSUFBSTtVQUNWQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RDLEtBQUssRUFBRTtZQUFFVCxJQUFJLEVBQUUsUUFBUTtZQUFFZSxJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pDTCxNQUFNLEVBQUU7WUFBRUgsSUFBSSxFQUFFLElBQUk7WUFBRVMsTUFBTSxFQUFFLENBQUM7WUFBRUwsTUFBTSxFQUFFLEtBQUs7WUFBRUMsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUMvRGhCLEtBQUssRUFBRTtZQUFFcUIsSUFBSSxFQUFFO1VBQVE7UUFDekIsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0VYLElBQUksRUFBRSxNQUFNO1VBQ1pQLElBQUksRUFBRSxNQUFNO1VBQ1plLElBQUksRUFBRSxTQUFTO1VBQ2ZJLElBQUksRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFZixFQUFFLEVBQUU7VUFBSSxDQUFDO1VBQ2pDZ0Isc0JBQXNCLEVBQUUsSUFBSTtVQUM1QkMsV0FBVyxFQUFFLElBQUk7VUFDakJDLFdBQVcsRUFBRSxRQUFRO1VBQ3JCQyxTQUFTLEVBQUU7UUFDYixDQUFDLENBQ0Y7UUFDREMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQkMsYUFBYSxFQUFFO1VBQUV2QixJQUFJLEVBQUUsS0FBSztVQUFFd0IsS0FBSyxFQUFFLEVBQUU7VUFBRUMsS0FBSyxFQUFFLENBQUM7VUFBRXhCLEtBQUssRUFBRSxNQUFNO1VBQUV5QixLQUFLLEVBQUU7UUFBVSxDQUFDO1FBQ3BGdkIsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWd0IsVUFBVSxFQUFFO1VBQ1ZDLENBQUMsRUFBRSxJQUFJO1VBQ1BDLENBQUMsRUFBRSxDQUFDO1lBQUVDLFFBQVEsRUFBRSxDQUFDO1lBQUVDLE1BQU0sRUFBRTtjQUFFakMsRUFBRSxFQUFFO1lBQVMsQ0FBQztZQUFFSixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQUVzQyxPQUFPLEVBQUU7VUFBUSxDQUFDO1FBQzdFO01BQ0YsQ0FBQztNQUNEQyxJQUFJLEVBQUUsQ0FDSjtRQUFFbkMsRUFBRSxFQUFFLEdBQUc7UUFBRW9DLE9BQU8sRUFBRSxJQUFJO1FBQUV6QyxJQUFJLEVBQUUsT0FBTztRQUFFMEMsTUFBTSxFQUFFLFFBQVE7UUFBRXpDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFSSxFQUFFLEVBQUUsR0FBRztRQUNQb0MsT0FBTyxFQUFFLElBQUk7UUFDYnpDLElBQUksRUFBRSxnQkFBZ0I7UUFDdEIwQyxNQUFNLEVBQUUsU0FBUztRQUNqQnpDLE1BQU0sRUFBRTtVQUNOMEMsS0FBSyxFQUFFLFdBQVc7VUFDbEJDLHVCQUF1QixFQUFFLElBQUk7VUFDN0JDLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsYUFBYSxFQUFFLENBQUM7VUFDaEJDLGVBQWUsRUFBRSxDQUFDO1FBQ3BCO01BQ0YsQ0FBQyxFQUNEO1FBQ0UzQyxFQUFFLEVBQUUsR0FBRztRQUNQb0MsT0FBTyxFQUFFLElBQUk7UUFDYnpDLElBQUksRUFBRSxPQUFPO1FBQ2IwQyxNQUFNLEVBQUUsT0FBTztRQUNmekMsTUFBTSxFQUFFO1VBQ04wQyxLQUFLLEVBQUUsaUNBQWlDO1VBQ3hDTSxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGQyxXQUFXLEVBQUUsSUFBSTtJQUNqQkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFOUQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0I4RCxLQUFLLEVBQUUsY0FBYztRQUNyQmxELE1BQU0sRUFBRSxFQUFFO1FBQ1ZtRCxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRXRFLEdBQUcsRUFBRSx3REFBd0Q7RUFDN0RDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsZ0NBQWdDO0lBQ3ZDQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsbUNBQW1DO01BQzFDSSxJQUFJLEVBQUUsS0FBSztNQUNYQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLEtBQUs7UUFDWHlCLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QnNDLE9BQU8sRUFBRSxJQUFJO1FBQ2J2RCxNQUFNLEVBQUU7VUFBRUgsSUFBSSxFQUFFLEtBQUs7VUFBRTJELE1BQU0sRUFBRSxJQUFJO1VBQUVDLFVBQVUsRUFBRSxJQUFJO1VBQUV2RCxRQUFRLEVBQUU7UUFBSSxDQUFDO1FBQ3RFc0IsVUFBVSxFQUFFO1VBQ1ZrQyxNQUFNLEVBQUU7WUFBRS9CLFFBQVEsRUFBRSxDQUFDO1lBQUVDLE1BQU0sRUFBRTtjQUFFakMsRUFBRSxFQUFFO1lBQVMsQ0FBQztZQUFFSixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQUVzQyxPQUFPLEVBQUU7VUFBUSxDQUFDO1VBQy9FOEIsT0FBTyxFQUFFLENBQ1A7WUFDRWhDLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUNOakMsRUFBRSxFQUFFLE9BQU87Y0FDWEosTUFBTSxFQUFFO2dCQUNOSSxFQUFFLEVBQUUsUUFBUTtnQkFDWmdELGdCQUFnQixFQUFFLE9BQU87Z0JBQ3pCRSxrQkFBa0IsRUFBRTtjQUN0QjtZQUNGLENBQUM7WUFDRHRELE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDVnNDLE9BQU8sRUFBRTtVQUNYLENBQUMsRUFDRDtZQUNFRixRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FDTmpDLEVBQUUsRUFBRSxPQUFPO2NBQ1hKLE1BQU0sRUFBRTtnQkFDTkksRUFBRSxFQUFFLFFBQVE7Z0JBQ1pnRCxnQkFBZ0IsRUFBRSxPQUFPO2dCQUN6QkUsa0JBQWtCLEVBQUU7Y0FDdEI7WUFDRixDQUFDO1lBQ0R0RCxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZzQyxPQUFPLEVBQUU7VUFDWCxDQUFDO1FBRUw7TUFDRixDQUFDO01BQ0RDLElBQUksRUFBRSxDQUNKO1FBQUVuQyxFQUFFLEVBQUUsR0FBRztRQUFFb0MsT0FBTyxFQUFFLElBQUk7UUFBRXpDLElBQUksRUFBRSxPQUFPO1FBQUUwQyxNQUFNLEVBQUUsUUFBUTtRQUFFekMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VJLEVBQUUsRUFBRSxHQUFHO1FBQ1BvQyxPQUFPLEVBQUUsSUFBSTtRQUNiekMsSUFBSSxFQUFFLE9BQU87UUFDYjBDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCekMsTUFBTSxFQUFFO1VBQ04wQyxLQUFLLEVBQUUscUNBQXFDO1VBQzVDTSxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JlLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0VqRSxFQUFFLEVBQUUsR0FBRztRQUNQb0MsT0FBTyxFQUFFLElBQUk7UUFDYnpDLElBQUksRUFBRSxPQUFPO1FBQ2IwQyxNQUFNLEVBQUUsU0FBUztRQUNqQnpDLE1BQU0sRUFBRTtVQUNOMEMsS0FBSyxFQUFFLG1DQUFtQztVQUMxQ00sT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCZSxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRmQsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTlELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9COEQsS0FBSyxFQUFFLGNBQWM7UUFDckJsRCxNQUFNLEVBQUUsRUFBRTtRQUNWbUQsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0V0RSxHQUFHLEVBQUUsdURBQXVEO0VBQzVEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLDZCQUE2QjtJQUNwQ0MsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLDhCQUE4QjtNQUNyQ0ksSUFBSSxFQUFFLGdCQUFnQjtNQUN0QkMsTUFBTSxFQUFFO1FBQ055QixTQUFTLEVBQUUsSUFBSTtRQUNmRyxhQUFhLEVBQUUsS0FBSztRQUNwQkosVUFBVSxFQUFFLElBQUk7UUFDaEJyQixZQUFZLEVBQUUsQ0FDWjtVQUNFQyxFQUFFLEVBQUUsZ0JBQWdCO1VBQ3BCSyxNQUFNLEVBQUU7WUFBRUMsTUFBTSxFQUFFLEtBQUs7WUFBRUssTUFBTSxFQUFFLENBQUM7WUFBRVQsSUFBSSxFQUFFLElBQUk7WUFBRUssUUFBUSxFQUFFO1VBQUksQ0FBQztVQUMvRE4sUUFBUSxFQUFFLFFBQVE7VUFDbEJHLEtBQUssRUFBRTtZQUFFVCxJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pCTyxJQUFJLEVBQUUsSUFBSTtVQUNWQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RaLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEksSUFBSSxFQUFFO1FBQ1IsQ0FBQyxDQUNGO1FBQ0RrQyxVQUFVLEVBQUU7VUFDVkMsQ0FBQyxFQUFFO1lBQ0RFLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUNOakMsRUFBRSxFQUFFLE9BQU87Y0FDWEosTUFBTSxFQUFFO2dCQUFFSSxFQUFFLEVBQUUsUUFBUTtnQkFBRWdELGdCQUFnQixFQUFFLE9BQU87Z0JBQUVFLGtCQUFrQixFQUFFO2NBQVU7WUFDbkYsQ0FBQztZQUNEdEQsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWc0MsT0FBTyxFQUFFO1VBQ1gsQ0FBQztVQUNESCxDQUFDLEVBQUUsQ0FBQztZQUFFQyxRQUFRLEVBQUUsQ0FBQztZQUFFQyxNQUFNLEVBQUU7Y0FBRWpDLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFBRUosTUFBTSxFQUFFLENBQUMsQ0FBQztZQUFFc0MsT0FBTyxFQUFFO1VBQVEsQ0FBQyxDQUFDO1VBQzVFZ0MsTUFBTSxFQUFFLENBQ047WUFDRWxDLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUNOakMsRUFBRSxFQUFFLE9BQU87Y0FDWEosTUFBTSxFQUFFO2dCQUNOSSxFQUFFLEVBQUUsUUFBUTtnQkFDWmdELGdCQUFnQixFQUFFLE9BQU87Z0JBQ3pCRSxrQkFBa0IsRUFBRTtjQUN0QjtZQUNGLENBQUM7WUFDRHRELE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDVnNDLE9BQU8sRUFBRTtVQUNYLENBQUM7UUFFTCxDQUFDO1FBQ0RyQyxJQUFJLEVBQUU7VUFBRUMsYUFBYSxFQUFFO1FBQU0sQ0FBQztRQUM5Qk8sTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWaUIsY0FBYyxFQUFFLE9BQU87UUFDdkJULFlBQVksRUFBRSxDQUNaO1VBQ0VDLElBQUksRUFBRTtZQUFFZCxFQUFFLEVBQUUsR0FBRztZQUFFZSxLQUFLLEVBQUU7VUFBUSxDQUFDO1VBQ2pDQyxzQkFBc0IsRUFBRSxJQUFJO1VBQzVCTixJQUFJLEVBQUUsUUFBUTtVQUNkUixJQUFJLEVBQUUsSUFBSTtVQUNWZSxXQUFXLEVBQUUsSUFBSTtVQUNqQnRCLElBQUksRUFBRSxXQUFXO1VBQ2pCd0IsU0FBUyxFQUFFO1FBQ2IsQ0FBQyxDQUNGO1FBQ0RJLEtBQUssRUFBRSxFQUFFO1FBQ1Q1QixJQUFJLEVBQUUsV0FBVztRQUNqQmEsU0FBUyxFQUFFLENBQ1Q7VUFDRVIsRUFBRSxFQUFFLGFBQWE7VUFDakJLLE1BQU0sRUFBRTtZQUFFQyxNQUFNLEVBQUUsSUFBSTtZQUFFSyxNQUFNLEVBQUUsRUFBRTtZQUFFVCxJQUFJLEVBQUUsSUFBSTtZQUFFSyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQy9ERSxJQUFJLEVBQUUsWUFBWTtVQUNsQlIsUUFBUSxFQUFFLE1BQU07VUFDaEJHLEtBQUssRUFBRTtZQUFFTSxJQUFJLEVBQUUsUUFBUTtZQUFFZixJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pDTyxJQUFJLEVBQUUsSUFBSTtVQUNWQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RaLEtBQUssRUFBRTtZQUFFcUIsSUFBSSxFQUFFO1VBQVEsQ0FBQztVQUN4QmpCLElBQUksRUFBRTtRQUNSLENBQUM7TUFFTCxDQUFDO01BQ0R3QyxJQUFJLEVBQUUsQ0FDSjtRQUFFbkMsRUFBRSxFQUFFLEdBQUc7UUFBRW9DLE9BQU8sRUFBRSxJQUFJO1FBQUV6QyxJQUFJLEVBQUUsT0FBTztRQUFFMEMsTUFBTSxFQUFFLFFBQVE7UUFBRXpDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFSSxFQUFFLEVBQUUsR0FBRztRQUNQb0MsT0FBTyxFQUFFLElBQUk7UUFDYnpDLElBQUksRUFBRSxPQUFPO1FBQ2IwQyxNQUFNLEVBQUUsU0FBUztRQUNqQnpDLE1BQU0sRUFBRTtVQUNOMEMsS0FBSyxFQUFFLHFDQUFxQztVQUM1Q00sT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCZSxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFakUsRUFBRSxFQUFFLEdBQUc7UUFDUG9DLE9BQU8sRUFBRSxJQUFJO1FBQ2J6QyxJQUFJLEVBQUUsT0FBTztRQUNiMEMsTUFBTSxFQUFFLE9BQU87UUFDZnpDLE1BQU0sRUFBRTtVQUNOMEMsS0FBSyxFQUFFLHdCQUF3QjtVQUMvQk0sT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCZSxXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRmQsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTlELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9COEQsS0FBSyxFQUFFLGNBQWM7UUFDckJsRCxNQUFNLEVBQUUsRUFBRTtRQUNWbUQsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0V0RSxHQUFHLEVBQUUsb0RBQW9EO0VBQ3pEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLDhCQUE4QjtJQUNyQ0MsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLCtCQUErQjtNQUN0Q0ksSUFBSSxFQUFFLEtBQUs7TUFDWEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1h5QixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJzQyxPQUFPLEVBQUUsSUFBSTtRQUNidkQsTUFBTSxFQUFFO1VBQUVILElBQUksRUFBRSxLQUFLO1VBQUUyRCxNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFdkQsUUFBUSxFQUFFO1FBQUksQ0FBQztRQUN0RXNCLFVBQVUsRUFBRTtVQUNWa0MsTUFBTSxFQUFFO1lBQUUvQixRQUFRLEVBQUUsQ0FBQztZQUFFQyxNQUFNLEVBQUU7Y0FBRWpDLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFBRUosTUFBTSxFQUFFLENBQUMsQ0FBQztZQUFFc0MsT0FBTyxFQUFFO1VBQVEsQ0FBQztVQUMvRThCLE9BQU8sRUFBRSxDQUNQO1lBQ0VoQyxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FDTmpDLEVBQUUsRUFBRSxPQUFPO2NBQ1hKLE1BQU0sRUFBRTtnQkFDTkksRUFBRSxFQUFFLFFBQVE7Z0JBQ1pnRCxnQkFBZ0IsRUFBRSxPQUFPO2dCQUN6QkUsa0JBQWtCLEVBQUU7Y0FDdEI7WUFDRixDQUFDO1lBQ0R0RCxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZzQyxPQUFPLEVBQUU7VUFDWCxDQUFDLEVBQ0Q7WUFDRUYsUUFBUSxFQUFFLENBQUM7WUFDWEMsTUFBTSxFQUFFO2NBQ05qQyxFQUFFLEVBQUUsT0FBTztjQUNYSixNQUFNLEVBQUU7Z0JBQ05JLEVBQUUsRUFBRSxRQUFRO2dCQUNaZ0QsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJFLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNEdEQsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWc0MsT0FBTyxFQUFFO1VBQ1gsQ0FBQyxFQUNEO1lBQ0VGLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUNOakMsRUFBRSxFQUFFLE9BQU87Y0FDWEosTUFBTSxFQUFFO2dCQUNOSSxFQUFFLEVBQUUsUUFBUTtnQkFDWmdELGdCQUFnQixFQUFFLE9BQU87Z0JBQ3pCRSxrQkFBa0IsRUFBRTtjQUN0QjtZQUNGLENBQUM7WUFDRHRELE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDVnNDLE9BQU8sRUFBRTtVQUNYLENBQUM7UUFFTDtNQUNGLENBQUM7TUFDREMsSUFBSSxFQUFFLENBQ0o7UUFBRW5DLEVBQUUsRUFBRSxHQUFHO1FBQUVvQyxPQUFPLEVBQUUsSUFBSTtRQUFFekMsSUFBSSxFQUFFLE9BQU87UUFBRTBDLE1BQU0sRUFBRSxRQUFRO1FBQUV6QyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRUksRUFBRSxFQUFFLEdBQUc7UUFDUG9DLE9BQU8sRUFBRSxJQUFJO1FBQ2J6QyxJQUFJLEVBQUUsT0FBTztRQUNiMEMsTUFBTSxFQUFFLFNBQVM7UUFDakJ6QyxNQUFNLEVBQUU7VUFDTjBDLEtBQUssRUFBRSxtQ0FBbUM7VUFDMUMyQixXQUFXLEVBQUUsVUFBVTtVQUN2QnJCLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxDQUFDO1VBQ1BDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEI7TUFDRixDQUFDLEVBQ0Q7UUFDRWxELEVBQUUsRUFBRSxHQUFHO1FBQ1BvQyxPQUFPLEVBQUUsSUFBSTtRQUNiekMsSUFBSSxFQUFFLE9BQU87UUFDYjBDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCekMsTUFBTSxFQUFFO1VBQ04wQyxLQUFLLEVBQUUscUNBQXFDO1VBQzVDMkIsV0FBVyxFQUFFLFlBQVk7VUFDekJyQixPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQyxFQUNEO1FBQ0VsRCxFQUFFLEVBQUUsR0FBRztRQUNQb0MsT0FBTyxFQUFFLElBQUk7UUFDYnpDLElBQUksRUFBRSxPQUFPO1FBQ2IwQyxNQUFNLEVBQUUsU0FBUztRQUNqQnpDLE1BQU0sRUFBRTtVQUNOMEMsS0FBSyxFQUFFLHNDQUFzQztVQUM3QzJCLFdBQVcsRUFBRSxhQUFhO1VBQzFCckIsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTlELElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9COEQsS0FBSyxFQUFFLGNBQWM7UUFDckJsRCxNQUFNLEVBQUUsRUFBRTtRQUNWbUQsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0V0RSxHQUFHLEVBQUUsd0NBQXdDO0VBQzdDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHdCQUF3QjtJQUMvQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLG1CQUFtQjtNQUMxQkksSUFBSSxFQUFFLFVBQVU7TUFDaEJDLE1BQU0sRUFBRTtRQUNOdUUsV0FBVyxFQUFFLGNBQWM7UUFDM0JDLE9BQU8sRUFBRSx1QkFBdUI7UUFDaENDLGFBQWEsRUFBRSxLQUFLO1FBQ3BCakQsVUFBVSxFQUFFLElBQUk7UUFDaEJrRCxlQUFlLEVBQUUsR0FBRztRQUNwQmhELGNBQWMsRUFBRSxhQUFhO1FBQzdCaUQsT0FBTyxFQUFFLENBQUM7UUFDVkMsU0FBUyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNqQkMsR0FBRyxFQUFFO1VBQUVyQyxPQUFPLEVBQUUsS0FBSztVQUFFc0MsT0FBTyxFQUFFO1lBQUV6QyxNQUFNLEVBQUUsV0FBVztZQUFFMEMsV0FBVyxFQUFFO1VBQUs7UUFBRSxDQUFDO1FBQzVFOUMsVUFBVSxFQUFFO1VBQ1ZrQyxNQUFNLEVBQUU7WUFBRS9CLFFBQVEsRUFBRSxDQUFDO1lBQUVDLE1BQU0sRUFBRTtjQUFFakMsRUFBRSxFQUFFO1lBQVMsQ0FBQztZQUFFSixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQUVzQyxPQUFPLEVBQUU7VUFBUSxDQUFDO1VBQy9FMEMsT0FBTyxFQUFFO1lBQ1A1QyxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FBRWpDLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFDeEJKLE1BQU0sRUFBRTtjQUFFaUYsU0FBUyxFQUFFLENBQUM7Y0FBRUMsY0FBYyxFQUFFO1lBQUssQ0FBQztZQUM5QzVDLE9BQU8sRUFBRTtVQUNYLENBQUM7VUFDRDZDLFdBQVcsRUFBRTtZQUNYL0MsUUFBUSxFQUFFLENBQUM7WUFDWEMsTUFBTSxFQUFFO2NBQUVqQyxFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQ3hCSixNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1ZzQyxPQUFPLEVBQUU7VUFDWDtRQUNGO01BQ0YsQ0FBQztNQUNEQyxJQUFJLEVBQUUsQ0FDSjtRQUFFbkMsRUFBRSxFQUFFLEdBQUc7UUFBRW9DLE9BQU8sRUFBRSxJQUFJO1FBQUV6QyxJQUFJLEVBQUUsT0FBTztRQUFFMEMsTUFBTSxFQUFFLFFBQVE7UUFBRXpDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFSSxFQUFFLEVBQUUsR0FBRztRQUNQb0MsT0FBTyxFQUFFLElBQUk7UUFDYnpDLElBQUksRUFBRSxjQUFjO1FBQ3BCMEMsTUFBTSxFQUFFLFNBQVM7UUFDakJ6QyxNQUFNLEVBQUU7VUFDTjBDLEtBQUssRUFBRSxzQkFBc0I7VUFDN0IwQyxhQUFhLEVBQUUsSUFBSTtVQUNuQkgsU0FBUyxFQUFFLENBQUM7VUFDWkMsY0FBYyxFQUFFLElBQUk7VUFDcEJHLGtCQUFrQixFQUFFLElBQUk7VUFDeEJWLE9BQU8sRUFBRSxDQUFDO1VBQ1ZDLFNBQVMsRUFBRTtZQUFFVSxHQUFHLEVBQUUsa0JBQWtCO1lBQUVDLEdBQUcsRUFBRTtVQUFrQixDQUFDO1VBQzlEQyxTQUFTLEVBQUU7WUFDVEMsWUFBWSxFQUFFO2NBQUVGLEdBQUcsRUFBRSxDQUFDLGtCQUFrQjtjQUFFRCxHQUFHLEVBQUU7WUFBbUIsQ0FBQztZQUNuRUksUUFBUSxFQUFFO2NBQUVILEdBQUcsRUFBRSxpQkFBaUI7Y0FBRUQsR0FBRyxFQUFFLENBQUM7WUFBbUI7VUFDL0Q7UUFDRjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRi9CLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU5RCxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjhELEtBQUssRUFBRSxjQUFjO1FBQ3JCbEQsTUFBTSxFQUFFLEVBQUU7UUFDVm1ELEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFdEUsR0FBRyxFQUFFLHVDQUF1QztFQUM1Q3NFLEtBQUssRUFBRSxlQUFlO0VBQ3RCckUsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxnQkFBZ0I7TUFDdkJJLElBQUksRUFBRSxPQUFPO01BQ2JDLE1BQU0sRUFBRTtRQUNOMkYsT0FBTyxFQUFFLEVBQUU7UUFDWEMsZUFBZSxFQUFFLEtBQUs7UUFDdEJDLHFCQUFxQixFQUFFLEtBQUs7UUFDNUJDLElBQUksRUFBRTtVQUFFQyxXQUFXLEVBQUUsQ0FBQztVQUFFQyxTQUFTLEVBQUU7UUFBTyxDQUFDO1FBQzNDQyxTQUFTLEVBQUUsS0FBSztRQUNoQkMsV0FBVyxFQUFFLElBQUk7UUFDakJDLFNBQVMsRUFBRTtNQUNiLENBQUM7TUFDRDVELElBQUksRUFBRSxDQUNKO1FBQUVuQyxFQUFFLEVBQUUsR0FBRztRQUFFb0MsT0FBTyxFQUFFLElBQUk7UUFBRXpDLElBQUksRUFBRSxPQUFPO1FBQUUwQyxNQUFNLEVBQUUsUUFBUTtRQUFFekMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VJLEVBQUUsRUFBRSxHQUFHO1FBQ1BvQyxPQUFPLEVBQUUsSUFBSTtRQUNiekMsSUFBSSxFQUFFLE9BQU87UUFDYjBDLE1BQU0sRUFBRSxRQUFRO1FBQ2hCekMsTUFBTSxFQUFFO1VBQ04wQyxLQUFLLEVBQUUsU0FBUztVQUNoQlMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCSixJQUFJLEVBQUUsRUFBRTtVQUNSRCxLQUFLLEVBQUUsTUFBTTtVQUNiRCxPQUFPLEVBQUUsR0FBRztVQUNacUIsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDLEVBQ0Q7UUFDRWpFLEVBQUUsRUFBRSxHQUFHO1FBQ1BvQyxPQUFPLEVBQUUsSUFBSTtRQUNiekMsSUFBSSxFQUFFLE9BQU87UUFDYjBDLE1BQU0sRUFBRSxRQUFRO1FBQ2hCekMsTUFBTSxFQUFFO1VBQ04wQyxLQUFLLEVBQUUsa0JBQWtCO1VBQ3pCUyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JKLElBQUksRUFBRSxHQUFHO1VBQ1RELEtBQUssRUFBRSxNQUFNO1VBQ2JELE9BQU8sRUFBRSxHQUFHO1VBQ1pxQixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFakUsRUFBRSxFQUFFLEdBQUc7UUFDUG9DLE9BQU8sRUFBRSxJQUFJO1FBQ2J6QyxJQUFJLEVBQUUsT0FBTztRQUNiMEMsTUFBTSxFQUFFLFFBQVE7UUFDaEJ6QyxNQUFNLEVBQUU7VUFDTjBDLEtBQUssRUFBRSxZQUFZO1VBQ25CUyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JKLElBQUksRUFBRSxFQUFFO1VBQ1JELEtBQUssRUFBRSxNQUFNO1VBQ2JELE9BQU8sRUFBRSxHQUFHO1VBQ1pxQixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRmQsV0FBVyxFQUFFLGtFQUFrRTtJQUMvRUMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFOUQsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0I4RCxLQUFLLEVBQUUsY0FBYztRQUNyQmxELE1BQU0sRUFBRSxFQUFFO1FBQ1ZtRCxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLENBQ0Y7QUFBQXNDLE9BQUEsQ0FBQUMsT0FBQSxHQUFBN0csUUFBQTtBQUFBOEcsTUFBQSxDQUFBRixPQUFBLEdBQUFBLE9BQUEsQ0FBQUMsT0FBQSJ9