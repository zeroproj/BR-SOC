"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Overview/Osquery visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Overview-Osquery-Alerts-over-time',
  _type: 'visualization',
  _source: {
    title: 'Alerts over time',
    visState: JSON.stringify({
      title: 'Alerts over time',
      type: 'area',
      params: {
        type: 'area',
        grid: {
          categoryLines: false,
          style: {
            color: '#eee'
          }
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'area',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'linear',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          interval: 'auto',
          customInterval: '2h',
          min_doc_count: 1,
          extended_bounds: {}
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Osquery-Top-5-added',
  _type: 'visualization',
  _source: {
    title: 'Top 5 added',
    visState: JSON.stringify({
      title: 'Top 5 added',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.osquery.name',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            negate: false,
            disabled: false,
            alias: null,
            type: 'phrase',
            key: 'data.osquery.action',
            value: 'added',
            params: {
              query: 'added',
              type: 'phrase'
            }
          },
          query: {
            match: {
              'data.osquery.action': {
                query: 'added',
                type: 'phrase'
              }
            }
          },
          $state: {
            store: 'appState'
          }
        }]
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Osquery-Top-5-removed',
  _type: 'visualization',
  _source: {
    title: 'Top 5 removed',
    visState: JSON.stringify({
      title: 'Top 5 removed',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.osquery.name',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            negate: false,
            disabled: false,
            alias: null,
            type: 'phrase',
            key: 'data.osquery.action',
            value: 'removed',
            params: {
              query: 'removed',
              type: 'phrase'
            }
          },
          query: {
            match: {
              'data.osquery.action': {
                query: 'removed',
                type: 'phrase'
              }
            }
          },
          $state: {
            store: 'appState'
          }
        }]
      })
    }
  }
}, {
  _id: 'Wazuh-App-Agents-Osquery-Evolution',
  _type: 'visualization',
  _source: {
    title: 'Evolution over time',
    visState: JSON.stringify({
      title: 'Evolution over time',
      type: 'histogram',
      params: {
        type: 'histogram',
        grid: {
          categoryLines: true,
          style: {
            color: '#eee'
          },
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-1h',
            to: 'now',
            mode: 'quick'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          time_zone: 'Europe/Berlin',
          drop_partials: false,
          customInterval: '2h',
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'data.osquery.name',
          size: 10,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Osquery-Most-common-packs',
  _type: 'visualization',
  _source: {
    title: 'Most common packs',
    visState: JSON.stringify({
      title: 'Most common packs',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'data.osquery.pack',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          language: 'lucene',
          query: ''
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Osquery-Top-5-rules',
  _type: 'visualization',
  _source: {
    title: 'Top 5 rules',
    visState: JSON.stringify({
      title: 'Top 5 rules',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: 2,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.id',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Rule ID'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.description',
          size: 1,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Description'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 2,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Osquery-Top-5-Agents',
  _type: 'visualization',
  _source: {
    title: 'Top 5 Agents',
    visState: JSON.stringify({
      title: 'Top 5 Agents',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'agent.name',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: [{
          meta: {
            index: 'wazuh-alerts',
            negate: false,
            disabled: false,
            alias: null,
            type: 'phrase',
            key: 'rule.groups',
            value: 'osquery',
            params: {
              query: 'osquery',
              type: 'phrase'
            }
          },
          query: {
            match: {
              'rule.groups': {
                query: 'osquery',
                type: 'phrase'
              }
            }
          },
          $state: {
            store: 'appState'
          }
        }]
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Osquery-Agents-reporting',
  _type: 'visualization',
  _source: {
    title: 'Agents reporting',
    visState: JSON.stringify({
      title: 'Agents reporting',
      type: 'metric',
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'metric',
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'None',
          colorsRange: [{
            from: 0,
            to: 10000
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 60
          }
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'cardinality',
        schema: 'metric',
        params: {
          field: 'agent.id'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-Osquery-Alerts-summary',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'table',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: 5,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'data.osquery.name',
          size: 20,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Name'
        }
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'data.osquery.action',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Action'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'agent.name',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agent'
        }
      }, {
        id: '5',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'data.osquery.pack',
          size: 5,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Pack'
        }
      }, {
        id: '6',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'data.osquery.calendarTime',
          size: 2,
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Date'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 5,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl90eXBlIiwiX3NvdXJjZSIsInRpdGxlIiwidmlzU3RhdGUiLCJKU09OIiwic3RyaW5naWZ5IiwidHlwZSIsInBhcmFtcyIsImdyaWQiLCJjYXRlZ29yeUxpbmVzIiwic3R5bGUiLCJjb2xvciIsImNhdGVnb3J5QXhlcyIsImlkIiwicG9zaXRpb24iLCJzaG93Iiwic2NhbGUiLCJsYWJlbHMiLCJmaWx0ZXIiLCJ0cnVuY2F0ZSIsInZhbHVlQXhlcyIsIm5hbWUiLCJtb2RlIiwicm90YXRlIiwidGV4dCIsInNlcmllc1BhcmFtcyIsImRhdGEiLCJsYWJlbCIsImRyYXdMaW5lc0JldHdlZW5Qb2ludHMiLCJzaG93Q2lyY2xlcyIsImludGVycG9sYXRlIiwidmFsdWVBeGlzIiwiYWRkVG9vbHRpcCIsImFkZExlZ2VuZCIsImxlZ2VuZFBvc2l0aW9uIiwidGltZXMiLCJhZGRUaW1lTWFya2VyIiwiYWdncyIsImVuYWJsZWQiLCJzY2hlbWEiLCJmaWVsZCIsImludGVydmFsIiwiY3VzdG9tSW50ZXJ2YWwiLCJtaW5fZG9jX2NvdW50IiwiZXh0ZW5kZWRfYm91bmRzIiwidWlTdGF0ZUpTT04iLCJkZXNjcmlwdGlvbiIsInZlcnNpb24iLCJraWJhbmFTYXZlZE9iamVjdE1ldGEiLCJzZWFyY2hTb3VyY2VKU09OIiwiaW5kZXgiLCJxdWVyeSIsImxhbmd1YWdlIiwiaXNEb251dCIsInZhbHVlcyIsImxhc3RfbGV2ZWwiLCJzaXplIiwib3JkZXIiLCJvcmRlckJ5Iiwib3RoZXJCdWNrZXQiLCJvdGhlckJ1Y2tldExhYmVsIiwibWlzc2luZ0J1Y2tldCIsIm1pc3NpbmdCdWNrZXRMYWJlbCIsIm1ldGEiLCJuZWdhdGUiLCJkaXNhYmxlZCIsImFsaWFzIiwia2V5IiwidmFsdWUiLCJtYXRjaCIsIiRzdGF0ZSIsInN0b3JlIiwidGltZVJhbmdlIiwiZnJvbSIsInRvIiwidXNlTm9ybWFsaXplZEVzSW50ZXJ2YWwiLCJ0aW1lX3pvbmUiLCJkcm9wX3BhcnRpYWxzIiwicGVyUGFnZSIsInNob3dQYXJ0aWFsUm93cyIsInNob3dNZXRyaWNzQXRBbGxMZXZlbHMiLCJzb3J0IiwiY29sdW1uSW5kZXgiLCJkaXJlY3Rpb24iLCJzaG93VG90YWwiLCJzaG93VG9vbGJhciIsInRvdGFsRnVuYyIsImN1c3RvbUxhYmVsIiwidmlzIiwibWV0cmljIiwicGVyY2VudGFnZU1vZGUiLCJ1c2VSYW5nZXMiLCJjb2xvclNjaGVtYSIsIm1ldHJpY0NvbG9yTW9kZSIsImNvbG9yc1JhbmdlIiwiaW52ZXJ0Q29sb3JzIiwiYmdGaWxsIiwiYmdDb2xvciIsImxhYmVsQ29sb3IiLCJzdWJUZXh0IiwiZm9udFNpemUiLCJleHBvcnRzIiwiZGVmYXVsdCIsIm1vZHVsZSJdLCJzb3VyY2VzIjpbIm92ZXJ2aWV3LW9zcXVlcnkudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIGFwcCAtIE1vZHVsZSBmb3IgT3ZlcnZpZXcvT3NxdWVyeSB2aXN1YWxpemF0aW9uc1xuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmV4cG9ydCBkZWZhdWx0IFtcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1Pc3F1ZXJ5LUFsZXJ0cy1vdmVyLXRpbWUnLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdBbGVydHMgb3ZlciB0aW1lJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQWxlcnRzIG92ZXIgdGltZScsXG4gICAgICAgIHR5cGU6ICdhcmVhJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ2FyZWEnLFxuICAgICAgICAgIGdyaWQ6IHsgY2F0ZWdvcnlMaW5lczogZmFsc2UsIHN0eWxlOiB7IGNvbG9yOiAnI2VlZScgfSB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgcm90YXRlOiAwLCBmaWx0ZXI6IGZhbHNlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdDb3VudCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogJ3RydWUnLFxuICAgICAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgICAgIG1vZGU6ICdzdGFja2VkJyxcbiAgICAgICAgICAgICAgZGF0YTogeyBsYWJlbDogJ0NvdW50JywgaWQ6ICcxJyB9LFxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJwb2xhdGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgdGltZXM6IFtdLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnZGF0ZV9oaXN0b2dyYW0nLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICd0aW1lc3RhbXAnLFxuICAgICAgICAgICAgICBpbnRlcnZhbDogJ2F1dG8nLFxuICAgICAgICAgICAgICBjdXN0b21JbnRlcnZhbDogJzJoJyxcbiAgICAgICAgICAgICAgbWluX2RvY19jb3VudDogMSxcbiAgICAgICAgICAgICAgZXh0ZW5kZWRfYm91bmRzOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgICBmaWx0ZXI6IFtdLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1Pc3F1ZXJ5LVRvcC01LWFkZGVkJyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIDUgYWRkZWQnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdUb3AgNSBhZGRlZCcsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICAgIGxhYmVsczogeyBzaG93OiBmYWxzZSwgdmFsdWVzOiB0cnVlLCBsYXN0X2xldmVsOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEub3NxdWVyeS5uYW1lJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgICBmaWx0ZXI6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbWV0YToge1xuICAgICAgICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICAgICAgICBuZWdhdGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBhbGlhczogbnVsbCxcbiAgICAgICAgICAgICAgICB0eXBlOiAncGhyYXNlJyxcbiAgICAgICAgICAgICAgICBrZXk6ICdkYXRhLm9zcXVlcnkuYWN0aW9uJyxcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ2FkZGVkJyxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHsgcXVlcnk6ICdhZGRlZCcsIHR5cGU6ICdwaHJhc2UnIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoOiB7ICdkYXRhLm9zcXVlcnkuYWN0aW9uJzogeyBxdWVyeTogJ2FkZGVkJywgdHlwZTogJ3BocmFzZScgfSB9IH0sXG4gICAgICAgICAgICAgICRzdGF0ZTogeyBzdG9yZTogJ2FwcFN0YXRlJyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1Pc3F1ZXJ5LVRvcC01LXJlbW92ZWQnLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdUb3AgNSByZW1vdmVkJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnVG9wIDUgcmVtb3ZlZCcsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICAgIGxhYmVsczogeyBzaG93OiBmYWxzZSwgdmFsdWVzOiB0cnVlLCBsYXN0X2xldmVsOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEub3NxdWVyeS5uYW1lJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgICBmaWx0ZXI6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbWV0YToge1xuICAgICAgICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICAgICAgICBuZWdhdGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBhbGlhczogbnVsbCxcbiAgICAgICAgICAgICAgICB0eXBlOiAncGhyYXNlJyxcbiAgICAgICAgICAgICAgICBrZXk6ICdkYXRhLm9zcXVlcnkuYWN0aW9uJyxcbiAgICAgICAgICAgICAgICB2YWx1ZTogJ3JlbW92ZWQnLFxuICAgICAgICAgICAgICAgIHBhcmFtczogeyBxdWVyeTogJ3JlbW92ZWQnLCB0eXBlOiAncGhyYXNlJyB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBxdWVyeTogeyBtYXRjaDogeyAnZGF0YS5vc3F1ZXJ5LmFjdGlvbic6IHsgcXVlcnk6ICdyZW1vdmVkJywgdHlwZTogJ3BocmFzZScgfSB9IH0sXG4gICAgICAgICAgICAgICRzdGF0ZTogeyBzdG9yZTogJ2FwcFN0YXRlJyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1BZ2VudHMtT3NxdWVyeS1Fdm9sdXRpb24nLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdFdm9sdXRpb24gb3ZlciB0aW1lJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnRXZvbHV0aW9uIG92ZXIgdGltZScsXG4gICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICBncmlkOiB7IGNhdGVnb3J5TGluZXM6IHRydWUsIHN0eWxlOiB7IGNvbG9yOiAnI2VlZScgfSwgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnIH0sXG4gICAgICAgICAgY2F0ZWdvcnlBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnQ2F0ZWdvcnlBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAnY2F0ZWdvcnknLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2JvdHRvbScsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIGZpbHRlcjogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnbGVmdCcsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHsgdHlwZTogJ2xpbmVhcicsIG1vZGU6ICdub3JtYWwnIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCByb3RhdGU6IDAsIGZpbHRlcjogZmFsc2UsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHsgdGV4dDogJ0NvdW50JyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNlcmllc1BhcmFtczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBzaG93OiAndHJ1ZScsXG4gICAgICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgICAgICBtb2RlOiAnc3RhY2tlZCcsXG4gICAgICAgICAgICAgIGRhdGE6IHsgbGFiZWw6ICdDb3VudCcsIGlkOiAnMScgfSxcbiAgICAgICAgICAgICAgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXG4gICAgICAgICAgICAgIHRpbWVSYW5nZTogeyBmcm9tOiAnbm93LTFoJywgdG86ICdub3cnLCBtb2RlOiAncXVpY2snIH0sXG4gICAgICAgICAgICAgIHVzZU5vcm1hbGl6ZWRFc0ludGVydmFsOiB0cnVlLFxuICAgICAgICAgICAgICBpbnRlcnZhbDogJ2F1dG8nLFxuICAgICAgICAgICAgICB0aW1lX3pvbmU6ICdFdXJvcGUvQmVybGluJyxcbiAgICAgICAgICAgICAgZHJvcF9wYXJ0aWFsczogZmFsc2UsXG4gICAgICAgICAgICAgIGN1c3RvbUludGVydmFsOiAnMmgnLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEub3NxdWVyeS5uYW1lJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT3NxdWVyeS1Nb3N0LWNvbW1vbi1wYWNrcycsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ01vc3QgY29tbW9uIHBhY2tzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnTW9zdCBjb21tb24gcGFja3MnLFxuICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogdHJ1ZSxcbiAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogZmFsc2UsIHZhbHVlczogdHJ1ZSwgbGFzdF9sZXZlbDogdHJ1ZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLm9zcXVlcnkucGFjaycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIHF1ZXJ5OiB7IGxhbmd1YWdlOiAnbHVjZW5lJywgcXVlcnk6ICcnIH0sXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctT3NxdWVyeS1Ub3AtNS1ydWxlcycsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1RvcCA1IHJ1bGVzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnVG9wIDUgcnVsZXMnLFxuICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBwZXJQYWdlOiAxMCxcbiAgICAgICAgICBzaG93UGFydGlhbFJvd3M6IGZhbHNlLFxuICAgICAgICAgIHNob3dNZXRyaWNzQXRBbGxMZXZlbHM6IGZhbHNlLFxuICAgICAgICAgIHNvcnQ6IHsgY29sdW1uSW5kZXg6IDIsIGRpcmVjdGlvbjogJ2Rlc2MnIH0sXG4gICAgICAgICAgc2hvd1RvdGFsOiBmYWxzZSxcbiAgICAgICAgICBzaG93VG9vbGJhcjogdHJ1ZSxcbiAgICAgICAgICB0b3RhbEZ1bmM6ICdzdW0nLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuaWQnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1J1bGUgSUQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdydWxlLmRlc2NyaXB0aW9uJyxcbiAgICAgICAgICAgICAgc2l6ZTogMSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdEZXNjcmlwdGlvbicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMiwgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9zcXVlcnktVG9wLTUtQWdlbnRzJyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIDUgQWdlbnRzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnVG9wIDUgQWdlbnRzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IGZhbHNlLCB2YWx1ZXM6IHRydWUsIGxhc3RfbGV2ZWw6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnYWdlbnQubmFtZScsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIHF1ZXJ5OiB7IHF1ZXJ5OiAnJywgbGFuZ3VhZ2U6ICdsdWNlbmUnIH0sXG4gICAgICAgICAgZmlsdGVyOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIG1ldGE6IHtcbiAgICAgICAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgICAgICAgbmVnYXRlOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBkaXNhYmxlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgYWxpYXM6IG51bGwsXG4gICAgICAgICAgICAgICAgdHlwZTogJ3BocmFzZScsXG4gICAgICAgICAgICAgICAga2V5OiAncnVsZS5ncm91cHMnLFxuICAgICAgICAgICAgICAgIHZhbHVlOiAnb3NxdWVyeScsXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7IHF1ZXJ5OiAnb3NxdWVyeScsIHR5cGU6ICdwaHJhc2UnIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHF1ZXJ5OiB7IG1hdGNoOiB7ICdydWxlLmdyb3Vwcyc6IHsgcXVlcnk6ICdvc3F1ZXJ5JywgdHlwZTogJ3BocmFzZScgfSB9IH0sXG4gICAgICAgICAgICAgICRzdGF0ZTogeyBzdG9yZTogJ2FwcFN0YXRlJyB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1Pc3F1ZXJ5LUFnZW50cy1yZXBvcnRpbmcnLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdBZ2VudHMgcmVwb3J0aW5nJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQWdlbnRzIHJlcG9ydGluZycsXG4gICAgICAgIHR5cGU6ICdtZXRyaWMnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogZmFsc2UsXG4gICAgICAgICAgdHlwZTogJ21ldHJpYycsXG4gICAgICAgICAgbWV0cmljOiB7XG4gICAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXG4gICAgICAgICAgICB1c2VSYW5nZXM6IGZhbHNlLFxuICAgICAgICAgICAgY29sb3JTY2hlbWE6ICdHcmVlbiB0byBSZWQnLFxuICAgICAgICAgICAgbWV0cmljQ29sb3JNb2RlOiAnTm9uZScsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW3sgZnJvbTogMCwgdG86IDEwMDAwIH1dLFxuICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUgfSxcbiAgICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgICBzdHlsZTogeyBiZ0ZpbGw6ICcjMDAwJywgYmdDb2xvcjogZmFsc2UsIGxhYmVsQ29sb3I6IGZhbHNlLCBzdWJUZXh0OiAnJywgZm9udFNpemU6IDYwIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NhcmRpbmFsaXR5JyxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgICBwYXJhbXM6IHsgZmllbGQ6ICdhZ2VudC5pZCcgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogJ3t9JyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU9zcXVlcnktQWxlcnRzLXN1bW1hcnknLFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdBbGVydHMgc3VtbWFyeScsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ3RhYmxlJyxcbiAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgcGVyUGFnZTogMTAsXG4gICAgICAgICAgc2hvd1BhcnRpYWxSb3dzOiBmYWxzZSxcbiAgICAgICAgICBzaG93TWV0cmljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiA1LCBkaXJlY3Rpb246ICdkZXNjJyB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgc2hvd1Rvb2xiYXI6IHRydWUsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLm9zcXVlcnkubmFtZScsXG4gICAgICAgICAgICAgIHNpemU6IDIwLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ05hbWUnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLm9zcXVlcnkuYWN0aW9uJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBY3Rpb24nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2J1Y2tldCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdhZ2VudC5uYW1lJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBZ2VudCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICc1JyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEub3NxdWVyeS5wYWNrJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdQYWNrJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzYnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5vc3F1ZXJ5LmNhbGVuZGFyVGltZScsXG4gICAgICAgICAgICAgIHNpemU6IDIsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnRGF0ZScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogNSwgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuXTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVZBLElBQUFBLFFBQUEsR0FXZSxDQUNiO0VBQ0VDLEdBQUcsRUFBRSw2Q0FBNkM7RUFDbERDLEtBQUssRUFBRSxlQUFlO0VBQ3RCQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGtCQUFrQjtJQUN6QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGtCQUFrQjtNQUN6QkksSUFBSSxFQUFFLE1BQU07TUFDWkMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxNQUFNO1FBQ1pFLElBQUksRUFBRTtVQUFFQyxhQUFhLEVBQUUsS0FBSztVQUFFQyxLQUFLLEVBQUU7WUFBRUMsS0FBSyxFQUFFO1VBQU87UUFBRSxDQUFDO1FBQ3hEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFQyxFQUFFLEVBQUUsZ0JBQWdCO1VBQ3BCUCxJQUFJLEVBQUUsVUFBVTtVQUNoQlEsUUFBUSxFQUFFLFFBQVE7VUFDbEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZMLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVE0sS0FBSyxFQUFFO1lBQUVWLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekJXLE1BQU0sRUFBRTtZQUFFRixJQUFJLEVBQUUsSUFBSTtZQUFFRyxNQUFNLEVBQUUsSUFBSTtZQUFFQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQ25EakIsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRGtCLFNBQVMsRUFBRSxDQUNUO1VBQ0VQLEVBQUUsRUFBRSxhQUFhO1VBQ2pCUSxJQUFJLEVBQUUsWUFBWTtVQUNsQmYsSUFBSSxFQUFFLE9BQU87VUFDYlEsUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZMLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVE0sS0FBSyxFQUFFO1lBQUVWLElBQUksRUFBRSxRQUFRO1lBQUVnQixJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pDTCxNQUFNLEVBQUU7WUFBRUYsSUFBSSxFQUFFLElBQUk7WUFBRVEsTUFBTSxFQUFFLENBQUM7WUFBRUwsTUFBTSxFQUFFLEtBQUs7WUFBRUMsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUMvRGpCLEtBQUssRUFBRTtZQUFFc0IsSUFBSSxFQUFFO1VBQVE7UUFDekIsQ0FBQyxDQUNGO1FBQ0RDLFlBQVksRUFBRSxDQUNaO1VBQ0VWLElBQUksRUFBRSxNQUFNO1VBQ1pULElBQUksRUFBRSxNQUFNO1VBQ1pnQixJQUFJLEVBQUUsU0FBUztVQUNmSSxJQUFJLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRWQsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQ2Usc0JBQXNCLEVBQUUsSUFBSTtVQUM1QkMsV0FBVyxFQUFFLElBQUk7VUFDakJDLFdBQVcsRUFBRSxRQUFRO1VBQ3JCQyxTQUFTLEVBQUU7UUFDYixDQUFDLENBQ0Y7UUFDREMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUU7TUFDakIsQ0FBQztNQUNEQyxJQUFJLEVBQUUsQ0FDSjtRQUFFeEIsRUFBRSxFQUFFLEdBQUc7UUFBRXlCLE9BQU8sRUFBRSxJQUFJO1FBQUVoQyxJQUFJLEVBQUUsT0FBTztRQUFFaUMsTUFBTSxFQUFFLFFBQVE7UUFBRWhDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFTSxFQUFFLEVBQUUsR0FBRztRQUNQeUIsT0FBTyxFQUFFLElBQUk7UUFDYmhDLElBQUksRUFBRSxnQkFBZ0I7UUFDdEJpQyxNQUFNLEVBQUUsU0FBUztRQUNqQmhDLE1BQU0sRUFBRTtVQUNOaUMsS0FBSyxFQUFFLFdBQVc7VUFDbEJDLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxjQUFjLEVBQUUsSUFBSTtVQUNwQkMsYUFBYSxFQUFFLENBQUM7VUFDaEJDLGVBQWUsRUFBRSxDQUFDO1FBQ3BCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGQyxXQUFXLEVBQUUsSUFBSTtJQUNqQkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFN0MsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0I2QyxLQUFLLEVBQUUsY0FBYztRQUNyQkMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTLENBQUM7UUFDeENsQyxNQUFNLEVBQUU7TUFDVixDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFbkIsR0FBRyxFQUFFLHdDQUF3QztFQUM3Q0MsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsYUFBYTtJQUNwQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGFBQWE7TUFDcEJJLElBQUksRUFBRSxLQUFLO01BQ1hDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYMEIsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCbUIsT0FBTyxFQUFFLElBQUk7UUFDYnBDLE1BQU0sRUFBRTtVQUFFRixJQUFJLEVBQUUsS0FBSztVQUFFdUMsTUFBTSxFQUFFLElBQUk7VUFBRUMsVUFBVSxFQUFFLElBQUk7VUFBRXBDLFFBQVEsRUFBRTtRQUFJO01BQ3ZFLENBQUM7TUFDRGtCLElBQUksRUFBRSxDQUNKO1FBQUV4QixFQUFFLEVBQUUsR0FBRztRQUFFeUIsT0FBTyxFQUFFLElBQUk7UUFBRWhDLElBQUksRUFBRSxPQUFPO1FBQUVpQyxNQUFNLEVBQUUsUUFBUTtRQUFFaEMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VNLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QixPQUFPLEVBQUUsSUFBSTtRQUNiaEMsSUFBSSxFQUFFLE9BQU87UUFDYmlDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCaEMsTUFBTSxFQUFFO1VBQ05pQyxLQUFLLEVBQUUsbUJBQW1CO1VBQzFCZ0IsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRmpCLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU3QyxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjZDLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVMsQ0FBQztRQUN4Q2xDLE1BQU0sRUFBRSxDQUNOO1VBQ0U2QyxJQUFJLEVBQUU7WUFDSmIsS0FBSyxFQUFFLGNBQWM7WUFDckJjLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRSxLQUFLO1lBQ2ZDLEtBQUssRUFBRSxJQUFJO1lBQ1g1RCxJQUFJLEVBQUUsUUFBUTtZQUNkNkQsR0FBRyxFQUFFLHFCQUFxQjtZQUMxQkMsS0FBSyxFQUFFLE9BQU87WUFDZDdELE1BQU0sRUFBRTtjQUFFNEMsS0FBSyxFQUFFLE9BQU87Y0FBRTdDLElBQUksRUFBRTtZQUFTO1VBQzNDLENBQUM7VUFDRDZDLEtBQUssRUFBRTtZQUFFa0IsS0FBSyxFQUFFO2NBQUUscUJBQXFCLEVBQUU7Z0JBQUVsQixLQUFLLEVBQUUsT0FBTztnQkFBRTdDLElBQUksRUFBRTtjQUFTO1lBQUU7VUFBRSxDQUFDO1VBQy9FZ0UsTUFBTSxFQUFFO1lBQUVDLEtBQUssRUFBRTtVQUFXO1FBQzlCLENBQUM7TUFFTCxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFeEUsR0FBRyxFQUFFLDBDQUEwQztFQUMvQ0MsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsZUFBZTtJQUN0QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGVBQWU7TUFDdEJJLElBQUksRUFBRSxLQUFLO01BQ1hDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsS0FBSztRQUNYMEIsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCbUIsT0FBTyxFQUFFLElBQUk7UUFDYnBDLE1BQU0sRUFBRTtVQUFFRixJQUFJLEVBQUUsS0FBSztVQUFFdUMsTUFBTSxFQUFFLElBQUk7VUFBRUMsVUFBVSxFQUFFLElBQUk7VUFBRXBDLFFBQVEsRUFBRTtRQUFJO01BQ3ZFLENBQUM7TUFDRGtCLElBQUksRUFBRSxDQUNKO1FBQUV4QixFQUFFLEVBQUUsR0FBRztRQUFFeUIsT0FBTyxFQUFFLElBQUk7UUFBRWhDLElBQUksRUFBRSxPQUFPO1FBQUVpQyxNQUFNLEVBQUUsUUFBUTtRQUFFaEMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VNLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QixPQUFPLEVBQUUsSUFBSTtRQUNiaEMsSUFBSSxFQUFFLE9BQU87UUFDYmlDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCaEMsTUFBTSxFQUFFO1VBQ05pQyxLQUFLLEVBQUUsbUJBQW1CO1VBQzFCZ0IsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRmpCLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU3QyxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjZDLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVMsQ0FBQztRQUN4Q2xDLE1BQU0sRUFBRSxDQUNOO1VBQ0U2QyxJQUFJLEVBQUU7WUFDSmIsS0FBSyxFQUFFLGNBQWM7WUFDckJjLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRSxLQUFLO1lBQ2ZDLEtBQUssRUFBRSxJQUFJO1lBQ1g1RCxJQUFJLEVBQUUsUUFBUTtZQUNkNkQsR0FBRyxFQUFFLHFCQUFxQjtZQUMxQkMsS0FBSyxFQUFFLFNBQVM7WUFDaEI3RCxNQUFNLEVBQUU7Y0FBRTRDLEtBQUssRUFBRSxTQUFTO2NBQUU3QyxJQUFJLEVBQUU7WUFBUztVQUM3QyxDQUFDO1VBQ0Q2QyxLQUFLLEVBQUU7WUFBRWtCLEtBQUssRUFBRTtjQUFFLHFCQUFxQixFQUFFO2dCQUFFbEIsS0FBSyxFQUFFLFNBQVM7Z0JBQUU3QyxJQUFJLEVBQUU7Y0FBUztZQUFFO1VBQUUsQ0FBQztVQUNqRmdFLE1BQU0sRUFBRTtZQUFFQyxLQUFLLEVBQUU7VUFBVztRQUM5QixDQUFDO01BRUwsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRXhFLEdBQUcsRUFBRSxvQ0FBb0M7RUFDekNDLEtBQUssRUFBRSxlQUFlO0VBQ3RCQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHFCQUFxQjtJQUM1QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHFCQUFxQjtNQUM1QkksSUFBSSxFQUFFLFdBQVc7TUFDakJDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsV0FBVztRQUNqQkUsSUFBSSxFQUFFO1VBQUVDLGFBQWEsRUFBRSxJQUFJO1VBQUVDLEtBQUssRUFBRTtZQUFFQyxLQUFLLEVBQUU7VUFBTyxDQUFDO1VBQUVvQixTQUFTLEVBQUU7UUFBYyxDQUFDO1FBQ2pGbkIsWUFBWSxFQUFFLENBQ1o7VUFDRUMsRUFBRSxFQUFFLGdCQUFnQjtVQUNwQlAsSUFBSSxFQUFFLFVBQVU7VUFDaEJRLFFBQVEsRUFBRSxRQUFRO1VBQ2xCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUFFVixJQUFJLEVBQUU7VUFBUyxDQUFDO1VBQ3pCVyxNQUFNLEVBQUU7WUFBRUYsSUFBSSxFQUFFLElBQUk7WUFBRUcsTUFBTSxFQUFFLElBQUk7WUFBRUMsUUFBUSxFQUFFO1VBQUksQ0FBQztVQUNuRGpCLEtBQUssRUFBRSxDQUFDO1FBQ1YsQ0FBQyxDQUNGO1FBQ0RrQixTQUFTLEVBQUUsQ0FDVDtVQUNFUCxFQUFFLEVBQUUsYUFBYTtVQUNqQlEsSUFBSSxFQUFFLFlBQVk7VUFDbEJmLElBQUksRUFBRSxPQUFPO1VBQ2JRLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxJQUFJLEVBQUUsSUFBSTtVQUNWTCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RNLEtBQUssRUFBRTtZQUFFVixJQUFJLEVBQUUsUUFBUTtZQUFFZ0IsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6Q0wsTUFBTSxFQUFFO1lBQUVGLElBQUksRUFBRSxJQUFJO1lBQUVRLE1BQU0sRUFBRSxDQUFDO1lBQUVMLE1BQU0sRUFBRSxLQUFLO1lBQUVDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDL0RqQixLQUFLLEVBQUU7WUFBRXNCLElBQUksRUFBRTtVQUFRO1FBQ3pCLENBQUMsQ0FDRjtRQUNEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFVixJQUFJLEVBQUUsTUFBTTtVQUNaVCxJQUFJLEVBQUUsV0FBVztVQUNqQmdCLElBQUksRUFBRSxTQUFTO1VBQ2ZJLElBQUksRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFZCxFQUFFLEVBQUU7VUFBSSxDQUFDO1VBQ2pDa0IsU0FBUyxFQUFFLGFBQWE7VUFDeEJILHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFdBQVcsRUFBRTtRQUNmLENBQUMsQ0FDRjtRQUNERyxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJDLEtBQUssRUFBRSxFQUFFO1FBQ1RDLGFBQWEsRUFBRTtNQUNqQixDQUFDO01BQ0RDLElBQUksRUFBRSxDQUNKO1FBQUV4QixFQUFFLEVBQUUsR0FBRztRQUFFeUIsT0FBTyxFQUFFLElBQUk7UUFBRWhDLElBQUksRUFBRSxPQUFPO1FBQUVpQyxNQUFNLEVBQUUsUUFBUTtRQUFFaEMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VNLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QixPQUFPLEVBQUUsSUFBSTtRQUNiaEMsSUFBSSxFQUFFLGdCQUFnQjtRQUN0QmlDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCaEMsTUFBTSxFQUFFO1VBQ05pQyxLQUFLLEVBQUUsV0FBVztVQUNsQmdDLFNBQVMsRUFBRTtZQUFFQyxJQUFJLEVBQUUsUUFBUTtZQUFFQyxFQUFFLEVBQUUsS0FBSztZQUFFcEQsSUFBSSxFQUFFO1VBQVEsQ0FBQztVQUN2RHFELHVCQUF1QixFQUFFLElBQUk7VUFDN0JsQyxRQUFRLEVBQUUsTUFBTTtVQUNoQm1DLFNBQVMsRUFBRSxlQUFlO1VBQzFCQyxhQUFhLEVBQUUsS0FBSztVQUNwQm5DLGNBQWMsRUFBRSxJQUFJO1VBQ3BCQyxhQUFhLEVBQUUsQ0FBQztVQUNoQkMsZUFBZSxFQUFFLENBQUM7UUFDcEI7TUFDRixDQUFDLEVBQ0Q7UUFDRS9CLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QixPQUFPLEVBQUUsSUFBSTtRQUNiaEMsSUFBSSxFQUFFLE9BQU87UUFDYmlDLE1BQU0sRUFBRSxPQUFPO1FBQ2ZoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxtQkFBbUI7VUFDMUJnQixJQUFJLEVBQUUsRUFBRTtVQUNSQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGakIsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTdDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CNkMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFDO1FBQ3hDbEMsTUFBTSxFQUFFO01BQ1YsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRW5CLEdBQUcsRUFBRSw4Q0FBOEM7RUFDbkRDLEtBQUssRUFBRSxlQUFlO0VBQ3RCQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLG1CQUFtQjtJQUMxQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLG1CQUFtQjtNQUMxQkksSUFBSSxFQUFFLEtBQUs7TUFDWEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1gwQixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJtQixPQUFPLEVBQUUsSUFBSTtRQUNicEMsTUFBTSxFQUFFO1VBQUVGLElBQUksRUFBRSxLQUFLO1VBQUV1QyxNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFcEMsUUFBUSxFQUFFO1FBQUk7TUFDdkUsQ0FBQztNQUNEa0IsSUFBSSxFQUFFLENBQ0o7UUFBRXhCLEVBQUUsRUFBRSxHQUFHO1FBQUV5QixPQUFPLEVBQUUsSUFBSTtRQUFFaEMsSUFBSSxFQUFFLE9BQU87UUFBRWlDLE1BQU0sRUFBRSxRQUFRO1FBQUVoQyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRU0sRUFBRSxFQUFFLEdBQUc7UUFDUHlCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFNBQVM7UUFDakJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxtQkFBbUI7VUFDMUJnQixJQUFJLEVBQUUsQ0FBQztVQUNQQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGakIsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTdDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CNkMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQyxRQUFRLEVBQUUsUUFBUTtVQUFFRCxLQUFLLEVBQUU7UUFBRyxDQUFDO1FBQ3hDakMsTUFBTSxFQUFFO01BQ1YsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRW5CLEdBQUcsRUFBRSx3Q0FBd0M7RUFDN0NDLEtBQUssRUFBRSxlQUFlO0VBQ3RCQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGFBQWE7SUFDcEJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxhQUFhO01BQ3BCSSxJQUFJLEVBQUUsT0FBTztNQUNiQyxNQUFNLEVBQUU7UUFDTnVFLE9BQU8sRUFBRSxFQUFFO1FBQ1hDLGVBQWUsRUFBRSxLQUFLO1FBQ3RCQyxzQkFBc0IsRUFBRSxLQUFLO1FBQzdCQyxJQUFJLEVBQUU7VUFBRUMsV0FBVyxFQUFFLENBQUM7VUFBRUMsU0FBUyxFQUFFO1FBQU8sQ0FBQztRQUMzQ0MsU0FBUyxFQUFFLEtBQUs7UUFDaEJDLFdBQVcsRUFBRSxJQUFJO1FBQ2pCQyxTQUFTLEVBQUU7TUFDYixDQUFDO01BQ0RqRCxJQUFJLEVBQUUsQ0FDSjtRQUFFeEIsRUFBRSxFQUFFLEdBQUc7UUFBRXlCLE9BQU8sRUFBRSxJQUFJO1FBQUVoQyxJQUFJLEVBQUUsT0FBTztRQUFFaUMsTUFBTSxFQUFFLFFBQVE7UUFBRWhDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFTSxFQUFFLEVBQUUsR0FBRztRQUNQeUIsT0FBTyxFQUFFLElBQUk7UUFDYmhDLElBQUksRUFBRSxPQUFPO1FBQ2JpQyxNQUFNLEVBQUUsUUFBUTtRQUNoQmhDLE1BQU0sRUFBRTtVQUNOaUMsS0FBSyxFQUFFLFNBQVM7VUFDaEJnQixJQUFJLEVBQUUsQ0FBQztVQUNQQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0J5QixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFMUUsRUFBRSxFQUFFLEdBQUc7UUFDUHlCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxrQkFBa0I7VUFDekJnQixJQUFJLEVBQUUsQ0FBQztVQUNQQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0J5QixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRjFDLFdBQVcsRUFBRXpDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQzFCbUYsR0FBRyxFQUFFO1FBQUVqRixNQUFNLEVBQUU7VUFBRTBFLElBQUksRUFBRTtZQUFFQyxXQUFXLEVBQUUsQ0FBQztZQUFFQyxTQUFTLEVBQUU7VUFBTztRQUFFO01BQUU7SUFDakUsQ0FBQyxDQUFDO0lBQ0ZyQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU3QyxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjZDLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVMsQ0FBQztRQUN4Q2xDLE1BQU0sRUFBRTtNQUNWLENBQUM7SUFDSDtFQUNGO0FBQ0YsQ0FBQyxFQUNEO0VBQ0VuQixHQUFHLEVBQUUseUNBQXlDO0VBQzlDQyxLQUFLLEVBQUUsZUFBZTtFQUN0QkMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxjQUFjO0lBQ3JCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsY0FBYztNQUNyQkksSUFBSSxFQUFFLEtBQUs7TUFDWEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1gwQixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJtQixPQUFPLEVBQUUsSUFBSTtRQUNicEMsTUFBTSxFQUFFO1VBQUVGLElBQUksRUFBRSxLQUFLO1VBQUV1QyxNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFcEMsUUFBUSxFQUFFO1FBQUk7TUFDdkUsQ0FBQztNQUNEa0IsSUFBSSxFQUFFLENBQ0o7UUFBRXhCLEVBQUUsRUFBRSxHQUFHO1FBQUV5QixPQUFPLEVBQUUsSUFBSTtRQUFFaEMsSUFBSSxFQUFFLE9BQU87UUFBRWlDLE1BQU0sRUFBRSxRQUFRO1FBQUVoQyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRU0sRUFBRSxFQUFFLEdBQUc7UUFDUHlCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFNBQVM7UUFDakJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxZQUFZO1VBQ25CZ0IsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRmpCLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUU3QyxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQjZDLEtBQUssRUFBRSxjQUFjO1FBQ3JCQyxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVMsQ0FBQztRQUN4Q2xDLE1BQU0sRUFBRSxDQUNOO1VBQ0U2QyxJQUFJLEVBQUU7WUFDSmIsS0FBSyxFQUFFLGNBQWM7WUFDckJjLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRSxLQUFLO1lBQ2ZDLEtBQUssRUFBRSxJQUFJO1lBQ1g1RCxJQUFJLEVBQUUsUUFBUTtZQUNkNkQsR0FBRyxFQUFFLGFBQWE7WUFDbEJDLEtBQUssRUFBRSxTQUFTO1lBQ2hCN0QsTUFBTSxFQUFFO2NBQUU0QyxLQUFLLEVBQUUsU0FBUztjQUFFN0MsSUFBSSxFQUFFO1lBQVM7VUFDN0MsQ0FBQztVQUNENkMsS0FBSyxFQUFFO1lBQUVrQixLQUFLLEVBQUU7Y0FBRSxhQUFhLEVBQUU7Z0JBQUVsQixLQUFLLEVBQUUsU0FBUztnQkFBRTdDLElBQUksRUFBRTtjQUFTO1lBQUU7VUFBRSxDQUFDO1VBQ3pFZ0UsTUFBTSxFQUFFO1lBQUVDLEtBQUssRUFBRTtVQUFXO1FBQzlCLENBQUM7TUFFTCxDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsRUFDRDtFQUNFeEUsR0FBRyxFQUFFLDZDQUE2QztFQUNsREMsS0FBSyxFQUFFLGVBQWU7RUFDdEJDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsa0JBQWtCO0lBQ3pCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsa0JBQWtCO01BQ3pCSSxJQUFJLEVBQUUsUUFBUTtNQUNkQyxNQUFNLEVBQUU7UUFDTnlCLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsS0FBSztRQUNoQjNCLElBQUksRUFBRSxRQUFRO1FBQ2RtRixNQUFNLEVBQUU7VUFDTkMsY0FBYyxFQUFFLEtBQUs7VUFDckJDLFNBQVMsRUFBRSxLQUFLO1VBQ2hCQyxXQUFXLEVBQUUsY0FBYztVQUMzQkMsZUFBZSxFQUFFLE1BQU07VUFDdkJDLFdBQVcsRUFBRSxDQUFDO1lBQUVyQixJQUFJLEVBQUUsQ0FBQztZQUFFQyxFQUFFLEVBQUU7VUFBTSxDQUFDLENBQUM7VUFDckN6RCxNQUFNLEVBQUU7WUFBRUYsSUFBSSxFQUFFO1VBQUssQ0FBQztVQUN0QmdGLFlBQVksRUFBRSxLQUFLO1VBQ25CckYsS0FBSyxFQUFFO1lBQUVzRixNQUFNLEVBQUUsTUFBTTtZQUFFQyxPQUFPLEVBQUUsS0FBSztZQUFFQyxVQUFVLEVBQUUsS0FBSztZQUFFQyxPQUFPLEVBQUUsRUFBRTtZQUFFQyxRQUFRLEVBQUU7VUFBRztRQUN4RjtNQUNGLENBQUM7TUFDRC9ELElBQUksRUFBRSxDQUNKO1FBQ0V4QixFQUFFLEVBQUUsR0FBRztRQUNQeUIsT0FBTyxFQUFFLElBQUk7UUFDYmhDLElBQUksRUFBRSxhQUFhO1FBQ25CaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFBRWlDLEtBQUssRUFBRTtRQUFXO01BQzlCLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkssV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRTdDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9CNkMsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFDO1FBQ3hDbEMsTUFBTSxFQUFFO01BQ1YsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRW5CLEdBQUcsRUFBRSwyQ0FBMkM7RUFDaERDLEtBQUssRUFBRSxlQUFlO0VBQ3RCQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLE9BQU87TUFDZEksSUFBSSxFQUFFLE9BQU87TUFDYkMsTUFBTSxFQUFFO1FBQ051RSxPQUFPLEVBQUUsRUFBRTtRQUNYQyxlQUFlLEVBQUUsS0FBSztRQUN0QkMsc0JBQXNCLEVBQUUsS0FBSztRQUM3QkMsSUFBSSxFQUFFO1VBQUVDLFdBQVcsRUFBRSxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFPLENBQUM7UUFDM0NDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsU0FBUyxFQUFFO01BQ2IsQ0FBQztNQUNEakQsSUFBSSxFQUFFLENBQ0o7UUFBRXhCLEVBQUUsRUFBRSxHQUFHO1FBQUV5QixPQUFPLEVBQUUsSUFBSTtRQUFFaEMsSUFBSSxFQUFFLE9BQU87UUFBRWlDLE1BQU0sRUFBRSxRQUFRO1FBQUVoQyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRU0sRUFBRSxFQUFFLEdBQUc7UUFDUHlCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxtQkFBbUI7VUFDMUJnQixJQUFJLEVBQUUsRUFBRTtVQUNSQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0J5QixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFMUUsRUFBRSxFQUFFLEdBQUc7UUFDUHlCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxxQkFBcUI7VUFDNUJnQixJQUFJLEVBQUUsQ0FBQztVQUNQQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxPQUFPLEVBQUUsR0FBRztVQUNaQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0J5QixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFMUUsRUFBRSxFQUFFLEdBQUc7UUFDUHlCLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxJQUFJLEVBQUUsT0FBTztRQUNiaUMsTUFBTSxFQUFFLFFBQVE7UUFDaEJoQyxNQUFNLEVBQUU7VUFDTmlDLEtBQUssRUFBRSxZQUFZO1VBQ25CZ0IsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCeUIsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDLEVBQ0Q7UUFDRTFFLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QixPQUFPLEVBQUUsSUFBSTtRQUNiaEMsSUFBSSxFQUFFLE9BQU87UUFDYmlDLE1BQU0sRUFBRSxRQUFRO1FBQ2hCaEMsTUFBTSxFQUFFO1VBQ05pQyxLQUFLLEVBQUUsbUJBQW1CO1VBQzFCZ0IsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCeUIsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDLEVBQ0Q7UUFDRTFFLEVBQUUsRUFBRSxHQUFHO1FBQ1B5QixPQUFPLEVBQUUsSUFBSTtRQUNiaEMsSUFBSSxFQUFFLE9BQU87UUFDYmlDLE1BQU0sRUFBRSxRQUFRO1FBQ2hCaEMsTUFBTSxFQUFFO1VBQ05pQyxLQUFLLEVBQUUsMkJBQTJCO1VBQ2xDZ0IsSUFBSSxFQUFFLENBQUM7VUFDUEMsS0FBSyxFQUFFLE1BQU07VUFDYkMsT0FBTyxFQUFFLEdBQUc7VUFDWkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCeUIsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0YxQyxXQUFXLEVBQUV6QyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUMxQm1GLEdBQUcsRUFBRTtRQUFFakYsTUFBTSxFQUFFO1VBQUUwRSxJQUFJLEVBQUU7WUFBRUMsV0FBVyxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQU87UUFBRTtNQUFFO0lBQ2pFLENBQUMsQ0FBQztJQUNGckMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFN0MsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0I2QyxLQUFLLEVBQUUsY0FBYztRQUNyQkMsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTLENBQUM7UUFDeENsQyxNQUFNLEVBQUU7TUFDVixDQUFDO0lBQ0g7RUFDRjtBQUNGLENBQUMsQ0FDRjtBQUFBbUYsT0FBQSxDQUFBQyxPQUFBLEdBQUF4RyxRQUFBO0FBQUF5RyxNQUFBLENBQUFGLE9BQUEsR0FBQUEsT0FBQSxDQUFBQyxPQUFBIn0=