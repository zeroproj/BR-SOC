"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Overview/NIST visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Overview-NIST-Requirements-over-time',
  _source: {
    title: 'Requirements over time',
    visState: JSON.stringify({
      title: 'NIST-Requirements-over-time',
      type: 'histogram',
      params: {
        type: 'histogram',
        grid: {
          categoryLines: true,
          valueAxis: 'ValueAxis-1'
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'linear'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {
          show: false
        },
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'date',
              params: {
                pattern: 'YYYY-MM-DD HH:mm'
              }
            },
            params: {
              date: true,
              interval: 'PT1H',
              format: 'YYYY-MM-DD HH:mm',
              bounds: {
                min: '2019-08-20T12:33:23.360Z',
                max: '2019-08-22T12:33:23.360Z'
              }
            },
            aggType: 'date_histogram'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        schema: 'segment',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-2d',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.nist_800_53',
          orderBy: '1',
          order: 'desc',
          size: 50,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          language: 'lucene',
          query: ''
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Requirements-Agents-heatmap',
  _type: 'visualization',
  _source: {
    title: 'Alerts volume by agent',
    visState: JSON.stringify({
      aggs: [{
        enabled: true,
        id: '1',
        params: {},
        schema: 'metric',
        type: 'count'
      }, {
        enabled: true,
        id: '3',
        params: {
          customLabel: 'Requirement',
          field: 'rule.nist_800_53',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          size: 10
        },
        schema: 'group',
        type: 'terms'
      }, {
        enabled: true,
        id: '2',
        params: {
          customLabel: 'Agent',
          field: 'agent.id',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          order: 'desc',
          orderBy: '1',
          otherBucket: false,
          otherBucketLabel: 'Other',
          size: 5
        },
        schema: 'segment',
        type: 'terms'
      }],
      params: {
        addLegend: true,
        addTooltip: true,
        colorSchema: 'Blues',
        colorsNumber: 10,
        colorsRange: [],
        dimensions: {
          series: [{
            accessor: 0,
            aggType: 'terms',
            format: {
              id: 'terms',
              params: {
                id: 'string',
                missingBucketLabel: 'Missing',
                otherBucketLabel: 'Other'
              }
            },
            params: {}
          }],
          x: {
            accessor: 1,
            aggType: 'terms',
            format: {
              id: 'terms',
              params: {
                id: 'string',
                missingBucketLabel: 'Missing',
                otherBucketLabel: 'Other'
              }
            },
            params: {}
          },
          y: [{
            accessor: 2,
            aggType: 'count',
            format: {
              id: 'number'
            },
            params: {}
          }]
        },
        enableHover: false,
        invertColors: false,
        legendPosition: 'right',
        percentageMode: false,
        setColorRange: false,
        times: [],
        type: 'heatmap',
        valueAxes: [{
          id: 'ValueAxis-1',
          labels: {
            color: 'black',
            overwriteColor: false,
            rotate: 0,
            show: false
          },
          scale: {
            defaultYExtents: false,
            type: 'linear'
          },
          show: false,
          type: 'value'
        }]
      },
      title: 'NIST-Last-alerts',
      type: 'heatmap'
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        defaultColors: {
          '0 - 160': 'rgb(247,251,255)',
          '160 - 320': 'rgb(227,238,249)',
          '320 - 480': 'rgb(208,225,242)',
          '480 - 640': 'rgb(182,212,233)',
          '640 - 800': 'rgb(148,196,223)',
          '800 - 960': 'rgb(107,174,214)',
          '960 - 1,120': 'rgb(74,152,201)',
          '1,120 - 1,280': 'rgb(46,126,188)',
          '1,280 - 1,440': 'rgb(23,100,171)',
          '1,440 - 1,600': 'rgb(8,74,145)'
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        query: {
          query: '',
          language: 'lucene'
        },
        filter: []
      })
    }
  }
}, {
  _id: 'Wazuh-App-Overview-NIST-requirements-by-agents',
  _source: {
    title: 'Requirements distribution by agent',
    visState: JSON.stringify({
      title: 'NIST-Top-requirements-by-agent',
      type: 'area',
      params: {
        type: 'area',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: 'true',
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          showCircles: true,
          interpolate: 'linear',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        dimensions: {
          x: {
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          },
          y: [{
            accessor: 2,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          series: [{
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'agent.id',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agent'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'group',
        params: {
          field: 'rule.nist_800_53',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        legendOpen: false
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Metrics',
  _source: {
    title: 'Stats',
    visState: JSON.stringify({
      title: 'nist-metrics',
      type: 'metric',
      params: {
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'None',
          colorsRange: [{
            type: 'range',
            from: 0,
            to: 10000
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 20
          }
        },
        dimensions: {
          metrics: [{
            type: 'vis_dimension',
            accessor: 0,
            format: {
              id: 'number',
              params: {}
            }
          }, {
            type: 'vis_dimension',
            accessor: 1,
            format: {
              id: 'number',
              params: {}
            }
          }]
        },
        addTooltip: true,
        addLegend: false,
        type: 'metric'
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {
          customLabel: 'Total alerts'
        }
      }, {
        id: '2',
        enabled: true,
        type: 'max',
        schema: 'metric',
        params: {
          field: 'rule.level',
          customLabel: 'Max rule level detected'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Top-10-requirements',
  _source: {
    title: 'Top 10 requirements',
    visState: JSON.stringify({
      title: 'NIST-Top-10-requirements',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'rule.nist_800_53',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Agents',
  _source: {
    title: 'Most active agents',
    visState: JSON.stringify({
      title: 'NIST-Top-10-agents',
      type: 'pie',
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        },
        dimensions: {
          metric: {
            accessor: 1,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          },
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'segment',
        params: {
          field: 'agent.name',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agent'
        }
      }]
    }),
    uiStateJSON: '{}',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-NIST-Alerts-summary',
  _type: 'visualization',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'NIST-Alerts-summary',
      type: 'table',
      params: {
        perPage: 10,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: 3,
          direction: 'desc'
        },
        showTotal: false,
        showToolbar: true,
        totalFunc: 'sum',
        dimensions: {
          metrics: [{
            accessor: 3,
            format: {
              id: 'number'
            },
            params: {},
            aggType: 'count'
          }],
          buckets: [{
            accessor: 0,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }, {
            accessor: 1,
            format: {
              id: 'terms',
              params: {
                id: 'string',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }, {
            accessor: 2,
            format: {
              id: 'terms',
              params: {
                id: 'number',
                otherBucketLabel: 'Other',
                missingBucketLabel: 'Missing'
              }
            },
            params: {},
            aggType: 'terms'
          }]
        }
      },
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        schema: 'metric',
        params: {}
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'agent.name',
          orderBy: '1',
          order: 'desc',
          size: 50,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Agent'
        }
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.nist_800_53',
          orderBy: '1',
          order: 'desc',
          size: 20,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Requirement'
        }
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        schema: 'bucket',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Rule level'
        }
      }]
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: JSON.stringify({
        index: 'wazuh-alerts',
        filter: [],
        query: {
          query: '',
          language: 'lucene'
        }
      })
    }
  }
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl9zb3VyY2UiLCJ0aXRsZSIsInZpc1N0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsInR5cGUiLCJwYXJhbXMiLCJncmlkIiwiY2F0ZWdvcnlMaW5lcyIsInZhbHVlQXhpcyIsImNhdGVnb3J5QXhlcyIsImlkIiwicG9zaXRpb24iLCJzaG93Iiwic3R5bGUiLCJzY2FsZSIsImxhYmVscyIsImZpbHRlciIsInRydW5jYXRlIiwidmFsdWVBeGVzIiwibmFtZSIsIm1vZGUiLCJyb3RhdGUiLCJ0ZXh0Iiwic2VyaWVzUGFyYW1zIiwiZGF0YSIsImxhYmVsIiwiZHJhd0xpbmVzQmV0d2VlblBvaW50cyIsInNob3dDaXJjbGVzIiwiaW50ZXJwb2xhdGUiLCJhZGRUb29sdGlwIiwiYWRkTGVnZW5kIiwibGVnZW5kUG9zaXRpb24iLCJ0aW1lcyIsImFkZFRpbWVNYXJrZXIiLCJkaW1lbnNpb25zIiwieCIsImFjY2Vzc29yIiwiZm9ybWF0IiwicGF0dGVybiIsImRhdGUiLCJpbnRlcnZhbCIsImJvdW5kcyIsIm1pbiIsIm1heCIsImFnZ1R5cGUiLCJ5Iiwic2VyaWVzIiwib3RoZXJCdWNrZXRMYWJlbCIsIm1pc3NpbmdCdWNrZXRMYWJlbCIsImFnZ3MiLCJlbmFibGVkIiwic2NoZW1hIiwiZmllbGQiLCJ0aW1lUmFuZ2UiLCJmcm9tIiwidG8iLCJ1c2VOb3JtYWxpemVkRXNJbnRlcnZhbCIsImRyb3BfcGFydGlhbHMiLCJtaW5fZG9jX2NvdW50IiwiZXh0ZW5kZWRfYm91bmRzIiwib3JkZXJCeSIsIm9yZGVyIiwic2l6ZSIsIm90aGVyQnVja2V0IiwibWlzc2luZ0J1Y2tldCIsImN1c3RvbUxhYmVsIiwidWlTdGF0ZUpTT04iLCJkZXNjcmlwdGlvbiIsInZlcnNpb24iLCJraWJhbmFTYXZlZE9iamVjdE1ldGEiLCJzZWFyY2hTb3VyY2VKU09OIiwiaW5kZXgiLCJxdWVyeSIsImxhbmd1YWdlIiwiX3R5cGUiLCJjb2xvclNjaGVtYSIsImNvbG9yc051bWJlciIsImNvbG9yc1JhbmdlIiwiZW5hYmxlSG92ZXIiLCJpbnZlcnRDb2xvcnMiLCJwZXJjZW50YWdlTW9kZSIsInNldENvbG9yUmFuZ2UiLCJjb2xvciIsIm92ZXJ3cml0ZUNvbG9yIiwiZGVmYXVsdFlFeHRlbnRzIiwidmlzIiwiZGVmYXVsdENvbG9ycyIsImxlZ2VuZE9wZW4iLCJtZXRyaWMiLCJ1c2VSYW5nZXMiLCJtZXRyaWNDb2xvck1vZGUiLCJiZ0ZpbGwiLCJiZ0NvbG9yIiwibGFiZWxDb2xvciIsInN1YlRleHQiLCJmb250U2l6ZSIsIm1ldHJpY3MiLCJpc0RvbnV0IiwidmFsdWVzIiwibGFzdF9sZXZlbCIsImJ1Y2tldHMiLCJwZXJQYWdlIiwic2hvd1BhcnRpYWxSb3dzIiwic2hvd01ldHJpY3NBdEFsbExldmVscyIsInNvcnQiLCJjb2x1bW5JbmRleCIsImRpcmVjdGlvbiIsInNob3dUb3RhbCIsInNob3dUb29sYmFyIiwidG90YWxGdW5jIiwiZXhwb3J0cyIsImRlZmF1bHQiLCJtb2R1bGUiXSwic291cmNlcyI6WyJvdmVydmlldy1uaXN0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBhcHAgLSBNb2R1bGUgZm9yIE92ZXJ2aWV3L05JU1QgdmlzdWFsaXphdGlvbnNcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXG4gKlxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxuICovXG5leHBvcnQgZGVmYXVsdCBbXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctTklTVC1SZXF1aXJlbWVudHMtb3Zlci10aW1lJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1JlcXVpcmVtZW50cyBvdmVyIHRpbWUnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdOSVNULVJlcXVpcmVtZW50cy1vdmVyLXRpbWUnLFxuICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ2hpc3RvZ3JhbScsXG4gICAgICAgICAgZ3JpZDogeyBjYXRlZ29yeUxpbmVzOiB0cnVlLCB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScgfSxcbiAgICAgICAgICBjYXRlZ29yeUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdDYXRlZ29yeUF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICdjYXRlZ29yeScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgZmlsdGVyOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIG5hbWU6ICdMZWZ0QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdsZWZ0JyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZTogeyB0eXBlOiAnbGluZWFyJywgbW9kZTogJ25vcm1hbCcgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUsIHJvdGF0ZTogMCwgZmlsdGVyOiBmYWxzZSwgdHJ1bmNhdGU6IDEwMCB9LFxuICAgICAgICAgICAgICB0aXRsZTogeyB0ZXh0OiAnQ291bnQnIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNob3c6ICd0cnVlJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcbiAgICAgICAgICAgICAgZGF0YTogeyBsYWJlbDogJ0NvdW50JywgaWQ6ICcxJyB9LFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgICBpbnRlcnBvbGF0ZTogJ2xpbmVhcicsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgdGltZXM6IFtdLFxuICAgICAgICAgIGFkZFRpbWVNYXJrZXI6IGZhbHNlLFxuICAgICAgICAgIGxhYmVsczogeyBzaG93OiBmYWxzZSB9LFxuICAgICAgICAgIGRpbWVuc2lvbnM6IHtcbiAgICAgICAgICAgIHg6IHtcbiAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXG4gICAgICAgICAgICAgIGZvcm1hdDogeyBpZDogJ2RhdGUnLCBwYXJhbXM6IHsgcGF0dGVybjogJ1lZWVktTU0tREQgSEg6bW0nIH0gfSxcbiAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgZGF0ZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBpbnRlcnZhbDogJ1BUMUgnLFxuICAgICAgICAgICAgICAgIGZvcm1hdDogJ1lZWVktTU0tREQgSEg6bW0nLFxuICAgICAgICAgICAgICAgIGJvdW5kczogeyBtaW46ICcyMDE5LTA4LTIwVDEyOjMzOjIzLjM2MFonLCBtYXg6ICcyMDE5LTA4LTIyVDEyOjMzOjIzLjM2MFonIH0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGFnZ1R5cGU6ICdkYXRlX2hpc3RvZ3JhbScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgeTogW3sgYWNjZXNzb3I6IDIsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9XSxcbiAgICAgICAgICAgIHNlcmllczogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDEsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAndGltZXN0YW1wJyxcbiAgICAgICAgICAgICAgdGltZVJhbmdlOiB7IGZyb206ICdub3ctMmQnLCB0bzogJ25vdycgfSxcbiAgICAgICAgICAgICAgdXNlTm9ybWFsaXplZEVzSW50ZXJ2YWw6IHRydWUsXG4gICAgICAgICAgICAgIGludGVydmFsOiAnYXV0bycsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubmlzdF84MDBfNTMnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSZXF1aXJlbWVudCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgbGFuZ3VhZ2U6ICdsdWNlbmUnLCBxdWVyeTogJycgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1OSVNULVJlcXVpcmVtZW50cy1BZ2VudHMtaGVhdG1hcCcsXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0FsZXJ0cyB2b2x1bWUgYnkgYWdlbnQnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgZW5hYmxlZDogdHJ1ZSwgaWQ6ICcxJywgcGFyYW1zOiB7fSwgc2NoZW1hOiAnbWV0cmljJywgdHlwZTogJ2NvdW50JyB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICBpZDogJzMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnUmVxdWlyZW1lbnQnLFxuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubmlzdF84MDBfNTMnLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdncm91cCcsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBZ2VudCcsXG4gICAgICAgICAgICAgIGZpZWxkOiAnYWdlbnQuaWQnLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBjb2xvclNjaGVtYTogJ0JsdWVzJyxcbiAgICAgICAgICBjb2xvcnNOdW1iZXI6IDEwLFxuICAgICAgICAgIGNvbG9yc1JhbmdlOiBbXSxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICBzZXJpZXM6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAwLFxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgeDoge1xuICAgICAgICAgICAgICBhY2Nlc3NvcjogMSxcbiAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7IGlkOiAnc3RyaW5nJywgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB5OiBbeyBhY2Nlc3NvcjogMiwgYWdnVHlwZTogJ2NvdW50JywgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9IH1dLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgZW5hYmxlSG92ZXI6IGZhbHNlLFxuICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgcGVyY2VudGFnZU1vZGU6IGZhbHNlLFxuICAgICAgICAgIHNldENvbG9yUmFuZ2U6IGZhbHNlLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICB0eXBlOiAnaGVhdG1hcCcsXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgY29sb3I6ICdibGFjaycsIG92ZXJ3cml0ZUNvbG9yOiBmYWxzZSwgcm90YXRlOiAwLCBzaG93OiBmYWxzZSB9LFxuICAgICAgICAgICAgICBzY2FsZTogeyBkZWZhdWx0WUV4dGVudHM6IGZhbHNlLCB0eXBlOiAnbGluZWFyJyB9LFxuICAgICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgICAgdHlwZTogJ3ZhbHVlJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgfSxcbiAgICAgICAgdGl0bGU6ICdOSVNULUxhc3QtYWxlcnRzJyxcbiAgICAgICAgdHlwZTogJ2hlYXRtYXAnLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB2aXM6IHtcbiAgICAgICAgICBkZWZhdWx0Q29sb3JzOiB7XG4gICAgICAgICAgICAnMCAtIDE2MCc6ICdyZ2IoMjQ3LDI1MSwyNTUpJyxcbiAgICAgICAgICAgICcxNjAgLSAzMjAnOiAncmdiKDIyNywyMzgsMjQ5KScsXG4gICAgICAgICAgICAnMzIwIC0gNDgwJzogJ3JnYigyMDgsMjI1LDI0MiknLFxuICAgICAgICAgICAgJzQ4MCAtIDY0MCc6ICdyZ2IoMTgyLDIxMiwyMzMpJyxcbiAgICAgICAgICAgICc2NDAgLSA4MDAnOiAncmdiKDE0OCwxOTYsMjIzKScsXG4gICAgICAgICAgICAnODAwIC0gOTYwJzogJ3JnYigxMDcsMTc0LDIxNCknLFxuICAgICAgICAgICAgJzk2MCAtIDEsMTIwJzogJ3JnYig3NCwxNTIsMjAxKScsXG4gICAgICAgICAgICAnMSwxMjAgLSAxLDI4MCc6ICdyZ2IoNDYsMTI2LDE4OCknLFxuICAgICAgICAgICAgJzEsMjgwIC0gMSw0NDAnOiAncmdiKDIzLDEwMCwxNzEpJyxcbiAgICAgICAgICAgICcxLDQ0MCAtIDEsNjAwJzogJ3JnYig4LDc0LDE0NSknLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgIGluZGV4OiAnd2F6dWgtYWxlcnRzJyxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU5JU1QtcmVxdWlyZW1lbnRzLWJ5LWFnZW50cycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdSZXF1aXJlbWVudHMgZGlzdHJpYnV0aW9uIGJ5IGFnZW50JyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnTklTVC1Ub3AtcmVxdWlyZW1lbnRzLWJ5LWFnZW50JyxcbiAgICAgICAgdHlwZTogJ2FyZWEnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgZ3JpZDogeyBjYXRlZ29yeUxpbmVzOiBmYWxzZSB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInIH0sXG4gICAgICAgICAgICAgIGxhYmVsczogeyBzaG93OiB0cnVlLCBmaWx0ZXI6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICAgICAgdGl0bGU6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHZhbHVlQXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgICAgbmFtZTogJ0xlZnRBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBwb3NpdGlvbjogJ2xlZnQnLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7IHR5cGU6ICdsaW5lYXInLCBtb2RlOiAnbm9ybWFsJyB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHsgc2hvdzogdHJ1ZSwgcm90YXRlOiAwLCBmaWx0ZXI6IGZhbHNlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgICAgIHRpdGxlOiB7IHRleHQ6ICdDb3VudCcgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBzZXJpZXNQYXJhbXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogJ3RydWUnLFxuICAgICAgICAgICAgICB0eXBlOiAnaGlzdG9ncmFtJyxcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxuICAgICAgICAgICAgICBkYXRhOiB7IGxhYmVsOiAnQ291bnQnLCBpZDogJzEnIH0sXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgICBpbnRlcnBvbGF0ZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgICAgZGltZW5zaW9uczoge1xuICAgICAgICAgICAgeDoge1xuICAgICAgICAgICAgICBhY2Nlc3NvcjogMCxcbiAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7IGlkOiAnc3RyaW5nJywgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJywgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB5OiBbeyBhY2Nlc3NvcjogMiwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9LCBhZ2dUeXBlOiAnY291bnQnIH1dLFxuICAgICAgICAgICAgc2VyaWVzOiBbXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMSxcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnc3RyaW5nJyxcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdhZ2VudC5pZCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnQWdlbnQnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubmlzdF84MDBfNTMnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSZXF1aXJlbWVudCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7IHZpczogeyBsZWdlbmRPcGVuOiBmYWxzZSB9IH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1OSVNULU1ldHJpY3MnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnU3RhdHMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICduaXN0LW1ldHJpY3MnLFxuICAgICAgICB0eXBlOiAnbWV0cmljJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgbWV0cmljOiB7XG4gICAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXG4gICAgICAgICAgICB1c2VSYW5nZXM6IGZhbHNlLFxuICAgICAgICAgICAgY29sb3JTY2hlbWE6ICdHcmVlbiB0byBSZWQnLFxuICAgICAgICAgICAgbWV0cmljQ29sb3JNb2RlOiAnTm9uZScsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW3sgdHlwZTogJ3JhbmdlJywgZnJvbTogMCwgdG86IDEwMDAwIH1dLFxuICAgICAgICAgICAgbGFiZWxzOiB7IHNob3c6IHRydWUgfSxcbiAgICAgICAgICAgIGludmVydENvbG9yczogZmFsc2UsXG4gICAgICAgICAgICBzdHlsZTogeyBiZ0ZpbGw6ICcjMDAwJywgYmdDb2xvcjogZmFsc2UsIGxhYmVsQ29sb3I6IGZhbHNlLCBzdWJUZXh0OiAnJywgZm9udFNpemU6IDIwIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICBtZXRyaWNzOiBbXG4gICAgICAgICAgICAgIHsgdHlwZTogJ3Zpc19kaW1lbnNpb24nLCBhY2Nlc3NvcjogMCwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJywgcGFyYW1zOiB7fSB9IH0sXG4gICAgICAgICAgICAgIHsgdHlwZTogJ3Zpc19kaW1lbnNpb24nLCBhY2Nlc3NvcjogMSwgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJywgcGFyYW1zOiB7fSB9IH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IGZhbHNlLFxuICAgICAgICAgIHR5cGU6ICdtZXRyaWMnLFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICAgIHBhcmFtczogeyBjdXN0b21MYWJlbDogJ1RvdGFsIGFsZXJ0cycgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ21heCcsXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7IGZpZWxkOiAncnVsZS5sZXZlbCcsIGN1c3RvbUxhYmVsOiAnTWF4IHJ1bGUgbGV2ZWwgZGV0ZWN0ZWQnIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU5JU1QtVG9wLTEwLXJlcXVpcmVtZW50cycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdUb3AgMTAgcmVxdWlyZW1lbnRzJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnTklTVC1Ub3AtMTAtcmVxdWlyZW1lbnRzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgICAgbGFiZWxzOiB7IHNob3c6IGZhbHNlLCB2YWx1ZXM6IHRydWUsIGxhc3RfbGV2ZWw6IHRydWUsIHRydW5jYXRlOiAxMDAgfSxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICBtZXRyaWM6IHsgYWNjZXNzb3I6IDEsIGZvcm1hdDogeyBpZDogJ251bWJlcicgfSwgcGFyYW1zOiB7fSwgYWdnVHlwZTogJ2NvdW50JyB9LFxuICAgICAgICAgICAgYnVja2V0czogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHsgaWQ6ICcxJywgZW5hYmxlZDogdHJ1ZSwgdHlwZTogJ2NvdW50Jywgc2NoZW1hOiAnbWV0cmljJywgcGFyYW1zOiB7fSB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5uaXN0XzgwMF81MycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1JlcXVpcmVtZW50JyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICd7fScsXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LU5JU1QtQWdlbnRzJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ01vc3QgYWN0aXZlIGFnZW50cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ05JU1QtVG9wLTEwLWFnZW50cycsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICAgIGxhYmVsczogeyBzaG93OiBmYWxzZSwgdmFsdWVzOiB0cnVlLCBsYXN0X2xldmVsOiB0cnVlLCB0cnVuY2F0ZTogMTAwIH0sXG4gICAgICAgICAgZGltZW5zaW9uczoge1xuICAgICAgICAgICAgbWV0cmljOiB7IGFjY2Vzc29yOiAxLCBmb3JtYXQ6IHsgaWQ6ICdudW1iZXInIH0sIHBhcmFtczoge30sIGFnZ1R5cGU6ICdjb3VudCcgfSxcbiAgICAgICAgICAgIGJ1Y2tldHM6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAwLFxuICAgICAgICAgICAgICAgIGZvcm1hdDoge1xuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6ICdzdHJpbmcnLFxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7IGlkOiAnMScsIGVuYWJsZWQ6IHRydWUsIHR5cGU6ICdjb3VudCcsIHNjaGVtYTogJ21ldHJpYycsIHBhcmFtczoge30gfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2FnZW50Lm5hbWUnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBZ2VudCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAne30nLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgaW5kZXg6ICd3YXp1aC1hbGVydHMnLFxuICAgICAgICAgIGZpbHRlcjogW10sXG4gICAgICAgICAgcXVlcnk6IHsgcXVlcnk6ICcnLCBsYW5ndWFnZTogJ2x1Y2VuZScgfSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1OSVNULUFsZXJ0cy1zdW1tYXJ5JyxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdOSVNULUFsZXJ0cy1zdW1tYXJ5JyxcbiAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgcGVyUGFnZTogMTAsXG4gICAgICAgICAgc2hvd1BhcnRpYWxSb3dzOiBmYWxzZSxcbiAgICAgICAgICBzaG93TWV0cmljc0F0QWxsTGV2ZWxzOiBmYWxzZSxcbiAgICAgICAgICBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9LFxuICAgICAgICAgIHNob3dUb3RhbDogZmFsc2UsXG4gICAgICAgICAgc2hvd1Rvb2xiYXI6IHRydWUsXG4gICAgICAgICAgdG90YWxGdW5jOiAnc3VtJyxcbiAgICAgICAgICBkaW1lbnNpb25zOiB7XG4gICAgICAgICAgICBtZXRyaWNzOiBbeyBhY2Nlc3NvcjogMywgZm9ybWF0OiB7IGlkOiAnbnVtYmVyJyB9LCBwYXJhbXM6IHt9LCBhZ2dUeXBlOiAnY291bnQnIH1dLFxuICAgICAgICAgICAgYnVja2V0czogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYWNjZXNzb3I6IDAsXG4gICAgICAgICAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICAgICAgICBpZDogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3N0cmluZycsXG4gICAgICAgICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICAgICAgYWdnVHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGFjY2Vzc29yOiAxLFxuICAgICAgICAgICAgICAgIGZvcm1hdDoge1xuICAgICAgICAgICAgICAgICAgaWQ6ICd0ZXJtcycsXG4gICAgICAgICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgaWQ6ICdzdHJpbmcnLFxuICAgICAgICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgICAgIGFnZ1R5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBhY2Nlc3NvcjogMixcbiAgICAgICAgICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgICAgICAgIGlkOiAndGVybXMnLFxuICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAnbnVtYmVyJyxcbiAgICAgICAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgICAgICBhZ2dUeXBlOiAndGVybXMnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAgeyBpZDogJzEnLCBlbmFibGVkOiB0cnVlLCB0eXBlOiAnY291bnQnLCBzY2hlbWE6ICdtZXRyaWMnLCBwYXJhbXM6IHt9IH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2FnZW50Lm5hbWUnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdBZ2VudCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubmlzdF84MDBfNTMnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDIwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdSZXF1aXJlbWVudCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICc0JyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUubGV2ZWwnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1J1bGUgbGV2ZWwnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxuICAgICAgfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBpbmRleDogJ3dhenVoLWFsZXJ0cycsXG4gICAgICAgICAgZmlsdGVyOiBbXSxcbiAgICAgICAgICBxdWVyeTogeyBxdWVyeTogJycsIGxhbmd1YWdlOiAnbHVjZW5lJyB9LFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbl07XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWQSxJQUFBQSxRQUFBLEdBV2UsQ0FDYjtFQUNFQyxHQUFHLEVBQUUsZ0RBQWdEO0VBQ3JEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHdCQUF3QjtJQUMvQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLDZCQUE2QjtNQUNwQ0ksSUFBSSxFQUFFLFdBQVc7TUFDakJDLE1BQU0sRUFBRTtRQUNORCxJQUFJLEVBQUUsV0FBVztRQUNqQkUsSUFBSSxFQUFFO1VBQUVDLGFBQWEsRUFBRSxJQUFJO1VBQUVDLFNBQVMsRUFBRTtRQUFjLENBQUM7UUFDdkRDLFlBQVksRUFBRSxDQUNaO1VBQ0VDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJOLElBQUksRUFBRSxVQUFVO1VBQ2hCTyxRQUFRLEVBQUUsUUFBUTtVQUNsQkMsSUFBSSxFQUFFLElBQUk7VUFDVkMsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUQyxLQUFLLEVBQUU7WUFBRVYsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6QlcsTUFBTSxFQUFFO1lBQUVILElBQUksRUFBRSxJQUFJO1lBQUVJLE1BQU0sRUFBRSxJQUFJO1lBQUVDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDbkRqQixLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEa0IsU0FBUyxFQUFFLENBQ1Q7VUFDRVIsRUFBRSxFQUFFLGFBQWE7VUFDakJTLElBQUksRUFBRSxZQUFZO1VBQ2xCZixJQUFJLEVBQUUsT0FBTztVQUNiTyxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsSUFBSSxFQUFFLElBQUk7VUFDVkMsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUQyxLQUFLLEVBQUU7WUFBRVYsSUFBSSxFQUFFLFFBQVE7WUFBRWdCLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekNMLE1BQU0sRUFBRTtZQUFFSCxJQUFJLEVBQUUsSUFBSTtZQUFFUyxNQUFNLEVBQUUsQ0FBQztZQUFFTCxNQUFNLEVBQUUsS0FBSztZQUFFQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQy9EakIsS0FBSyxFQUFFO1lBQUVzQixJQUFJLEVBQUU7VUFBUTtRQUN6QixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVgsSUFBSSxFQUFFLE1BQU07VUFDWlIsSUFBSSxFQUFFLE1BQU07VUFDWmdCLElBQUksRUFBRSxRQUFRO1VBQ2RJLElBQUksRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFZixFQUFFLEVBQUU7VUFBSSxDQUFDO1VBQ2pDRixTQUFTLEVBQUUsYUFBYTtVQUN4QmtCLHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFdBQVcsRUFBRSxJQUFJO1VBQ2pCQyxXQUFXLEVBQUU7UUFDZixDQUFDLENBQ0Y7UUFDREMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQmxCLE1BQU0sRUFBRTtVQUFFSCxJQUFJLEVBQUU7UUFBTSxDQUFDO1FBQ3ZCc0IsVUFBVSxFQUFFO1VBQ1ZDLENBQUMsRUFBRTtZQUNEQyxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FBRTNCLEVBQUUsRUFBRSxNQUFNO2NBQUVMLE1BQU0sRUFBRTtnQkFBRWlDLE9BQU8sRUFBRTtjQUFtQjtZQUFFLENBQUM7WUFDL0RqQyxNQUFNLEVBQUU7Y0FDTmtDLElBQUksRUFBRSxJQUFJO2NBQ1ZDLFFBQVEsRUFBRSxNQUFNO2NBQ2hCSCxNQUFNLEVBQUUsa0JBQWtCO2NBQzFCSSxNQUFNLEVBQUU7Z0JBQUVDLEdBQUcsRUFBRSwwQkFBMEI7Z0JBQUVDLEdBQUcsRUFBRTtjQUEyQjtZQUM3RSxDQUFDO1lBQ0RDLE9BQU8sRUFBRTtVQUNYLENBQUM7VUFDREMsQ0FBQyxFQUFFLENBQUM7WUFBRVQsUUFBUSxFQUFFLENBQUM7WUFBRUMsTUFBTSxFQUFFO2NBQUUzQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVMLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRXVDLE9BQU8sRUFBRTtVQUFRLENBQUMsQ0FBQztVQUM1RUUsTUFBTSxFQUFFLENBQ047WUFDRVYsUUFBUSxFQUFFLENBQUM7WUFDWEMsTUFBTSxFQUFFO2NBQ04zQixFQUFFLEVBQUUsT0FBTztjQUNYTCxNQUFNLEVBQUU7Z0JBQ05LLEVBQUUsRUFBRSxRQUFRO2dCQUNacUMsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJDLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNEM0MsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWdUMsT0FBTyxFQUFFO1VBQ1gsQ0FBQztRQUVMO01BQ0YsQ0FBQztNQUNESyxJQUFJLEVBQUUsQ0FDSjtRQUFFdkMsRUFBRSxFQUFFLEdBQUc7UUFBRXdDLE9BQU8sRUFBRSxJQUFJO1FBQUU5QyxJQUFJLEVBQUUsT0FBTztRQUFFK0MsTUFBTSxFQUFFLFFBQVE7UUFBRTlDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFSyxFQUFFLEVBQUUsR0FBRztRQUNQd0MsT0FBTyxFQUFFLElBQUk7UUFDYjlDLElBQUksRUFBRSxnQkFBZ0I7UUFDdEIrQyxNQUFNLEVBQUUsU0FBUztRQUNqQjlDLE1BQU0sRUFBRTtVQUNOK0MsS0FBSyxFQUFFLFdBQVc7VUFDbEJDLFNBQVMsRUFBRTtZQUFFQyxJQUFJLEVBQUUsUUFBUTtZQUFFQyxFQUFFLEVBQUU7VUFBTSxDQUFDO1VBQ3hDQyx1QkFBdUIsRUFBRSxJQUFJO1VBQzdCaEIsUUFBUSxFQUFFLE1BQU07VUFDaEJpQixhQUFhLEVBQUUsS0FBSztVQUNwQkMsYUFBYSxFQUFFLENBQUM7VUFDaEJDLGVBQWUsRUFBRSxDQUFDO1FBQ3BCO01BQ0YsQ0FBQyxFQUNEO1FBQ0VqRCxFQUFFLEVBQUUsR0FBRztRQUNQd0MsT0FBTyxFQUFFLElBQUk7UUFDYjlDLElBQUksRUFBRSxPQUFPO1FBQ2IrQyxNQUFNLEVBQUUsT0FBTztRQUNmOUMsTUFBTSxFQUFFO1VBQ04rQyxLQUFLLEVBQUUsa0JBQWtCO1VBQ3pCUSxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsRUFBRTtVQUNSQyxXQUFXLEVBQUUsS0FBSztVQUNsQmhCLGdCQUFnQixFQUFFLE9BQU87VUFDekJpQixhQUFhLEVBQUUsS0FBSztVQUNwQmhCLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JpQixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXBFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cb0UsS0FBSyxFQUFFLGNBQWM7UUFDckJ2RCxNQUFNLEVBQUUsRUFBRTtRQUNWd0QsS0FBSyxFQUFFO1VBQUVDLFFBQVEsRUFBRSxRQUFRO1VBQUVELEtBQUssRUFBRTtRQUFHO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREUsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0U1RSxHQUFHLEVBQUUscURBQXFEO0VBQzFENEUsS0FBSyxFQUFFLGVBQWU7RUFDdEIzRSxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHdCQUF3QjtJQUMvQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QjhDLElBQUksRUFBRSxDQUNKO1FBQUVDLE9BQU8sRUFBRSxJQUFJO1FBQUV4QyxFQUFFLEVBQUUsR0FBRztRQUFFTCxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQUU4QyxNQUFNLEVBQUUsUUFBUTtRQUFFL0MsSUFBSSxFQUFFO01BQVEsQ0FBQyxFQUN2RTtRQUNFOEMsT0FBTyxFQUFFLElBQUk7UUFDYnhDLEVBQUUsRUFBRSxHQUFHO1FBQ1BMLE1BQU0sRUFBRTtVQUNONEQsV0FBVyxFQUFFLGFBQWE7VUFDMUJiLEtBQUssRUFBRSxrQkFBa0I7VUFDekJZLGFBQWEsRUFBRSxLQUFLO1VBQ3BCaEIsa0JBQWtCLEVBQUUsU0FBUztVQUM3QmEsS0FBSyxFQUFFLE1BQU07VUFDYkQsT0FBTyxFQUFFLEdBQUc7VUFDWkcsV0FBVyxFQUFFLEtBQUs7VUFDbEJoQixnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCZSxJQUFJLEVBQUU7UUFDUixDQUFDO1FBQ0RYLE1BQU0sRUFBRSxPQUFPO1FBQ2YvQyxJQUFJLEVBQUU7TUFDUixDQUFDLEVBQ0Q7UUFDRThDLE9BQU8sRUFBRSxJQUFJO1FBQ2J4QyxFQUFFLEVBQUUsR0FBRztRQUNQTCxNQUFNLEVBQUU7VUFDTjRELFdBQVcsRUFBRSxPQUFPO1VBQ3BCYixLQUFLLEVBQUUsVUFBVTtVQUNqQlksYUFBYSxFQUFFLEtBQUs7VUFDcEJoQixrQkFBa0IsRUFBRSxTQUFTO1VBQzdCYSxLQUFLLEVBQUUsTUFBTTtVQUNiRCxPQUFPLEVBQUUsR0FBRztVQUNaRyxXQUFXLEVBQUUsS0FBSztVQUNsQmhCLGdCQUFnQixFQUFFLE9BQU87VUFDekJlLElBQUksRUFBRTtRQUNSLENBQUM7UUFDRFgsTUFBTSxFQUFFLFNBQVM7UUFDakIvQyxJQUFJLEVBQUU7TUFDUixDQUFDLENBQ0Y7TUFDREMsTUFBTSxFQUFFO1FBQ055QixTQUFTLEVBQUUsSUFBSTtRQUNmRCxVQUFVLEVBQUUsSUFBSTtRQUNoQjhDLFdBQVcsRUFBRSxPQUFPO1FBQ3BCQyxZQUFZLEVBQUUsRUFBRTtRQUNoQkMsV0FBVyxFQUFFLEVBQUU7UUFDZjNDLFVBQVUsRUFBRTtVQUNWWSxNQUFNLEVBQUUsQ0FDTjtZQUNFVixRQUFRLEVBQUUsQ0FBQztZQUNYUSxPQUFPLEVBQUUsT0FBTztZQUNoQlAsTUFBTSxFQUFFO2NBQ04zQixFQUFFLEVBQUUsT0FBTztjQUNYTCxNQUFNLEVBQUU7Z0JBQ05LLEVBQUUsRUFBRSxRQUFRO2dCQUNac0Msa0JBQWtCLEVBQUUsU0FBUztnQkFDN0JELGdCQUFnQixFQUFFO2NBQ3BCO1lBQ0YsQ0FBQztZQUNEMUMsTUFBTSxFQUFFLENBQUM7VUFDWCxDQUFDLENBQ0Y7VUFDRDhCLENBQUMsRUFBRTtZQUNEQyxRQUFRLEVBQUUsQ0FBQztZQUNYUSxPQUFPLEVBQUUsT0FBTztZQUNoQlAsTUFBTSxFQUFFO2NBQ04zQixFQUFFLEVBQUUsT0FBTztjQUNYTCxNQUFNLEVBQUU7Z0JBQUVLLEVBQUUsRUFBRSxRQUFRO2dCQUFFc0Msa0JBQWtCLEVBQUUsU0FBUztnQkFBRUQsZ0JBQWdCLEVBQUU7Y0FBUTtZQUNuRixDQUFDO1lBQ0QxQyxNQUFNLEVBQUUsQ0FBQztVQUNYLENBQUM7VUFDRHdDLENBQUMsRUFBRSxDQUFDO1lBQUVULFFBQVEsRUFBRSxDQUFDO1lBQUVRLE9BQU8sRUFBRSxPQUFPO1lBQUVQLE1BQU0sRUFBRTtjQUFFM0IsRUFBRSxFQUFFO1lBQVMsQ0FBQztZQUFFTCxNQUFNLEVBQUUsQ0FBQztVQUFFLENBQUM7UUFDN0UsQ0FBQztRQUNEeUUsV0FBVyxFQUFFLEtBQUs7UUFDbEJDLFlBQVksRUFBRSxLQUFLO1FBQ25CaEQsY0FBYyxFQUFFLE9BQU87UUFDdkJpRCxjQUFjLEVBQUUsS0FBSztRQUNyQkMsYUFBYSxFQUFFLEtBQUs7UUFDcEJqRCxLQUFLLEVBQUUsRUFBRTtRQUNUNUIsSUFBSSxFQUFFLFNBQVM7UUFDZmMsU0FBUyxFQUFFLENBQ1Q7VUFDRVIsRUFBRSxFQUFFLGFBQWE7VUFDakJLLE1BQU0sRUFBRTtZQUFFbUUsS0FBSyxFQUFFLE9BQU87WUFBRUMsY0FBYyxFQUFFLEtBQUs7WUFBRTlELE1BQU0sRUFBRSxDQUFDO1lBQUVULElBQUksRUFBRTtVQUFNLENBQUM7VUFDekVFLEtBQUssRUFBRTtZQUFFc0UsZUFBZSxFQUFFLEtBQUs7WUFBRWhGLElBQUksRUFBRTtVQUFTLENBQUM7VUFDakRRLElBQUksRUFBRSxLQUFLO1VBQ1hSLElBQUksRUFBRTtRQUNSLENBQUM7TUFFTCxDQUFDO01BQ0RKLEtBQUssRUFBRSxrQkFBa0I7TUFDekJJLElBQUksRUFBRTtJQUNSLENBQUMsQ0FBQztJQUNGOEQsV0FBVyxFQUFFaEUsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUJrRixHQUFHLEVBQUU7UUFDSEMsYUFBYSxFQUFFO1VBQ2IsU0FBUyxFQUFFLGtCQUFrQjtVQUM3QixXQUFXLEVBQUUsa0JBQWtCO1VBQy9CLFdBQVcsRUFBRSxrQkFBa0I7VUFDL0IsV0FBVyxFQUFFLGtCQUFrQjtVQUMvQixXQUFXLEVBQUUsa0JBQWtCO1VBQy9CLFdBQVcsRUFBRSxrQkFBa0I7VUFDL0IsYUFBYSxFQUFFLGlCQUFpQjtVQUNoQyxlQUFlLEVBQUUsaUJBQWlCO1VBQ2xDLGVBQWUsRUFBRSxpQkFBaUI7VUFDbEMsZUFBZSxFQUFFO1FBQ25CO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFDRm5CLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXBFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cb0UsS0FBSyxFQUFFLGNBQWM7UUFDckJDLEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUyxDQUFDO1FBQ3hDekQsTUFBTSxFQUFFO01BQ1YsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLEVBQ0Q7RUFDRWxCLEdBQUcsRUFBRSxnREFBZ0Q7RUFDckRDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsb0NBQW9DO0lBQzNDQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsZ0NBQWdDO01BQ3ZDSSxJQUFJLEVBQUUsTUFBTTtNQUNaQyxNQUFNLEVBQUU7UUFDTkQsSUFBSSxFQUFFLE1BQU07UUFDWkUsSUFBSSxFQUFFO1VBQUVDLGFBQWEsRUFBRTtRQUFNLENBQUM7UUFDOUJFLFlBQVksRUFBRSxDQUNaO1VBQ0VDLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJOLElBQUksRUFBRSxVQUFVO1VBQ2hCTyxRQUFRLEVBQUUsUUFBUTtVQUNsQkMsSUFBSSxFQUFFLElBQUk7VUFDVkMsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUQyxLQUFLLEVBQUU7WUFBRVYsSUFBSSxFQUFFO1VBQVMsQ0FBQztVQUN6QlcsTUFBTSxFQUFFO1lBQUVILElBQUksRUFBRSxJQUFJO1lBQUVJLE1BQU0sRUFBRSxJQUFJO1lBQUVDLFFBQVEsRUFBRTtVQUFJLENBQUM7VUFDbkRqQixLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEa0IsU0FBUyxFQUFFLENBQ1Q7VUFDRVIsRUFBRSxFQUFFLGFBQWE7VUFDakJTLElBQUksRUFBRSxZQUFZO1VBQ2xCZixJQUFJLEVBQUUsT0FBTztVQUNiTyxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsSUFBSSxFQUFFLElBQUk7VUFDVkMsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUQyxLQUFLLEVBQUU7WUFBRVYsSUFBSSxFQUFFLFFBQVE7WUFBRWdCLElBQUksRUFBRTtVQUFTLENBQUM7VUFDekNMLE1BQU0sRUFBRTtZQUFFSCxJQUFJLEVBQUUsSUFBSTtZQUFFUyxNQUFNLEVBQUUsQ0FBQztZQUFFTCxNQUFNLEVBQUUsS0FBSztZQUFFQyxRQUFRLEVBQUU7VUFBSSxDQUFDO1VBQy9EakIsS0FBSyxFQUFFO1lBQUVzQixJQUFJLEVBQUU7VUFBUTtRQUN6QixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVgsSUFBSSxFQUFFLE1BQU07VUFDWlIsSUFBSSxFQUFFLFdBQVc7VUFDakJnQixJQUFJLEVBQUUsU0FBUztVQUNmSSxJQUFJLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRWYsRUFBRSxFQUFFO1VBQUksQ0FBQztVQUNqQ2dCLHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFdBQVcsRUFBRSxJQUFJO1VBQ2pCQyxXQUFXLEVBQUUsUUFBUTtVQUNyQnBCLFNBQVMsRUFBRTtRQUNiLENBQUMsQ0FDRjtRQUNEcUIsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCQyxLQUFLLEVBQUUsRUFBRTtRQUNUQyxhQUFhLEVBQUUsS0FBSztRQUNwQkMsVUFBVSxFQUFFO1VBQ1ZDLENBQUMsRUFBRTtZQUNEQyxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FDTjNCLEVBQUUsRUFBRSxPQUFPO2NBQ1hMLE1BQU0sRUFBRTtnQkFBRUssRUFBRSxFQUFFLFFBQVE7Z0JBQUVxQyxnQkFBZ0IsRUFBRSxPQUFPO2dCQUFFQyxrQkFBa0IsRUFBRTtjQUFVO1lBQ25GLENBQUM7WUFDRDNDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDVnVDLE9BQU8sRUFBRTtVQUNYLENBQUM7VUFDREMsQ0FBQyxFQUFFLENBQUM7WUFBRVQsUUFBUSxFQUFFLENBQUM7WUFBRUMsTUFBTSxFQUFFO2NBQUUzQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVMLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRXVDLE9BQU8sRUFBRTtVQUFRLENBQUMsQ0FBQztVQUM1RUUsTUFBTSxFQUFFLENBQ047WUFDRVYsUUFBUSxFQUFFLENBQUM7WUFDWEMsTUFBTSxFQUFFO2NBQ04zQixFQUFFLEVBQUUsT0FBTztjQUNYTCxNQUFNLEVBQUU7Z0JBQ05LLEVBQUUsRUFBRSxRQUFRO2dCQUNacUMsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJDLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNEM0MsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWdUMsT0FBTyxFQUFFO1VBQ1gsQ0FBQztRQUVMO01BQ0YsQ0FBQztNQUNESyxJQUFJLEVBQUUsQ0FDSjtRQUFFdkMsRUFBRSxFQUFFLEdBQUc7UUFBRXdDLE9BQU8sRUFBRSxJQUFJO1FBQUU5QyxJQUFJLEVBQUUsT0FBTztRQUFFK0MsTUFBTSxFQUFFLFFBQVE7UUFBRTlDLE1BQU0sRUFBRSxDQUFDO01BQUUsQ0FBQyxFQUN2RTtRQUNFSyxFQUFFLEVBQUUsR0FBRztRQUNQd0MsT0FBTyxFQUFFLElBQUk7UUFDYjlDLElBQUksRUFBRSxPQUFPO1FBQ2IrQyxNQUFNLEVBQUUsU0FBUztRQUNqQjlDLE1BQU0sRUFBRTtVQUNOK0MsS0FBSyxFQUFFLFVBQVU7VUFDakJRLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxDQUFDO1VBQ1BDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCaEIsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QmlCLGFBQWEsRUFBRSxLQUFLO1VBQ3BCaEIsa0JBQWtCLEVBQUUsU0FBUztVQUM3QmlCLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0V2RCxFQUFFLEVBQUUsR0FBRztRQUNQd0MsT0FBTyxFQUFFLElBQUk7UUFDYjlDLElBQUksRUFBRSxPQUFPO1FBQ2IrQyxNQUFNLEVBQUUsT0FBTztRQUNmOUMsTUFBTSxFQUFFO1VBQ04rQyxLQUFLLEVBQUUsa0JBQWtCO1VBQ3pCUSxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsRUFBRTtVQUNSQyxXQUFXLEVBQUUsS0FBSztVQUNsQmhCLGdCQUFnQixFQUFFLE9BQU87VUFDekJpQixhQUFhLEVBQUUsS0FBSztVQUNwQmhCLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JpQixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFaEUsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFBRWtGLEdBQUcsRUFBRTtRQUFFRSxVQUFVLEVBQUU7TUFBTTtJQUFFLENBQUMsQ0FBQztJQUMzRHBCLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXBFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cb0UsS0FBSyxFQUFFLGNBQWM7UUFDckJ2RCxNQUFNLEVBQUUsRUFBRTtRQUNWd0QsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0U1RSxHQUFHLEVBQUUsaUNBQWlDO0VBQ3RDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLE9BQU87SUFDZEMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGNBQWM7TUFDckJJLElBQUksRUFBRSxRQUFRO01BQ2RDLE1BQU0sRUFBRTtRQUNObUYsTUFBTSxFQUFFO1VBQ05SLGNBQWMsRUFBRSxLQUFLO1VBQ3JCUyxTQUFTLEVBQUUsS0FBSztVQUNoQmQsV0FBVyxFQUFFLGNBQWM7VUFDM0JlLGVBQWUsRUFBRSxNQUFNO1VBQ3ZCYixXQUFXLEVBQUUsQ0FBQztZQUFFekUsSUFBSSxFQUFFLE9BQU87WUFBRWtELElBQUksRUFBRSxDQUFDO1lBQUVDLEVBQUUsRUFBRTtVQUFNLENBQUMsQ0FBQztVQUNwRHhDLE1BQU0sRUFBRTtZQUFFSCxJQUFJLEVBQUU7VUFBSyxDQUFDO1VBQ3RCbUUsWUFBWSxFQUFFLEtBQUs7VUFDbkJsRSxLQUFLLEVBQUU7WUFBRThFLE1BQU0sRUFBRSxNQUFNO1lBQUVDLE9BQU8sRUFBRSxLQUFLO1lBQUVDLFVBQVUsRUFBRSxLQUFLO1lBQUVDLE9BQU8sRUFBRSxFQUFFO1lBQUVDLFFBQVEsRUFBRTtVQUFHO1FBQ3hGLENBQUM7UUFDRDdELFVBQVUsRUFBRTtVQUNWOEQsT0FBTyxFQUFFLENBQ1A7WUFBRTVGLElBQUksRUFBRSxlQUFlO1lBQUVnQyxRQUFRLEVBQUUsQ0FBQztZQUFFQyxNQUFNLEVBQUU7Y0FBRTNCLEVBQUUsRUFBRSxRQUFRO2NBQUVMLE1BQU0sRUFBRSxDQUFDO1lBQUU7VUFBRSxDQUFDLEVBQzVFO1lBQUVELElBQUksRUFBRSxlQUFlO1lBQUVnQyxRQUFRLEVBQUUsQ0FBQztZQUFFQyxNQUFNLEVBQUU7Y0FBRTNCLEVBQUUsRUFBRSxRQUFRO2NBQUVMLE1BQU0sRUFBRSxDQUFDO1lBQUU7VUFBRSxDQUFDO1FBRWhGLENBQUM7UUFDRHdCLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsS0FBSztRQUNoQjFCLElBQUksRUFBRTtNQUNSLENBQUM7TUFDRDZDLElBQUksRUFBRSxDQUNKO1FBQ0V2QyxFQUFFLEVBQUUsR0FBRztRQUNQd0MsT0FBTyxFQUFFLElBQUk7UUFDYjlDLElBQUksRUFBRSxPQUFPO1FBQ2IrQyxNQUFNLEVBQUUsUUFBUTtRQUNoQjlDLE1BQU0sRUFBRTtVQUFFNEQsV0FBVyxFQUFFO1FBQWU7TUFDeEMsQ0FBQyxFQUNEO1FBQ0V2RCxFQUFFLEVBQUUsR0FBRztRQUNQd0MsT0FBTyxFQUFFLElBQUk7UUFDYjlDLElBQUksRUFBRSxLQUFLO1FBQ1grQyxNQUFNLEVBQUUsUUFBUTtRQUNoQjlDLE1BQU0sRUFBRTtVQUFFK0MsS0FBSyxFQUFFLFlBQVk7VUFBRWEsV0FBVyxFQUFFO1FBQTBCO01BQ3hFLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXBFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cb0UsS0FBSyxFQUFFLGNBQWM7UUFDckJ2RCxNQUFNLEVBQUUsRUFBRTtRQUNWd0QsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0U1RSxHQUFHLEVBQUUsNkNBQTZDO0VBQ2xEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHFCQUFxQjtJQUM1QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLDBCQUEwQjtNQUNqQ0ksSUFBSSxFQUFFLEtBQUs7TUFDWEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1h5QixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJrRSxPQUFPLEVBQUUsSUFBSTtRQUNibEYsTUFBTSxFQUFFO1VBQUVILElBQUksRUFBRSxLQUFLO1VBQUVzRixNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFbEYsUUFBUSxFQUFFO1FBQUksQ0FBQztRQUN0RWlCLFVBQVUsRUFBRTtVQUNWc0QsTUFBTSxFQUFFO1lBQUVwRCxRQUFRLEVBQUUsQ0FBQztZQUFFQyxNQUFNLEVBQUU7Y0FBRTNCLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFBRUwsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUFFdUMsT0FBTyxFQUFFO1VBQVEsQ0FBQztVQUMvRXdELE9BQU8sRUFBRSxDQUNQO1lBQ0VoRSxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FDTjNCLEVBQUUsRUFBRSxPQUFPO2NBQ1hMLE1BQU0sRUFBRTtnQkFDTkssRUFBRSxFQUFFLFFBQVE7Z0JBQ1pxQyxnQkFBZ0IsRUFBRSxPQUFPO2dCQUN6QkMsa0JBQWtCLEVBQUU7Y0FDdEI7WUFDRixDQUFDO1lBQ0QzQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1Z1QyxPQUFPLEVBQUU7VUFDWCxDQUFDO1FBRUw7TUFDRixDQUFDO01BQ0RLLElBQUksRUFBRSxDQUNKO1FBQUV2QyxFQUFFLEVBQUUsR0FBRztRQUFFd0MsT0FBTyxFQUFFLElBQUk7UUFBRTlDLElBQUksRUFBRSxPQUFPO1FBQUUrQyxNQUFNLEVBQUUsUUFBUTtRQUFFOUMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VLLEVBQUUsRUFBRSxHQUFHO1FBQ1B3QyxPQUFPLEVBQUUsSUFBSTtRQUNiOUMsSUFBSSxFQUFFLE9BQU87UUFDYitDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCOUMsTUFBTSxFQUFFO1VBQ04rQyxLQUFLLEVBQUUsa0JBQWtCO1VBQ3pCUSxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsRUFBRTtVQUNSQyxXQUFXLEVBQUUsS0FBSztVQUNsQmhCLGdCQUFnQixFQUFFLE9BQU87VUFDekJpQixhQUFhLEVBQUUsS0FBSztVQUNwQmhCLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JpQixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUM7SUFFTCxDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFLElBQUk7SUFDakJDLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFBRXBFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQy9Cb0UsS0FBSyxFQUFFLGNBQWM7UUFDckJ2RCxNQUFNLEVBQUUsRUFBRTtRQUNWd0QsS0FBSyxFQUFFO1VBQUVBLEtBQUssRUFBRSxFQUFFO1VBQUVDLFFBQVEsRUFBRTtRQUFTO01BQ3pDLENBQUM7SUFDSDtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0U1RSxHQUFHLEVBQUUsZ0NBQWdDO0VBQ3JDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLG9CQUFvQjtJQUMzQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLG9CQUFvQjtNQUMzQkksSUFBSSxFQUFFLEtBQUs7TUFDWEMsTUFBTSxFQUFFO1FBQ05ELElBQUksRUFBRSxLQUFLO1FBQ1h5QixVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJrRSxPQUFPLEVBQUUsSUFBSTtRQUNibEYsTUFBTSxFQUFFO1VBQUVILElBQUksRUFBRSxLQUFLO1VBQUVzRixNQUFNLEVBQUUsSUFBSTtVQUFFQyxVQUFVLEVBQUUsSUFBSTtVQUFFbEYsUUFBUSxFQUFFO1FBQUksQ0FBQztRQUN0RWlCLFVBQVUsRUFBRTtVQUNWc0QsTUFBTSxFQUFFO1lBQUVwRCxRQUFRLEVBQUUsQ0FBQztZQUFFQyxNQUFNLEVBQUU7Y0FBRTNCLEVBQUUsRUFBRTtZQUFTLENBQUM7WUFBRUwsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUFFdUMsT0FBTyxFQUFFO1VBQVEsQ0FBQztVQUMvRXdELE9BQU8sRUFBRSxDQUNQO1lBQ0VoRSxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FDTjNCLEVBQUUsRUFBRSxPQUFPO2NBQ1hMLE1BQU0sRUFBRTtnQkFDTkssRUFBRSxFQUFFLFFBQVE7Z0JBQ1pxQyxnQkFBZ0IsRUFBRSxPQUFPO2dCQUN6QkMsa0JBQWtCLEVBQUU7Y0FDdEI7WUFDRixDQUFDO1lBQ0QzQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1Z1QyxPQUFPLEVBQUU7VUFDWCxDQUFDO1FBRUw7TUFDRixDQUFDO01BQ0RLLElBQUksRUFBRSxDQUNKO1FBQUV2QyxFQUFFLEVBQUUsR0FBRztRQUFFd0MsT0FBTyxFQUFFLElBQUk7UUFBRTlDLElBQUksRUFBRSxPQUFPO1FBQUUrQyxNQUFNLEVBQUUsUUFBUTtRQUFFOUMsTUFBTSxFQUFFLENBQUM7TUFBRSxDQUFDLEVBQ3ZFO1FBQ0VLLEVBQUUsRUFBRSxHQUFHO1FBQ1B3QyxPQUFPLEVBQUUsSUFBSTtRQUNiOUMsSUFBSSxFQUFFLE9BQU87UUFDYitDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCOUMsTUFBTSxFQUFFO1VBQ04rQyxLQUFLLEVBQUUsWUFBWTtVQUNuQlEsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEVBQUU7VUFDUkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJoQixnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCaUIsYUFBYSxFQUFFLEtBQUs7VUFDcEJoQixrQkFBa0IsRUFBRSxTQUFTO1VBQzdCaUIsV0FBVyxFQUFFO1FBQ2Y7TUFDRixDQUFDO0lBRUwsQ0FBQyxDQUFDO0lBQ0ZDLFdBQVcsRUFBRSxJQUFJO0lBQ2pCQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQUVwRSxJQUFJLENBQUNDLFNBQVMsQ0FBQztRQUMvQm9FLEtBQUssRUFBRSxjQUFjO1FBQ3JCdkQsTUFBTSxFQUFFLEVBQUU7UUFDVndELEtBQUssRUFBRTtVQUFFQSxLQUFLLEVBQUUsRUFBRTtVQUFFQyxRQUFRLEVBQUU7UUFBUztNQUN6QyxDQUFDO0lBQ0g7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFNUUsR0FBRyxFQUFFLHdDQUF3QztFQUM3QzRFLEtBQUssRUFBRSxlQUFlO0VBQ3RCM0UsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxxQkFBcUI7TUFDNUJJLElBQUksRUFBRSxPQUFPO01BQ2JDLE1BQU0sRUFBRTtRQUNOZ0csT0FBTyxFQUFFLEVBQUU7UUFDWEMsZUFBZSxFQUFFLEtBQUs7UUFDdEJDLHNCQUFzQixFQUFFLEtBQUs7UUFDN0JDLElBQUksRUFBRTtVQUFFQyxXQUFXLEVBQUUsQ0FBQztVQUFFQyxTQUFTLEVBQUU7UUFBTyxDQUFDO1FBQzNDQyxTQUFTLEVBQUUsS0FBSztRQUNoQkMsV0FBVyxFQUFFLElBQUk7UUFDakJDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCM0UsVUFBVSxFQUFFO1VBQ1Y4RCxPQUFPLEVBQUUsQ0FBQztZQUFFNUQsUUFBUSxFQUFFLENBQUM7WUFBRUMsTUFBTSxFQUFFO2NBQUUzQixFQUFFLEVBQUU7WUFBUyxDQUFDO1lBQUVMLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFBRXVDLE9BQU8sRUFBRTtVQUFRLENBQUMsQ0FBQztVQUNsRndELE9BQU8sRUFBRSxDQUNQO1lBQ0VoRSxRQUFRLEVBQUUsQ0FBQztZQUNYQyxNQUFNLEVBQUU7Y0FDTjNCLEVBQUUsRUFBRSxPQUFPO2NBQ1hMLE1BQU0sRUFBRTtnQkFDTkssRUFBRSxFQUFFLFFBQVE7Z0JBQ1pxQyxnQkFBZ0IsRUFBRSxPQUFPO2dCQUN6QkMsa0JBQWtCLEVBQUU7Y0FDdEI7WUFDRixDQUFDO1lBQ0QzQyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1lBQ1Z1QyxPQUFPLEVBQUU7VUFDWCxDQUFDLEVBQ0Q7WUFDRVIsUUFBUSxFQUFFLENBQUM7WUFDWEMsTUFBTSxFQUFFO2NBQ04zQixFQUFFLEVBQUUsT0FBTztjQUNYTCxNQUFNLEVBQUU7Z0JBQ05LLEVBQUUsRUFBRSxRQUFRO2dCQUNacUMsZ0JBQWdCLEVBQUUsT0FBTztnQkFDekJDLGtCQUFrQixFQUFFO2NBQ3RCO1lBQ0YsQ0FBQztZQUNEM0MsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNWdUMsT0FBTyxFQUFFO1VBQ1gsQ0FBQyxFQUNEO1lBQ0VSLFFBQVEsRUFBRSxDQUFDO1lBQ1hDLE1BQU0sRUFBRTtjQUNOM0IsRUFBRSxFQUFFLE9BQU87Y0FDWEwsTUFBTSxFQUFFO2dCQUNOSyxFQUFFLEVBQUUsUUFBUTtnQkFDWnFDLGdCQUFnQixFQUFFLE9BQU87Z0JBQ3pCQyxrQkFBa0IsRUFBRTtjQUN0QjtZQUNGLENBQUM7WUFDRDNDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDVnVDLE9BQU8sRUFBRTtVQUNYLENBQUM7UUFFTDtNQUNGLENBQUM7TUFDREssSUFBSSxFQUFFLENBQ0o7UUFBRXZDLEVBQUUsRUFBRSxHQUFHO1FBQUV3QyxPQUFPLEVBQUUsSUFBSTtRQUFFOUMsSUFBSSxFQUFFLE9BQU87UUFBRStDLE1BQU0sRUFBRSxRQUFRO1FBQUU5QyxNQUFNLEVBQUUsQ0FBQztNQUFFLENBQUMsRUFDdkU7UUFDRUssRUFBRSxFQUFFLEdBQUc7UUFDUHdDLE9BQU8sRUFBRSxJQUFJO1FBQ2I5QyxJQUFJLEVBQUUsT0FBTztRQUNiK0MsTUFBTSxFQUFFLFFBQVE7UUFDaEI5QyxNQUFNLEVBQUU7VUFDTitDLEtBQUssRUFBRSxZQUFZO1VBQ25CUSxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsRUFBRTtVQUNSQyxXQUFXLEVBQUUsS0FBSztVQUNsQmhCLGdCQUFnQixFQUFFLE9BQU87VUFDekJpQixhQUFhLEVBQUUsS0FBSztVQUNwQmhCLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JpQixXQUFXLEVBQUU7UUFDZjtNQUNGLENBQUMsRUFDRDtRQUNFdkQsRUFBRSxFQUFFLEdBQUc7UUFDUHdDLE9BQU8sRUFBRSxJQUFJO1FBQ2I5QyxJQUFJLEVBQUUsT0FBTztRQUNiK0MsTUFBTSxFQUFFLFFBQVE7UUFDaEI5QyxNQUFNLEVBQUU7VUFDTitDLEtBQUssRUFBRSxrQkFBa0I7VUFDekJRLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxFQUFFO1VBQ1JDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCaEIsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QmlCLGFBQWEsRUFBRSxLQUFLO1VBQ3BCaEIsa0JBQWtCLEVBQUUsU0FBUztVQUM3QmlCLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQyxFQUNEO1FBQ0V2RCxFQUFFLEVBQUUsR0FBRztRQUNQd0MsT0FBTyxFQUFFLElBQUk7UUFDYjlDLElBQUksRUFBRSxPQUFPO1FBQ2IrQyxNQUFNLEVBQUUsUUFBUTtRQUNoQjlDLE1BQU0sRUFBRTtVQUNOK0MsS0FBSyxFQUFFLFlBQVk7VUFDbkJRLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxDQUFDO1VBQ1BDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCaEIsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QmlCLGFBQWEsRUFBRSxLQUFLO1VBQ3BCaEIsa0JBQWtCLEVBQUUsU0FBUztVQUM3QmlCLFdBQVcsRUFBRTtRQUNmO01BQ0YsQ0FBQztJQUVMLENBQUMsQ0FBQztJQUNGQyxXQUFXLEVBQUVoRSxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUMxQmtGLEdBQUcsRUFBRTtRQUFFaEYsTUFBTSxFQUFFO1VBQUVtRyxJQUFJLEVBQUU7WUFBRUMsV0FBVyxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQU87UUFBRTtNQUFFO0lBQ2pFLENBQUMsQ0FBQztJQUNGdkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUFFcEUsSUFBSSxDQUFDQyxTQUFTLENBQUM7UUFDL0JvRSxLQUFLLEVBQUUsY0FBYztRQUNyQnZELE1BQU0sRUFBRSxFQUFFO1FBQ1Z3RCxLQUFLLEVBQUU7VUFBRUEsS0FBSyxFQUFFLEVBQUU7VUFBRUMsUUFBUSxFQUFFO1FBQVM7TUFDekMsQ0FBQztJQUNIO0VBQ0Y7QUFDRixDQUFDLENBQ0Y7QUFBQXFDLE9BQUEsQ0FBQUMsT0FBQSxHQUFBbEgsUUFBQTtBQUFBbUgsTUFBQSxDQUFBRixPQUFBLEdBQUFBLE9BQUEsQ0FBQUMsT0FBQSJ9