"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
/*
 * Wazuh app - Module for Overview/GitHub visualizations
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var _default = [{
  _id: 'Wazuh-App-Overview-GitHub-Alerts-Evolution-By-Organization',
  _source: {
    title: 'Alerts evolution by organization',
    visState: JSON.stringify({
      title: 'Alerts evolution by organization',
      type: 'area',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-7d',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          scaleMetricValues: false,
          interval: 'auto',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {},
          customLabel: ''
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'area',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100,
            rotate: 0
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'line',
          mode: 'normal',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          showCircles: true,
          interpolate: 'linear',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        },
        labels: {},
        orderBucketsBySum: false
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-5-Organizations-By-Alerts',
  _source: {
    title: 'Top 5 organizations by alerts',
    visState: JSON.stringify({
      title: 'Top 5 organizations by alerts',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: false,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Users-With-More-Alerts',
  _source: {
    title: 'Users with more alerts',
    visState: JSON.stringify({
      title: 'Users with more alerts',
      type: 'line',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.actor',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'line',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'histogram',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          valueAxis: 'ValueAxis-1',
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          interpolate: 'linear',
          showCircles: true
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        labels: {},
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Alert-Action-Type-By-Organization',
  _source: {
    title: 'Top alerts by alert action type and organization',
    visState: JSON.stringify({
      title: 'Top alerts by alert action type and organization',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.action',
          orderBy: '1',
          order: 'desc',
          size: 3,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: '',
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Alert-Summary',
  _source: {
    title: 'Alerts summary',
    visState: JSON.stringify({
      title: 'Alerts summary',
      type: 'table',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'agent.name',
          orderBy: '1',
          order: 'desc',
          size: 50,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'bucket'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'bucket'
      }, {
        id: '4',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.description',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'bucket'
      }],
      params: {
        perPage: 10,
        showPartialRows: false,
        showMetricsAtAllLevels: false,
        sort: {
          columnIndex: null,
          direction: null
        },
        showTotal: false,
        totalFunc: 'sum',
        percentageCol: ''
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Organizations',
  _source: {
    title: 'Top 10 organizations',
    visState: JSON.stringify({
      title: 'Top 10 Organizations',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Organizations'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Countries',
  _source: {
    title: 'Countries',
    visState: JSON.stringify({
      title: 'Top github actors countries',
      type: 'tagcloud',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.actor_location.country_code',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Top countries '
        },
        schema: 'segment'
      }],
      params: {
        scale: 'linear',
        orientation: 'single',
        minFontSize: 18,
        maxFontSize: 72,
        showLabel: true
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Events',
  _source: {
    title: 'GitHub top events',
    visState: JSON.stringify({
      title: 'Github Top Events',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.action',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Github Actions'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: false,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Stats',
  _source: {
    title: 'GitHub Stats',
    visState: JSON.stringify({
      title: 'Github Stats',
      type: 'metric',
      aggs: [{
        id: '2',
        enabled: true,
        type: 'count',
        params: {
          customLabel: 'Total Alerts'
        },
        schema: 'metric'
      }, {
        id: '1',
        enabled: true,
        type: 'top_hits',
        params: {
          field: 'rule.level',
          aggregate: 'concat',
          size: 1,
          sortField: 'rule.level',
          sortOrder: 'desc',
          customLabel: 'Max rule level detected'
        },
        schema: 'metric'
      }],
      params: {
        addTooltip: true,
        addLegend: false,
        type: 'metric',
        metric: {
          percentageMode: false,
          useRanges: false,
          colorSchema: 'Green to Red',
          metricColorMode: 'None',
          colorsRange: [{
            from: 0,
            to: 10000
          }],
          labels: {
            show: true
          },
          invertColors: false,
          style: {
            bgFill: '#000',
            bgColor: false,
            labelColor: false,
            subText: '',
            fontSize: 60
          }
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Organization-Heatmap',
  _source: {
    title: 'GitHub Organization Heatmap',
    visState: JSON.stringify({
      title: 'GitHub Organization Heatmap',
      type: 'heatmap',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.action',
          orderBy: '1',
          order: 'desc',
          size: 5,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'heatmap',
        addTooltip: true,
        addLegend: true,
        enableHover: false,
        legendPosition: 'right',
        times: [],
        colorsNumber: 4,
        colorSchema: 'Blues',
        setColorRange: false,
        colorsRange: [],
        invertColors: false,
        percentageMode: false,
        valueAxes: [{
          show: false,
          id: 'ValueAxis-1',
          type: 'value',
          scale: {
            type: 'linear',
            defaultYExtents: false
          },
          labels: {
            show: false,
            rotate: 0,
            overwriteColor: false,
            color: 'black'
          }
        }]
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Organizations',
  _source: {
    title: 'GitHub top 10 organizations',
    visState: JSON.stringify({
      title: 'Top 10 Organizations',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.org',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Organizations'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Actors',
  _source: {
    title: 'Top 10 actors',
    visState: JSON.stringify({
      title: 'Top 10 Actors',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.actor',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Actors'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Repositories',
  _source: {
    title: 'Top 10 repositories',
    visState: JSON.stringify({
      title: 'Top 10 Repositories',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.repo',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Repositories'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Top-Ten-Actions',
  _source: {
    title: 'Top 10 actions',
    visState: JSON.stringify({
      title: 'Top 10 Actions',
      type: 'pie',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'terms',
        params: {
          field: 'data.github.action',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing',
          customLabel: 'Actions'
        },
        schema: 'segment'
      }],
      params: {
        type: 'pie',
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        isDonut: true,
        labels: {
          show: false,
          values: true,
          last_level: true,
          truncate: 100
        }
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}, {
  _id: 'Wazuh-App-Overview-GitHub-Alert-Level-Evolution',
  _source: {
    title: 'Alert level evolution',
    visState: JSON.stringify({
      title: 'Rule Level Over Time',
      type: 'area',
      aggs: [{
        id: '1',
        enabled: true,
        type: 'count',
        params: {},
        schema: 'metric'
      }, {
        id: '2',
        enabled: true,
        type: 'date_histogram',
        params: {
          field: 'timestamp',
          timeRange: {
            from: 'now-30d',
            to: 'now'
          },
          useNormalizedEsInterval: true,
          scaleMetricValues: false,
          interval: 'd',
          drop_partials: false,
          min_doc_count: 1,
          extended_bounds: {}
        },
        schema: 'segment'
      }, {
        id: '3',
        enabled: true,
        type: 'terms',
        params: {
          field: 'rule.level',
          orderBy: '1',
          order: 'desc',
          size: 10,
          otherBucket: false,
          otherBucketLabel: 'Other',
          missingBucket: false,
          missingBucketLabel: 'Missing'
        },
        schema: 'group'
      }],
      params: {
        type: 'area',
        grid: {
          categoryLines: false
        },
        categoryAxes: [{
          id: 'CategoryAxis-1',
          type: 'category',
          position: 'bottom',
          show: true,
          style: {},
          scale: {
            type: 'linear'
          },
          labels: {
            show: true,
            filter: true,
            truncate: 100
          },
          title: {}
        }],
        valueAxes: [{
          id: 'ValueAxis-1',
          name: 'LeftAxis-1',
          type: 'value',
          position: 'left',
          show: true,
          style: {},
          scale: {
            type: 'linear',
            mode: 'normal'
          },
          labels: {
            show: true,
            rotate: 0,
            filter: false,
            truncate: 100
          },
          title: {
            text: 'Count'
          }
        }],
        seriesParams: [{
          show: true,
          type: 'area',
          mode: 'stacked',
          data: {
            label: 'Count',
            id: '1'
          },
          drawLinesBetweenPoints: true,
          lineWidth: 2,
          showCircles: true,
          interpolate: 'step-after',
          valueAxis: 'ValueAxis-1'
        }],
        addTooltip: true,
        addLegend: true,
        legendPosition: 'right',
        times: [],
        addTimeMarker: false,
        thresholdLine: {
          show: false,
          value: 10,
          width: 1,
          style: 'full',
          color: '#E7664C'
        },
        labels: {}
      }
    }),
    uiStateJSON: JSON.stringify({
      vis: {
        params: {
          sort: {
            columnIndex: 3,
            direction: 'desc'
          }
        }
      }
    }),
    description: '',
    version: 1,
    kibanaSavedObjectMeta: {
      searchSourceJSON: '{"index":"wazuh-alerts","filter":[],"query":{"query":"","language":"lucene"}}'
    }
  },
  _type: 'visualization'
}];
exports.default = _default;
module.exports = exports.default;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZGVmYXVsdCIsIl9pZCIsIl9zb3VyY2UiLCJ0aXRsZSIsInZpc1N0YXRlIiwiSlNPTiIsInN0cmluZ2lmeSIsInR5cGUiLCJhZ2dzIiwiaWQiLCJlbmFibGVkIiwicGFyYW1zIiwic2NoZW1hIiwiZmllbGQiLCJ0aW1lUmFuZ2UiLCJmcm9tIiwidG8iLCJ1c2VOb3JtYWxpemVkRXNJbnRlcnZhbCIsInNjYWxlTWV0cmljVmFsdWVzIiwiaW50ZXJ2YWwiLCJkcm9wX3BhcnRpYWxzIiwibWluX2RvY19jb3VudCIsImV4dGVuZGVkX2JvdW5kcyIsImN1c3RvbUxhYmVsIiwib3JkZXJCeSIsIm9yZGVyIiwic2l6ZSIsIm90aGVyQnVja2V0Iiwib3RoZXJCdWNrZXRMYWJlbCIsIm1pc3NpbmdCdWNrZXQiLCJtaXNzaW5nQnVja2V0TGFiZWwiLCJncmlkIiwiY2F0ZWdvcnlMaW5lcyIsImNhdGVnb3J5QXhlcyIsInBvc2l0aW9uIiwic2hvdyIsInN0eWxlIiwic2NhbGUiLCJsYWJlbHMiLCJmaWx0ZXIiLCJ0cnVuY2F0ZSIsInJvdGF0ZSIsInZhbHVlQXhlcyIsIm5hbWUiLCJtb2RlIiwidGV4dCIsInNlcmllc1BhcmFtcyIsImRhdGEiLCJsYWJlbCIsImRyYXdMaW5lc0JldHdlZW5Qb2ludHMiLCJsaW5lV2lkdGgiLCJzaG93Q2lyY2xlcyIsImludGVycG9sYXRlIiwidmFsdWVBeGlzIiwiYWRkVG9vbHRpcCIsImFkZExlZ2VuZCIsImxlZ2VuZFBvc2l0aW9uIiwidGltZXMiLCJhZGRUaW1lTWFya2VyIiwidGhyZXNob2xkTGluZSIsInZhbHVlIiwid2lkdGgiLCJjb2xvciIsIm9yZGVyQnVja2V0c0J5U3VtIiwidWlTdGF0ZUpTT04iLCJkZXNjcmlwdGlvbiIsInZlcnNpb24iLCJraWJhbmFTYXZlZE9iamVjdE1ldGEiLCJzZWFyY2hTb3VyY2VKU09OIiwiX3R5cGUiLCJpc0RvbnV0IiwidmFsdWVzIiwibGFzdF9sZXZlbCIsInBlclBhZ2UiLCJzaG93UGFydGlhbFJvd3MiLCJzaG93TWV0cmljc0F0QWxsTGV2ZWxzIiwic29ydCIsImNvbHVtbkluZGV4IiwiZGlyZWN0aW9uIiwic2hvd1RvdGFsIiwidG90YWxGdW5jIiwicGVyY2VudGFnZUNvbCIsInZpcyIsIm9yaWVudGF0aW9uIiwibWluRm9udFNpemUiLCJtYXhGb250U2l6ZSIsInNob3dMYWJlbCIsImFnZ3JlZ2F0ZSIsInNvcnRGaWVsZCIsInNvcnRPcmRlciIsIm1ldHJpYyIsInBlcmNlbnRhZ2VNb2RlIiwidXNlUmFuZ2VzIiwiY29sb3JTY2hlbWEiLCJtZXRyaWNDb2xvck1vZGUiLCJjb2xvcnNSYW5nZSIsImludmVydENvbG9ycyIsImJnRmlsbCIsImJnQ29sb3IiLCJsYWJlbENvbG9yIiwic3ViVGV4dCIsImZvbnRTaXplIiwiZW5hYmxlSG92ZXIiLCJjb2xvcnNOdW1iZXIiLCJzZXRDb2xvclJhbmdlIiwiZGVmYXVsdFlFeHRlbnRzIiwib3ZlcndyaXRlQ29sb3IiLCJleHBvcnRzIiwiZGVmYXVsdCIsIm1vZHVsZSJdLCJzb3VyY2VzIjpbIm92ZXJ2aWV3LWdpdGh1Yi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gTW9kdWxlIGZvciBPdmVydmlldy9HaXRIdWIgdmlzdWFsaXphdGlvbnNcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXG4gKlxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxuICovXG5leHBvcnQgZGVmYXVsdCBbXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR2l0SHViLUFsZXJ0cy1Fdm9sdXRpb24tQnktT3JnYW5pemF0aW9uJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0FsZXJ0cyBldm9sdXRpb24gYnkgb3JnYW5pemF0aW9uJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnQWxlcnRzIGV2b2x1dGlvbiBieSBvcmdhbml6YXRpb24nLFxuICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXG4gICAgICAgICAgICAgIHRpbWVSYW5nZToge1xuICAgICAgICAgICAgICAgIGZyb206ICdub3ctN2QnLFxuICAgICAgICAgICAgICAgIHRvOiAnbm93JyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgdXNlTm9ybWFsaXplZEVzSW50ZXJ2YWw6IHRydWUsXG4gICAgICAgICAgICAgIHNjYWxlTWV0cmljVmFsdWVzOiBmYWxzZSxcbiAgICAgICAgICAgICAgaW50ZXJ2YWw6ICdhdXRvJyxcbiAgICAgICAgICAgICAgZHJvcF9wYXJ0aWFsczogZmFsc2UsXG4gICAgICAgICAgICAgIG1pbl9kb2NfY291bnQ6IDEsXG4gICAgICAgICAgICAgIGV4dGVuZGVkX2JvdW5kczoge30sXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMycsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLm9yZycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnZ3JvdXAnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdhcmVhJyxcbiAgICAgICAgICBncmlkOiB7XG4gICAgICAgICAgICBjYXRlZ29yeUxpbmVzOiBmYWxzZSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNhdGVnb3J5QXhlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpZDogJ0NhdGVnb3J5QXhpcy0xJyxcbiAgICAgICAgICAgICAgdHlwZTogJ2NhdGVnb3J5JyxcbiAgICAgICAgICAgICAgcG9zaXRpb246ICdib3R0b20nLFxuICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICBzdHlsZToge30sXG4gICAgICAgICAgICAgIHNjYWxlOiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgICAgZmlsdGVyOiB0cnVlLFxuICAgICAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgICAgICAgcm90YXRlOiAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnbGVmdCcsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnbGluZWFyJyxcbiAgICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgICByb3RhdGU6IDAsXG4gICAgICAgICAgICAgICAgZmlsdGVyOiBmYWxzZSxcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB0aXRsZToge1xuICAgICAgICAgICAgICAgIHRleHQ6ICdDb3VudCcsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHR5cGU6ICdsaW5lJyxcbiAgICAgICAgICAgICAgbW9kZTogJ25vcm1hbCcsXG4gICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBsYWJlbDogJ0NvdW50JyxcbiAgICAgICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBkcmF3TGluZXNCZXR3ZWVuUG9pbnRzOiB0cnVlLFxuICAgICAgICAgICAgICBsaW5lV2lkdGg6IDIsXG4gICAgICAgICAgICAgIHNob3dDaXJjbGVzOiB0cnVlLFxuICAgICAgICAgICAgICBpbnRlcnBvbGF0ZTogJ2xpbmVhcicsXG4gICAgICAgICAgICAgIHZhbHVlQXhpczogJ1ZhbHVlQXhpcy0xJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgICAgdGhyZXNob2xkTGluZToge1xuICAgICAgICAgICAgc2hvdzogZmFsc2UsXG4gICAgICAgICAgICB2YWx1ZTogMTAsXG4gICAgICAgICAgICB3aWR0aDogMSxcbiAgICAgICAgICAgIHN0eWxlOiAnZnVsbCcsXG4gICAgICAgICAgICBjb2xvcjogJyNFNzY2NEMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgbGFiZWxzOiB7fSxcbiAgICAgICAgICBvcmRlckJ1Y2tldHNCeVN1bTogZmFsc2UsXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAnJyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjpcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Ub3AtNS1Pcmdhbml6YXRpb25zLUJ5LUFsZXJ0cycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdUb3AgNSBvcmdhbml6YXRpb25zIGJ5IGFsZXJ0cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1RvcCA1IG9yZ2FuaXphdGlvbnMgYnkgYWxlcnRzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLm9yZycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogNSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogZmFsc2UsXG4gICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlczogdHJ1ZSxcbiAgICAgICAgICAgIGxhc3RfbGV2ZWw6IHRydWUsXG4gICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiAnJyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjpcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Vc2Vycy1XaXRoLU1vcmUtQWxlcnRzJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1VzZXJzIHdpdGggbW9yZSBhbGVydHMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdVc2VycyB3aXRoIG1vcmUgYWxlcnRzJyxcbiAgICAgICAgdHlwZTogJ2xpbmUnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzQnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdpdGh1Yi5vcmcnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIuYWN0b3InLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnbGluZScsXG4gICAgICAgICAgZ3JpZDoge1xuICAgICAgICAgICAgY2F0ZWdvcnlMaW5lczogZmFsc2UsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBjYXRlZ29yeUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdDYXRlZ29yeUF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICdjYXRlZ29yeScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZToge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICAgIGZpbHRlcjogdHJ1ZSxcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnbGVmdCcsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnbGluZWFyJyxcbiAgICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgICByb3RhdGU6IDAsXG4gICAgICAgICAgICAgICAgZmlsdGVyOiBmYWxzZSxcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB0aXRsZToge1xuICAgICAgICAgICAgICAgIHRleHQ6ICdDb3VudCcsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHR5cGU6ICdoaXN0b2dyYW0nLFxuICAgICAgICAgICAgICBtb2RlOiAnc3RhY2tlZCcsXG4gICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBsYWJlbDogJ0NvdW50JyxcbiAgICAgICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB2YWx1ZUF4aXM6ICdWYWx1ZUF4aXMtMScsXG4gICAgICAgICAgICAgIGRyYXdMaW5lc0JldHdlZW5Qb2ludHM6IHRydWUsXG4gICAgICAgICAgICAgIGxpbmVXaWR0aDogMixcbiAgICAgICAgICAgICAgaW50ZXJwb2xhdGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgYWRkVGltZU1hcmtlcjogZmFsc2UsXG4gICAgICAgICAgbGFiZWxzOiB7fSxcbiAgICAgICAgICB0aHJlc2hvbGRMaW5lOiB7XG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlOiAxMCxcbiAgICAgICAgICAgIHdpZHRoOiAxLFxuICAgICAgICAgICAgc3R5bGU6ICdmdWxsJyxcbiAgICAgICAgICAgIGNvbG9yOiAnI0U3NjY0QycsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICcnLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR2l0SHViLUFsZXJ0LUFjdGlvbi1UeXBlLUJ5LU9yZ2FuaXphdGlvbicsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdUb3AgYWxlcnRzIGJ5IGFsZXJ0IGFjdGlvbiB0eXBlIGFuZCBvcmdhbml6YXRpb24nLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdUb3AgYWxlcnRzIGJ5IGFsZXJ0IGFjdGlvbiB0eXBlIGFuZCBvcmdhbml6YXRpb24nLFxuICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIub3JnJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLmFjdGlvbicsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMyxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogdHJ1ZSxcbiAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxuICAgICAgICAgICAgbGFzdF9sZXZlbDogdHJ1ZSxcbiAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046ICcnLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR2l0SHViLUFsZXJ0LVN1bW1hcnknLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWxlcnRzIHN1bW1hcnknLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdBbGVydHMgc3VtbWFyeScsXG4gICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2FnZW50Lm5hbWUnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDUwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIub3JnJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnYnVja2V0JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnNCcsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3J1bGUuZGVzY3JpcHRpb24nLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdidWNrZXQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHBlclBhZ2U6IDEwLFxuICAgICAgICAgIHNob3dQYXJ0aWFsUm93czogZmFsc2UsXG4gICAgICAgICAgc2hvd01ldHJpY3NBdEFsbExldmVsczogZmFsc2UsXG4gICAgICAgICAgc29ydDoge1xuICAgICAgICAgICAgY29sdW1uSW5kZXg6IG51bGwsXG4gICAgICAgICAgICBkaXJlY3Rpb246IG51bGwsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBzaG93VG90YWw6IGZhbHNlLFxuICAgICAgICAgIHRvdGFsRnVuYzogJ3N1bScsXG4gICAgICAgICAgcGVyY2VudGFnZUNvbDogJycsXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjpcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Ub3AtVGVuLU9yZ2FuaXphdGlvbnMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIDEwIG9yZ2FuaXphdGlvbnMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdUb3AgMTAgT3JnYW5pemF0aW9ucycsXG4gICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7fSxcbiAgICAgICAgICAgIHNjaGVtYTogJ21ldHJpYycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzInLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICd0ZXJtcycsXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgZmllbGQ6ICdkYXRhLmdpdGh1Yi5vcmcnLFxuICAgICAgICAgICAgICBvcmRlckJ5OiAnMScsXG4gICAgICAgICAgICAgIG9yZGVyOiAnZGVzYycsXG4gICAgICAgICAgICAgIHNpemU6IDEwLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdPcmdhbml6YXRpb25zJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgc2hvdzogZmFsc2UsXG4gICAgICAgICAgICB2YWx1ZXM6IHRydWUsXG4gICAgICAgICAgICBsYXN0X2xldmVsOiB0cnVlLFxuICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxuICAgICAgfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046XG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItQ291bnRyaWVzJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0NvdW50cmllcycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1RvcCBnaXRodWIgYWN0b3JzIGNvdW50cmllcycsXG4gICAgICAgIHR5cGU6ICd0YWdjbG91ZCcsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLmFjdG9yX2xvY2F0aW9uLmNvdW50cnlfY29kZScsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1RvcCBjb3VudHJpZXMgJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBzY2FsZTogJ2xpbmVhcicsXG4gICAgICAgICAgb3JpZW50YXRpb246ICdzaW5nbGUnLFxuICAgICAgICAgIG1pbkZvbnRTaXplOiAxOCxcbiAgICAgICAgICBtYXhGb250U2l6ZTogNzIsXG4gICAgICAgICAgc2hvd0xhYmVsOiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxuICAgICAgfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046XG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItVG9wLUV2ZW50cycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdHaXRIdWIgdG9wIGV2ZW50cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0dpdGh1YiBUb3AgRXZlbnRzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLmFjdGlvbicsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0dpdGh1YiBBY3Rpb25zJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiBmYWxzZSxcbiAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxuICAgICAgICAgICAgbGFzdF9sZXZlbDogdHJ1ZSxcbiAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdmlzOiB7IHBhcmFtczogeyBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9IH0gfSxcbiAgICAgIH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR2l0SHViLVN0YXRzJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ0dpdEh1YiBTdGF0cycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ0dpdGh1YiBTdGF0cycsXG4gICAgICAgIHR5cGU6ICdtZXRyaWMnLFxuICAgICAgICBhZ2dzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAnY291bnQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnVG90YWwgQWxlcnRzJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndG9wX2hpdHMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgIGFnZ3JlZ2F0ZTogJ2NvbmNhdCcsXG4gICAgICAgICAgICAgIHNpemU6IDEsXG4gICAgICAgICAgICAgIHNvcnRGaWVsZDogJ3J1bGUubGV2ZWwnLFxuICAgICAgICAgICAgICBzb3J0T3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgY3VzdG9tTGFiZWw6ICdNYXggcnVsZSBsZXZlbCBkZXRlY3RlZCcsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogZmFsc2UsXG4gICAgICAgICAgdHlwZTogJ21ldHJpYycsXG4gICAgICAgICAgbWV0cmljOiB7XG4gICAgICAgICAgICBwZXJjZW50YWdlTW9kZTogZmFsc2UsXG4gICAgICAgICAgICB1c2VSYW5nZXM6IGZhbHNlLFxuICAgICAgICAgICAgY29sb3JTY2hlbWE6ICdHcmVlbiB0byBSZWQnLFxuICAgICAgICAgICAgbWV0cmljQ29sb3JNb2RlOiAnTm9uZScsXG4gICAgICAgICAgICBjb2xvcnNSYW5nZTogW1xuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgZnJvbTogMCxcbiAgICAgICAgICAgICAgICB0bzogMTAwMDAsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgaW52ZXJ0Q29sb3JzOiBmYWxzZSxcbiAgICAgICAgICAgIHN0eWxlOiB7XG4gICAgICAgICAgICAgIGJnRmlsbDogJyMwMDAnLFxuICAgICAgICAgICAgICBiZ0NvbG9yOiBmYWxzZSxcbiAgICAgICAgICAgICAgbGFiZWxDb2xvcjogZmFsc2UsXG4gICAgICAgICAgICAgIHN1YlRleHQ6ICcnLFxuICAgICAgICAgICAgICBmb250U2l6ZTogNjAsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjpcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Pcmdhbml6YXRpb24tSGVhdG1hcCcsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdHaXRIdWIgT3JnYW5pemF0aW9uIEhlYXRtYXAnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdHaXRIdWIgT3JnYW5pemF0aW9uIEhlYXRtYXAnLFxuICAgICAgICB0eXBlOiAnaGVhdG1hcCcsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLm9yZycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIuYWN0aW9uJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiA1LFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0TGFiZWw6ICdPdGhlcicsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0TGFiZWw6ICdNaXNzaW5nJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdncm91cCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ2hlYXRtYXAnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGVuYWJsZUhvdmVyOiBmYWxzZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICB0aW1lczogW10sXG4gICAgICAgICAgY29sb3JzTnVtYmVyOiA0LFxuICAgICAgICAgIGNvbG9yU2NoZW1hOiAnQmx1ZXMnLFxuICAgICAgICAgIHNldENvbG9yUmFuZ2U6IGZhbHNlLFxuICAgICAgICAgIGNvbG9yc1JhbmdlOiBbXSxcbiAgICAgICAgICBpbnZlcnRDb2xvcnM6IGZhbHNlLFxuICAgICAgICAgIHBlcmNlbnRhZ2VNb2RlOiBmYWxzZSxcbiAgICAgICAgICB2YWx1ZUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2hvdzogZmFsc2UsXG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICB0eXBlOiAndmFsdWUnLFxuICAgICAgICAgICAgICBzY2FsZToge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICAgIGRlZmF1bHRZRXh0ZW50czogZmFsc2UsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHJvdGF0ZTogMCxcbiAgICAgICAgICAgICAgICBvdmVyd3JpdGVDb2xvcjogZmFsc2UsXG4gICAgICAgICAgICAgICAgY29sb3I6ICdibGFjaycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjpcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1Ub3AtVGVuLU9yZ2FuaXphdGlvbnMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnR2l0SHViIHRvcCAxMCBvcmdhbml6YXRpb25zJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnVG9wIDEwIE9yZ2FuaXphdGlvbnMnLFxuICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIub3JnJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnT3JnYW5pemF0aW9ucycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogdHJ1ZSxcbiAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxuICAgICAgICAgICAgbGFzdF9sZXZlbDogdHJ1ZSxcbiAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdmlzOiB7IHBhcmFtczogeyBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9IH0gfSxcbiAgICAgIH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR2l0SHViLVRvcC1UZW4tQWN0b3JzJyxcbiAgICBfc291cmNlOiB7XG4gICAgICB0aXRsZTogJ1RvcCAxMCBhY3RvcnMnLFxuICAgICAgdmlzU3RhdGU6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdGl0bGU6ICdUb3AgMTAgQWN0b3JzJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLmFjdG9yJyxcbiAgICAgICAgICAgICAgb3JkZXJCeTogJzEnLFxuICAgICAgICAgICAgICBvcmRlcjogJ2Rlc2MnLFxuICAgICAgICAgICAgICBzaXplOiAxMCxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXQ6IGZhbHNlLFxuICAgICAgICAgICAgICBvdGhlckJ1Y2tldExhYmVsOiAnT3RoZXInLFxuICAgICAgICAgICAgICBtaXNzaW5nQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldExhYmVsOiAnTWlzc2luZycsXG4gICAgICAgICAgICAgIGN1c3RvbUxhYmVsOiAnQWN0b3JzJyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzY2hlbWE6ICdzZWdtZW50JyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgICBhZGRUb29sdGlwOiB0cnVlLFxuICAgICAgICAgIGFkZExlZ2VuZDogdHJ1ZSxcbiAgICAgICAgICBsZWdlbmRQb3NpdGlvbjogJ3JpZ2h0JyxcbiAgICAgICAgICBpc0RvbnV0OiB0cnVlLFxuICAgICAgICAgIGxhYmVsczoge1xuICAgICAgICAgICAgc2hvdzogZmFsc2UsXG4gICAgICAgICAgICB2YWx1ZXM6IHRydWUsXG4gICAgICAgICAgICBsYXN0X2xldmVsOiB0cnVlLFxuICAgICAgICAgICAgdHJ1bmNhdGU6IDEwMCxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxuICAgICAgfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046XG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbiAge1xuICAgIF9pZDogJ1dhenVoLUFwcC1PdmVydmlldy1HaXRIdWItVG9wLVRlbi1SZXBvc2l0b3JpZXMnLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnVG9wIDEwIHJlcG9zaXRvcmllcycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1RvcCAxMCBSZXBvc2l0b3JpZXMnLFxuICAgICAgICB0eXBlOiAncGllJyxcbiAgICAgICAgYWdnczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMScsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2NvdW50JyxcbiAgICAgICAgICAgIHBhcmFtczoge30sXG4gICAgICAgICAgICBzY2hlbWE6ICdtZXRyaWMnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICcyJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAnZGF0YS5naXRodWIucmVwbycsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ1JlcG9zaXRvcmllcycsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2NoZW1hOiAnc2VnbWVudCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgXSxcbiAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgICAgYWRkVG9vbHRpcDogdHJ1ZSxcbiAgICAgICAgICBhZGRMZWdlbmQ6IHRydWUsXG4gICAgICAgICAgbGVnZW5kUG9zaXRpb246ICdyaWdodCcsXG4gICAgICAgICAgaXNEb251dDogdHJ1ZSxcbiAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgIHNob3c6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxuICAgICAgICAgICAgbGFzdF9sZXZlbDogdHJ1ZSxcbiAgICAgICAgICAgIHRydW5jYXRlOiAxMDAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pLFxuICAgICAgdWlTdGF0ZUpTT046IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgdmlzOiB7IHBhcmFtczogeyBzb3J0OiB7IGNvbHVtbkluZGV4OiAzLCBkaXJlY3Rpb246ICdkZXNjJyB9IH0gfSxcbiAgICAgIH0pLFxuICAgICAgZGVzY3JpcHRpb246ICcnLFxuICAgICAgdmVyc2lvbjogMSxcbiAgICAgIGtpYmFuYVNhdmVkT2JqZWN0TWV0YToge1xuICAgICAgICBzZWFyY2hTb3VyY2VKU09OOlxuICAgICAgICAgICd7XCJpbmRleFwiOlwid2F6dWgtYWxlcnRzXCIsXCJmaWx0ZXJcIjpbXSxcInF1ZXJ5XCI6e1wicXVlcnlcIjpcIlwiLFwibGFuZ3VhZ2VcIjpcImx1Y2VuZVwifX0nLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF90eXBlOiAndmlzdWFsaXphdGlvbicsXG4gIH0sXG4gIHtcbiAgICBfaWQ6ICdXYXp1aC1BcHAtT3ZlcnZpZXctR2l0SHViLVRvcC1UZW4tQWN0aW9ucycsXG4gICAgX3NvdXJjZToge1xuICAgICAgdGl0bGU6ICdUb3AgMTAgYWN0aW9ucycsXG4gICAgICB2aXNTdGF0ZTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0aXRsZTogJ1RvcCAxMCBBY3Rpb25zJyxcbiAgICAgICAgdHlwZTogJ3BpZScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ3Rlcm1zJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ2RhdGEuZ2l0aHViLmFjdGlvbicsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgICBjdXN0b21MYWJlbDogJ0FjdGlvbnMnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICAgIHBhcmFtczoge1xuICAgICAgICAgIHR5cGU6ICdwaWUnLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIGlzRG9udXQ6IHRydWUsXG4gICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlczogdHJ1ZSxcbiAgICAgICAgICAgIGxhc3RfbGV2ZWw6IHRydWUsXG4gICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIHVpU3RhdGVKU09OOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHZpczogeyBwYXJhbXM6IHsgc29ydDogeyBjb2x1bW5JbmRleDogMywgZGlyZWN0aW9uOiAnZGVzYycgfSB9IH0sXG4gICAgICB9KSxcbiAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgIHZlcnNpb246IDEsXG4gICAgICBraWJhbmFTYXZlZE9iamVjdE1ldGE6IHtcbiAgICAgICAgc2VhcmNoU291cmNlSlNPTjpcbiAgICAgICAgICAne1wiaW5kZXhcIjpcIndhenVoLWFsZXJ0c1wiLFwiZmlsdGVyXCI6W10sXCJxdWVyeVwiOntcInF1ZXJ5XCI6XCJcIixcImxhbmd1YWdlXCI6XCJsdWNlbmVcIn19JyxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBfdHlwZTogJ3Zpc3VhbGl6YXRpb24nLFxuICB9LFxuICB7XG4gICAgX2lkOiAnV2F6dWgtQXBwLU92ZXJ2aWV3LUdpdEh1Yi1BbGVydC1MZXZlbC1Fdm9sdXRpb24nLFxuICAgIF9zb3VyY2U6IHtcbiAgICAgIHRpdGxlOiAnQWxlcnQgbGV2ZWwgZXZvbHV0aW9uJyxcbiAgICAgIHZpc1N0YXRlOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgIHRpdGxlOiAnUnVsZSBMZXZlbCBPdmVyIFRpbWUnLFxuICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgIGFnZ3M6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICBpZDogJzEnLFxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHR5cGU6ICdjb3VudCcsXG4gICAgICAgICAgICBwYXJhbXM6IHt9LFxuICAgICAgICAgICAgc2NoZW1hOiAnbWV0cmljJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGlkOiAnMicsXG4gICAgICAgICAgICBlbmFibGVkOiB0cnVlLFxuICAgICAgICAgICAgdHlwZTogJ2RhdGVfaGlzdG9ncmFtJyxcbiAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJ3RpbWVzdGFtcCcsXG4gICAgICAgICAgICAgIHRpbWVSYW5nZToge1xuICAgICAgICAgICAgICAgIGZyb206ICdub3ctMzBkJyxcbiAgICAgICAgICAgICAgICB0bzogJ25vdycsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIHVzZU5vcm1hbGl6ZWRFc0ludGVydmFsOiB0cnVlLFxuICAgICAgICAgICAgICBzY2FsZU1ldHJpY1ZhbHVlczogZmFsc2UsXG4gICAgICAgICAgICAgIGludGVydmFsOiAnZCcsXG4gICAgICAgICAgICAgIGRyb3BfcGFydGlhbHM6IGZhbHNlLFxuICAgICAgICAgICAgICBtaW5fZG9jX2NvdW50OiAxLFxuICAgICAgICAgICAgICBleHRlbmRlZF9ib3VuZHM6IHt9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ3NlZ21lbnQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICczJyxcbiAgICAgICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgICAgICB0eXBlOiAndGVybXMnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgIGZpZWxkOiAncnVsZS5sZXZlbCcsXG4gICAgICAgICAgICAgIG9yZGVyQnk6ICcxJyxcbiAgICAgICAgICAgICAgb3JkZXI6ICdkZXNjJyxcbiAgICAgICAgICAgICAgc2l6ZTogMTAsXG4gICAgICAgICAgICAgIG90aGVyQnVja2V0OiBmYWxzZSxcbiAgICAgICAgICAgICAgb3RoZXJCdWNrZXRMYWJlbDogJ090aGVyJyxcbiAgICAgICAgICAgICAgbWlzc2luZ0J1Y2tldDogZmFsc2UsXG4gICAgICAgICAgICAgIG1pc3NpbmdCdWNrZXRMYWJlbDogJ01pc3NpbmcnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNjaGVtYTogJ2dyb3VwJyxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICB0eXBlOiAnYXJlYScsXG4gICAgICAgICAgZ3JpZDoge1xuICAgICAgICAgICAgY2F0ZWdvcnlMaW5lczogZmFsc2UsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBjYXRlZ29yeUF4ZXM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgaWQ6ICdDYXRlZ29yeUF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICdjYXRlZ29yeScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnYm90dG9tJyxcbiAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgc3R5bGU6IHt9LFxuICAgICAgICAgICAgICBzY2FsZToge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdsaW5lYXInLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBsYWJlbHM6IHtcbiAgICAgICAgICAgICAgICBzaG93OiB0cnVlLFxuICAgICAgICAgICAgICAgIGZpbHRlcjogdHJ1ZSxcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB0aXRsZToge30sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgdmFsdWVBeGVzOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIGlkOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgICBuYW1lOiAnTGVmdEF4aXMtMScsXG4gICAgICAgICAgICAgIHR5cGU6ICd2YWx1ZScsXG4gICAgICAgICAgICAgIHBvc2l0aW9uOiAnbGVmdCcsXG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHN0eWxlOiB7fSxcbiAgICAgICAgICAgICAgc2NhbGU6IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnbGluZWFyJyxcbiAgICAgICAgICAgICAgICBtb2RlOiAnbm9ybWFsJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgbGFiZWxzOiB7XG4gICAgICAgICAgICAgICAgc2hvdzogdHJ1ZSxcbiAgICAgICAgICAgICAgICByb3RhdGU6IDAsXG4gICAgICAgICAgICAgICAgZmlsdGVyOiBmYWxzZSxcbiAgICAgICAgICAgICAgICB0cnVuY2F0ZTogMTAwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB0aXRsZToge1xuICAgICAgICAgICAgICAgIHRleHQ6ICdDb3VudCcsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2VyaWVzUGFyYW1zOiBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIHNob3c6IHRydWUsXG4gICAgICAgICAgICAgIHR5cGU6ICdhcmVhJyxcbiAgICAgICAgICAgICAgbW9kZTogJ3N0YWNrZWQnLFxuICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgbGFiZWw6ICdDb3VudCcsXG4gICAgICAgICAgICAgICAgaWQ6ICcxJyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgZHJhd0xpbmVzQmV0d2VlblBvaW50czogdHJ1ZSxcbiAgICAgICAgICAgICAgbGluZVdpZHRoOiAyLFxuICAgICAgICAgICAgICBzaG93Q2lyY2xlczogdHJ1ZSxcbiAgICAgICAgICAgICAgaW50ZXJwb2xhdGU6ICdzdGVwLWFmdGVyJyxcbiAgICAgICAgICAgICAgdmFsdWVBeGlzOiAnVmFsdWVBeGlzLTEnLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIGFkZFRvb2x0aXA6IHRydWUsXG4gICAgICAgICAgYWRkTGVnZW5kOiB0cnVlLFxuICAgICAgICAgIGxlZ2VuZFBvc2l0aW9uOiAncmlnaHQnLFxuICAgICAgICAgIHRpbWVzOiBbXSxcbiAgICAgICAgICBhZGRUaW1lTWFya2VyOiBmYWxzZSxcbiAgICAgICAgICB0aHJlc2hvbGRMaW5lOiB7XG4gICAgICAgICAgICBzaG93OiBmYWxzZSxcbiAgICAgICAgICAgIHZhbHVlOiAxMCxcbiAgICAgICAgICAgIHdpZHRoOiAxLFxuICAgICAgICAgICAgc3R5bGU6ICdmdWxsJyxcbiAgICAgICAgICAgIGNvbG9yOiAnI0U3NjY0QycsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBsYWJlbHM6IHt9LFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgICB1aVN0YXRlSlNPTjogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB2aXM6IHsgcGFyYW1zOiB7IHNvcnQ6IHsgY29sdW1uSW5kZXg6IDMsIGRpcmVjdGlvbjogJ2Rlc2MnIH0gfSB9LFxuICAgICAgfSksXG4gICAgICBkZXNjcmlwdGlvbjogJycsXG4gICAgICB2ZXJzaW9uOiAxLFxuICAgICAga2liYW5hU2F2ZWRPYmplY3RNZXRhOiB7XG4gICAgICAgIHNlYXJjaFNvdXJjZUpTT046XG4gICAgICAgICAgJ3tcImluZGV4XCI6XCJ3YXp1aC1hbGVydHNcIixcImZpbHRlclwiOltdLFwicXVlcnlcIjp7XCJxdWVyeVwiOlwiXCIsXCJsYW5ndWFnZVwiOlwibHVjZW5lXCJ9fScsXG4gICAgICB9LFxuICAgIH0sXG4gICAgX3R5cGU6ICd2aXN1YWxpemF0aW9uJyxcbiAgfSxcbl07XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFWQSxJQUFBQSxRQUFBLEdBV2UsQ0FDYjtFQUNFQyxHQUFHLEVBQUUsNERBQTREO0VBQ2pFQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGtDQUFrQztJQUN6Q0MsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLGtDQUFrQztNQUN6Q0ksSUFBSSxFQUFFLE1BQU07TUFDWkMsSUFBSSxFQUFFLENBQ0o7UUFDRUMsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRUgsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLGdCQUFnQjtRQUN0QkksTUFBTSxFQUFFO1VBQ05FLEtBQUssRUFBRSxXQUFXO1VBQ2xCQyxTQUFTLEVBQUU7WUFDVEMsSUFBSSxFQUFFLFFBQVE7WUFDZEMsRUFBRSxFQUFFO1VBQ04sQ0FBQztVQUNEQyx1QkFBdUIsRUFBRSxJQUFJO1VBQzdCQyxpQkFBaUIsRUFBRSxLQUFLO1VBQ3hCQyxRQUFRLEVBQUUsTUFBTTtVQUNoQkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGFBQWEsRUFBRSxDQUFDO1VBQ2hCQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1VBQ25CQyxXQUFXLEVBQUU7UUFDZixDQUFDO1FBQ0RYLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFSCxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUU7VUFDTkUsS0FBSyxFQUFFLGlCQUFpQjtVQUN4QlcsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QixDQUFDO1FBQ0RsQixNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDREQsTUFBTSxFQUFFO1FBQ05KLElBQUksRUFBRSxNQUFNO1FBQ1p3QixJQUFJLEVBQUU7VUFDSkMsYUFBYSxFQUFFO1FBQ2pCLENBQUM7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRXhCLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJGLElBQUksRUFBRSxVQUFVO1VBQ2hCMkIsUUFBUSxFQUFFLFFBQVE7VUFDbEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEMsS0FBSyxFQUFFO1lBQ0w5QixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0QrQixNQUFNLEVBQUU7WUFDTkgsSUFBSSxFQUFFLElBQUk7WUFDVkksTUFBTSxFQUFFLElBQUk7WUFDWkMsUUFBUSxFQUFFLEdBQUc7WUFDYkMsTUFBTSxFQUFFO1VBQ1YsQ0FBQztVQUNEdEMsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRHVDLFNBQVMsRUFBRSxDQUNUO1VBQ0VqQyxFQUFFLEVBQUUsYUFBYTtVQUNqQmtDLElBQUksRUFBRSxZQUFZO1VBQ2xCcEMsSUFBSSxFQUFFLE9BQU87VUFDYjJCLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxJQUFJLEVBQUUsSUFBSTtVQUNWQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RDLEtBQUssRUFBRTtZQUNMOUIsSUFBSSxFQUFFLFFBQVE7WUFDZHFDLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRE4sTUFBTSxFQUFFO1lBQ05ILElBQUksRUFBRSxJQUFJO1lBQ1ZNLE1BQU0sRUFBRSxDQUFDO1lBQ1RGLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRTtVQUNaLENBQUM7VUFDRHJDLEtBQUssRUFBRTtZQUNMMEMsSUFBSSxFQUFFO1VBQ1I7UUFDRixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVgsSUFBSSxFQUFFLElBQUk7VUFDVjVCLElBQUksRUFBRSxNQUFNO1VBQ1pxQyxJQUFJLEVBQUUsUUFBUTtVQUNkRyxJQUFJLEVBQUU7WUFDSkMsS0FBSyxFQUFFLE9BQU87WUFDZHZDLEVBQUUsRUFBRTtVQUNOLENBQUM7VUFDRHdDLHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFNBQVMsRUFBRSxDQUFDO1VBQ1pDLFdBQVcsRUFBRSxJQUFJO1VBQ2pCQyxXQUFXLEVBQUUsUUFBUTtVQUNyQkMsU0FBUyxFQUFFO1FBQ2IsQ0FBQyxDQUNGO1FBQ0RDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QkMsS0FBSyxFQUFFLEVBQUU7UUFDVEMsYUFBYSxFQUFFLEtBQUs7UUFDcEJDLGFBQWEsRUFBRTtVQUNieEIsSUFBSSxFQUFFLEtBQUs7VUFDWHlCLEtBQUssRUFBRSxFQUFFO1VBQ1RDLEtBQUssRUFBRSxDQUFDO1VBQ1J6QixLQUFLLEVBQUUsTUFBTTtVQUNiMEIsS0FBSyxFQUFFO1FBQ1QsQ0FBQztRQUNEeEIsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWeUIsaUJBQWlCLEVBQUU7TUFDckI7SUFDRixDQUFDLENBQUM7SUFDRkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUNkO0lBQ0o7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFcEUsR0FBRyxFQUFFLHlEQUF5RDtFQUM5REMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSwrQkFBK0I7SUFDdENDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSwrQkFBK0I7TUFDdENJLElBQUksRUFBRSxLQUFLO01BQ1hDLElBQUksRUFBRSxDQUNKO1FBQ0VDLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVkMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0VILEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRTtVQUNORSxLQUFLLEVBQUUsaUJBQWlCO1VBQ3hCVyxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCLENBQUM7UUFDRGxCLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNERCxNQUFNLEVBQUU7UUFDTkosSUFBSSxFQUFFLEtBQUs7UUFDWCtDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QmMsT0FBTyxFQUFFLEtBQUs7UUFDZGhDLE1BQU0sRUFBRTtVQUNOSCxJQUFJLEVBQUUsS0FBSztVQUNYb0MsTUFBTSxFQUFFLElBQUk7VUFDWkMsVUFBVSxFQUFFLElBQUk7VUFDaEJoQyxRQUFRLEVBQUU7UUFDWjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0Z3QixXQUFXLEVBQUUsRUFBRTtJQUNmQyxXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQ2Q7SUFDSjtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VwRSxHQUFHLEVBQUUsa0RBQWtEO0VBQ3ZEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHdCQUF3QjtJQUMvQkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHdCQUF3QjtNQUMvQkksSUFBSSxFQUFFLE1BQU07TUFDWkMsSUFBSSxFQUFFLENBQ0o7UUFDRUMsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRUgsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFO1VBQ05FLEtBQUssRUFBRSxpQkFBaUI7VUFDeEJXLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxDQUFDO1VBQ1BDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEIsQ0FBQztRQUNEbEIsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0VILEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRTtVQUNORSxLQUFLLEVBQUUsbUJBQW1CO1VBQzFCVyxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCLENBQUM7UUFDRGxCLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNERCxNQUFNLEVBQUU7UUFDTkosSUFBSSxFQUFFLE1BQU07UUFDWndCLElBQUksRUFBRTtVQUNKQyxhQUFhLEVBQUU7UUFDakIsQ0FBQztRQUNEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFeEIsRUFBRSxFQUFFLGdCQUFnQjtVQUNwQkYsSUFBSSxFQUFFLFVBQVU7VUFDaEIyQixRQUFRLEVBQUUsUUFBUTtVQUNsQkMsSUFBSSxFQUFFLElBQUk7VUFDVkMsS0FBSyxFQUFFLENBQUMsQ0FBQztVQUNUQyxLQUFLLEVBQUU7WUFDTDlCLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRCtCLE1BQU0sRUFBRTtZQUNOSCxJQUFJLEVBQUUsSUFBSTtZQUNWSSxNQUFNLEVBQUUsSUFBSTtZQUNaQyxRQUFRLEVBQUU7VUFDWixDQUFDO1VBQ0RyQyxLQUFLLEVBQUUsQ0FBQztRQUNWLENBQUMsQ0FDRjtRQUNEdUMsU0FBUyxFQUFFLENBQ1Q7VUFDRWpDLEVBQUUsRUFBRSxhQUFhO1VBQ2pCa0MsSUFBSSxFQUFFLFlBQVk7VUFDbEJwQyxJQUFJLEVBQUUsT0FBTztVQUNiMkIsUUFBUSxFQUFFLE1BQU07VUFDaEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEMsS0FBSyxFQUFFO1lBQ0w5QixJQUFJLEVBQUUsUUFBUTtZQUNkcUMsSUFBSSxFQUFFO1VBQ1IsQ0FBQztVQUNETixNQUFNLEVBQUU7WUFDTkgsSUFBSSxFQUFFLElBQUk7WUFDVk0sTUFBTSxFQUFFLENBQUM7WUFDVEYsTUFBTSxFQUFFLEtBQUs7WUFDYkMsUUFBUSxFQUFFO1VBQ1osQ0FBQztVQUNEckMsS0FBSyxFQUFFO1lBQ0wwQyxJQUFJLEVBQUU7VUFDUjtRQUNGLENBQUMsQ0FDRjtRQUNEQyxZQUFZLEVBQUUsQ0FDWjtVQUNFWCxJQUFJLEVBQUUsSUFBSTtVQUNWNUIsSUFBSSxFQUFFLFdBQVc7VUFDakJxQyxJQUFJLEVBQUUsU0FBUztVQUNmRyxJQUFJLEVBQUU7WUFDSkMsS0FBSyxFQUFFLE9BQU87WUFDZHZDLEVBQUUsRUFBRTtVQUNOLENBQUM7VUFDRDRDLFNBQVMsRUFBRSxhQUFhO1VBQ3hCSixzQkFBc0IsRUFBRSxJQUFJO1VBQzVCQyxTQUFTLEVBQUUsQ0FBQztVQUNaRSxXQUFXLEVBQUUsUUFBUTtVQUNyQkQsV0FBVyxFQUFFO1FBQ2YsQ0FBQyxDQUNGO1FBQ0RHLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QkMsS0FBSyxFQUFFLEVBQUU7UUFDVEMsYUFBYSxFQUFFLEtBQUs7UUFDcEJwQixNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZxQixhQUFhLEVBQUU7VUFDYnhCLElBQUksRUFBRSxLQUFLO1VBQ1h5QixLQUFLLEVBQUUsRUFBRTtVQUNUQyxLQUFLLEVBQUUsQ0FBQztVQUNSekIsS0FBSyxFQUFFLE1BQU07VUFDYjBCLEtBQUssRUFBRTtRQUNUO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFDRkUsV0FBVyxFQUFFLEVBQUU7SUFDZkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUNkO0lBQ0o7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFcEUsR0FBRyxFQUFFLDZEQUE2RDtFQUNsRUMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxrREFBa0Q7SUFDekRDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxrREFBa0Q7TUFDekRJLElBQUksRUFBRSxLQUFLO01BQ1hDLElBQUksRUFBRSxDQUNKO1FBQ0VDLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVkMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0VILEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRTtVQUNORSxLQUFLLEVBQUUsaUJBQWlCO1VBQ3hCVyxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCLENBQUM7UUFDRGxCLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFSCxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUU7VUFDTkUsS0FBSyxFQUFFLG9CQUFvQjtVQUMzQlcsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLENBQUM7VUFDUEMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QixDQUFDO1FBQ0RsQixNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDREQsTUFBTSxFQUFFO1FBQ05KLElBQUksRUFBRSxLQUFLO1FBQ1grQyxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJjLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxNQUFNLEVBQUU7VUFDTkgsSUFBSSxFQUFFLEtBQUs7VUFDWG9DLE1BQU0sRUFBRSxJQUFJO1VBQ1pDLFVBQVUsRUFBRSxJQUFJO1VBQ2hCaEMsUUFBUSxFQUFFO1FBQ1o7TUFDRjtJQUNGLENBQUMsQ0FBQztJQUNGd0IsV0FBVyxFQUFFLEVBQUU7SUFDZkMsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUNkO0lBQ0o7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFcEUsR0FBRyxFQUFFLHlDQUF5QztFQUM5Q0MsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxnQkFBZ0I7TUFDdkJJLElBQUksRUFBRSxPQUFPO01BQ2JDLElBQUksRUFBRSxDQUNKO1FBQ0VDLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVkMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0VILEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRTtVQUNORSxLQUFLLEVBQUUsWUFBWTtVQUNuQlcsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEVBQUU7VUFDUkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QixDQUFDO1FBQ0RsQixNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRUgsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFO1VBQ05FLEtBQUssRUFBRSxpQkFBaUI7VUFDeEJXLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxFQUFFO1VBQ1JDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEIsQ0FBQztRQUNEbEIsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0VILEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRTtVQUNORSxLQUFLLEVBQUUsa0JBQWtCO1VBQ3pCVyxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsRUFBRTtVQUNSQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCLENBQUM7UUFDRGxCLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNERCxNQUFNLEVBQUU7UUFDTjhELE9BQU8sRUFBRSxFQUFFO1FBQ1hDLGVBQWUsRUFBRSxLQUFLO1FBQ3RCQyxzQkFBc0IsRUFBRSxLQUFLO1FBQzdCQyxJQUFJLEVBQUU7VUFDSkMsV0FBVyxFQUFFLElBQUk7VUFDakJDLFNBQVMsRUFBRTtRQUNiLENBQUM7UUFDREMsU0FBUyxFQUFFLEtBQUs7UUFDaEJDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCQyxhQUFhLEVBQUU7TUFDakI7SUFDRixDQUFDLENBQUM7SUFDRmpCLFdBQVcsRUFBRTNELElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQzFCNEUsR0FBRyxFQUFFO1FBQUV2RSxNQUFNLEVBQUU7VUFBRWlFLElBQUksRUFBRTtZQUFFQyxXQUFXLEVBQUUsQ0FBQztZQUFFQyxTQUFTLEVBQUU7VUFBTztRQUFFO01BQUU7SUFDakUsQ0FBQyxDQUFDO0lBQ0ZiLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFDZDtJQUNKO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRXBFLEdBQUcsRUFBRSxpREFBaUQ7RUFDdERDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsc0JBQXNCO0lBQzdCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsc0JBQXNCO01BQzdCSSxJQUFJLEVBQUUsS0FBSztNQUNYQyxJQUFJLEVBQUUsQ0FDSjtRQUNFQyxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFSCxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUU7VUFDTkUsS0FBSyxFQUFFLGlCQUFpQjtVQUN4QlcsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEVBQUU7VUFDUkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCUCxXQUFXLEVBQUU7UUFDZixDQUFDO1FBQ0RYLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNERCxNQUFNLEVBQUU7UUFDTkosSUFBSSxFQUFFLEtBQUs7UUFDWCtDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QmMsT0FBTyxFQUFFLElBQUk7UUFDYmhDLE1BQU0sRUFBRTtVQUNOSCxJQUFJLEVBQUUsS0FBSztVQUNYb0MsTUFBTSxFQUFFLElBQUk7VUFDWkMsVUFBVSxFQUFFLElBQUk7VUFDaEJoQyxRQUFRLEVBQUU7UUFDWjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0Z3QixXQUFXLEVBQUUzRCxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUMxQjRFLEdBQUcsRUFBRTtRQUFFdkUsTUFBTSxFQUFFO1VBQUVpRSxJQUFJLEVBQUU7WUFBRUMsV0FBVyxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQU87UUFBRTtNQUFFO0lBQ2pFLENBQUMsQ0FBQztJQUNGYixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQ2Q7SUFDSjtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VwRSxHQUFHLEVBQUUscUNBQXFDO0VBQzFDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLFdBQVc7SUFDbEJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSw2QkFBNkI7TUFDcENJLElBQUksRUFBRSxVQUFVO01BQ2hCQyxJQUFJLEVBQUUsQ0FDSjtRQUNFQyxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFSCxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUU7VUFDTkUsS0FBSyxFQUFFLHlDQUF5QztVQUNoRFcsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEVBQUU7VUFDUkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCUCxXQUFXLEVBQUU7UUFDZixDQUFDO1FBQ0RYLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNERCxNQUFNLEVBQUU7UUFDTjBCLEtBQUssRUFBRSxRQUFRO1FBQ2Y4QyxXQUFXLEVBQUUsUUFBUTtRQUNyQkMsV0FBVyxFQUFFLEVBQUU7UUFDZkMsV0FBVyxFQUFFLEVBQUU7UUFDZkMsU0FBUyxFQUFFO01BQ2I7SUFDRixDQUFDLENBQUM7SUFDRnRCLFdBQVcsRUFBRTNELElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQzFCNEUsR0FBRyxFQUFFO1FBQUV2RSxNQUFNLEVBQUU7VUFBRWlFLElBQUksRUFBRTtZQUFFQyxXQUFXLEVBQUUsQ0FBQztZQUFFQyxTQUFTLEVBQUU7VUFBTztRQUFFO01BQUU7SUFDakUsQ0FBQyxDQUFDO0lBQ0ZiLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFDZDtJQUNKO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRXBFLEdBQUcsRUFBRSxzQ0FBc0M7RUFDM0NDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsbUJBQW1CO0lBQzFCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsbUJBQW1CO01BQzFCSSxJQUFJLEVBQUUsS0FBSztNQUNYQyxJQUFJLEVBQUUsQ0FDSjtRQUNFQyxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFSCxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUU7VUFDTkUsS0FBSyxFQUFFLG9CQUFvQjtVQUMzQlcsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEVBQUU7VUFDUkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCUCxXQUFXLEVBQUU7UUFDZixDQUFDO1FBQ0RYLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNERCxNQUFNLEVBQUU7UUFDTkosSUFBSSxFQUFFLEtBQUs7UUFDWCtDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QmMsT0FBTyxFQUFFLEtBQUs7UUFDZGhDLE1BQU0sRUFBRTtVQUNOSCxJQUFJLEVBQUUsS0FBSztVQUNYb0MsTUFBTSxFQUFFLElBQUk7VUFDWkMsVUFBVSxFQUFFLElBQUk7VUFDaEJoQyxRQUFRLEVBQUU7UUFDWjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0Z3QixXQUFXLEVBQUUzRCxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUMxQjRFLEdBQUcsRUFBRTtRQUFFdkUsTUFBTSxFQUFFO1VBQUVpRSxJQUFJLEVBQUU7WUFBRUMsV0FBVyxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQU87UUFBRTtNQUFFO0lBQ2pFLENBQUMsQ0FBQztJQUNGYixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQ2Q7SUFDSjtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VwRSxHQUFHLEVBQUUsaUNBQWlDO0VBQ3RDQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLGNBQWM7SUFDckJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxjQUFjO01BQ3JCSSxJQUFJLEVBQUUsUUFBUTtNQUNkQyxJQUFJLEVBQUUsQ0FDSjtRQUNFQyxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUU7VUFDTlksV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNEWCxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRUgsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLFVBQVU7UUFDaEJJLE1BQU0sRUFBRTtVQUNORSxLQUFLLEVBQUUsWUFBWTtVQUNuQjBFLFNBQVMsRUFBRSxRQUFRO1VBQ25CN0QsSUFBSSxFQUFFLENBQUM7VUFDUDhELFNBQVMsRUFBRSxZQUFZO1VBQ3ZCQyxTQUFTLEVBQUUsTUFBTTtVQUNqQmxFLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRFgsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUNGO01BQ0RELE1BQU0sRUFBRTtRQUNOMkMsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxLQUFLO1FBQ2hCaEQsSUFBSSxFQUFFLFFBQVE7UUFDZG1GLE1BQU0sRUFBRTtVQUNOQyxjQUFjLEVBQUUsS0FBSztVQUNyQkMsU0FBUyxFQUFFLEtBQUs7VUFDaEJDLFdBQVcsRUFBRSxjQUFjO1VBQzNCQyxlQUFlLEVBQUUsTUFBTTtVQUN2QkMsV0FBVyxFQUFFLENBQ1g7WUFDRWhGLElBQUksRUFBRSxDQUFDO1lBQ1BDLEVBQUUsRUFBRTtVQUNOLENBQUMsQ0FDRjtVQUNEc0IsTUFBTSxFQUFFO1lBQ05ILElBQUksRUFBRTtVQUNSLENBQUM7VUFDRDZELFlBQVksRUFBRSxLQUFLO1VBQ25CNUQsS0FBSyxFQUFFO1lBQ0w2RCxNQUFNLEVBQUUsTUFBTTtZQUNkQyxPQUFPLEVBQUUsS0FBSztZQUNkQyxVQUFVLEVBQUUsS0FBSztZQUNqQkMsT0FBTyxFQUFFLEVBQUU7WUFDWEMsUUFBUSxFQUFFO1VBQ1o7UUFDRjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0ZyQyxXQUFXLEVBQUUzRCxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUMxQjRFLEdBQUcsRUFBRTtRQUFFdkUsTUFBTSxFQUFFO1VBQUVpRSxJQUFJLEVBQUU7WUFBRUMsV0FBVyxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQU87UUFBRTtNQUFFO0lBQ2pFLENBQUMsQ0FBQztJQUNGYixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQ2Q7SUFDSjtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VwRSxHQUFHLEVBQUUsZ0RBQWdEO0VBQ3JEQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLDZCQUE2QjtJQUNwQ0MsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLDZCQUE2QjtNQUNwQ0ksSUFBSSxFQUFFLFNBQVM7TUFDZkMsSUFBSSxFQUFFLENBQ0o7UUFDRUMsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRUgsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFO1VBQ05FLEtBQUssRUFBRSxpQkFBaUI7VUFDeEJXLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxFQUFFO1VBQ1JDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUU7UUFDdEIsQ0FBQztRQUNEbEIsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0VILEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRTtVQUNORSxLQUFLLEVBQUUsb0JBQW9CO1VBQzNCVyxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsQ0FBQztVQUNQQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFO1FBQ3RCLENBQUM7UUFDRGxCLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNERCxNQUFNLEVBQUU7UUFDTkosSUFBSSxFQUFFLFNBQVM7UUFDZitDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmK0MsV0FBVyxFQUFFLEtBQUs7UUFDbEI5QyxjQUFjLEVBQUUsT0FBTztRQUN2QkMsS0FBSyxFQUFFLEVBQUU7UUFDVDhDLFlBQVksRUFBRSxDQUFDO1FBQ2ZWLFdBQVcsRUFBRSxPQUFPO1FBQ3BCVyxhQUFhLEVBQUUsS0FBSztRQUNwQlQsV0FBVyxFQUFFLEVBQUU7UUFDZkMsWUFBWSxFQUFFLEtBQUs7UUFDbkJMLGNBQWMsRUFBRSxLQUFLO1FBQ3JCakQsU0FBUyxFQUFFLENBQ1Q7VUFDRVAsSUFBSSxFQUFFLEtBQUs7VUFDWDFCLEVBQUUsRUFBRSxhQUFhO1VBQ2pCRixJQUFJLEVBQUUsT0FBTztVQUNiOEIsS0FBSyxFQUFFO1lBQ0w5QixJQUFJLEVBQUUsUUFBUTtZQUNka0csZUFBZSxFQUFFO1VBQ25CLENBQUM7VUFDRG5FLE1BQU0sRUFBRTtZQUNOSCxJQUFJLEVBQUUsS0FBSztZQUNYTSxNQUFNLEVBQUUsQ0FBQztZQUNUaUUsY0FBYyxFQUFFLEtBQUs7WUFDckI1QyxLQUFLLEVBQUU7VUFDVDtRQUNGLENBQUM7TUFFTDtJQUNGLENBQUMsQ0FBQztJQUNGRSxXQUFXLEVBQUUzRCxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUMxQjRFLEdBQUcsRUFBRTtRQUFFdkUsTUFBTSxFQUFFO1VBQUVpRSxJQUFJLEVBQUU7WUFBRUMsV0FBVyxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQU87UUFBRTtNQUFFO0lBQ2pFLENBQUMsQ0FBQztJQUNGYixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQ2Q7SUFDSjtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VwRSxHQUFHLEVBQUUsaURBQWlEO0VBQ3REQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLDZCQUE2QjtJQUNwQ0MsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHNCQUFzQjtNQUM3QkksSUFBSSxFQUFFLEtBQUs7TUFDWEMsSUFBSSxFQUFFLENBQ0o7UUFDRUMsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRUgsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFO1VBQ05FLEtBQUssRUFBRSxpQkFBaUI7VUFDeEJXLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxFQUFFO1VBQ1JDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3QlAsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNEWCxNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDREQsTUFBTSxFQUFFO1FBQ05KLElBQUksRUFBRSxLQUFLO1FBQ1grQyxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJjLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxNQUFNLEVBQUU7VUFDTkgsSUFBSSxFQUFFLEtBQUs7VUFDWG9DLE1BQU0sRUFBRSxJQUFJO1VBQ1pDLFVBQVUsRUFBRSxJQUFJO1VBQ2hCaEMsUUFBUSxFQUFFO1FBQ1o7TUFDRjtJQUNGLENBQUMsQ0FBQztJQUNGd0IsV0FBVyxFQUFFM0QsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUI0RSxHQUFHLEVBQUU7UUFBRXZFLE1BQU0sRUFBRTtVQUFFaUUsSUFBSSxFQUFFO1lBQUVDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLFNBQVMsRUFBRTtVQUFPO1FBQUU7TUFBRTtJQUNqRSxDQUFDLENBQUM7SUFDRmIsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUNkO0lBQ0o7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFcEUsR0FBRyxFQUFFLDBDQUEwQztFQUMvQ0MsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxlQUFlO0lBQ3RCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsZUFBZTtNQUN0QkksSUFBSSxFQUFFLEtBQUs7TUFDWEMsSUFBSSxFQUFFLENBQ0o7UUFDRUMsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRUgsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFO1VBQ05FLEtBQUssRUFBRSxtQkFBbUI7VUFDMUJXLE9BQU8sRUFBRSxHQUFHO1VBQ1pDLEtBQUssRUFBRSxNQUFNO1VBQ2JDLElBQUksRUFBRSxFQUFFO1VBQ1JDLFdBQVcsRUFBRSxLQUFLO1VBQ2xCQyxnQkFBZ0IsRUFBRSxPQUFPO1VBQ3pCQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsa0JBQWtCLEVBQUUsU0FBUztVQUM3QlAsV0FBVyxFQUFFO1FBQ2YsQ0FBQztRQUNEWCxNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDREQsTUFBTSxFQUFFO1FBQ05KLElBQUksRUFBRSxLQUFLO1FBQ1grQyxVQUFVLEVBQUUsSUFBSTtRQUNoQkMsU0FBUyxFQUFFLElBQUk7UUFDZkMsY0FBYyxFQUFFLE9BQU87UUFDdkJjLE9BQU8sRUFBRSxJQUFJO1FBQ2JoQyxNQUFNLEVBQUU7VUFDTkgsSUFBSSxFQUFFLEtBQUs7VUFDWG9DLE1BQU0sRUFBRSxJQUFJO1VBQ1pDLFVBQVUsRUFBRSxJQUFJO1VBQ2hCaEMsUUFBUSxFQUFFO1FBQ1o7TUFDRjtJQUNGLENBQUMsQ0FBQztJQUNGd0IsV0FBVyxFQUFFM0QsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUI0RSxHQUFHLEVBQUU7UUFBRXZFLE1BQU0sRUFBRTtVQUFFaUUsSUFBSSxFQUFFO1lBQUVDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLFNBQVMsRUFBRTtVQUFPO1FBQUU7TUFBRTtJQUNqRSxDQUFDLENBQUM7SUFDRmIsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUNkO0lBQ0o7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsRUFDRDtFQUNFcEUsR0FBRyxFQUFFLGdEQUFnRDtFQUNyREMsT0FBTyxFQUFFO0lBQ1BDLEtBQUssRUFBRSxxQkFBcUI7SUFDNUJDLFFBQVEsRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDdkJILEtBQUssRUFBRSxxQkFBcUI7TUFDNUJJLElBQUksRUFBRSxLQUFLO01BQ1hDLElBQUksRUFBRSxDQUNKO1FBQ0VDLEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDVkMsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0VILEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRTtVQUNORSxLQUFLLEVBQUUsa0JBQWtCO1VBQ3pCVyxPQUFPLEVBQUUsR0FBRztVQUNaQyxLQUFLLEVBQUUsTUFBTTtVQUNiQyxJQUFJLEVBQUUsRUFBRTtVQUNSQyxXQUFXLEVBQUUsS0FBSztVQUNsQkMsZ0JBQWdCLEVBQUUsT0FBTztVQUN6QkMsYUFBYSxFQUFFLEtBQUs7VUFDcEJDLGtCQUFrQixFQUFFLFNBQVM7VUFDN0JQLFdBQVcsRUFBRTtRQUNmLENBQUM7UUFDRFgsTUFBTSxFQUFFO01BQ1YsQ0FBQyxDQUNGO01BQ0RELE1BQU0sRUFBRTtRQUNOSixJQUFJLEVBQUUsS0FBSztRQUNYK0MsVUFBVSxFQUFFLElBQUk7UUFDaEJDLFNBQVMsRUFBRSxJQUFJO1FBQ2ZDLGNBQWMsRUFBRSxPQUFPO1FBQ3ZCYyxPQUFPLEVBQUUsSUFBSTtRQUNiaEMsTUFBTSxFQUFFO1VBQ05ILElBQUksRUFBRSxLQUFLO1VBQ1hvQyxNQUFNLEVBQUUsSUFBSTtVQUNaQyxVQUFVLEVBQUUsSUFBSTtVQUNoQmhDLFFBQVEsRUFBRTtRQUNaO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFDRndCLFdBQVcsRUFBRTNELElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQzFCNEUsR0FBRyxFQUFFO1FBQUV2RSxNQUFNLEVBQUU7VUFBRWlFLElBQUksRUFBRTtZQUFFQyxXQUFXLEVBQUUsQ0FBQztZQUFFQyxTQUFTLEVBQUU7VUFBTztRQUFFO01BQUU7SUFDakUsQ0FBQyxDQUFDO0lBQ0ZiLFdBQVcsRUFBRSxFQUFFO0lBQ2ZDLE9BQU8sRUFBRSxDQUFDO0lBQ1ZDLHFCQUFxQixFQUFFO01BQ3JCQyxnQkFBZ0IsRUFDZDtJQUNKO0VBQ0YsQ0FBQztFQUNEQyxLQUFLLEVBQUU7QUFDVCxDQUFDLEVBQ0Q7RUFDRXBFLEdBQUcsRUFBRSwyQ0FBMkM7RUFDaERDLE9BQU8sRUFBRTtJQUNQQyxLQUFLLEVBQUUsZ0JBQWdCO0lBQ3ZCQyxRQUFRLEVBQUVDLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ3ZCSCxLQUFLLEVBQUUsZ0JBQWdCO01BQ3ZCSSxJQUFJLEVBQUUsS0FBSztNQUNYQyxJQUFJLEVBQUUsQ0FDSjtRQUNFQyxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ1ZDLE1BQU0sRUFBRTtNQUNWLENBQUMsRUFDRDtRQUNFSCxFQUFFLEVBQUUsR0FBRztRQUNQQyxPQUFPLEVBQUUsSUFBSTtRQUNiSCxJQUFJLEVBQUUsT0FBTztRQUNiSSxNQUFNLEVBQUU7VUFDTkUsS0FBSyxFQUFFLG9CQUFvQjtVQUMzQlcsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEVBQUU7VUFDUkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRSxTQUFTO1VBQzdCUCxXQUFXLEVBQUU7UUFDZixDQUFDO1FBQ0RYLE1BQU0sRUFBRTtNQUNWLENBQUMsQ0FDRjtNQUNERCxNQUFNLEVBQUU7UUFDTkosSUFBSSxFQUFFLEtBQUs7UUFDWCtDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QmMsT0FBTyxFQUFFLElBQUk7UUFDYmhDLE1BQU0sRUFBRTtVQUNOSCxJQUFJLEVBQUUsS0FBSztVQUNYb0MsTUFBTSxFQUFFLElBQUk7VUFDWkMsVUFBVSxFQUFFLElBQUk7VUFDaEJoQyxRQUFRLEVBQUU7UUFDWjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0lBQ0Z3QixXQUFXLEVBQUUzRCxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUMxQjRFLEdBQUcsRUFBRTtRQUFFdkUsTUFBTSxFQUFFO1VBQUVpRSxJQUFJLEVBQUU7WUFBRUMsV0FBVyxFQUFFLENBQUM7WUFBRUMsU0FBUyxFQUFFO1VBQU87UUFBRTtNQUFFO0lBQ2pFLENBQUMsQ0FBQztJQUNGYixXQUFXLEVBQUUsRUFBRTtJQUNmQyxPQUFPLEVBQUUsQ0FBQztJQUNWQyxxQkFBcUIsRUFBRTtNQUNyQkMsZ0JBQWdCLEVBQ2Q7SUFDSjtFQUNGLENBQUM7RUFDREMsS0FBSyxFQUFFO0FBQ1QsQ0FBQyxFQUNEO0VBQ0VwRSxHQUFHLEVBQUUsaURBQWlEO0VBQ3REQyxPQUFPLEVBQUU7SUFDUEMsS0FBSyxFQUFFLHVCQUF1QjtJQUM5QkMsUUFBUSxFQUFFQyxJQUFJLENBQUNDLFNBQVMsQ0FBQztNQUN2QkgsS0FBSyxFQUFFLHNCQUFzQjtNQUM3QkksSUFBSSxFQUFFLE1BQU07TUFDWkMsSUFBSSxFQUFFLENBQ0o7UUFDRUMsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLE9BQU87UUFDYkksTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNWQyxNQUFNLEVBQUU7TUFDVixDQUFDLEVBQ0Q7UUFDRUgsRUFBRSxFQUFFLEdBQUc7UUFDUEMsT0FBTyxFQUFFLElBQUk7UUFDYkgsSUFBSSxFQUFFLGdCQUFnQjtRQUN0QkksTUFBTSxFQUFFO1VBQ05FLEtBQUssRUFBRSxXQUFXO1VBQ2xCQyxTQUFTLEVBQUU7WUFDVEMsSUFBSSxFQUFFLFNBQVM7WUFDZkMsRUFBRSxFQUFFO1VBQ04sQ0FBQztVQUNEQyx1QkFBdUIsRUFBRSxJQUFJO1VBQzdCQyxpQkFBaUIsRUFBRSxLQUFLO1VBQ3hCQyxRQUFRLEVBQUUsR0FBRztVQUNiQyxhQUFhLEVBQUUsS0FBSztVQUNwQkMsYUFBYSxFQUFFLENBQUM7VUFDaEJDLGVBQWUsRUFBRSxDQUFDO1FBQ3BCLENBQUM7UUFDRFYsTUFBTSxFQUFFO01BQ1YsQ0FBQyxFQUNEO1FBQ0VILEVBQUUsRUFBRSxHQUFHO1FBQ1BDLE9BQU8sRUFBRSxJQUFJO1FBQ2JILElBQUksRUFBRSxPQUFPO1FBQ2JJLE1BQU0sRUFBRTtVQUNORSxLQUFLLEVBQUUsWUFBWTtVQUNuQlcsT0FBTyxFQUFFLEdBQUc7VUFDWkMsS0FBSyxFQUFFLE1BQU07VUFDYkMsSUFBSSxFQUFFLEVBQUU7VUFDUkMsV0FBVyxFQUFFLEtBQUs7VUFDbEJDLGdCQUFnQixFQUFFLE9BQU87VUFDekJDLGFBQWEsRUFBRSxLQUFLO1VBQ3BCQyxrQkFBa0IsRUFBRTtRQUN0QixDQUFDO1FBQ0RsQixNQUFNLEVBQUU7TUFDVixDQUFDLENBQ0Y7TUFDREQsTUFBTSxFQUFFO1FBQ05KLElBQUksRUFBRSxNQUFNO1FBQ1p3QixJQUFJLEVBQUU7VUFDSkMsYUFBYSxFQUFFO1FBQ2pCLENBQUM7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRXhCLEVBQUUsRUFBRSxnQkFBZ0I7VUFDcEJGLElBQUksRUFBRSxVQUFVO1VBQ2hCMkIsUUFBUSxFQUFFLFFBQVE7VUFDbEJDLElBQUksRUFBRSxJQUFJO1VBQ1ZDLEtBQUssRUFBRSxDQUFDLENBQUM7VUFDVEMsS0FBSyxFQUFFO1lBQ0w5QixJQUFJLEVBQUU7VUFDUixDQUFDO1VBQ0QrQixNQUFNLEVBQUU7WUFDTkgsSUFBSSxFQUFFLElBQUk7WUFDVkksTUFBTSxFQUFFLElBQUk7WUFDWkMsUUFBUSxFQUFFO1VBQ1osQ0FBQztVQUNEckMsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDLENBQ0Y7UUFDRHVDLFNBQVMsRUFBRSxDQUNUO1VBQ0VqQyxFQUFFLEVBQUUsYUFBYTtVQUNqQmtDLElBQUksRUFBRSxZQUFZO1VBQ2xCcEMsSUFBSSxFQUFFLE9BQU87VUFDYjJCLFFBQVEsRUFBRSxNQUFNO1VBQ2hCQyxJQUFJLEVBQUUsSUFBSTtVQUNWQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1VBQ1RDLEtBQUssRUFBRTtZQUNMOUIsSUFBSSxFQUFFLFFBQVE7WUFDZHFDLElBQUksRUFBRTtVQUNSLENBQUM7VUFDRE4sTUFBTSxFQUFFO1lBQ05ILElBQUksRUFBRSxJQUFJO1lBQ1ZNLE1BQU0sRUFBRSxDQUFDO1lBQ1RGLE1BQU0sRUFBRSxLQUFLO1lBQ2JDLFFBQVEsRUFBRTtVQUNaLENBQUM7VUFDRHJDLEtBQUssRUFBRTtZQUNMMEMsSUFBSSxFQUFFO1VBQ1I7UUFDRixDQUFDLENBQ0Y7UUFDREMsWUFBWSxFQUFFLENBQ1o7VUFDRVgsSUFBSSxFQUFFLElBQUk7VUFDVjVCLElBQUksRUFBRSxNQUFNO1VBQ1pxQyxJQUFJLEVBQUUsU0FBUztVQUNmRyxJQUFJLEVBQUU7WUFDSkMsS0FBSyxFQUFFLE9BQU87WUFDZHZDLEVBQUUsRUFBRTtVQUNOLENBQUM7VUFDRHdDLHNCQUFzQixFQUFFLElBQUk7VUFDNUJDLFNBQVMsRUFBRSxDQUFDO1VBQ1pDLFdBQVcsRUFBRSxJQUFJO1VBQ2pCQyxXQUFXLEVBQUUsWUFBWTtVQUN6QkMsU0FBUyxFQUFFO1FBQ2IsQ0FBQyxDQUNGO1FBQ0RDLFVBQVUsRUFBRSxJQUFJO1FBQ2hCQyxTQUFTLEVBQUUsSUFBSTtRQUNmQyxjQUFjLEVBQUUsT0FBTztRQUN2QkMsS0FBSyxFQUFFLEVBQUU7UUFDVEMsYUFBYSxFQUFFLEtBQUs7UUFDcEJDLGFBQWEsRUFBRTtVQUNieEIsSUFBSSxFQUFFLEtBQUs7VUFDWHlCLEtBQUssRUFBRSxFQUFFO1VBQ1RDLEtBQUssRUFBRSxDQUFDO1VBQ1J6QixLQUFLLEVBQUUsTUFBTTtVQUNiMEIsS0FBSyxFQUFFO1FBQ1QsQ0FBQztRQUNEeEIsTUFBTSxFQUFFLENBQUM7TUFDWDtJQUNGLENBQUMsQ0FBQztJQUNGMEIsV0FBVyxFQUFFM0QsSUFBSSxDQUFDQyxTQUFTLENBQUM7TUFDMUI0RSxHQUFHLEVBQUU7UUFBRXZFLE1BQU0sRUFBRTtVQUFFaUUsSUFBSSxFQUFFO1lBQUVDLFdBQVcsRUFBRSxDQUFDO1lBQUVDLFNBQVMsRUFBRTtVQUFPO1FBQUU7TUFBRTtJQUNqRSxDQUFDLENBQUM7SUFDRmIsV0FBVyxFQUFFLEVBQUU7SUFDZkMsT0FBTyxFQUFFLENBQUM7SUFDVkMscUJBQXFCLEVBQUU7TUFDckJDLGdCQUFnQixFQUNkO0lBQ0o7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtBQUNULENBQUMsQ0FDRjtBQUFBc0MsT0FBQSxDQUFBQyxPQUFBLEdBQUE1RyxRQUFBO0FBQUE2RyxNQUFBLENBQUFGLE9BQUEsR0FBQUEsT0FBQSxDQUFBQyxPQUFBIn0=