"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhElasticCtrl = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _errorResponse = require("../lib/error-response");
var _logger = require("../lib/logger");
var _getConfiguration = require("../lib/get-configuration");
var _visualizations = require("../integration-files/visualizations");
var _generateAlertsScript = require("../lib/generate-alerts/generate-alerts-script");
var _constants = require("../../common/constants");
var _jwtDecode = _interopRequireDefault(require("jwt-decode"));
var _manageHosts = require("../lib/manage-hosts");
var _cookie = require("../lib/cookie");
var _settings = require("../../common/services/settings");
/*
 * Wazuh app - Class for Wazuh-Elastic functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */

class WazuhElasticCtrl {
  constructor() {
    (0, _defineProperty2.default)(this, "wzSampleAlertsIndexPrefix", void 0);
    (0, _defineProperty2.default)(this, "manageHosts", void 0);
    this.wzSampleAlertsIndexPrefix = this.getSampleAlertPrefix();
    this.manageHosts = new _manageHosts.ManageHosts();
  }

  /**
   * This returns the index according the category
   * @param {string} category
   */
  buildSampleIndexByCategory(category) {
    return `${this.wzSampleAlertsIndexPrefix}sample-${category}`;
  }

  /**
   * This returns the defined config for sample alerts prefix or the default value.
   */
  getSampleAlertPrefix() {
    const config = (0, _getConfiguration.getConfiguration)();
    return config['alerts.sample.prefix'] || (0, _settings.getSettingDefaultValue)('alerts.sample.prefix');
  }

  /**
   * This retrieves a template from Elasticsearch
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} template or ErrorResponse
   */
  async getTemplate(context, request, response) {
    try {
      const data = await context.core.elasticsearch.client.asInternalUser.cat.templates();
      const templates = data.body;
      if (!templates || typeof templates !== 'string') {
        throw new Error('An unknown error occurred when fetching templates from Elasticseach');
      }
      const lastChar = request.params.pattern[request.params.pattern.length - 1];

      // Split into separate patterns
      const tmpdata = templates.match(/\[.*\]/g);
      const tmparray = [];
      for (let item of tmpdata) {
        // A template might use more than one pattern
        if (item.includes(',')) {
          item = item.substr(1).slice(0, -1);
          const subItems = item.split(',');
          for (const subitem of subItems) {
            tmparray.push(`[${subitem.trim()}]`);
          }
        } else {
          tmparray.push(item);
        }
      }

      // Ensure we are handling just patterns
      const array = tmparray.filter(item => item.includes('[') && item.includes(']'));
      const pattern = lastChar === '*' ? request.params.pattern.slice(0, -1) : request.params.pattern;
      const isIncluded = array.filter(item => {
        item = item.slice(1, -1);
        const lastChar = item[item.length - 1];
        item = lastChar === '*' ? item.slice(0, -1) : item;
        return item.includes(pattern) || pattern.includes(item);
      });
      (0, _logger.log)('wazuh-elastic:getTemplate', `Template is valid: ${isIncluded && Array.isArray(isIncluded) && isIncluded.length ? 'yes' : 'no'}`, 'debug');
      return isIncluded && Array.isArray(isIncluded) && isIncluded.length ? response.ok({
        body: {
          statusCode: 200,
          status: true,
          data: `Template found for ${request.params.pattern}`
        }
      }) : response.ok({
        body: {
          statusCode: 200,
          status: false,
          data: `No template found for ${request.params.pattern}`
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:getTemplate', error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Could not retrieve templates from Elasticsearch due to ${error.message || error}`, 4002, 500, response);
    }
  }

  /**
   * This check index-pattern
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */
  async checkPattern(context, request, response) {
    try {
      const data = await context.core.savedObjects.client.find({
        type: 'index-pattern'
      });
      const existsIndexPattern = data.saved_objects.find(item => item.attributes.title === request.params.pattern);
      (0, _logger.log)('wazuh-elastic:checkPattern', `Index pattern found: ${existsIndexPattern ? existsIndexPattern.attributes.title : 'no'}`, 'debug');
      return existsIndexPattern ? response.ok({
        body: {
          statusCode: 200,
          status: true,
          data: 'Index pattern found'
        }
      }) : response.ok({
        body: {
          statusCode: 500,
          status: false,
          error: 10020,
          message: 'Index pattern not found'
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:checkPattern', error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Something went wrong retrieving index-patterns from Elasticsearch due to ${error.message || error}`, 4003, 500, response);
    }
  }

  /**
   * This get the fields keys
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Array<Object>} fields or ErrorResponse
   */
  async getFieldTop(context, request, response) {
    try {
      // Top field payload
      let payload = {
        size: 1,
        query: {
          bool: {
            must: [],
            must_not: {
              term: {
                'agent.id': '000'
              }
            },
            filter: [{
              range: {
                timestamp: {}
              }
            }]
          }
        },
        aggs: {
          '2': {
            terms: {
              field: '',
              size: 1,
              order: {
                _count: 'desc'
              }
            }
          }
        }
      };

      // Set up time interval, default to Last 24h
      const timeGTE = 'now-1d';
      const timeLT = 'now';
      payload.query.bool.filter[0].range['timestamp']['gte'] = timeGTE;
      payload.query.bool.filter[0].range['timestamp']['lt'] = timeLT;

      // Set up match for default cluster name
      payload.query.bool.must.push(request.params.mode === 'cluster' ? {
        match: {
          'cluster.name': request.params.cluster
        }
      } : {
        match: {
          'manager.name': request.params.cluster
        }
      });
      if (request.query.agentsList) payload.query.bool.filter.push({
        terms: {
          'agent.id': request.query.agentsList.split(',')
        }
      });
      payload.aggs['2'].terms.field = request.params.field;
      const data = await context.core.elasticsearch.client.asCurrentUser.search({
        size: 1,
        index: request.params.pattern,
        body: payload
      });
      return data.body.hits.total.value === 0 || typeof data.body.aggregations['2'].buckets[0] === 'undefined' ? response.ok({
        body: {
          statusCode: 200,
          data: ''
        }
      }) : response.ok({
        body: {
          statusCode: 200,
          data: data.body.aggregations['2'].buckets[0].key
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:getFieldTop', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4004, 500, response);
    }
  }

  /**
   * Checks one by one if the requesting user has enough privileges to use
   * an index pattern from the list.
   * @param {Array<Object>} list List of index patterns
   * @param {Object} req
   * @returns {Array<Object>} List of allowed index
   */
  async filterAllowedIndexPatternList(context, list, req) {
    //TODO: review if necesary to delete
    let finalList = [];
    for (let item of list) {
      let results = false,
        forbidden = false;
      try {
        results = await context.core.elasticsearch.client.asCurrentUser.search({
          index: item.title
        });
      } catch (error) {
        forbidden = true;
      }
      if ((((results || {}).body || {}).hits || {}).total.value >= 1 || !forbidden && (((results || {}).body || {}).hits || {}).total === 0) {
        finalList.push(item);
      }
    }
    return finalList;
  }

  /**
   * Checks for minimum index pattern fields in a list of index patterns.
   * @param {Array<Object>} indexPatternList List of index patterns
   */
  validateIndexPattern(indexPatternList) {
    const minimum = ['timestamp', 'rule.groups', 'manager.name', 'agent.id'];
    let list = [];
    for (const index of indexPatternList) {
      let valid, parsed;
      try {
        parsed = JSON.parse(index.attributes.fields);
      } catch (error) {
        continue;
      }
      valid = parsed.filter(item => minimum.includes(item.name));
      if (valid.length === 4) {
        list.push({
          id: index.id,
          title: index.attributes.title
        });
      }
    }
    return list;
  }

  /**
   * Returns current security platform
   * @param {Object} req
   * @param {Object} reply
   * @returns {String}
   */
  async getCurrentPlatform(context, request, response) {
    try {
      return response.ok({
        body: {
          platform: context.wazuh.security.platform
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:getCurrentPlatform', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4011, 500, response);
    }
  }

  /**
   * Replaces visualizations main fields to fit a certain pattern.
   * @param {Array<Object>} app_objects Object containing raw visualizations.
   * @param {String} id Index-pattern id to use in the visualizations. Eg: 'wazuh-alerts'
   */
  async buildVisualizationsRaw(app_objects, id, namespace = false) {
    try {
      const config = (0, _getConfiguration.getConfiguration)();
      let monitoringPattern = (config || {})['wazuh.monitoring.pattern'] || (0, _settings.getSettingDefaultValue)('wazuh.monitoring.pattern');
      (0, _logger.log)('wazuh-elastic:buildVisualizationsRaw', `Building ${app_objects.length} visualizations`, 'debug');
      (0, _logger.log)('wazuh-elastic:buildVisualizationsRaw', `Index pattern ID: ${id}`, 'debug');
      const visArray = [];
      let aux_source, bulk_content;
      for (let element of app_objects) {
        aux_source = JSON.parse(JSON.stringify(element._source));

        // Replace index-pattern for visualizations
        if (aux_source && aux_source.kibanaSavedObjectMeta && aux_source.kibanaSavedObjectMeta.searchSourceJSON && typeof aux_source.kibanaSavedObjectMeta.searchSourceJSON === 'string') {
          const defaultStr = aux_source.kibanaSavedObjectMeta.searchSourceJSON;
          const isMonitoring = defaultStr.includes('wazuh-monitoring');
          if (isMonitoring) {
            if (namespace && namespace !== 'default') {
              if (monitoringPattern.includes(namespace) && monitoringPattern.includes('index-pattern:')) {
                monitoringPattern = monitoringPattern.split('index-pattern:')[1];
              }
            }
            aux_source.kibanaSavedObjectMeta.searchSourceJSON = defaultStr.replace(/wazuh-monitoring/g, monitoringPattern[monitoringPattern.length - 1] === '*' || namespace && namespace !== 'default' ? monitoringPattern : monitoringPattern + '*');
          } else {
            aux_source.kibanaSavedObjectMeta.searchSourceJSON = defaultStr.replace(/wazuh-alerts/g, id);
          }
        }

        // Replace index-pattern for selector visualizations
        if (typeof (aux_source || {}).visState === 'string') {
          aux_source.visState = aux_source.visState.replace(/wazuh-alerts/g, id);
        }

        // Bulk source
        bulk_content = {};
        bulk_content[element._type] = aux_source;
        visArray.push({
          attributes: bulk_content.visualization,
          type: element._type,
          id: element._id,
          _version: bulk_content.visualization.version
        });
      }
      return visArray;
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:buildVisualizationsRaw', error.message || error);
      return Promise.reject(error);
    }
  }

  /**
   * Replaces cluster visualizations main fields.
   * @param {Array<Object>} app_objects Object containing raw visualizations.
   * @param {String} id Index-pattern id to use in the visualizations. Eg: 'wazuh-alerts'
   * @param {Array<String>} nodes Array of node names. Eg: ['node01', 'node02']
   * @param {String} name Cluster name. Eg: 'wazuh'
   * @param {String} master_node Master node name. Eg: 'node01'
   */
  buildClusterVisualizationsRaw(app_objects, id, nodes = [], name, master_node, pattern_name = '*') {
    try {
      const visArray = [];
      let aux_source, bulk_content;
      for (const element of app_objects) {
        // Stringify and replace index-pattern for visualizations
        aux_source = JSON.stringify(element._source);
        aux_source = aux_source.replace(/wazuh-alerts/g, id);
        aux_source = JSON.parse(aux_source);

        // Bulk source
        bulk_content = {};
        bulk_content[element._type] = aux_source;
        const visState = JSON.parse(bulk_content.visualization.visState);
        const title = visState.title;
        if (visState.type && visState.type === 'timelion') {
          let query = '';
          if (title === 'Wazuh App Cluster Overview') {
            for (const node of nodes) {
              query += `.es(index=${pattern_name},q="cluster.name: ${name} AND cluster.node: ${node.name}").label("${node.name}"),`;
            }
            query = query.substring(0, query.length - 1);
          } else if (title === 'Wazuh App Cluster Overview Manager') {
            query += `.es(index=${pattern_name},q="cluster.name: ${name}").label("${name} cluster")`;
          } else {
            if (title.startsWith('Wazuh App Statistics')) {
              const {
                searchSourceJSON
              } = bulk_content.visualization.kibanaSavedObjectMeta;
              bulk_content.visualization.kibanaSavedObjectMeta.searchSourceJSON = searchSourceJSON.replace('wazuh-statistics-*', pattern_name);
            }
            if (title.startsWith('Wazuh App Statistics') && name !== '-' && name !== 'all' && visState.params.expression.includes('q=')) {
              const expressionRegex = /q='\*'/gi;
              const _visState = bulk_content.visualization.visStateByNode ? JSON.parse(bulk_content.visualization.visStateByNode) : visState;
              query += _visState.params.expression.replace(/wazuh-statistics-\*/g, pattern_name).replace(expressionRegex, `q="nodeName.keyword:${name} AND apiName.keyword:${master_node}"`).replace("NODE_NAME", name);
            } else if (title.startsWith('Wazuh App Statistics')) {
              const expressionRegex = /q='\*'/gi;
              query += visState.params.expression.replace(/wazuh-statistics-\*/g, pattern_name).replace(expressionRegex, `q="apiName.keyword:${master_node}"`);
            } else {
              query = visState.params.expression;
            }
          }
          visState.params.expression = query.replace(/'/g, "\"");
          bulk_content.visualization.visState = JSON.stringify(visState);
        }
        visArray.push({
          attributes: bulk_content.visualization,
          type: element._type,
          id: element._id,
          _version: bulk_content.visualization.version
        });
      }
      return visArray;
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:buildClusterVisualizationsRaw', error.message || error);
      return Promise.reject(error);
    }
  }

  /**
   * This creates a visualization of data in req
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} vis obj or ErrorResponse
   */
  async createVis(context, request, response) {
    try {
      if (!request.params.tab.includes('overview-') && !request.params.tab.includes('agents-')) {
        throw new Error('Missing parameters creating visualizations');
      }
      const tabPrefix = request.params.tab.includes('overview') ? 'overview' : 'agents';
      const tabSplit = request.params.tab.split('-');
      const tabSufix = tabSplit[1];
      const file = tabPrefix === 'overview' ? _visualizations.OverviewVisualizations[tabSufix] : _visualizations.AgentsVisualizations[tabSufix];
      if (!file) {
        return response.notFound({
          body: {
            message: `Visualizations not found for ${request.params.tab}`
          }
        });
      }
      (0, _logger.log)('wazuh-elastic:createVis', `${tabPrefix}[${tabSufix}] with index pattern ${request.params.pattern}`, 'debug');
      const namespace = context.wazuh.plugins.spaces && context.wazuh.plugins.spaces.spacesService && context.wazuh.plugins.spaces.spacesService.getSpaceId(request);
      const raw = await this.buildVisualizationsRaw(file, request.params.pattern, namespace);
      return response.ok({
        body: {
          acknowledge: true,
          raw: raw
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:createVis', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4007, 500, response);
    }
  }

  /**
   * This creates a visualization of cluster
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} vis obj or ErrorResponse
   */
  async createClusterVis(context, request, response) {
    try {
      if (!request.params.pattern || !request.params.tab || !request.body || !request.body.nodes || !request.body.nodes.affected_items || !request.body.nodes.name || request.params.tab && !request.params.tab.includes('cluster-')) {
        throw new Error('Missing parameters creating visualizations');
      }
      const type = request.params.tab.split('-')[1];
      const file = _visualizations.ClusterVisualizations[type];
      const nodes = request.body.nodes.affected_items;
      const name = request.body.nodes.name;
      const masterNode = request.body.nodes.master_node;
      const {
        id: patternID,
        title: patternName
      } = request.body.pattern;
      const raw = await this.buildClusterVisualizationsRaw(file, patternID, nodes, name, masterNode, patternName);
      return response.ok({
        body: {
          acknowledge: true,
          raw: raw
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:createClusterVis', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4009, 500, response);
    }
  }

  /**
   * This checks if there is sample alerts
   * GET /elastic/samplealerts
   * @param {*} context
   * @param {*} request
   * @param {*} response
   * {alerts: [...]} or ErrorResponse
   */
  async haveSampleAlerts(context, request, response) {
    try {
      // Check if wazuh sample alerts index exists
      const results = await Promise.all(Object.keys(_constants.WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS).map(category => context.core.elasticsearch.client.asCurrentUser.indices.exists({
        index: this.buildSampleIndexByCategory(category)
      })));
      return response.ok({
        body: {
          sampleAlertsInstalled: results.some(result => result.body)
        }
      });
    } catch (error) {
      return (0, _errorResponse.ErrorResponse)('Sample Alerts category not valid', 1000, 500, response);
    }
  }
  /**
   * This creates sample alerts in wazuh-sample-alerts
   * GET /elastic/samplealerts/{category}
   * @param {*} context
   * @param {*} request
   * @param {*} response
   * {alerts: [...]} or ErrorResponse
   */
  async haveSampleAlertsOfCategory(context, request, response) {
    try {
      const sampleAlertsIndex = this.buildSampleIndexByCategory(request.params.category);
      // Check if wazuh sample alerts index exists
      const existsSampleIndex = await context.core.elasticsearch.client.asCurrentUser.indices.exists({
        index: sampleAlertsIndex
      });
      return response.ok({
        body: {
          index: sampleAlertsIndex,
          exists: existsSampleIndex.body
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:haveSampleAlertsOfCategory', `Error checking if there are sample alerts indices: ${error.message || error}`);
      const [statusCode, errorMessage] = this.getErrorDetails(error);
      return (0, _errorResponse.ErrorResponse)(`Error checking if there are sample alerts indices: ${errorMessage || error}`, 1000, statusCode, response);
    }
  }
  /**
   * This creates sample alerts in wazuh-sample-alerts
   * POST /elastic/samplealerts/{category}
   * {
   *   "manager": {
   *      "name": "manager_name"
   *    },
   *    cluster: {
   *      name: "mycluster",
   *      node: "mynode"
   *    }
   * }
   * @param {*} context
   * @param {*} request
   * @param {*} response
   * {index: string, alerts: [...], count: number} or ErrorResponse
   */
  async createSampleAlerts(context, request, response) {
    const sampleAlertsIndex = this.buildSampleIndexByCategory(request.params.category);
    try {
      // Check if user has administrator role in token
      const token = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-token');
      if (!token) {
        return (0, _errorResponse.ErrorResponse)('No token provided', 401, 401, response);
      }
      ;
      const decodedToken = (0, _jwtDecode.default)(token);
      if (!decodedToken) {
        return (0, _errorResponse.ErrorResponse)('No permissions in token', 401, 401, response);
      }
      ;
      if (!decodedToken.rbac_roles || !decodedToken.rbac_roles.includes(_constants.WAZUH_ROLE_ADMINISTRATOR_ID)) {
        return (0, _errorResponse.ErrorResponse)('No administrator role', 401, 401, response);
      }
      ;
      // Check the provided token is valid
      const apiHostID = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');
      if (!apiHostID) {
        return (0, _errorResponse.ErrorResponse)('No API id provided', 401, 401, response);
      }
      ;
      const responseTokenIsWorking = await context.wazuh.api.client.asCurrentUser.request('GET', `//`, {}, {
        apiHostID
      });
      if (responseTokenIsWorking.status !== 200) {
        return (0, _errorResponse.ErrorResponse)('Token is not valid', 500, 500, response);
      }
      ;
      const bulkPrefix = JSON.stringify({
        index: {
          _index: sampleAlertsIndex
        }
      });
      const alertGenerateParams = request.body && request.body.params || {};
      const sampleAlerts = _constants.WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS[request.params.category].map(typeAlert => (0, _generateAlertsScript.generateAlerts)({
        ...typeAlert,
        ...alertGenerateParams
      }, request.body.alerts || typeAlert.alerts || _constants.WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS)).flat();
      const bulk = sampleAlerts.map(sampleAlert => `${bulkPrefix}\n${JSON.stringify(sampleAlert)}\n`).join('');

      // Index alerts

      // Check if wazuh sample alerts index exists
      const existsSampleIndex = await context.core.elasticsearch.client.asCurrentUser.indices.exists({
        index: sampleAlertsIndex
      });
      if (!existsSampleIndex.body) {
        // Create wazuh sample alerts index

        const configuration = {
          settings: {
            index: {
              number_of_shards: _constants.WAZUH_SAMPLE_ALERTS_INDEX_SHARDS,
              number_of_replicas: _constants.WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS
            }
          }
        };
        await context.core.elasticsearch.client.asCurrentUser.indices.create({
          index: sampleAlertsIndex,
          body: configuration
        });
        (0, _logger.log)('wazuh-elastic:createSampleAlerts', `Created ${sampleAlertsIndex} index`, 'debug');
      }
      await context.core.elasticsearch.client.asCurrentUser.bulk({
        index: sampleAlertsIndex,
        body: bulk
      });
      (0, _logger.log)('wazuh-elastic:createSampleAlerts', `Added sample alerts to ${sampleAlertsIndex} index`, 'debug');
      return response.ok({
        body: {
          index: sampleAlertsIndex,
          alertCount: sampleAlerts.length
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:createSampleAlerts', `Error adding sample alerts to ${sampleAlertsIndex} index: ${error.message || error}`);
      const [statusCode, errorMessage] = this.getErrorDetails(error);
      return (0, _errorResponse.ErrorResponse)(errorMessage || error, 1000, statusCode, response);
    }
  }
  /**
   * This deletes sample alerts
   * @param {*} context
   * @param {*} request
   * @param {*} response
   * {result: "deleted", index: string} or ErrorResponse
   */
  async deleteSampleAlerts(context, request, response) {
    // Delete Wazuh sample alert index

    const sampleAlertsIndex = this.buildSampleIndexByCategory(request.params.category);
    try {
      // Check if user has administrator role in token
      const token = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-token');
      if (!token) {
        return (0, _errorResponse.ErrorResponse)('No token provided', 401, 401, response);
      }
      ;
      const decodedToken = (0, _jwtDecode.default)(token);
      if (!decodedToken) {
        return (0, _errorResponse.ErrorResponse)('No permissions in token', 401, 401, response);
      }
      ;
      if (!decodedToken.rbac_roles || !decodedToken.rbac_roles.includes(_constants.WAZUH_ROLE_ADMINISTRATOR_ID)) {
        return (0, _errorResponse.ErrorResponse)('No administrator role', 401, 401, response);
      }
      ;
      // Check the provided token is valid
      const apiHostID = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');
      if (!apiHostID) {
        return (0, _errorResponse.ErrorResponse)('No API id provided', 401, 401, response);
      }
      ;
      const responseTokenIsWorking = await context.wazuh.api.client.asCurrentUser.request('GET', `//`, {}, {
        apiHostID
      });
      if (responseTokenIsWorking.status !== 200) {
        return (0, _errorResponse.ErrorResponse)('Token is not valid', 500, 500, response);
      }
      ;

      // Check if Wazuh sample alerts index exists
      const existsSampleIndex = await context.core.elasticsearch.client.asCurrentUser.indices.exists({
        index: sampleAlertsIndex
      });
      if (existsSampleIndex.body) {
        // Delete Wazuh sample alerts index
        await context.core.elasticsearch.client.asCurrentUser.indices.delete({
          index: sampleAlertsIndex
        });
        (0, _logger.log)('wazuh-elastic:deleteSampleAlerts', `Deleted ${sampleAlertsIndex} index`, 'debug');
        return response.ok({
          body: {
            result: 'deleted',
            index: sampleAlertsIndex
          }
        });
      } else {
        return (0, _errorResponse.ErrorResponse)(`${sampleAlertsIndex} index doesn't exist`, 1000, 500, response);
      }
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:deleteSampleAlerts', `Error deleting sample alerts of ${sampleAlertsIndex} index: ${error.message || error}`);
      const [statusCode, errorMessage] = this.getErrorDetails(error);
      return (0, _errorResponse.ErrorResponse)(errorMessage || error, 1000, statusCode, response);
    }
  }
  async alerts(context, request, response) {
    try {
      const data = await context.core.elasticsearch.client.asCurrentUser.search(request.body);
      return response.ok({
        body: data.body
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:alerts', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 4010, 500, response);
    }
  }

  // Check if there are indices for Statistics
  async existStatisticsIndices(context, request, response) {
    try {
      const config = (0, _getConfiguration.getConfiguration)();
      const statisticsPattern = `${config['cron.prefix'] || 'wazuh'}-${config['cron.statistics.index.name'] || 'statistics'}*`; //TODO: replace by default as constants instead hardcoded ('wazuh' and 'statistics')
      const existIndex = await context.core.elasticsearch.client.asCurrentUser.indices.exists({
        index: statisticsPattern,
        allow_no_indices: false
      });
      return response.ok({
        body: existIndex.body
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:existsStatisticsIndices', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 1000, 500, response);
    }
  }

  // Check if there are indices for Monitoring
  async existMonitoringIndices(context, request, response) {
    try {
      const config = (0, _getConfiguration.getConfiguration)();
      const monitoringIndexPattern = config['wazuh.monitoring.pattern'] || (0, _settings.getSettingDefaultValue)('wazuh.monitoring.pattern');
      const existIndex = await context.core.elasticsearch.client.asCurrentUser.indices.exists({
        index: monitoringIndexPattern,
        allow_no_indices: false
      });
      return response.ok({
        body: existIndex.body
      });
    } catch (error) {
      (0, _logger.log)('wazuh-elastic:existsMonitoringIndices', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 1000, 500, response);
    }
  }
  async usingCredentials(context) {
    try {
      const data = await context.core.elasticsearch.client.asInternalUser.cluster.getSettings({
        include_defaults: true
      });
      return (((((data || {}).body || {}).defaults || {}).xpack || {}).security || {}).user !== null;
    } catch (error) {
      return Promise.reject(error);
    }
  }
  getErrorDetails(error) {
    var _error$meta;
    const statusCode = (error === null || error === void 0 ? void 0 : (_error$meta = error.meta) === null || _error$meta === void 0 ? void 0 : _error$meta.statusCode) || 500;
    let errorMessage = error.message;
    if (statusCode === 403) {
      var _error$meta2, _error$meta2$body, _error$meta2$body$err;
      errorMessage = (error === null || error === void 0 ? void 0 : (_error$meta2 = error.meta) === null || _error$meta2 === void 0 ? void 0 : (_error$meta2$body = _error$meta2.body) === null || _error$meta2$body === void 0 ? void 0 : (_error$meta2$body$err = _error$meta2$body.error) === null || _error$meta2$body$err === void 0 ? void 0 : _error$meta2$body$err.reason) || 'Permission denied';
    }
    return [statusCode, errorMessage];
  }
}
exports.WazuhElasticCtrl = WazuhElasticCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZXJyb3JSZXNwb25zZSIsInJlcXVpcmUiLCJfbG9nZ2VyIiwiX2dldENvbmZpZ3VyYXRpb24iLCJfdmlzdWFsaXphdGlvbnMiLCJfZ2VuZXJhdGVBbGVydHNTY3JpcHQiLCJfY29uc3RhbnRzIiwiX2p3dERlY29kZSIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfbWFuYWdlSG9zdHMiLCJfY29va2llIiwiX3NldHRpbmdzIiwiV2F6dWhFbGFzdGljQ3RybCIsImNvbnN0cnVjdG9yIiwiX2RlZmluZVByb3BlcnR5MiIsImRlZmF1bHQiLCJ3elNhbXBsZUFsZXJ0c0luZGV4UHJlZml4IiwiZ2V0U2FtcGxlQWxlcnRQcmVmaXgiLCJtYW5hZ2VIb3N0cyIsIk1hbmFnZUhvc3RzIiwiYnVpbGRTYW1wbGVJbmRleEJ5Q2F0ZWdvcnkiLCJjYXRlZ29yeSIsImNvbmZpZyIsImdldENvbmZpZ3VyYXRpb24iLCJnZXRTZXR0aW5nRGVmYXVsdFZhbHVlIiwiZ2V0VGVtcGxhdGUiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiZGF0YSIsImNvcmUiLCJlbGFzdGljc2VhcmNoIiwiY2xpZW50IiwiYXNJbnRlcm5hbFVzZXIiLCJjYXQiLCJ0ZW1wbGF0ZXMiLCJib2R5IiwiRXJyb3IiLCJsYXN0Q2hhciIsInBhcmFtcyIsInBhdHRlcm4iLCJsZW5ndGgiLCJ0bXBkYXRhIiwibWF0Y2giLCJ0bXBhcnJheSIsIml0ZW0iLCJpbmNsdWRlcyIsInN1YnN0ciIsInNsaWNlIiwic3ViSXRlbXMiLCJzcGxpdCIsInN1Yml0ZW0iLCJwdXNoIiwidHJpbSIsImFycmF5IiwiZmlsdGVyIiwiaXNJbmNsdWRlZCIsImxvZyIsIkFycmF5IiwiaXNBcnJheSIsIm9rIiwic3RhdHVzQ29kZSIsInN0YXR1cyIsImVycm9yIiwibWVzc2FnZSIsIkVycm9yUmVzcG9uc2UiLCJjaGVja1BhdHRlcm4iLCJzYXZlZE9iamVjdHMiLCJmaW5kIiwidHlwZSIsImV4aXN0c0luZGV4UGF0dGVybiIsInNhdmVkX29iamVjdHMiLCJhdHRyaWJ1dGVzIiwidGl0bGUiLCJnZXRGaWVsZFRvcCIsInBheWxvYWQiLCJzaXplIiwicXVlcnkiLCJib29sIiwibXVzdCIsIm11c3Rfbm90IiwidGVybSIsInJhbmdlIiwidGltZXN0YW1wIiwiYWdncyIsInRlcm1zIiwiZmllbGQiLCJvcmRlciIsIl9jb3VudCIsInRpbWVHVEUiLCJ0aW1lTFQiLCJtb2RlIiwiY2x1c3RlciIsImFnZW50c0xpc3QiLCJhc0N1cnJlbnRVc2VyIiwic2VhcmNoIiwiaW5kZXgiLCJoaXRzIiwidG90YWwiLCJ2YWx1ZSIsImFnZ3JlZ2F0aW9ucyIsImJ1Y2tldHMiLCJrZXkiLCJmaWx0ZXJBbGxvd2VkSW5kZXhQYXR0ZXJuTGlzdCIsImxpc3QiLCJyZXEiLCJmaW5hbExpc3QiLCJyZXN1bHRzIiwiZm9yYmlkZGVuIiwidmFsaWRhdGVJbmRleFBhdHRlcm4iLCJpbmRleFBhdHRlcm5MaXN0IiwibWluaW11bSIsInZhbGlkIiwicGFyc2VkIiwiSlNPTiIsInBhcnNlIiwiZmllbGRzIiwibmFtZSIsImlkIiwiZ2V0Q3VycmVudFBsYXRmb3JtIiwicGxhdGZvcm0iLCJ3YXp1aCIsInNlY3VyaXR5IiwiYnVpbGRWaXN1YWxpemF0aW9uc1JhdyIsImFwcF9vYmplY3RzIiwibmFtZXNwYWNlIiwibW9uaXRvcmluZ1BhdHRlcm4iLCJ2aXNBcnJheSIsImF1eF9zb3VyY2UiLCJidWxrX2NvbnRlbnQiLCJlbGVtZW50Iiwic3RyaW5naWZ5IiwiX3NvdXJjZSIsImtpYmFuYVNhdmVkT2JqZWN0TWV0YSIsInNlYXJjaFNvdXJjZUpTT04iLCJkZWZhdWx0U3RyIiwiaXNNb25pdG9yaW5nIiwicmVwbGFjZSIsInZpc1N0YXRlIiwiX3R5cGUiLCJ2aXN1YWxpemF0aW9uIiwiX2lkIiwiX3ZlcnNpb24iLCJ2ZXJzaW9uIiwiUHJvbWlzZSIsInJlamVjdCIsImJ1aWxkQ2x1c3RlclZpc3VhbGl6YXRpb25zUmF3Iiwibm9kZXMiLCJtYXN0ZXJfbm9kZSIsInBhdHRlcm5fbmFtZSIsIm5vZGUiLCJzdWJzdHJpbmciLCJzdGFydHNXaXRoIiwiZXhwcmVzc2lvbiIsImV4cHJlc3Npb25SZWdleCIsIl92aXNTdGF0ZSIsInZpc1N0YXRlQnlOb2RlIiwiY3JlYXRlVmlzIiwidGFiIiwidGFiUHJlZml4IiwidGFiU3BsaXQiLCJ0YWJTdWZpeCIsImZpbGUiLCJPdmVydmlld1Zpc3VhbGl6YXRpb25zIiwiQWdlbnRzVmlzdWFsaXphdGlvbnMiLCJub3RGb3VuZCIsInBsdWdpbnMiLCJzcGFjZXMiLCJzcGFjZXNTZXJ2aWNlIiwiZ2V0U3BhY2VJZCIsInJhdyIsImFja25vd2xlZGdlIiwiY3JlYXRlQ2x1c3RlclZpcyIsImFmZmVjdGVkX2l0ZW1zIiwiQ2x1c3RlclZpc3VhbGl6YXRpb25zIiwibWFzdGVyTm9kZSIsInBhdHRlcm5JRCIsInBhdHRlcm5OYW1lIiwiaGF2ZVNhbXBsZUFsZXJ0cyIsImFsbCIsIk9iamVjdCIsImtleXMiLCJXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JJRVNfVFlQRV9BTEVSVFMiLCJtYXAiLCJpbmRpY2VzIiwiZXhpc3RzIiwic2FtcGxlQWxlcnRzSW5zdGFsbGVkIiwic29tZSIsInJlc3VsdCIsImhhdmVTYW1wbGVBbGVydHNPZkNhdGVnb3J5Iiwic2FtcGxlQWxlcnRzSW5kZXgiLCJleGlzdHNTYW1wbGVJbmRleCIsImVycm9yTWVzc2FnZSIsImdldEVycm9yRGV0YWlscyIsImNyZWF0ZVNhbXBsZUFsZXJ0cyIsInRva2VuIiwiZ2V0Q29va2llVmFsdWVCeU5hbWUiLCJoZWFkZXJzIiwiY29va2llIiwiZGVjb2RlZFRva2VuIiwiand0RGVjb2RlIiwicmJhY19yb2xlcyIsIldBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9JRCIsImFwaUhvc3RJRCIsInJlc3BvbnNlVG9rZW5Jc1dvcmtpbmciLCJhcGkiLCJidWxrUHJlZml4IiwiX2luZGV4IiwiYWxlcnRHZW5lcmF0ZVBhcmFtcyIsInNhbXBsZUFsZXJ0cyIsInR5cGVBbGVydCIsImdlbmVyYXRlQWxlcnRzIiwiYWxlcnRzIiwiV0FaVUhfU0FNUExFX0FMRVJUU19ERUZBVUxUX05VTUJFUl9BTEVSVFMiLCJmbGF0IiwiYnVsayIsInNhbXBsZUFsZXJ0Iiwiam9pbiIsImNvbmZpZ3VyYXRpb24iLCJzZXR0aW5ncyIsIm51bWJlcl9vZl9zaGFyZHMiLCJXQVpVSF9TQU1QTEVfQUxFUlRTX0lOREVYX1NIQVJEUyIsIm51bWJlcl9vZl9yZXBsaWNhcyIsIldBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfUkVQTElDQVMiLCJjcmVhdGUiLCJhbGVydENvdW50IiwiZGVsZXRlU2FtcGxlQWxlcnRzIiwiZGVsZXRlIiwiZXhpc3RTdGF0aXN0aWNzSW5kaWNlcyIsInN0YXRpc3RpY3NQYXR0ZXJuIiwiZXhpc3RJbmRleCIsImFsbG93X25vX2luZGljZXMiLCJleGlzdE1vbml0b3JpbmdJbmRpY2VzIiwibW9uaXRvcmluZ0luZGV4UGF0dGVybiIsInVzaW5nQ3JlZGVudGlhbHMiLCJnZXRTZXR0aW5ncyIsImluY2x1ZGVfZGVmYXVsdHMiLCJkZWZhdWx0cyIsInhwYWNrIiwidXNlciIsIl9lcnJvciRtZXRhIiwibWV0YSIsIl9lcnJvciRtZXRhMiIsIl9lcnJvciRtZXRhMiRib2R5IiwiX2Vycm9yJG1ldGEyJGJvZHkkZXJyIiwicmVhc29uIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbIndhenVoLWVsYXN0aWMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIGFwcCAtIENsYXNzIGZvciBXYXp1aC1FbGFzdGljIGZ1bmN0aW9uc1xuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmltcG9ydCB7IEVycm9yUmVzcG9uc2UgfSBmcm9tICcuLi9saWIvZXJyb3ItcmVzcG9uc2UnO1xuaW1wb3J0IHsgbG9nIH0gZnJvbSAnLi4vbGliL2xvZ2dlcic7XG5pbXBvcnQgeyBnZXRDb25maWd1cmF0aW9uIH0gZnJvbSAnLi4vbGliL2dldC1jb25maWd1cmF0aW9uJztcbmltcG9ydCB7XG4gIEFnZW50c1Zpc3VhbGl6YXRpb25zLFxuICBPdmVydmlld1Zpc3VhbGl6YXRpb25zLFxuICBDbHVzdGVyVmlzdWFsaXphdGlvbnNcbn0gZnJvbSAnLi4vaW50ZWdyYXRpb24tZmlsZXMvdmlzdWFsaXphdGlvbnMnO1xuXG5pbXBvcnQgeyBnZW5lcmF0ZUFsZXJ0cyB9IGZyb20gJy4uL2xpYi9nZW5lcmF0ZS1hbGVydHMvZ2VuZXJhdGUtYWxlcnRzLXNjcmlwdCc7XG5pbXBvcnQgeyBXQVpVSF9ST0xFX0FETUlOSVNUUkFUT1JfSUQsIFdBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfU0hBUkRTLCBXQVpVSF9TQU1QTEVfQUxFUlRTX0lOREVYX1JFUExJQ0FTIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQgand0RGVjb2RlIGZyb20gJ2p3dC1kZWNvZGUnO1xuaW1wb3J0IHsgTWFuYWdlSG9zdHMgfSBmcm9tICcuLi9saWIvbWFuYWdlLWhvc3RzJztcbmltcG9ydCB7IEtpYmFuYVJlcXVlc3QsIFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgS2liYW5hUmVzcG9uc2VGYWN0b3J5LCBTYXZlZE9iamVjdCwgU2F2ZWRPYmplY3RzRmluZFJlc3BvbnNlIH0gZnJvbSAnc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IGdldENvb2tpZVZhbHVlQnlOYW1lIH0gZnJvbSAnLi4vbGliL2Nvb2tpZSc7XG5pbXBvcnQgeyBXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JJRVNfVFlQRV9BTEVSVFMsIFdBWlVIX1NBTVBMRV9BTEVSVFNfREVGQVVMVF9OVU1CRVJfQUxFUlRTIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cydcbmltcG9ydCB7IGdldFNldHRpbmdEZWZhdWx0VmFsdWUgfSBmcm9tICcuLi8uLi9jb21tb24vc2VydmljZXMvc2V0dGluZ3MnO1xuXG5leHBvcnQgY2xhc3MgV2F6dWhFbGFzdGljQ3RybCB7XG4gIHd6U2FtcGxlQWxlcnRzSW5kZXhQcmVmaXg6IHN0cmluZ1xuICBtYW5hZ2VIb3N0czogTWFuYWdlSG9zdHNcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy53elNhbXBsZUFsZXJ0c0luZGV4UHJlZml4ID0gdGhpcy5nZXRTYW1wbGVBbGVydFByZWZpeCgpO1xuICAgIHRoaXMubWFuYWdlSG9zdHMgPSBuZXcgTWFuYWdlSG9zdHMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIHJldHVybnMgdGhlIGluZGV4IGFjY29yZGluZyB0aGUgY2F0ZWdvcnlcbiAgICogQHBhcmFtIHtzdHJpbmd9IGNhdGVnb3J5XG4gICAqL1xuICBidWlsZFNhbXBsZUluZGV4QnlDYXRlZ29yeShjYXRlZ29yeTogc3RyaW5nKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYCR7dGhpcy53elNhbXBsZUFsZXJ0c0luZGV4UHJlZml4fXNhbXBsZS0ke2NhdGVnb3J5fWA7XG4gIH1cblxuICAvKipcbiAgICogVGhpcyByZXR1cm5zIHRoZSBkZWZpbmVkIGNvbmZpZyBmb3Igc2FtcGxlIGFsZXJ0cyBwcmVmaXggb3IgdGhlIGRlZmF1bHQgdmFsdWUuXG4gICAqL1xuICBnZXRTYW1wbGVBbGVydFByZWZpeCgpOiBzdHJpbmcge1xuICAgIGNvbnN0IGNvbmZpZyA9IGdldENvbmZpZ3VyYXRpb24oKTtcbiAgICByZXR1cm4gY29uZmlnWydhbGVydHMuc2FtcGxlLnByZWZpeCddIHx8IGdldFNldHRpbmdEZWZhdWx0VmFsdWUoJ2FsZXJ0cy5zYW1wbGUucHJlZml4Jyk7XG4gIH1cblxuICAvKipcbiAgICogVGhpcyByZXRyaWV2ZXMgYSB0ZW1wbGF0ZSBmcm9tIEVsYXN0aWNzZWFyY2hcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IHRlbXBsYXRlIG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGdldFRlbXBsYXRlKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdDx7IHBhdHRlcm46IHN0cmluZyB9PiwgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgY29udGV4dC5jb3JlLmVsYXN0aWNzZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmNhdC50ZW1wbGF0ZXMoKTtcblxuICAgICAgY29uc3QgdGVtcGxhdGVzID0gZGF0YS5ib2R5O1xuICAgICAgaWYgKCF0ZW1wbGF0ZXMgfHwgdHlwZW9mIHRlbXBsYXRlcyAhPT0gJ3N0cmluZycpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICdBbiB1bmtub3duIGVycm9yIG9jY3VycmVkIHdoZW4gZmV0Y2hpbmcgdGVtcGxhdGVzIGZyb20gRWxhc3RpY3NlYWNoJ1xuICAgICAgICApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBsYXN0Q2hhciA9IHJlcXVlc3QucGFyYW1zLnBhdHRlcm5bcmVxdWVzdC5wYXJhbXMucGF0dGVybi5sZW5ndGggLSAxXTtcblxuICAgICAgLy8gU3BsaXQgaW50byBzZXBhcmF0ZSBwYXR0ZXJuc1xuICAgICAgY29uc3QgdG1wZGF0YSA9IHRlbXBsYXRlcy5tYXRjaCgvXFxbLipcXF0vZyk7XG4gICAgICBjb25zdCB0bXBhcnJheSA9IFtdO1xuICAgICAgZm9yIChsZXQgaXRlbSBvZiB0bXBkYXRhKSB7XG4gICAgICAgIC8vIEEgdGVtcGxhdGUgbWlnaHQgdXNlIG1vcmUgdGhhbiBvbmUgcGF0dGVyblxuICAgICAgICBpZiAoaXRlbS5pbmNsdWRlcygnLCcpKSB7XG4gICAgICAgICAgaXRlbSA9IGl0ZW0uc3Vic3RyKDEpLnNsaWNlKDAsIC0xKTtcbiAgICAgICAgICBjb25zdCBzdWJJdGVtcyA9IGl0ZW0uc3BsaXQoJywnKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IHN1Yml0ZW0gb2Ygc3ViSXRlbXMpIHtcbiAgICAgICAgICAgIHRtcGFycmF5LnB1c2goYFske3N1Yml0ZW0udHJpbSgpfV1gKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdG1wYXJyYXkucHVzaChpdGVtKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBFbnN1cmUgd2UgYXJlIGhhbmRsaW5nIGp1c3QgcGF0dGVybnNcbiAgICAgIGNvbnN0IGFycmF5ID0gdG1wYXJyYXkuZmlsdGVyKFxuICAgICAgICBpdGVtID0+IGl0ZW0uaW5jbHVkZXMoJ1snKSAmJiBpdGVtLmluY2x1ZGVzKCddJylcbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IHBhdHRlcm4gPVxuICAgICAgICBsYXN0Q2hhciA9PT0gJyonID8gcmVxdWVzdC5wYXJhbXMucGF0dGVybi5zbGljZSgwLCAtMSkgOiByZXF1ZXN0LnBhcmFtcy5wYXR0ZXJuO1xuICAgICAgY29uc3QgaXNJbmNsdWRlZCA9IGFycmF5LmZpbHRlcihpdGVtID0+IHtcbiAgICAgICAgaXRlbSA9IGl0ZW0uc2xpY2UoMSwgLTEpO1xuICAgICAgICBjb25zdCBsYXN0Q2hhciA9IGl0ZW1baXRlbS5sZW5ndGggLSAxXTtcbiAgICAgICAgaXRlbSA9IGxhc3RDaGFyID09PSAnKicgPyBpdGVtLnNsaWNlKDAsIC0xKSA6IGl0ZW07XG4gICAgICAgIHJldHVybiBpdGVtLmluY2x1ZGVzKHBhdHRlcm4pIHx8IHBhdHRlcm4uaW5jbHVkZXMoaXRlbSk7XG4gICAgICB9KTtcbiAgICAgIGxvZyhcbiAgICAgICAgJ3dhenVoLWVsYXN0aWM6Z2V0VGVtcGxhdGUnLFxuICAgICAgICBgVGVtcGxhdGUgaXMgdmFsaWQ6ICR7aXNJbmNsdWRlZCAmJiBBcnJheS5pc0FycmF5KGlzSW5jbHVkZWQpICYmIGlzSW5jbHVkZWQubGVuZ3RoXG4gICAgICAgICAgPyAneWVzJ1xuICAgICAgICAgIDogJ25vJ1xuICAgICAgICB9YCxcbiAgICAgICAgJ2RlYnVnJ1xuICAgICAgKTtcbiAgICAgIHJldHVybiBpc0luY2x1ZGVkICYmIEFycmF5LmlzQXJyYXkoaXNJbmNsdWRlZCkgJiYgaXNJbmNsdWRlZC5sZW5ndGhcbiAgICAgICAgPyByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICAgICAgc3RhdHVzOiB0cnVlLFxuICAgICAgICAgICAgZGF0YTogYFRlbXBsYXRlIGZvdW5kIGZvciAke3JlcXVlc3QucGFyYW1zLnBhdHRlcm59YFxuICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgICAgOiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICAgICAgc3RhdHVzOiBmYWxzZSxcbiAgICAgICAgICAgIGRhdGE6IGBObyB0ZW1wbGF0ZSBmb3VuZCBmb3IgJHtyZXF1ZXN0LnBhcmFtcy5wYXR0ZXJufWBcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6Z2V0VGVtcGxhdGUnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICBgQ291bGQgbm90IHJldHJpZXZlIHRlbXBsYXRlcyBmcm9tIEVsYXN0aWNzZWFyY2ggZHVlIHRvICR7ZXJyb3IubWVzc2FnZSB8fFxuICAgICAgICBlcnJvcn1gLFxuICAgICAgICA0MDAyLFxuICAgICAgICA1MDAsXG4gICAgICAgIHJlc3BvbnNlXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGNoZWNrIGluZGV4LXBhdHRlcm5cbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IHN0YXR1cyBvYmogb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgY2hlY2tQYXR0ZXJuKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdDx7IHBhdHRlcm46IHN0cmluZyB9PiwgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgY29udGV4dC5jb3JlLnNhdmVkT2JqZWN0cy5jbGllbnQuZmluZDxTYXZlZE9iamVjdHNGaW5kUmVzcG9uc2U8U2F2ZWRPYmplY3Q+Pih7IHR5cGU6ICdpbmRleC1wYXR0ZXJuJyB9KTtcblxuICAgICAgY29uc3QgZXhpc3RzSW5kZXhQYXR0ZXJuID0gZGF0YS5zYXZlZF9vYmplY3RzLmZpbmQoXG4gICAgICAgIGl0ZW0gPT4gaXRlbS5hdHRyaWJ1dGVzLnRpdGxlID09PSByZXF1ZXN0LnBhcmFtcy5wYXR0ZXJuXG4gICAgICApO1xuICAgICAgbG9nKFxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpjaGVja1BhdHRlcm4nLFxuICAgICAgICBgSW5kZXggcGF0dGVybiBmb3VuZDogJHtleGlzdHNJbmRleFBhdHRlcm4gPyBleGlzdHNJbmRleFBhdHRlcm4uYXR0cmlidXRlcy50aXRsZSA6ICdubyd9YCxcbiAgICAgICAgJ2RlYnVnJ1xuICAgICAgKTtcbiAgICAgIHJldHVybiBleGlzdHNJbmRleFBhdHRlcm5cbiAgICAgICAgPyByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogeyBzdGF0dXNDb2RlOiAyMDAsIHN0YXR1czogdHJ1ZSwgZGF0YTogJ0luZGV4IHBhdHRlcm4gZm91bmQnIH1cbiAgICAgICAgfSlcbiAgICAgICAgOiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogNTAwLFxuICAgICAgICAgICAgc3RhdHVzOiBmYWxzZSxcbiAgICAgICAgICAgIGVycm9yOiAxMDAyMCxcbiAgICAgICAgICAgIG1lc3NhZ2U6ICdJbmRleCBwYXR0ZXJuIG5vdCBmb3VuZCdcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6Y2hlY2tQYXR0ZXJuJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgYFNvbWV0aGluZyB3ZW50IHdyb25nIHJldHJpZXZpbmcgaW5kZXgtcGF0dGVybnMgZnJvbSBFbGFzdGljc2VhcmNoIGR1ZSB0byAke2Vycm9yLm1lc3NhZ2UgfHxcbiAgICAgICAgZXJyb3J9YCxcbiAgICAgICAgNDAwMyxcbiAgICAgICAgNTAwLFxuICAgICAgICByZXNwb25zZVxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBnZXQgdGhlIGZpZWxkcyBrZXlzXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7QXJyYXk8T2JqZWN0Pn0gZmllbGRzIG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGdldEZpZWxkVG9wKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdDx7IG1vZGU6IHN0cmluZywgY2x1c3Rlcjogc3RyaW5nLCBmaWVsZDogc3RyaW5nLCBwYXR0ZXJuOiBzdHJpbmcgfSwgeyBhZ2VudHNMaXN0OiBzdHJpbmcgfT4sIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnkpIHtcbiAgICB0cnkge1xuICAgICAgLy8gVG9wIGZpZWxkIHBheWxvYWRcbiAgICAgIGxldCBwYXlsb2FkID0ge1xuICAgICAgICBzaXplOiAxLFxuICAgICAgICBxdWVyeToge1xuICAgICAgICAgIGJvb2w6IHtcbiAgICAgICAgICAgIG11c3Q6IFtdLFxuICAgICAgICAgICAgbXVzdF9ub3Q6IHtcbiAgICAgICAgICAgICAgdGVybToge1xuICAgICAgICAgICAgICAgICdhZ2VudC5pZCc6ICcwMDAnXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBmaWx0ZXI6IFtcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHJhbmdlOiB7IHRpbWVzdGFtcDoge30gfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBdXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBhZ2dzOiB7XG4gICAgICAgICAgJzInOiB7XG4gICAgICAgICAgICB0ZXJtczoge1xuICAgICAgICAgICAgICBmaWVsZDogJycsXG4gICAgICAgICAgICAgIHNpemU6IDEsXG4gICAgICAgICAgICAgIG9yZGVyOiB7IF9jb3VudDogJ2Rlc2MnIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIC8vIFNldCB1cCB0aW1lIGludGVydmFsLCBkZWZhdWx0IHRvIExhc3QgMjRoXG4gICAgICBjb25zdCB0aW1lR1RFID0gJ25vdy0xZCc7XG4gICAgICBjb25zdCB0aW1lTFQgPSAnbm93JztcbiAgICAgIHBheWxvYWQucXVlcnkuYm9vbC5maWx0ZXJbMF0ucmFuZ2VbJ3RpbWVzdGFtcCddWydndGUnXSA9IHRpbWVHVEU7XG4gICAgICBwYXlsb2FkLnF1ZXJ5LmJvb2wuZmlsdGVyWzBdLnJhbmdlWyd0aW1lc3RhbXAnXVsnbHQnXSA9IHRpbWVMVDtcblxuICAgICAgLy8gU2V0IHVwIG1hdGNoIGZvciBkZWZhdWx0IGNsdXN0ZXIgbmFtZVxuICAgICAgcGF5bG9hZC5xdWVyeS5ib29sLm11c3QucHVzaChcbiAgICAgICAgcmVxdWVzdC5wYXJhbXMubW9kZSA9PT0gJ2NsdXN0ZXInXG4gICAgICAgICAgPyB7IG1hdGNoOiB7ICdjbHVzdGVyLm5hbWUnOiByZXF1ZXN0LnBhcmFtcy5jbHVzdGVyIH0gfVxuICAgICAgICAgIDogeyBtYXRjaDogeyAnbWFuYWdlci5uYW1lJzogcmVxdWVzdC5wYXJhbXMuY2x1c3RlciB9IH1cbiAgICAgICk7XG5cbiAgICAgIGlmKHJlcXVlc3QucXVlcnkuYWdlbnRzTGlzdClcbiAgICAgICAgcGF5bG9hZC5xdWVyeS5ib29sLmZpbHRlci5wdXNoKFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHRlcm1zOiB7XG4gICAgICAgICAgICAgICdhZ2VudC5pZCc6IHJlcXVlc3QucXVlcnkuYWdlbnRzTGlzdC5zcGxpdCgnLCcpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgcGF5bG9hZC5hZ2dzWycyJ10udGVybXMuZmllbGQgPSByZXF1ZXN0LnBhcmFtcy5maWVsZDtcblxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLnNlYXJjaCh7XG4gICAgICAgIHNpemU6IDEsXG4gICAgICAgIGluZGV4OiByZXF1ZXN0LnBhcmFtcy5wYXR0ZXJuLFxuICAgICAgICBib2R5OiBwYXlsb2FkXG4gICAgICB9KTtcblxuICAgICAgcmV0dXJuIGRhdGEuYm9keS5oaXRzLnRvdGFsLnZhbHVlID09PSAwIHx8XG4gICAgICAgIHR5cGVvZiBkYXRhLmJvZHkuYWdncmVnYXRpb25zWycyJ10uYnVja2V0c1swXSA9PT0gJ3VuZGVmaW5lZCdcbiAgICAgICAgPyByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogeyBzdGF0dXNDb2RlOiAyMDAsIGRhdGE6ICcnIH1cbiAgICAgICAgfSlcbiAgICAgICAgOiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICAgICAgZGF0YTogZGF0YS5ib2R5LmFnZ3JlZ2F0aW9uc1snMiddLmJ1Y2tldHNbMF0ua2V5XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCd3YXp1aC1lbGFzdGljOmdldEZpZWxkVG9wJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA0MDA0LCA1MDAsIHJlc3BvbnNlKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIG9uZSBieSBvbmUgaWYgdGhlIHJlcXVlc3RpbmcgdXNlciBoYXMgZW5vdWdoIHByaXZpbGVnZXMgdG8gdXNlXG4gICAqIGFuIGluZGV4IHBhdHRlcm4gZnJvbSB0aGUgbGlzdC5cbiAgICogQHBhcmFtIHtBcnJheTxPYmplY3Q+fSBsaXN0IExpc3Qgb2YgaW5kZXggcGF0dGVybnNcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcVxuICAgKiBAcmV0dXJucyB7QXJyYXk8T2JqZWN0Pn0gTGlzdCBvZiBhbGxvd2VkIGluZGV4XG4gICAqL1xuICBhc3luYyBmaWx0ZXJBbGxvd2VkSW5kZXhQYXR0ZXJuTGlzdChjb250ZXh0LCBsaXN0LCByZXEpIHtcbiAgICAvL1RPRE86IHJldmlldyBpZiBuZWNlc2FyeSB0byBkZWxldGVcbiAgICBsZXQgZmluYWxMaXN0ID0gW107XG4gICAgZm9yIChsZXQgaXRlbSBvZiBsaXN0KSB7XG4gICAgICBsZXQgcmVzdWx0cyA9IGZhbHNlLFxuICAgICAgICBmb3JiaWRkZW4gPSBmYWxzZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJlc3VsdHMgPSBhd2FpdCBjb250ZXh0LmNvcmUuZWxhc3RpY3NlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWFyY2goe1xuICAgICAgICAgIGluZGV4OiBpdGVtLnRpdGxlXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgZm9yYmlkZGVuID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChcbiAgICAgICAgKCgocmVzdWx0cyB8fCB7fSkuYm9keSB8fCB7fSkuaGl0cyB8fCB7fSkudG90YWwudmFsdWUgPj0gMSB8fFxuICAgICAgICAoIWZvcmJpZGRlbiAmJiAoKChyZXN1bHRzIHx8IHt9KS5ib2R5IHx8IHt9KS5oaXRzIHx8IHt9KS50b3RhbCA9PT0gMClcbiAgICAgICkge1xuICAgICAgICBmaW5hbExpc3QucHVzaChpdGVtKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZpbmFsTGlzdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVja3MgZm9yIG1pbmltdW0gaW5kZXggcGF0dGVybiBmaWVsZHMgaW4gYSBsaXN0IG9mIGluZGV4IHBhdHRlcm5zLlxuICAgKiBAcGFyYW0ge0FycmF5PE9iamVjdD59IGluZGV4UGF0dGVybkxpc3QgTGlzdCBvZiBpbmRleCBwYXR0ZXJuc1xuICAgKi9cbiAgdmFsaWRhdGVJbmRleFBhdHRlcm4oaW5kZXhQYXR0ZXJuTGlzdCkge1xuICAgIGNvbnN0IG1pbmltdW0gPSBbJ3RpbWVzdGFtcCcsICdydWxlLmdyb3VwcycsICdtYW5hZ2VyLm5hbWUnLCAnYWdlbnQuaWQnXTtcbiAgICBsZXQgbGlzdCA9IFtdO1xuICAgIGZvciAoY29uc3QgaW5kZXggb2YgaW5kZXhQYXR0ZXJuTGlzdCkge1xuICAgICAgbGV0IHZhbGlkLCBwYXJzZWQ7XG4gICAgICB0cnkge1xuICAgICAgICBwYXJzZWQgPSBKU09OLnBhcnNlKGluZGV4LmF0dHJpYnV0ZXMuZmllbGRzKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICB2YWxpZCA9IHBhcnNlZC5maWx0ZXIoaXRlbSA9PiBtaW5pbXVtLmluY2x1ZGVzKGl0ZW0ubmFtZSkpO1xuICAgICAgaWYgKHZhbGlkLmxlbmd0aCA9PT0gNCkge1xuICAgICAgICBsaXN0LnB1c2goe1xuICAgICAgICAgIGlkOiBpbmRleC5pZCxcbiAgICAgICAgICB0aXRsZTogaW5kZXguYXR0cmlidXRlcy50aXRsZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGxpc3Q7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBjdXJyZW50IHNlY3VyaXR5IHBsYXRmb3JtXG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXFcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcGx5XG4gICAqIEByZXR1cm5zIHtTdHJpbmd9XG4gICAqL1xuICBhc3luYyBnZXRDdXJyZW50UGxhdGZvcm0oY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBLaWJhbmFSZXF1ZXN0PHsgdXNlcjogc3RyaW5nIH0+LCByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5KSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBwbGF0Zm9ybTogY29udGV4dC53YXp1aC5zZWN1cml0eS5wbGF0Zm9ybVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCd3YXp1aC1lbGFzdGljOmdldEN1cnJlbnRQbGF0Zm9ybScsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNDAxMSwgNTAwLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJlcGxhY2VzIHZpc3VhbGl6YXRpb25zIG1haW4gZmllbGRzIHRvIGZpdCBhIGNlcnRhaW4gcGF0dGVybi5cbiAgICogQHBhcmFtIHtBcnJheTxPYmplY3Q+fSBhcHBfb2JqZWN0cyBPYmplY3QgY29udGFpbmluZyByYXcgdmlzdWFsaXphdGlvbnMuXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBpZCBJbmRleC1wYXR0ZXJuIGlkIHRvIHVzZSBpbiB0aGUgdmlzdWFsaXphdGlvbnMuIEVnOiAnd2F6dWgtYWxlcnRzJ1xuICAgKi9cbiAgYXN5bmMgYnVpbGRWaXN1YWxpemF0aW9uc1JhdyhhcHBfb2JqZWN0cywgaWQsIG5hbWVzcGFjZSA9IGZhbHNlKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldENvbmZpZ3VyYXRpb24oKTtcbiAgICAgIGxldCBtb25pdG9yaW5nUGF0dGVybiA9XG4gICAgICAgIChjb25maWcgfHwge30pWyd3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm4nXSB8fCBnZXRTZXR0aW5nRGVmYXVsdFZhbHVlKCd3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm4nKTtcbiAgICAgIGxvZyhcbiAgICAgICAgJ3dhenVoLWVsYXN0aWM6YnVpbGRWaXN1YWxpemF0aW9uc1JhdycsXG4gICAgICAgIGBCdWlsZGluZyAke2FwcF9vYmplY3RzLmxlbmd0aH0gdmlzdWFsaXphdGlvbnNgLFxuICAgICAgICAnZGVidWcnXG4gICAgICApO1xuICAgICAgbG9nKFxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpidWlsZFZpc3VhbGl6YXRpb25zUmF3JyxcbiAgICAgICAgYEluZGV4IHBhdHRlcm4gSUQ6ICR7aWR9YCxcbiAgICAgICAgJ2RlYnVnJ1xuICAgICAgKTtcbiAgICAgIGNvbnN0IHZpc0FycmF5ID0gW107XG4gICAgICBsZXQgYXV4X3NvdXJjZSwgYnVsa19jb250ZW50O1xuICAgICAgZm9yIChsZXQgZWxlbWVudCBvZiBhcHBfb2JqZWN0cykge1xuICAgICAgICBhdXhfc291cmNlID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShlbGVtZW50Ll9zb3VyY2UpKTtcblxuICAgICAgICAvLyBSZXBsYWNlIGluZGV4LXBhdHRlcm4gZm9yIHZpc3VhbGl6YXRpb25zXG4gICAgICAgIGlmIChcbiAgICAgICAgICBhdXhfc291cmNlICYmXG4gICAgICAgICAgYXV4X3NvdXJjZS5raWJhbmFTYXZlZE9iamVjdE1ldGEgJiZcbiAgICAgICAgICBhdXhfc291cmNlLmtpYmFuYVNhdmVkT2JqZWN0TWV0YS5zZWFyY2hTb3VyY2VKU09OICYmXG4gICAgICAgICAgdHlwZW9mIGF1eF9zb3VyY2Uua2liYW5hU2F2ZWRPYmplY3RNZXRhLnNlYXJjaFNvdXJjZUpTT04gPT09ICdzdHJpbmcnXG4gICAgICAgICkge1xuICAgICAgICAgIGNvbnN0IGRlZmF1bHRTdHIgPSBhdXhfc291cmNlLmtpYmFuYVNhdmVkT2JqZWN0TWV0YS5zZWFyY2hTb3VyY2VKU09OO1xuXG4gICAgICAgICAgY29uc3QgaXNNb25pdG9yaW5nID0gZGVmYXVsdFN0ci5pbmNsdWRlcygnd2F6dWgtbW9uaXRvcmluZycpO1xuICAgICAgICAgIGlmIChpc01vbml0b3JpbmcpIHtcbiAgICAgICAgICAgIGlmIChuYW1lc3BhY2UgJiYgbmFtZXNwYWNlICE9PSAnZGVmYXVsdCcpIHtcbiAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgIG1vbml0b3JpbmdQYXR0ZXJuLmluY2x1ZGVzKG5hbWVzcGFjZSkgJiZcbiAgICAgICAgICAgICAgICBtb25pdG9yaW5nUGF0dGVybi5pbmNsdWRlcygnaW5kZXgtcGF0dGVybjonKVxuICAgICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICBtb25pdG9yaW5nUGF0dGVybiA9IG1vbml0b3JpbmdQYXR0ZXJuLnNwbGl0KFxuICAgICAgICAgICAgICAgICAgJ2luZGV4LXBhdHRlcm46J1xuICAgICAgICAgICAgICAgIClbMV07XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGF1eF9zb3VyY2Uua2liYW5hU2F2ZWRPYmplY3RNZXRhLnNlYXJjaFNvdXJjZUpTT04gPSBkZWZhdWx0U3RyLnJlcGxhY2UoXG4gICAgICAgICAgICAgIC93YXp1aC1tb25pdG9yaW5nL2csXG4gICAgICAgICAgICAgIG1vbml0b3JpbmdQYXR0ZXJuW21vbml0b3JpbmdQYXR0ZXJuLmxlbmd0aCAtIDFdID09PSAnKicgfHxcbiAgICAgICAgICAgICAgICAobmFtZXNwYWNlICYmIG5hbWVzcGFjZSAhPT0gJ2RlZmF1bHQnKVxuICAgICAgICAgICAgICAgID8gbW9uaXRvcmluZ1BhdHRlcm5cbiAgICAgICAgICAgICAgICA6IG1vbml0b3JpbmdQYXR0ZXJuICsgJyonXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBhdXhfc291cmNlLmtpYmFuYVNhdmVkT2JqZWN0TWV0YS5zZWFyY2hTb3VyY2VKU09OID0gZGVmYXVsdFN0ci5yZXBsYWNlKFxuICAgICAgICAgICAgICAvd2F6dWgtYWxlcnRzL2csXG4gICAgICAgICAgICAgIGlkXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJlcGxhY2UgaW5kZXgtcGF0dGVybiBmb3Igc2VsZWN0b3IgdmlzdWFsaXphdGlvbnNcbiAgICAgICAgaWYgKHR5cGVvZiAoYXV4X3NvdXJjZSB8fCB7fSkudmlzU3RhdGUgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgYXV4X3NvdXJjZS52aXNTdGF0ZSA9IGF1eF9zb3VyY2UudmlzU3RhdGUucmVwbGFjZShcbiAgICAgICAgICAgIC93YXp1aC1hbGVydHMvZyxcbiAgICAgICAgICAgIGlkXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEJ1bGsgc291cmNlXG4gICAgICAgIGJ1bGtfY29udGVudCA9IHt9O1xuICAgICAgICBidWxrX2NvbnRlbnRbZWxlbWVudC5fdHlwZV0gPSBhdXhfc291cmNlO1xuXG4gICAgICAgIHZpc0FycmF5LnB1c2goe1xuICAgICAgICAgIGF0dHJpYnV0ZXM6IGJ1bGtfY29udGVudC52aXN1YWxpemF0aW9uLFxuICAgICAgICAgIHR5cGU6IGVsZW1lbnQuX3R5cGUsXG4gICAgICAgICAgaWQ6IGVsZW1lbnQuX2lkLFxuICAgICAgICAgIF92ZXJzaW9uOiBidWxrX2NvbnRlbnQudmlzdWFsaXphdGlvbi52ZXJzaW9uXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHZpc0FycmF5O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coJ3dhenVoLWVsYXN0aWM6YnVpbGRWaXN1YWxpemF0aW9uc1JhdycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmVwbGFjZXMgY2x1c3RlciB2aXN1YWxpemF0aW9ucyBtYWluIGZpZWxkcy5cbiAgICogQHBhcmFtIHtBcnJheTxPYmplY3Q+fSBhcHBfb2JqZWN0cyBPYmplY3QgY29udGFpbmluZyByYXcgdmlzdWFsaXphdGlvbnMuXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBpZCBJbmRleC1wYXR0ZXJuIGlkIHRvIHVzZSBpbiB0aGUgdmlzdWFsaXphdGlvbnMuIEVnOiAnd2F6dWgtYWxlcnRzJ1xuICAgKiBAcGFyYW0ge0FycmF5PFN0cmluZz59IG5vZGVzIEFycmF5IG9mIG5vZGUgbmFtZXMuIEVnOiBbJ25vZGUwMScsICdub2RlMDInXVxuICAgKiBAcGFyYW0ge1N0cmluZ30gbmFtZSBDbHVzdGVyIG5hbWUuIEVnOiAnd2F6dWgnXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtYXN0ZXJfbm9kZSBNYXN0ZXIgbm9kZSBuYW1lLiBFZzogJ25vZGUwMSdcbiAgICovXG4gIGJ1aWxkQ2x1c3RlclZpc3VhbGl6YXRpb25zUmF3KFxuICAgIGFwcF9vYmplY3RzLFxuICAgIGlkLFxuICAgIG5vZGVzID0gW10sXG4gICAgbmFtZSxcbiAgICBtYXN0ZXJfbm9kZSxcbiAgICBwYXR0ZXJuX25hbWUgPSAnKidcbiAgKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHZpc0FycmF5ID0gW107XG4gICAgICBsZXQgYXV4X3NvdXJjZSwgYnVsa19jb250ZW50O1xuXG4gICAgICBmb3IgKGNvbnN0IGVsZW1lbnQgb2YgYXBwX29iamVjdHMpIHtcbiAgICAgICAgLy8gU3RyaW5naWZ5IGFuZCByZXBsYWNlIGluZGV4LXBhdHRlcm4gZm9yIHZpc3VhbGl6YXRpb25zXG4gICAgICAgIGF1eF9zb3VyY2UgPSBKU09OLnN0cmluZ2lmeShlbGVtZW50Ll9zb3VyY2UpO1xuICAgICAgICBhdXhfc291cmNlID0gYXV4X3NvdXJjZS5yZXBsYWNlKC93YXp1aC1hbGVydHMvZywgaWQpO1xuICAgICAgICBhdXhfc291cmNlID0gSlNPTi5wYXJzZShhdXhfc291cmNlKTtcblxuICAgICAgICAvLyBCdWxrIHNvdXJjZVxuICAgICAgICBidWxrX2NvbnRlbnQgPSB7fTtcbiAgICAgICAgYnVsa19jb250ZW50W2VsZW1lbnQuX3R5cGVdID0gYXV4X3NvdXJjZTtcblxuICAgICAgICBjb25zdCB2aXNTdGF0ZSA9IEpTT04ucGFyc2UoYnVsa19jb250ZW50LnZpc3VhbGl6YXRpb24udmlzU3RhdGUpO1xuICAgICAgICBjb25zdCB0aXRsZSA9IHZpc1N0YXRlLnRpdGxlO1xuXG4gICAgICAgIGlmICh2aXNTdGF0ZS50eXBlICYmIHZpc1N0YXRlLnR5cGUgPT09ICd0aW1lbGlvbicpIHtcbiAgICAgICAgICBsZXQgcXVlcnkgPSAnJztcbiAgICAgICAgICBpZiAodGl0bGUgPT09ICdXYXp1aCBBcHAgQ2x1c3RlciBPdmVydmlldycpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3Qgbm9kZSBvZiBub2Rlcykge1xuICAgICAgICAgICAgICBxdWVyeSArPSBgLmVzKGluZGV4PSR7cGF0dGVybl9uYW1lfSxxPVwiY2x1c3Rlci5uYW1lOiAke25hbWV9IEFORCBjbHVzdGVyLm5vZGU6ICR7bm9kZS5uYW1lfVwiKS5sYWJlbChcIiR7bm9kZS5uYW1lfVwiKSxgO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcXVlcnkgPSBxdWVyeS5zdWJzdHJpbmcoMCwgcXVlcnkubGVuZ3RoIC0gMSk7XG4gICAgICAgICAgfSBlbHNlIGlmICh0aXRsZSA9PT0gJ1dhenVoIEFwcCBDbHVzdGVyIE92ZXJ2aWV3IE1hbmFnZXInKSB7XG4gICAgICAgICAgICBxdWVyeSArPSBgLmVzKGluZGV4PSR7cGF0dGVybl9uYW1lfSxxPVwiY2x1c3Rlci5uYW1lOiAke25hbWV9XCIpLmxhYmVsKFwiJHtuYW1lfSBjbHVzdGVyXCIpYDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKHRpdGxlLnN0YXJ0c1dpdGgoJ1dhenVoIEFwcCBTdGF0aXN0aWNzJykpIHtcbiAgICAgICAgICAgICAgY29uc3QgeyBzZWFyY2hTb3VyY2VKU09OIH0gPSBidWxrX2NvbnRlbnQudmlzdWFsaXphdGlvbi5raWJhbmFTYXZlZE9iamVjdE1ldGE7XG4gICAgICAgICAgICAgIGJ1bGtfY29udGVudC52aXN1YWxpemF0aW9uLmtpYmFuYVNhdmVkT2JqZWN0TWV0YS5zZWFyY2hTb3VyY2VKU09OID0gc2VhcmNoU291cmNlSlNPTi5yZXBsYWNlKCd3YXp1aC1zdGF0aXN0aWNzLSonLCBwYXR0ZXJuX25hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHRpdGxlLnN0YXJ0c1dpdGgoJ1dhenVoIEFwcCBTdGF0aXN0aWNzJykgJiYgbmFtZSAhPT0gJy0nICYmIG5hbWUgIT09ICdhbGwnICYmIHZpc1N0YXRlLnBhcmFtcy5leHByZXNzaW9uLmluY2x1ZGVzKCdxPScpKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGV4cHJlc3Npb25SZWdleCA9IC9xPSdcXConL2dpO1xuICAgICAgICAgICAgICBjb25zdCBfdmlzU3RhdGUgPSBidWxrX2NvbnRlbnQudmlzdWFsaXphdGlvbi52aXNTdGF0ZUJ5Tm9kZVxuICAgICAgICAgICAgICAgID8gSlNPTi5wYXJzZShidWxrX2NvbnRlbnQudmlzdWFsaXphdGlvbi52aXNTdGF0ZUJ5Tm9kZSlcbiAgICAgICAgICAgICAgICA6IHZpc1N0YXRlO1xuICAgICAgICAgICAgICBxdWVyeSArPSBfdmlzU3RhdGUucGFyYW1zLmV4cHJlc3Npb24ucmVwbGFjZSgvd2F6dWgtc3RhdGlzdGljcy1cXCovZywgcGF0dGVybl9uYW1lKS5yZXBsYWNlKGV4cHJlc3Npb25SZWdleCwgYHE9XCJub2RlTmFtZS5rZXl3b3JkOiR7bmFtZX0gQU5EIGFwaU5hbWUua2V5d29yZDoke21hc3Rlcl9ub2RlfVwiYClcbiAgICAgICAgICAgICAgICAucmVwbGFjZShcIk5PREVfTkFNRVwiLCBuYW1lKVxuICAgICAgICAgICAgfSBlbHNlIGlmICh0aXRsZS5zdGFydHNXaXRoKCdXYXp1aCBBcHAgU3RhdGlzdGljcycpKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGV4cHJlc3Npb25SZWdleCA9IC9xPSdcXConL2dpXG4gICAgICAgICAgICAgIHF1ZXJ5ICs9IHZpc1N0YXRlLnBhcmFtcy5leHByZXNzaW9uLnJlcGxhY2UoL3dhenVoLXN0YXRpc3RpY3MtXFwqL2csIHBhdHRlcm5fbmFtZSkucmVwbGFjZShleHByZXNzaW9uUmVnZXgsIGBxPVwiYXBpTmFtZS5rZXl3b3JkOiR7bWFzdGVyX25vZGV9XCJgKVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgcXVlcnkgPSB2aXNTdGF0ZS5wYXJhbXMuZXhwcmVzc2lvbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICB2aXNTdGF0ZS5wYXJhbXMuZXhwcmVzc2lvbiA9IHF1ZXJ5LnJlcGxhY2UoLycvZywgXCJcXFwiXCIpO1xuICAgICAgICAgIGJ1bGtfY29udGVudC52aXN1YWxpemF0aW9uLnZpc1N0YXRlID0gSlNPTi5zdHJpbmdpZnkodmlzU3RhdGUpO1xuICAgICAgICB9XG5cbiAgICAgICAgdmlzQXJyYXkucHVzaCh7XG4gICAgICAgICAgYXR0cmlidXRlczogYnVsa19jb250ZW50LnZpc3VhbGl6YXRpb24sXG4gICAgICAgICAgdHlwZTogZWxlbWVudC5fdHlwZSxcbiAgICAgICAgICBpZDogZWxlbWVudC5faWQsXG4gICAgICAgICAgX3ZlcnNpb246IGJ1bGtfY29udGVudC52aXN1YWxpemF0aW9uLnZlcnNpb25cbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB2aXNBcnJheTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKFxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpidWlsZENsdXN0ZXJWaXN1YWxpemF0aW9uc1JhdycsXG4gICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3JcbiAgICAgICk7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGNyZWF0ZXMgYSB2aXN1YWxpemF0aW9uIG9mIGRhdGEgaW4gcmVxXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSB2aXMgb2JqIG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGNyZWF0ZVZpcyhjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3Q8eyBwYXR0ZXJuOiBzdHJpbmcsIHRhYjogc3RyaW5nIH0+LCByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5KSB7XG4gICAgdHJ5IHtcbiAgICAgIGlmIChcbiAgICAgICAgKCFyZXF1ZXN0LnBhcmFtcy50YWIuaW5jbHVkZXMoJ292ZXJ2aWV3LScpICYmXG4gICAgICAgICAgIXJlcXVlc3QucGFyYW1zLnRhYi5pbmNsdWRlcygnYWdlbnRzLScpKVxuICAgICAgKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTWlzc2luZyBwYXJhbWV0ZXJzIGNyZWF0aW5nIHZpc3VhbGl6YXRpb25zJyk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHRhYlByZWZpeCA9IHJlcXVlc3QucGFyYW1zLnRhYi5pbmNsdWRlcygnb3ZlcnZpZXcnKVxuICAgICAgICA/ICdvdmVydmlldydcbiAgICAgICAgOiAnYWdlbnRzJztcblxuICAgICAgY29uc3QgdGFiU3BsaXQgPSByZXF1ZXN0LnBhcmFtcy50YWIuc3BsaXQoJy0nKTtcbiAgICAgIGNvbnN0IHRhYlN1Zml4ID0gdGFiU3BsaXRbMV07XG5cbiAgICAgIGNvbnN0IGZpbGUgPVxuICAgICAgICB0YWJQcmVmaXggPT09ICdvdmVydmlldydcbiAgICAgICAgICA/IE92ZXJ2aWV3VmlzdWFsaXphdGlvbnNbdGFiU3VmaXhdXG4gICAgICAgICAgOiBBZ2VudHNWaXN1YWxpemF0aW9uc1t0YWJTdWZpeF07XG4gICAgICBpZiAoIWZpbGUpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm5vdEZvdW5kKHtib2R5OnttZXNzYWdlOiBgVmlzdWFsaXphdGlvbnMgbm90IGZvdW5kIGZvciAke3JlcXVlc3QucGFyYW1zLnRhYn1gfX0pO1xuICAgICAgfVxuICAgICAgbG9nKCd3YXp1aC1lbGFzdGljOmNyZWF0ZVZpcycsIGAke3RhYlByZWZpeH1bJHt0YWJTdWZpeH1dIHdpdGggaW5kZXggcGF0dGVybiAke3JlcXVlc3QucGFyYW1zLnBhdHRlcm59YCwgJ2RlYnVnJyk7XG4gICAgICBjb25zdCBuYW1lc3BhY2UgPSBjb250ZXh0LndhenVoLnBsdWdpbnMuc3BhY2VzICYmIGNvbnRleHQud2F6dWgucGx1Z2lucy5zcGFjZXMuc3BhY2VzU2VydmljZSAmJiBjb250ZXh0LndhenVoLnBsdWdpbnMuc3BhY2VzLnNwYWNlc1NlcnZpY2UuZ2V0U3BhY2VJZChyZXF1ZXN0KTtcbiAgICAgIGNvbnN0IHJhdyA9IGF3YWl0IHRoaXMuYnVpbGRWaXN1YWxpemF0aW9uc1JhdyhcbiAgICAgICAgZmlsZSxcbiAgICAgICAgcmVxdWVzdC5wYXJhbXMucGF0dGVybixcbiAgICAgICAgbmFtZXNwYWNlXG4gICAgICApO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keTogeyBhY2tub3dsZWRnZTogdHJ1ZSwgcmF3OiByYXcgfVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygnd2F6dWgtZWxhc3RpYzpjcmVhdGVWaXMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDQwMDcsIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGNyZWF0ZXMgYSB2aXN1YWxpemF0aW9uIG9mIGNsdXN0ZXJcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IHZpcyBvYmogb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgY3JlYXRlQ2x1c3RlclZpcyhjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3Q8eyBwYXR0ZXJuOiBzdHJpbmcsIHRhYjogc3RyaW5nIH0sIHVua25vd24sIGFueT4sIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnkpIHtcbiAgICB0cnkge1xuICAgICAgaWYgKFxuICAgICAgICAhcmVxdWVzdC5wYXJhbXMucGF0dGVybiB8fFxuICAgICAgICAhcmVxdWVzdC5wYXJhbXMudGFiIHx8XG4gICAgICAgICFyZXF1ZXN0LmJvZHkgfHxcbiAgICAgICAgIXJlcXVlc3QuYm9keS5ub2RlcyB8fFxuICAgICAgICAhcmVxdWVzdC5ib2R5Lm5vZGVzLmFmZmVjdGVkX2l0ZW1zIHx8XG4gICAgICAgICFyZXF1ZXN0LmJvZHkubm9kZXMubmFtZSB8fFxuICAgICAgICAocmVxdWVzdC5wYXJhbXMudGFiICYmICFyZXF1ZXN0LnBhcmFtcy50YWIuaW5jbHVkZXMoJ2NsdXN0ZXItJykpXG4gICAgICApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdNaXNzaW5nIHBhcmFtZXRlcnMgY3JlYXRpbmcgdmlzdWFsaXphdGlvbnMnKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgdHlwZSA9IHJlcXVlc3QucGFyYW1zLnRhYi5zcGxpdCgnLScpWzFdO1xuXG4gICAgICBjb25zdCBmaWxlID0gQ2x1c3RlclZpc3VhbGl6YXRpb25zW3R5cGVdO1xuICAgICAgY29uc3Qgbm9kZXMgPSByZXF1ZXN0LmJvZHkubm9kZXMuYWZmZWN0ZWRfaXRlbXM7XG4gICAgICBjb25zdCBuYW1lID0gcmVxdWVzdC5ib2R5Lm5vZGVzLm5hbWU7XG4gICAgICBjb25zdCBtYXN0ZXJOb2RlID0gcmVxdWVzdC5ib2R5Lm5vZGVzLm1hc3Rlcl9ub2RlO1xuXG4gICAgICBjb25zdCB7IGlkOiBwYXR0ZXJuSUQsIHRpdGxlOiBwYXR0ZXJuTmFtZSB9ID0gcmVxdWVzdC5ib2R5LnBhdHRlcm47XG5cbiAgICAgIGNvbnN0IHJhdyA9IGF3YWl0IHRoaXMuYnVpbGRDbHVzdGVyVmlzdWFsaXphdGlvbnNSYXcoXG4gICAgICAgIGZpbGUsXG4gICAgICAgIHBhdHRlcm5JRCxcbiAgICAgICAgbm9kZXMsXG4gICAgICAgIG5hbWUsXG4gICAgICAgIG1hc3Rlck5vZGUsXG4gICAgICAgIHBhdHRlcm5OYW1lXG4gICAgICApO1xuXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7IGFja25vd2xlZGdlOiB0cnVlLCByYXc6IHJhdyB9XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCd3YXp1aC1lbGFzdGljOmNyZWF0ZUNsdXN0ZXJWaXMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDQwMDksIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGNoZWNrcyBpZiB0aGVyZSBpcyBzYW1wbGUgYWxlcnRzXG4gICAqIEdFVCAvZWxhc3RpYy9zYW1wbGVhbGVydHNcbiAgICogQHBhcmFtIHsqfSBjb250ZXh0XG4gICAqIEBwYXJhbSB7Kn0gcmVxdWVzdFxuICAgKiBAcGFyYW0geyp9IHJlc3BvbnNlXG4gICAqIHthbGVydHM6IFsuLi5dfSBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBoYXZlU2FtcGxlQWxlcnRzKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdCwgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSkge1xuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBpZiB3YXp1aCBzYW1wbGUgYWxlcnRzIGluZGV4IGV4aXN0c1xuICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IFByb21pc2UuYWxsKE9iamVjdC5rZXlzKFdBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUklFU19UWVBFX0FMRVJUUylcbiAgICAgICAgLm1hcCgoY2F0ZWdvcnkpID0+IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuZXhpc3RzKHtcbiAgICAgICAgICBpbmRleDogdGhpcy5idWlsZFNhbXBsZUluZGV4QnlDYXRlZ29yeShjYXRlZ29yeSlcbiAgICAgICAgfSkpKTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHsgc2FtcGxlQWxlcnRzSW5zdGFsbGVkOiByZXN1bHRzLnNvbWUocmVzdWx0ID0+IHJlc3VsdC5ib2R5KSB9XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ1NhbXBsZSBBbGVydHMgY2F0ZWdvcnkgbm90IHZhbGlkJywgMTAwMCwgNTAwLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBUaGlzIGNyZWF0ZXMgc2FtcGxlIGFsZXJ0cyBpbiB3YXp1aC1zYW1wbGUtYWxlcnRzXG4gICAqIEdFVCAvZWxhc3RpYy9zYW1wbGVhbGVydHMve2NhdGVnb3J5fVxuICAgKiBAcGFyYW0geyp9IGNvbnRleHRcbiAgICogQHBhcmFtIHsqfSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7Kn0gcmVzcG9uc2VcbiAgICoge2FsZXJ0czogWy4uLl19IG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGhhdmVTYW1wbGVBbGVydHNPZkNhdGVnb3J5KGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdDx7IGNhdGVnb3J5OiBzdHJpbmcgfT4sIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnkpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc2FtcGxlQWxlcnRzSW5kZXggPSB0aGlzLmJ1aWxkU2FtcGxlSW5kZXhCeUNhdGVnb3J5KHJlcXVlc3QucGFyYW1zLmNhdGVnb3J5KTtcbiAgICAgIC8vIENoZWNrIGlmIHdhenVoIHNhbXBsZSBhbGVydHMgaW5kZXggZXhpc3RzXG4gICAgICBjb25zdCBleGlzdHNTYW1wbGVJbmRleCA9IGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuZXhpc3RzKHtcbiAgICAgICAgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4XG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHsgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4LCBleGlzdHM6IGV4aXN0c1NhbXBsZUluZGV4LmJvZHkgfVxuICAgICAgfSlcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKFxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpoYXZlU2FtcGxlQWxlcnRzT2ZDYXRlZ29yeScsXG4gICAgICAgIGBFcnJvciBjaGVja2luZyBpZiB0aGVyZSBhcmUgc2FtcGxlIGFsZXJ0cyBpbmRpY2VzOiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YFxuICAgICAgKTtcblxuICAgICAgY29uc3QgW3N0YXR1c0NvZGUsIGVycm9yTWVzc2FnZV0gPSB0aGlzLmdldEVycm9yRGV0YWlscyhlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShgRXJyb3IgY2hlY2tpbmcgaWYgdGhlcmUgYXJlIHNhbXBsZSBhbGVydHMgaW5kaWNlczogJHtlcnJvck1lc3NhZ2UgfHwgZXJyb3J9YCwgMTAwMCwgc3RhdHVzQ29kZSwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogVGhpcyBjcmVhdGVzIHNhbXBsZSBhbGVydHMgaW4gd2F6dWgtc2FtcGxlLWFsZXJ0c1xuICAgKiBQT1NUIC9lbGFzdGljL3NhbXBsZWFsZXJ0cy97Y2F0ZWdvcnl9XG4gICAqIHtcbiAgICogICBcIm1hbmFnZXJcIjoge1xuICAgKiAgICAgIFwibmFtZVwiOiBcIm1hbmFnZXJfbmFtZVwiXG4gICAqICAgIH0sXG4gICAqICAgIGNsdXN0ZXI6IHtcbiAgICogICAgICBuYW1lOiBcIm15Y2x1c3RlclwiLFxuICAgKiAgICAgIG5vZGU6IFwibXlub2RlXCJcbiAgICogICAgfVxuICAgKiB9XG4gICAqIEBwYXJhbSB7Kn0gY29udGV4dFxuICAgKiBAcGFyYW0geyp9IHJlcXVlc3RcbiAgICogQHBhcmFtIHsqfSByZXNwb25zZVxuICAgKiB7aW5kZXg6IHN0cmluZywgYWxlcnRzOiBbLi4uXSwgY291bnQ6IG51bWJlcn0gb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgYXN5bmMgY3JlYXRlU2FtcGxlQWxlcnRzKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdDx7IGNhdGVnb3J5OiBzdHJpbmcgfT4sIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnkpIHtcbiAgICBjb25zdCBzYW1wbGVBbGVydHNJbmRleCA9IHRoaXMuYnVpbGRTYW1wbGVJbmRleEJ5Q2F0ZWdvcnkocmVxdWVzdC5wYXJhbXMuY2F0ZWdvcnkpO1xuXG4gICAgdHJ5IHtcbiAgICAgIC8vIENoZWNrIGlmIHVzZXIgaGFzIGFkbWluaXN0cmF0b3Igcm9sZSBpbiB0b2tlblxuICAgICAgY29uc3QgdG9rZW4gPSBnZXRDb29raWVWYWx1ZUJ5TmFtZShyZXF1ZXN0LmhlYWRlcnMuY29va2llLCAnd3otdG9rZW4nKTtcbiAgICAgIGlmICghdG9rZW4pIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ05vIHRva2VuIHByb3ZpZGVkJywgNDAxLCA0MDEsIHJlc3BvbnNlKTtcbiAgICAgIH07XG4gICAgICBjb25zdCBkZWNvZGVkVG9rZW4gPSBqd3REZWNvZGUodG9rZW4pO1xuICAgICAgaWYgKCFkZWNvZGVkVG9rZW4pIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ05vIHBlcm1pc3Npb25zIGluIHRva2VuJywgNDAxLCA0MDEsIHJlc3BvbnNlKTtcbiAgICAgIH07XG4gICAgICBpZiAoIWRlY29kZWRUb2tlbi5yYmFjX3JvbGVzIHx8ICFkZWNvZGVkVG9rZW4ucmJhY19yb2xlcy5pbmNsdWRlcyhXQVpVSF9ST0xFX0FETUlOSVNUUkFUT1JfSUQpKSB7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdObyBhZG1pbmlzdHJhdG9yIHJvbGUnLCA0MDEsIDQwMSwgcmVzcG9uc2UpO1xuICAgICAgfTtcbiAgICAgIC8vIENoZWNrIHRoZSBwcm92aWRlZCB0b2tlbiBpcyB2YWxpZFxuICAgICAgY29uc3QgYXBpSG9zdElEID0gZ2V0Q29va2llVmFsdWVCeU5hbWUocmVxdWVzdC5oZWFkZXJzLmNvb2tpZSwgJ3d6LWFwaScpO1xuICAgICAgaWYgKCFhcGlIb3N0SUQpIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ05vIEFQSSBpZCBwcm92aWRlZCcsIDQwMSwgNDAxLCByZXNwb25zZSk7XG4gICAgICB9O1xuICAgICAgY29uc3QgcmVzcG9uc2VUb2tlbklzV29ya2luZyA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoJ0dFVCcsIGAvL2AsIHt9LCB7IGFwaUhvc3RJRCB9KTtcbiAgICAgIGlmIChyZXNwb25zZVRva2VuSXNXb3JraW5nLnN0YXR1cyAhPT0gMjAwKSB7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdUb2tlbiBpcyBub3QgdmFsaWQnLCA1MDAsIDUwMCwgcmVzcG9uc2UpO1xuICAgICAgfTtcblxuICAgICAgY29uc3QgYnVsa1ByZWZpeCA9IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgaW5kZXg6IHtcbiAgICAgICAgICBfaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgY29uc3QgYWxlcnRHZW5lcmF0ZVBhcmFtcyA9IHJlcXVlc3QuYm9keSAmJiByZXF1ZXN0LmJvZHkucGFyYW1zIHx8IHt9O1xuXG4gICAgICBjb25zdCBzYW1wbGVBbGVydHMgPSBXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JJRVNfVFlQRV9BTEVSVFNbcmVxdWVzdC5wYXJhbXMuY2F0ZWdvcnldLm1hcCgodHlwZUFsZXJ0KSA9PiBnZW5lcmF0ZUFsZXJ0cyh7IC4uLnR5cGVBbGVydCwgLi4uYWxlcnRHZW5lcmF0ZVBhcmFtcyB9LCByZXF1ZXN0LmJvZHkuYWxlcnRzIHx8IHR5cGVBbGVydC5hbGVydHMgfHwgV0FaVUhfU0FNUExFX0FMRVJUU19ERUZBVUxUX05VTUJFUl9BTEVSVFMpKS5mbGF0KCk7XG4gICAgICBjb25zdCBidWxrID0gc2FtcGxlQWxlcnRzLm1hcChzYW1wbGVBbGVydCA9PiBgJHtidWxrUHJlZml4fVxcbiR7SlNPTi5zdHJpbmdpZnkoc2FtcGxlQWxlcnQpfVxcbmApLmpvaW4oJycpO1xuXG4gICAgICAvLyBJbmRleCBhbGVydHNcblxuICAgICAgLy8gQ2hlY2sgaWYgd2F6dWggc2FtcGxlIGFsZXJ0cyBpbmRleCBleGlzdHNcbiAgICAgIGNvbnN0IGV4aXN0c1NhbXBsZUluZGV4ID0gYXdhaXQgY29udGV4dC5jb3JlLmVsYXN0aWNzZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuaW5kaWNlcy5leGlzdHMoe1xuICAgICAgICBpbmRleDogc2FtcGxlQWxlcnRzSW5kZXhcbiAgICAgIH0pO1xuICAgICAgaWYgKCFleGlzdHNTYW1wbGVJbmRleC5ib2R5KSB7XG4gICAgICAgIC8vIENyZWF0ZSB3YXp1aCBzYW1wbGUgYWxlcnRzIGluZGV4XG5cbiAgICAgICAgY29uc3QgY29uZmlndXJhdGlvbiA9IHtcbiAgICAgICAgICBzZXR0aW5nczoge1xuICAgICAgICAgICAgaW5kZXg6IHtcbiAgICAgICAgICAgICAgbnVtYmVyX29mX3NoYXJkczogV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9TSEFSRFMsXG4gICAgICAgICAgICAgIG51bWJlcl9vZl9yZXBsaWNhczogV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9SRVBMSUNBU1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBhd2FpdCBjb250ZXh0LmNvcmUuZWxhc3RpY3NlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5pbmRpY2VzLmNyZWF0ZSh7XG4gICAgICAgICAgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4LFxuICAgICAgICAgIGJvZHk6IGNvbmZpZ3VyYXRpb25cbiAgICAgICAgfSk7XG4gICAgICAgIGxvZyhcbiAgICAgICAgICAnd2F6dWgtZWxhc3RpYzpjcmVhdGVTYW1wbGVBbGVydHMnLFxuICAgICAgICAgIGBDcmVhdGVkICR7c2FtcGxlQWxlcnRzSW5kZXh9IGluZGV4YCxcbiAgICAgICAgICAnZGVidWcnXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmJ1bGsoe1xuICAgICAgICBpbmRleDogc2FtcGxlQWxlcnRzSW5kZXgsXG4gICAgICAgIGJvZHk6IGJ1bGtcbiAgICAgIH0pO1xuICAgICAgbG9nKFxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpjcmVhdGVTYW1wbGVBbGVydHMnLFxuICAgICAgICBgQWRkZWQgc2FtcGxlIGFsZXJ0cyB0byAke3NhbXBsZUFsZXJ0c0luZGV4fSBpbmRleGAsXG4gICAgICAgICdkZWJ1ZydcbiAgICAgICk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7IGluZGV4OiBzYW1wbGVBbGVydHNJbmRleCwgYWxlcnRDb3VudDogc2FtcGxlQWxlcnRzLmxlbmd0aCB9XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKFxuICAgICAgICAnd2F6dWgtZWxhc3RpYzpjcmVhdGVTYW1wbGVBbGVydHMnLFxuICAgICAgICBgRXJyb3IgYWRkaW5nIHNhbXBsZSBhbGVydHMgdG8gJHtzYW1wbGVBbGVydHNJbmRleH0gaW5kZXg6ICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gXG4gICAgICApO1xuICAgICAgXG4gICAgICBjb25zdCBbc3RhdHVzQ29kZSwgZXJyb3JNZXNzYWdlXSA9IHRoaXMuZ2V0RXJyb3JEZXRhaWxzKGVycm9yKTtcbiAgICAgIFxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3JNZXNzYWdlIHx8IGVycm9yLCAxMDAwLCBzdGF0dXNDb2RlLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBUaGlzIGRlbGV0ZXMgc2FtcGxlIGFsZXJ0c1xuICAgKiBAcGFyYW0geyp9IGNvbnRleHRcbiAgICogQHBhcmFtIHsqfSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7Kn0gcmVzcG9uc2VcbiAgICoge3Jlc3VsdDogXCJkZWxldGVkXCIsIGluZGV4OiBzdHJpbmd9IG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGRlbGV0ZVNhbXBsZUFsZXJ0cyhjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3Q8eyBjYXRlZ29yeTogc3RyaW5nIH0+LCByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5KSB7XG4gICAgLy8gRGVsZXRlIFdhenVoIHNhbXBsZSBhbGVydCBpbmRleFxuXG4gICAgY29uc3Qgc2FtcGxlQWxlcnRzSW5kZXggPSB0aGlzLmJ1aWxkU2FtcGxlSW5kZXhCeUNhdGVnb3J5KHJlcXVlc3QucGFyYW1zLmNhdGVnb3J5KTtcblxuICAgIHRyeSB7XG4gICAgICAvLyBDaGVjayBpZiB1c2VyIGhhcyBhZG1pbmlzdHJhdG9yIHJvbGUgaW4gdG9rZW5cbiAgICAgIGNvbnN0IHRva2VuID0gZ2V0Q29va2llVmFsdWVCeU5hbWUocmVxdWVzdC5oZWFkZXJzLmNvb2tpZSwgJ3d6LXRva2VuJyk7XG4gICAgICBpZiAoIXRva2VuKSB7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdObyB0b2tlbiBwcm92aWRlZCcsIDQwMSwgNDAxLCByZXNwb25zZSk7XG4gICAgICB9O1xuICAgICAgY29uc3QgZGVjb2RlZFRva2VuID0gand0RGVjb2RlKHRva2VuKTtcbiAgICAgIGlmICghZGVjb2RlZFRva2VuKSB7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdObyBwZXJtaXNzaW9ucyBpbiB0b2tlbicsIDQwMSwgNDAxLCByZXNwb25zZSk7XG4gICAgICB9O1xuICAgICAgaWYgKCFkZWNvZGVkVG9rZW4ucmJhY19yb2xlcyB8fCAhZGVjb2RlZFRva2VuLnJiYWNfcm9sZXMuaW5jbHVkZXMoV0FaVUhfUk9MRV9BRE1JTklTVFJBVE9SX0lEKSkge1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnTm8gYWRtaW5pc3RyYXRvciByb2xlJywgNDAxLCA0MDEsIHJlc3BvbnNlKTtcbiAgICAgIH07XG4gICAgICAvLyBDaGVjayB0aGUgcHJvdmlkZWQgdG9rZW4gaXMgdmFsaWRcbiAgICAgIGNvbnN0IGFwaUhvc3RJRCA9IGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsICd3ei1hcGknKTtcbiAgICAgIGlmICghYXBpSG9zdElEKSB7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdObyBBUEkgaWQgcHJvdmlkZWQnLCA0MDEsIDQwMSwgcmVzcG9uc2UpO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IHJlc3BvbnNlVG9rZW5Jc1dvcmtpbmcgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KCdHRVQnLCBgLy9gLCB7fSwgeyBhcGlIb3N0SUQgfSk7XG4gICAgICBpZiAocmVzcG9uc2VUb2tlbklzV29ya2luZy5zdGF0dXMgIT09IDIwMCkge1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnVG9rZW4gaXMgbm90IHZhbGlkJywgNTAwLCA1MDAsIHJlc3BvbnNlKTtcbiAgICAgIH07XG5cbiAgICAgIC8vIENoZWNrIGlmIFdhenVoIHNhbXBsZSBhbGVydHMgaW5kZXggZXhpc3RzXG4gICAgICBjb25zdCBleGlzdHNTYW1wbGVJbmRleCA9IGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuZXhpc3RzKHtcbiAgICAgICAgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4XG4gICAgICB9KTtcbiAgICAgIGlmIChleGlzdHNTYW1wbGVJbmRleC5ib2R5KSB7XG4gICAgICAgIC8vIERlbGV0ZSBXYXp1aCBzYW1wbGUgYWxlcnRzIGluZGV4XG4gICAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyLmluZGljZXMuZGVsZXRlKHsgaW5kZXg6IHNhbXBsZUFsZXJ0c0luZGV4IH0pO1xuICAgICAgICBsb2coXG4gICAgICAgICAgJ3dhenVoLWVsYXN0aWM6ZGVsZXRlU2FtcGxlQWxlcnRzJyxcbiAgICAgICAgICBgRGVsZXRlZCAke3NhbXBsZUFsZXJ0c0luZGV4fSBpbmRleGAsXG4gICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHsgcmVzdWx0OiAnZGVsZXRlZCcsIGluZGV4OiBzYW1wbGVBbGVydHNJbmRleCB9XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoYCR7c2FtcGxlQWxlcnRzSW5kZXh9IGluZGV4IGRvZXNuJ3QgZXhpc3RgLCAxMDAwLCA1MDAsIHJlc3BvbnNlKVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coXG4gICAgICAgICd3YXp1aC1lbGFzdGljOmRlbGV0ZVNhbXBsZUFsZXJ0cycsXG4gICAgICAgIGBFcnJvciBkZWxldGluZyBzYW1wbGUgYWxlcnRzIG9mICR7c2FtcGxlQWxlcnRzSW5kZXh9IGluZGV4OiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YFxuICAgICAgKTtcbiAgICAgIGNvbnN0IFtzdGF0dXNDb2RlLCBlcnJvck1lc3NhZ2VdID0gdGhpcy5nZXRFcnJvckRldGFpbHMoZXJyb3IpO1xuXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvck1lc3NhZ2UgfHwgZXJyb3IsIDEwMDAsIHN0YXR1c0NvZGUsIHJlc3BvbnNlKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBhbGVydHMoY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBLaWJhbmFSZXF1ZXN0LCByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5KSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBjb250ZXh0LmNvcmUuZWxhc3RpY3NlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlci5zZWFyY2gocmVxdWVzdC5ib2R5KTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IGRhdGEuYm9keVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygnd2F6dWgtZWxhc3RpYzphbGVydHMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDQwMTAsIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuXG4gIC8vIENoZWNrIGlmIHRoZXJlIGFyZSBpbmRpY2VzIGZvciBTdGF0aXN0aWNzXG4gIGFzeW5jIGV4aXN0U3RhdGlzdGljc0luZGljZXMoY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBLaWJhbmFSZXF1ZXN0LCByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5KSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNvbmZpZyA9IGdldENvbmZpZ3VyYXRpb24oKTtcbiAgICAgIGNvbnN0IHN0YXRpc3RpY3NQYXR0ZXJuID0gYCR7Y29uZmlnWydjcm9uLnByZWZpeCddIHx8ICd3YXp1aCd9LSR7Y29uZmlnWydjcm9uLnN0YXRpc3RpY3MuaW5kZXgubmFtZSddIHx8ICdzdGF0aXN0aWNzJ30qYDsgLy9UT0RPOiByZXBsYWNlIGJ5IGRlZmF1bHQgYXMgY29uc3RhbnRzIGluc3RlYWQgaGFyZGNvZGVkICgnd2F6dWgnIGFuZCAnc3RhdGlzdGljcycpXG4gICAgICBjb25zdCBleGlzdEluZGV4ID0gYXdhaXQgY29udGV4dC5jb3JlLmVsYXN0aWNzZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuaW5kaWNlcy5leGlzdHMoe1xuICAgICAgICBpbmRleDogc3RhdGlzdGljc1BhdHRlcm4sXG4gICAgICAgIGFsbG93X25vX2luZGljZXM6IGZhbHNlXG4gICAgICB9KTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IGV4aXN0SW5kZXguYm9keVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygnd2F6dWgtZWxhc3RpYzpleGlzdHNTdGF0aXN0aWNzSW5kaWNlcycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgMTAwMCwgNTAwLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG5cbiAgLy8gQ2hlY2sgaWYgdGhlcmUgYXJlIGluZGljZXMgZm9yIE1vbml0b3JpbmdcbiAgYXN5bmMgZXhpc3RNb25pdG9yaW5nSW5kaWNlcyhjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3QsIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnkpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY29uZmlnID0gZ2V0Q29uZmlndXJhdGlvbigpO1xuICAgICAgY29uc3QgbW9uaXRvcmluZ0luZGV4UGF0dGVybiA9IGNvbmZpZ1snd2F6dWgubW9uaXRvcmluZy5wYXR0ZXJuJ10gfHwgZ2V0U2V0dGluZ0RlZmF1bHRWYWx1ZSgnd2F6dWgubW9uaXRvcmluZy5wYXR0ZXJuJyk7XG4gICAgICBjb25zdCBleGlzdEluZGV4ID0gYXdhaXQgY29udGV4dC5jb3JlLmVsYXN0aWNzZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXIuaW5kaWNlcy5leGlzdHMoe1xuICAgICAgICBpbmRleDogbW9uaXRvcmluZ0luZGV4UGF0dGVybixcbiAgICAgICAgYWxsb3dfbm9faW5kaWNlczogZmFsc2VcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keTogZXhpc3RJbmRleC5ib2R5XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCd3YXp1aC1lbGFzdGljOmV4aXN0c01vbml0b3JpbmdJbmRpY2VzJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAxMDAwLCA1MDAsIHJlc3BvbnNlKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyB1c2luZ0NyZWRlbnRpYWxzKGNvbnRleHQpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5jbHVzdGVyLmdldFNldHRpbmdzKFxuICAgICAgICB7IGluY2x1ZGVfZGVmYXVsdHM6IHRydWUgfVxuICAgICAgKTtcbiAgICAgIHJldHVybiAoKCgoKGRhdGEgfHwge30pLmJvZHkgfHwge30pLmRlZmF1bHRzIHx8IHt9KS54cGFjayB8fCB7fSkuc2VjdXJpdHkgfHwge30pLnVzZXIgIT09IG51bGw7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuICB9O1xuXG4gIGdldEVycm9yRGV0YWlscyhlcnJvcil7XG4gICAgY29uc3Qgc3RhdHVzQ29kZSA9IGVycm9yPy5tZXRhPy5zdGF0dXNDb2RlIHx8IDUwMDtcbiAgICBsZXQgZXJyb3JNZXNzYWdlID0gZXJyb3IubWVzc2FnZTtcblxuICAgIGlmKHN0YXR1c0NvZGUgPT09IDQwMyl7XG4gICAgICBlcnJvck1lc3NhZ2UgPSBlcnJvcj8ubWV0YT8uYm9keT8uZXJyb3I/LnJlYXNvbiB8fCAnUGVybWlzc2lvbiBkZW5pZWQnO1xuICAgIH1cblxuICAgIHJldHVybiBbc3RhdHVzQ29kZSwgZXJyb3JNZXNzYWdlXTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQVdBLElBQUFBLGNBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLE9BQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLGlCQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxlQUFBLEdBQUFILE9BQUE7QUFNQSxJQUFBSSxxQkFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUssVUFBQSxHQUFBTCxPQUFBO0FBQ0EsSUFBQU0sVUFBQSxHQUFBQyxzQkFBQSxDQUFBUCxPQUFBO0FBQ0EsSUFBQVEsWUFBQSxHQUFBUixPQUFBO0FBRUEsSUFBQVMsT0FBQSxHQUFBVCxPQUFBO0FBRUEsSUFBQVUsU0FBQSxHQUFBVixPQUFBO0FBM0JBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBbUJPLE1BQU1XLGdCQUFnQixDQUFDO0VBRzVCQyxXQUFXQSxDQUFBLEVBQUc7SUFBQSxJQUFBQyxnQkFBQSxDQUFBQyxPQUFBO0lBQUEsSUFBQUQsZ0JBQUEsQ0FBQUMsT0FBQTtJQUNaLElBQUksQ0FBQ0MseUJBQXlCLEdBQUcsSUFBSSxDQUFDQyxvQkFBb0IsRUFBRTtJQUM1RCxJQUFJLENBQUNDLFdBQVcsR0FBRyxJQUFJQyx3QkFBVyxFQUFFO0VBQ3RDOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0VDLDBCQUEwQkEsQ0FBQ0MsUUFBZ0IsRUFBVTtJQUNuRCxPQUFRLEdBQUUsSUFBSSxDQUFDTCx5QkFBMEIsVUFBU0ssUUFBUyxFQUFDO0VBQzlEOztFQUVBO0FBQ0Y7QUFDQTtFQUNFSixvQkFBb0JBLENBQUEsRUFBVztJQUM3QixNQUFNSyxNQUFNLEdBQUcsSUFBQUMsa0NBQWdCLEdBQUU7SUFDakMsT0FBT0QsTUFBTSxDQUFDLHNCQUFzQixDQUFDLElBQUksSUFBQUUsZ0NBQXNCLEVBQUMsc0JBQXNCLENBQUM7RUFDekY7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNQyxXQUFXQSxDQUFDQyxPQUE4QixFQUFFQyxPQUEyQyxFQUFFQyxRQUErQixFQUFFO0lBQzlILElBQUk7TUFDRixNQUFNQyxJQUFJLEdBQUcsTUFBTUgsT0FBTyxDQUFDSSxJQUFJLENBQUNDLGFBQWEsQ0FBQ0MsTUFBTSxDQUFDQyxjQUFjLENBQUNDLEdBQUcsQ0FBQ0MsU0FBUyxFQUFFO01BRW5GLE1BQU1BLFNBQVMsR0FBR04sSUFBSSxDQUFDTyxJQUFJO01BQzNCLElBQUksQ0FBQ0QsU0FBUyxJQUFJLE9BQU9BLFNBQVMsS0FBSyxRQUFRLEVBQUU7UUFDL0MsTUFBTSxJQUFJRSxLQUFLLENBQ2IscUVBQXFFLENBQ3RFO01BQ0g7TUFFQSxNQUFNQyxRQUFRLEdBQUdYLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDQyxPQUFPLENBQUNiLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDQyxPQUFPLENBQUNDLE1BQU0sR0FBRyxDQUFDLENBQUM7O01BRTFFO01BQ0EsTUFBTUMsT0FBTyxHQUFHUCxTQUFTLENBQUNRLEtBQUssQ0FBQyxTQUFTLENBQUM7TUFDMUMsTUFBTUMsUUFBUSxHQUFHLEVBQUU7TUFDbkIsS0FBSyxJQUFJQyxJQUFJLElBQUlILE9BQU8sRUFBRTtRQUN4QjtRQUNBLElBQUlHLElBQUksQ0FBQ0MsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1VBQ3RCRCxJQUFJLEdBQUdBLElBQUksQ0FBQ0UsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1VBQ2xDLE1BQU1DLFFBQVEsR0FBR0osSUFBSSxDQUFDSyxLQUFLLENBQUMsR0FBRyxDQUFDO1VBQ2hDLEtBQUssTUFBTUMsT0FBTyxJQUFJRixRQUFRLEVBQUU7WUFDOUJMLFFBQVEsQ0FBQ1EsSUFBSSxDQUFFLElBQUdELE9BQU8sQ0FBQ0UsSUFBSSxFQUFHLEdBQUUsQ0FBQztVQUN0QztRQUNGLENBQUMsTUFBTTtVQUNMVCxRQUFRLENBQUNRLElBQUksQ0FBQ1AsSUFBSSxDQUFDO1FBQ3JCO01BQ0Y7O01BRUE7TUFDQSxNQUFNUyxLQUFLLEdBQUdWLFFBQVEsQ0FBQ1csTUFBTSxDQUMzQlYsSUFBSSxJQUFJQSxJQUFJLENBQUNDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSUQsSUFBSSxDQUFDQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQ2pEO01BRUQsTUFBTU4sT0FBTyxHQUNYRixRQUFRLEtBQUssR0FBRyxHQUFHWCxPQUFPLENBQUNZLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDUSxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUdyQixPQUFPLENBQUNZLE1BQU0sQ0FBQ0MsT0FBTztNQUNqRixNQUFNZ0IsVUFBVSxHQUFHRixLQUFLLENBQUNDLE1BQU0sQ0FBQ1YsSUFBSSxJQUFJO1FBQ3RDQSxJQUFJLEdBQUdBLElBQUksQ0FBQ0csS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUN4QixNQUFNVixRQUFRLEdBQUdPLElBQUksQ0FBQ0EsSUFBSSxDQUFDSixNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3RDSSxJQUFJLEdBQUdQLFFBQVEsS0FBSyxHQUFHLEdBQUdPLElBQUksQ0FBQ0csS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHSCxJQUFJO1FBQ2xELE9BQU9BLElBQUksQ0FBQ0MsUUFBUSxDQUFDTixPQUFPLENBQUMsSUFBSUEsT0FBTyxDQUFDTSxRQUFRLENBQUNELElBQUksQ0FBQztNQUN6RCxDQUFDLENBQUM7TUFDRixJQUFBWSxXQUFHLEVBQ0QsMkJBQTJCLEVBQzFCLHNCQUFxQkQsVUFBVSxJQUFJRSxLQUFLLENBQUNDLE9BQU8sQ0FBQ0gsVUFBVSxDQUFDLElBQUlBLFVBQVUsQ0FBQ2YsTUFBTSxHQUM5RSxLQUFLLEdBQ0wsSUFDSCxFQUFDLEVBQ0YsT0FBTyxDQUNSO01BQ0QsT0FBT2UsVUFBVSxJQUFJRSxLQUFLLENBQUNDLE9BQU8sQ0FBQ0gsVUFBVSxDQUFDLElBQUlBLFVBQVUsQ0FBQ2YsTUFBTSxHQUMvRGIsUUFBUSxDQUFDZ0MsRUFBRSxDQUFDO1FBQ1p4QixJQUFJLEVBQUU7VUFDSnlCLFVBQVUsRUFBRSxHQUFHO1VBQ2ZDLE1BQU0sRUFBRSxJQUFJO1VBQ1pqQyxJQUFJLEVBQUcsc0JBQXFCRixPQUFPLENBQUNZLE1BQU0sQ0FBQ0MsT0FBUTtRQUNyRDtNQUNGLENBQUMsQ0FBQyxHQUNBWixRQUFRLENBQUNnQyxFQUFFLENBQUM7UUFDWnhCLElBQUksRUFBRTtVQUNKeUIsVUFBVSxFQUFFLEdBQUc7VUFDZkMsTUFBTSxFQUFFLEtBQUs7VUFDYmpDLElBQUksRUFBRyx5QkFBd0JGLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDQyxPQUFRO1FBQ3hEO01BQ0YsQ0FBQyxDQUFDO0lBQ04sQ0FBQyxDQUFDLE9BQU91QixLQUFLLEVBQUU7TUFDZCxJQUFBTixXQUFHLEVBQUMsMkJBQTJCLEVBQUVNLEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFLLENBQUM7TUFDeEQsT0FBTyxJQUFBRSw0QkFBYSxFQUNqQiwwREFBeURGLEtBQUssQ0FBQ0MsT0FBTyxJQUN2RUQsS0FBTSxFQUFDLEVBQ1AsSUFBSSxFQUNKLEdBQUcsRUFDSG5DLFFBQVEsQ0FDVDtJQUNIO0VBQ0Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNc0MsWUFBWUEsQ0FBQ3hDLE9BQThCLEVBQUVDLE9BQTJDLEVBQUVDLFFBQStCLEVBQUU7SUFDL0gsSUFBSTtNQUNGLE1BQU1DLElBQUksR0FBRyxNQUFNSCxPQUFPLENBQUNJLElBQUksQ0FBQ3FDLFlBQVksQ0FBQ25DLE1BQU0sQ0FBQ29DLElBQUksQ0FBd0M7UUFBRUMsSUFBSSxFQUFFO01BQWdCLENBQUMsQ0FBQztNQUUxSCxNQUFNQyxrQkFBa0IsR0FBR3pDLElBQUksQ0FBQzBDLGFBQWEsQ0FBQ0gsSUFBSSxDQUNoRHZCLElBQUksSUFBSUEsSUFBSSxDQUFDMkIsVUFBVSxDQUFDQyxLQUFLLEtBQUs5QyxPQUFPLENBQUNZLE1BQU0sQ0FBQ0MsT0FBTyxDQUN6RDtNQUNELElBQUFpQixXQUFHLEVBQ0QsNEJBQTRCLEVBQzNCLHdCQUF1QmEsa0JBQWtCLEdBQUdBLGtCQUFrQixDQUFDRSxVQUFVLENBQUNDLEtBQUssR0FBRyxJQUFLLEVBQUMsRUFDekYsT0FBTyxDQUNSO01BQ0QsT0FBT0gsa0JBQWtCLEdBQ3JCMUMsUUFBUSxDQUFDZ0MsRUFBRSxDQUFDO1FBQ1p4QixJQUFJLEVBQUU7VUFBRXlCLFVBQVUsRUFBRSxHQUFHO1VBQUVDLE1BQU0sRUFBRSxJQUFJO1VBQUVqQyxJQUFJLEVBQUU7UUFBc0I7TUFDckUsQ0FBQyxDQUFDLEdBQ0FELFFBQVEsQ0FBQ2dDLEVBQUUsQ0FBQztRQUNaeEIsSUFBSSxFQUFFO1VBQ0p5QixVQUFVLEVBQUUsR0FBRztVQUNmQyxNQUFNLEVBQUUsS0FBSztVQUNiQyxLQUFLLEVBQUUsS0FBSztVQUNaQyxPQUFPLEVBQUU7UUFDWDtNQUNGLENBQUMsQ0FBQztJQUNOLENBQUMsQ0FBQyxPQUFPRCxLQUFLLEVBQUU7TUFDZCxJQUFBTixXQUFHLEVBQUMsNEJBQTRCLEVBQUVNLEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFLLENBQUM7TUFDekQsT0FBTyxJQUFBRSw0QkFBYSxFQUNqQiw0RUFBMkVGLEtBQUssQ0FBQ0MsT0FBTyxJQUN6RkQsS0FBTSxFQUFDLEVBQ1AsSUFBSSxFQUNKLEdBQUcsRUFDSG5DLFFBQVEsQ0FDVDtJQUNIO0VBQ0Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNOEMsV0FBV0EsQ0FBQ2hELE9BQThCLEVBQUVDLE9BQWlILEVBQUVDLFFBQStCLEVBQUU7SUFDcE0sSUFBSTtNQUNGO01BQ0EsSUFBSStDLE9BQU8sR0FBRztRQUNaQyxJQUFJLEVBQUUsQ0FBQztRQUNQQyxLQUFLLEVBQUU7VUFDTEMsSUFBSSxFQUFFO1lBQ0pDLElBQUksRUFBRSxFQUFFO1lBQ1JDLFFBQVEsRUFBRTtjQUNSQyxJQUFJLEVBQUU7Z0JBQ0osVUFBVSxFQUFFO2NBQ2Q7WUFDRixDQUFDO1lBQ0QxQixNQUFNLEVBQUUsQ0FDTjtjQUNFMkIsS0FBSyxFQUFFO2dCQUFFQyxTQUFTLEVBQUUsQ0FBQztjQUFFO1lBQ3pCLENBQUM7VUFFTDtRQUNGLENBQUM7UUFDREMsSUFBSSxFQUFFO1VBQ0osR0FBRyxFQUFFO1lBQ0hDLEtBQUssRUFBRTtjQUNMQyxLQUFLLEVBQUUsRUFBRTtjQUNUVixJQUFJLEVBQUUsQ0FBQztjQUNQVyxLQUFLLEVBQUU7Z0JBQUVDLE1BQU0sRUFBRTtjQUFPO1lBQzFCO1VBQ0Y7UUFDRjtNQUNGLENBQUM7O01BRUQ7TUFDQSxNQUFNQyxPQUFPLEdBQUcsUUFBUTtNQUN4QixNQUFNQyxNQUFNLEdBQUcsS0FBSztNQUNwQmYsT0FBTyxDQUFDRSxLQUFLLENBQUNDLElBQUksQ0FBQ3ZCLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzJCLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBR08sT0FBTztNQUNoRWQsT0FBTyxDQUFDRSxLQUFLLENBQUNDLElBQUksQ0FBQ3ZCLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzJCLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBR1EsTUFBTTs7TUFFOUQ7TUFDQWYsT0FBTyxDQUFDRSxLQUFLLENBQUNDLElBQUksQ0FBQ0MsSUFBSSxDQUFDM0IsSUFBSSxDQUMxQnpCLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDb0QsSUFBSSxLQUFLLFNBQVMsR0FDN0I7UUFBRWhELEtBQUssRUFBRTtVQUFFLGNBQWMsRUFBRWhCLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDcUQ7UUFBUTtNQUFFLENBQUMsR0FDckQ7UUFBRWpELEtBQUssRUFBRTtVQUFFLGNBQWMsRUFBRWhCLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDcUQ7UUFBUTtNQUFFLENBQUMsQ0FDMUQ7TUFFRCxJQUFHakUsT0FBTyxDQUFDa0QsS0FBSyxDQUFDZ0IsVUFBVSxFQUN6QmxCLE9BQU8sQ0FBQ0UsS0FBSyxDQUFDQyxJQUFJLENBQUN2QixNQUFNLENBQUNILElBQUksQ0FDNUI7UUFDRWlDLEtBQUssRUFBRTtVQUNMLFVBQVUsRUFBRTFELE9BQU8sQ0FBQ2tELEtBQUssQ0FBQ2dCLFVBQVUsQ0FBQzNDLEtBQUssQ0FBQyxHQUFHO1FBQ2hEO01BQ0YsQ0FBQyxDQUNGO01BQ0h5QixPQUFPLENBQUNTLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsS0FBSyxDQUFDQyxLQUFLLEdBQUczRCxPQUFPLENBQUNZLE1BQU0sQ0FBQytDLEtBQUs7TUFFcEQsTUFBTXpELElBQUksR0FBRyxNQUFNSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsYUFBYSxDQUFDQyxNQUFNLENBQUM4RCxhQUFhLENBQUNDLE1BQU0sQ0FBQztRQUN4RW5CLElBQUksRUFBRSxDQUFDO1FBQ1BvQixLQUFLLEVBQUVyRSxPQUFPLENBQUNZLE1BQU0sQ0FBQ0MsT0FBTztRQUM3QkosSUFBSSxFQUFFdUM7TUFDUixDQUFDLENBQUM7TUFFRixPQUFPOUMsSUFBSSxDQUFDTyxJQUFJLENBQUM2RCxJQUFJLENBQUNDLEtBQUssQ0FBQ0MsS0FBSyxLQUFLLENBQUMsSUFDckMsT0FBT3RFLElBQUksQ0FBQ08sSUFBSSxDQUFDZ0UsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxHQUMzRHpFLFFBQVEsQ0FBQ2dDLEVBQUUsQ0FBQztRQUNaeEIsSUFBSSxFQUFFO1VBQUV5QixVQUFVLEVBQUUsR0FBRztVQUFFaEMsSUFBSSxFQUFFO1FBQUc7TUFDcEMsQ0FBQyxDQUFDLEdBQ0FELFFBQVEsQ0FBQ2dDLEVBQUUsQ0FBQztRQUNaeEIsSUFBSSxFQUFFO1VBQ0p5QixVQUFVLEVBQUUsR0FBRztVQUNmaEMsSUFBSSxFQUFFQSxJQUFJLENBQUNPLElBQUksQ0FBQ2dFLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDQztRQUMvQztNQUNGLENBQUMsQ0FBQztJQUNOLENBQUMsQ0FBQyxPQUFPdkMsS0FBSyxFQUFFO01BQ2QsSUFBQU4sV0FBRyxFQUFDLDJCQUEyQixFQUFFTSxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSyxDQUFDO01BQ3hELE9BQU8sSUFBQUUsNEJBQWEsRUFBQ0YsS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFbkMsUUFBUSxDQUFDO0lBQ25FO0VBQ0Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNMkUsNkJBQTZCQSxDQUFDN0UsT0FBTyxFQUFFOEUsSUFBSSxFQUFFQyxHQUFHLEVBQUU7SUFDdEQ7SUFDQSxJQUFJQyxTQUFTLEdBQUcsRUFBRTtJQUNsQixLQUFLLElBQUk3RCxJQUFJLElBQUkyRCxJQUFJLEVBQUU7TUFDckIsSUFBSUcsT0FBTyxHQUFHLEtBQUs7UUFDakJDLFNBQVMsR0FBRyxLQUFLO01BQ25CLElBQUk7UUFDRkQsT0FBTyxHQUFHLE1BQU1qRixPQUFPLENBQUNJLElBQUksQ0FBQ0MsYUFBYSxDQUFDQyxNQUFNLENBQUM4RCxhQUFhLENBQUNDLE1BQU0sQ0FBQztVQUNyRUMsS0FBSyxFQUFFbkQsSUFBSSxDQUFDNEI7UUFDZCxDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT1YsS0FBSyxFQUFFO1FBQ2Q2QyxTQUFTLEdBQUcsSUFBSTtNQUNsQjtNQUNBLElBQ0UsQ0FBQyxDQUFDLENBQUNELE9BQU8sSUFBSSxDQUFDLENBQUMsRUFBRXZFLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRTZELElBQUksSUFBSSxDQUFDLENBQUMsRUFBRUMsS0FBSyxDQUFDQyxLQUFLLElBQUksQ0FBQyxJQUN6RCxDQUFDUyxTQUFTLElBQUksQ0FBQyxDQUFDLENBQUNELE9BQU8sSUFBSSxDQUFDLENBQUMsRUFBRXZFLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRTZELElBQUksSUFBSSxDQUFDLENBQUMsRUFBRUMsS0FBSyxLQUFLLENBQUUsRUFDckU7UUFDQVEsU0FBUyxDQUFDdEQsSUFBSSxDQUFDUCxJQUFJLENBQUM7TUFDdEI7SUFDRjtJQUNBLE9BQU82RCxTQUFTO0VBQ2xCOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0VHLG9CQUFvQkEsQ0FBQ0MsZ0JBQWdCLEVBQUU7SUFDckMsTUFBTUMsT0FBTyxHQUFHLENBQUMsV0FBVyxFQUFFLGFBQWEsRUFBRSxjQUFjLEVBQUUsVUFBVSxDQUFDO0lBQ3hFLElBQUlQLElBQUksR0FBRyxFQUFFO0lBQ2IsS0FBSyxNQUFNUixLQUFLLElBQUljLGdCQUFnQixFQUFFO01BQ3BDLElBQUlFLEtBQUssRUFBRUMsTUFBTTtNQUNqQixJQUFJO1FBQ0ZBLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxLQUFLLENBQUNuQixLQUFLLENBQUN4QixVQUFVLENBQUM0QyxNQUFNLENBQUM7TUFDOUMsQ0FBQyxDQUFDLE9BQU9yRCxLQUFLLEVBQUU7UUFDZDtNQUNGO01BRUFpRCxLQUFLLEdBQUdDLE1BQU0sQ0FBQzFELE1BQU0sQ0FBQ1YsSUFBSSxJQUFJa0UsT0FBTyxDQUFDakUsUUFBUSxDQUFDRCxJQUFJLENBQUN3RSxJQUFJLENBQUMsQ0FBQztNQUMxRCxJQUFJTCxLQUFLLENBQUN2RSxNQUFNLEtBQUssQ0FBQyxFQUFFO1FBQ3RCK0QsSUFBSSxDQUFDcEQsSUFBSSxDQUFDO1VBQ1JrRSxFQUFFLEVBQUV0QixLQUFLLENBQUNzQixFQUFFO1VBQ1o3QyxLQUFLLEVBQUV1QixLQUFLLENBQUN4QixVQUFVLENBQUNDO1FBQzFCLENBQUMsQ0FBQztNQUNKO0lBQ0Y7SUFDQSxPQUFPK0IsSUFBSTtFQUNiOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1lLGtCQUFrQkEsQ0FBQzdGLE9BQThCLEVBQUVDLE9BQXdDLEVBQUVDLFFBQStCLEVBQUU7SUFDbEksSUFBSTtNQUNGLE9BQU9BLFFBQVEsQ0FBQ2dDLEVBQUUsQ0FBQztRQUNqQnhCLElBQUksRUFBRTtVQUNKb0YsUUFBUSxFQUFFOUYsT0FBTyxDQUFDK0YsS0FBSyxDQUFDQyxRQUFRLENBQUNGO1FBQ25DO01BQ0YsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU96RCxLQUFLLEVBQUU7TUFDZCxJQUFBTixXQUFHLEVBQUMsa0NBQWtDLEVBQUVNLEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFLLENBQUM7TUFDL0QsT0FBTyxJQUFBRSw0QkFBYSxFQUFDRixLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUVuQyxRQUFRLENBQUM7SUFDbkU7RUFDRjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTStGLHNCQUFzQkEsQ0FBQ0MsV0FBVyxFQUFFTixFQUFFLEVBQUVPLFNBQVMsR0FBRyxLQUFLLEVBQUU7SUFDL0QsSUFBSTtNQUNGLE1BQU12RyxNQUFNLEdBQUcsSUFBQUMsa0NBQWdCLEdBQUU7TUFDakMsSUFBSXVHLGlCQUFpQixHQUNuQixDQUFDeEcsTUFBTSxJQUFJLENBQUMsQ0FBQyxFQUFFLDBCQUEwQixDQUFDLElBQUksSUFBQUUsZ0NBQXNCLEVBQUMsMEJBQTBCLENBQUM7TUFDbEcsSUFBQWlDLFdBQUcsRUFDRCxzQ0FBc0MsRUFDckMsWUFBV21FLFdBQVcsQ0FBQ25GLE1BQU8saUJBQWdCLEVBQy9DLE9BQU8sQ0FDUjtNQUNELElBQUFnQixXQUFHLEVBQ0Qsc0NBQXNDLEVBQ3JDLHFCQUFvQjZELEVBQUcsRUFBQyxFQUN6QixPQUFPLENBQ1I7TUFDRCxNQUFNUyxRQUFRLEdBQUcsRUFBRTtNQUNuQixJQUFJQyxVQUFVLEVBQUVDLFlBQVk7TUFDNUIsS0FBSyxJQUFJQyxPQUFPLElBQUlOLFdBQVcsRUFBRTtRQUMvQkksVUFBVSxHQUFHZCxJQUFJLENBQUNDLEtBQUssQ0FBQ0QsSUFBSSxDQUFDaUIsU0FBUyxDQUFDRCxPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDOztRQUV4RDtRQUNBLElBQ0VKLFVBQVUsSUFDVkEsVUFBVSxDQUFDSyxxQkFBcUIsSUFDaENMLFVBQVUsQ0FBQ0sscUJBQXFCLENBQUNDLGdCQUFnQixJQUNqRCxPQUFPTixVQUFVLENBQUNLLHFCQUFxQixDQUFDQyxnQkFBZ0IsS0FBSyxRQUFRLEVBQ3JFO1VBQ0EsTUFBTUMsVUFBVSxHQUFHUCxVQUFVLENBQUNLLHFCQUFxQixDQUFDQyxnQkFBZ0I7VUFFcEUsTUFBTUUsWUFBWSxHQUFHRCxVQUFVLENBQUN6RixRQUFRLENBQUMsa0JBQWtCLENBQUM7VUFDNUQsSUFBSTBGLFlBQVksRUFBRTtZQUNoQixJQUFJWCxTQUFTLElBQUlBLFNBQVMsS0FBSyxTQUFTLEVBQUU7Y0FDeEMsSUFDRUMsaUJBQWlCLENBQUNoRixRQUFRLENBQUMrRSxTQUFTLENBQUMsSUFDckNDLGlCQUFpQixDQUFDaEYsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEVBQzVDO2dCQUNBZ0YsaUJBQWlCLEdBQUdBLGlCQUFpQixDQUFDNUUsS0FBSyxDQUN6QyxnQkFBZ0IsQ0FDakIsQ0FBQyxDQUFDLENBQUM7Y0FDTjtZQUNGO1lBQ0E4RSxVQUFVLENBQUNLLHFCQUFxQixDQUFDQyxnQkFBZ0IsR0FBR0MsVUFBVSxDQUFDRSxPQUFPLENBQ3BFLG1CQUFtQixFQUNuQlgsaUJBQWlCLENBQUNBLGlCQUFpQixDQUFDckYsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFDcERvRixTQUFTLElBQUlBLFNBQVMsS0FBSyxTQUFVLEdBQ3BDQyxpQkFBaUIsR0FDakJBLGlCQUFpQixHQUFHLEdBQUcsQ0FDNUI7VUFDSCxDQUFDLE1BQU07WUFDTEUsVUFBVSxDQUFDSyxxQkFBcUIsQ0FBQ0MsZ0JBQWdCLEdBQUdDLFVBQVUsQ0FBQ0UsT0FBTyxDQUNwRSxlQUFlLEVBQ2ZuQixFQUFFLENBQ0g7VUFDSDtRQUNGOztRQUVBO1FBQ0EsSUFBSSxPQUFPLENBQUNVLFVBQVUsSUFBSSxDQUFDLENBQUMsRUFBRVUsUUFBUSxLQUFLLFFBQVEsRUFBRTtVQUNuRFYsVUFBVSxDQUFDVSxRQUFRLEdBQUdWLFVBQVUsQ0FBQ1UsUUFBUSxDQUFDRCxPQUFPLENBQy9DLGVBQWUsRUFDZm5CLEVBQUUsQ0FDSDtRQUNIOztRQUVBO1FBQ0FXLFlBQVksR0FBRyxDQUFDLENBQUM7UUFDakJBLFlBQVksQ0FBQ0MsT0FBTyxDQUFDUyxLQUFLLENBQUMsR0FBR1gsVUFBVTtRQUV4Q0QsUUFBUSxDQUFDM0UsSUFBSSxDQUFDO1VBQ1pvQixVQUFVLEVBQUV5RCxZQUFZLENBQUNXLGFBQWE7VUFDdEN2RSxJQUFJLEVBQUU2RCxPQUFPLENBQUNTLEtBQUs7VUFDbkJyQixFQUFFLEVBQUVZLE9BQU8sQ0FBQ1csR0FBRztVQUNmQyxRQUFRLEVBQUViLFlBQVksQ0FBQ1csYUFBYSxDQUFDRztRQUN2QyxDQUFDLENBQUM7TUFDSjtNQUNBLE9BQU9oQixRQUFRO0lBQ2pCLENBQUMsQ0FBQyxPQUFPaEUsS0FBSyxFQUFFO01BQ2QsSUFBQU4sV0FBRyxFQUFDLHNDQUFzQyxFQUFFTSxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSyxDQUFDO01BQ25FLE9BQU9pRixPQUFPLENBQUNDLE1BQU0sQ0FBQ2xGLEtBQUssQ0FBQztJQUM5QjtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRW1GLDZCQUE2QkEsQ0FDM0J0QixXQUFXLEVBQ1hOLEVBQUUsRUFDRjZCLEtBQUssR0FBRyxFQUFFLEVBQ1Y5QixJQUFJLEVBQ0orQixXQUFXLEVBQ1hDLFlBQVksR0FBRyxHQUFHLEVBQ2xCO0lBQ0EsSUFBSTtNQUNGLE1BQU10QixRQUFRLEdBQUcsRUFBRTtNQUNuQixJQUFJQyxVQUFVLEVBQUVDLFlBQVk7TUFFNUIsS0FBSyxNQUFNQyxPQUFPLElBQUlOLFdBQVcsRUFBRTtRQUNqQztRQUNBSSxVQUFVLEdBQUdkLElBQUksQ0FBQ2lCLFNBQVMsQ0FBQ0QsT0FBTyxDQUFDRSxPQUFPLENBQUM7UUFDNUNKLFVBQVUsR0FBR0EsVUFBVSxDQUFDUyxPQUFPLENBQUMsZUFBZSxFQUFFbkIsRUFBRSxDQUFDO1FBQ3BEVSxVQUFVLEdBQUdkLElBQUksQ0FBQ0MsS0FBSyxDQUFDYSxVQUFVLENBQUM7O1FBRW5DO1FBQ0FDLFlBQVksR0FBRyxDQUFDLENBQUM7UUFDakJBLFlBQVksQ0FBQ0MsT0FBTyxDQUFDUyxLQUFLLENBQUMsR0FBR1gsVUFBVTtRQUV4QyxNQUFNVSxRQUFRLEdBQUd4QixJQUFJLENBQUNDLEtBQUssQ0FBQ2MsWUFBWSxDQUFDVyxhQUFhLENBQUNGLFFBQVEsQ0FBQztRQUNoRSxNQUFNakUsS0FBSyxHQUFHaUUsUUFBUSxDQUFDakUsS0FBSztRQUU1QixJQUFJaUUsUUFBUSxDQUFDckUsSUFBSSxJQUFJcUUsUUFBUSxDQUFDckUsSUFBSSxLQUFLLFVBQVUsRUFBRTtVQUNqRCxJQUFJUSxLQUFLLEdBQUcsRUFBRTtVQUNkLElBQUlKLEtBQUssS0FBSyw0QkFBNEIsRUFBRTtZQUMxQyxLQUFLLE1BQU02RSxJQUFJLElBQUlILEtBQUssRUFBRTtjQUN4QnRFLEtBQUssSUFBSyxhQUFZd0UsWUFBYSxxQkFBb0JoQyxJQUFLLHNCQUFxQmlDLElBQUksQ0FBQ2pDLElBQUssYUFBWWlDLElBQUksQ0FBQ2pDLElBQUssS0FBSTtZQUN2SDtZQUNBeEMsS0FBSyxHQUFHQSxLQUFLLENBQUMwRSxTQUFTLENBQUMsQ0FBQyxFQUFFMUUsS0FBSyxDQUFDcEMsTUFBTSxHQUFHLENBQUMsQ0FBQztVQUM5QyxDQUFDLE1BQU0sSUFBSWdDLEtBQUssS0FBSyxvQ0FBb0MsRUFBRTtZQUN6REksS0FBSyxJQUFLLGFBQVl3RSxZQUFhLHFCQUFvQmhDLElBQUssYUFBWUEsSUFBSyxZQUFXO1VBQzFGLENBQUMsTUFBTTtZQUNMLElBQUk1QyxLQUFLLENBQUMrRSxVQUFVLENBQUMsc0JBQXNCLENBQUMsRUFBRTtjQUM1QyxNQUFNO2dCQUFFbEI7Y0FBaUIsQ0FBQyxHQUFHTCxZQUFZLENBQUNXLGFBQWEsQ0FBQ1AscUJBQXFCO2NBQzdFSixZQUFZLENBQUNXLGFBQWEsQ0FBQ1AscUJBQXFCLENBQUNDLGdCQUFnQixHQUFHQSxnQkFBZ0IsQ0FBQ0csT0FBTyxDQUFDLG9CQUFvQixFQUFFWSxZQUFZLENBQUM7WUFDbEk7WUFDQSxJQUFJNUUsS0FBSyxDQUFDK0UsVUFBVSxDQUFDLHNCQUFzQixDQUFDLElBQUluQyxJQUFJLEtBQUssR0FBRyxJQUFJQSxJQUFJLEtBQUssS0FBSyxJQUFJcUIsUUFBUSxDQUFDbkcsTUFBTSxDQUFDa0gsVUFBVSxDQUFDM0csUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO2NBQzNILE1BQU00RyxlQUFlLEdBQUcsVUFBVTtjQUNsQyxNQUFNQyxTQUFTLEdBQUcxQixZQUFZLENBQUNXLGFBQWEsQ0FBQ2dCLGNBQWMsR0FDdkQxQyxJQUFJLENBQUNDLEtBQUssQ0FBQ2MsWUFBWSxDQUFDVyxhQUFhLENBQUNnQixjQUFjLENBQUMsR0FDckRsQixRQUFRO2NBQ1o3RCxLQUFLLElBQUk4RSxTQUFTLENBQUNwSCxNQUFNLENBQUNrSCxVQUFVLENBQUNoQixPQUFPLENBQUMsc0JBQXNCLEVBQUVZLFlBQVksQ0FBQyxDQUFDWixPQUFPLENBQUNpQixlQUFlLEVBQUcsdUJBQXNCckMsSUFBSyx3QkFBdUIrQixXQUFZLEdBQUUsQ0FBQyxDQUMzS1gsT0FBTyxDQUFDLFdBQVcsRUFBRXBCLElBQUksQ0FBQztZQUMvQixDQUFDLE1BQU0sSUFBSTVDLEtBQUssQ0FBQytFLFVBQVUsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFO2NBQ25ELE1BQU1FLGVBQWUsR0FBRyxVQUFVO2NBQ2xDN0UsS0FBSyxJQUFJNkQsUUFBUSxDQUFDbkcsTUFBTSxDQUFDa0gsVUFBVSxDQUFDaEIsT0FBTyxDQUFDLHNCQUFzQixFQUFFWSxZQUFZLENBQUMsQ0FBQ1osT0FBTyxDQUFDaUIsZUFBZSxFQUFHLHNCQUFxQk4sV0FBWSxHQUFFLENBQUM7WUFDbEosQ0FBQyxNQUFNO2NBQ0x2RSxLQUFLLEdBQUc2RCxRQUFRLENBQUNuRyxNQUFNLENBQUNrSCxVQUFVO1lBQ3BDO1VBQ0Y7VUFFQWYsUUFBUSxDQUFDbkcsTUFBTSxDQUFDa0gsVUFBVSxHQUFHNUUsS0FBSyxDQUFDNEQsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUM7VUFDdERSLFlBQVksQ0FBQ1csYUFBYSxDQUFDRixRQUFRLEdBQUd4QixJQUFJLENBQUNpQixTQUFTLENBQUNPLFFBQVEsQ0FBQztRQUNoRTtRQUVBWCxRQUFRLENBQUMzRSxJQUFJLENBQUM7VUFDWm9CLFVBQVUsRUFBRXlELFlBQVksQ0FBQ1csYUFBYTtVQUN0Q3ZFLElBQUksRUFBRTZELE9BQU8sQ0FBQ1MsS0FBSztVQUNuQnJCLEVBQUUsRUFBRVksT0FBTyxDQUFDVyxHQUFHO1VBQ2ZDLFFBQVEsRUFBRWIsWUFBWSxDQUFDVyxhQUFhLENBQUNHO1FBQ3ZDLENBQUMsQ0FBQztNQUNKO01BRUEsT0FBT2hCLFFBQVE7SUFDakIsQ0FBQyxDQUFDLE9BQU9oRSxLQUFLLEVBQUU7TUFDZCxJQUFBTixXQUFHLEVBQ0QsNkNBQTZDLEVBQzdDTSxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSyxDQUN2QjtNQUNELE9BQU9pRixPQUFPLENBQUNDLE1BQU0sQ0FBQ2xGLEtBQUssQ0FBQztJQUM5QjtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTThGLFNBQVNBLENBQUNuSSxPQUE4QixFQUFFQyxPQUF3RCxFQUFFQyxRQUErQixFQUFFO0lBQ3pJLElBQUk7TUFDRixJQUNHLENBQUNELE9BQU8sQ0FBQ1ksTUFBTSxDQUFDdUgsR0FBRyxDQUFDaEgsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUN4QyxDQUFDbkIsT0FBTyxDQUFDWSxNQUFNLENBQUN1SCxHQUFHLENBQUNoSCxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQ3pDO1FBQ0EsTUFBTSxJQUFJVCxLQUFLLENBQUMsNENBQTRDLENBQUM7TUFDL0Q7TUFFQSxNQUFNMEgsU0FBUyxHQUFHcEksT0FBTyxDQUFDWSxNQUFNLENBQUN1SCxHQUFHLENBQUNoSCxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQ3JELFVBQVUsR0FDVixRQUFRO01BRVosTUFBTWtILFFBQVEsR0FBR3JJLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDdUgsR0FBRyxDQUFDNUcsS0FBSyxDQUFDLEdBQUcsQ0FBQztNQUM5QyxNQUFNK0csUUFBUSxHQUFHRCxRQUFRLENBQUMsQ0FBQyxDQUFDO01BRTVCLE1BQU1FLElBQUksR0FDUkgsU0FBUyxLQUFLLFVBQVUsR0FDcEJJLHNDQUFzQixDQUFDRixRQUFRLENBQUMsR0FDaENHLG9DQUFvQixDQUFDSCxRQUFRLENBQUM7TUFDcEMsSUFBSSxDQUFDQyxJQUFJLEVBQUU7UUFDVCxPQUFPdEksUUFBUSxDQUFDeUksUUFBUSxDQUFDO1VBQUNqSSxJQUFJLEVBQUM7WUFBQzRCLE9BQU8sRUFBRyxnQ0FBK0JyQyxPQUFPLENBQUNZLE1BQU0sQ0FBQ3VILEdBQUk7VUFBQztRQUFDLENBQUMsQ0FBQztNQUNsRztNQUNBLElBQUFyRyxXQUFHLEVBQUMseUJBQXlCLEVBQUcsR0FBRXNHLFNBQVUsSUFBR0UsUUFBUyx3QkFBdUJ0SSxPQUFPLENBQUNZLE1BQU0sQ0FBQ0MsT0FBUSxFQUFDLEVBQUUsT0FBTyxDQUFDO01BQ2pILE1BQU1xRixTQUFTLEdBQUduRyxPQUFPLENBQUMrRixLQUFLLENBQUM2QyxPQUFPLENBQUNDLE1BQU0sSUFBSTdJLE9BQU8sQ0FBQytGLEtBQUssQ0FBQzZDLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDQyxhQUFhLElBQUk5SSxPQUFPLENBQUMrRixLQUFLLENBQUM2QyxPQUFPLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDQyxVQUFVLENBQUM5SSxPQUFPLENBQUM7TUFDOUosTUFBTStJLEdBQUcsR0FBRyxNQUFNLElBQUksQ0FBQy9DLHNCQUFzQixDQUMzQ3VDLElBQUksRUFDSnZJLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDQyxPQUFPLEVBQ3RCcUYsU0FBUyxDQUNWO01BQ0QsT0FBT2pHLFFBQVEsQ0FBQ2dDLEVBQUUsQ0FBQztRQUNqQnhCLElBQUksRUFBRTtVQUFFdUksV0FBVyxFQUFFLElBQUk7VUFBRUQsR0FBRyxFQUFFQTtRQUFJO01BQ3RDLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPM0csS0FBSyxFQUFFO01BQ2QsSUFBQU4sV0FBRyxFQUFDLHlCQUF5QixFQUFFTSxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSyxDQUFDO01BQ3RELE9BQU8sSUFBQUUsNEJBQWEsRUFBQ0YsS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFbkMsUUFBUSxDQUFDO0lBQ25FO0VBQ0Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNZ0osZ0JBQWdCQSxDQUFDbEosT0FBOEIsRUFBRUMsT0FBc0UsRUFBRUMsUUFBK0IsRUFBRTtJQUM5SixJQUFJO01BQ0YsSUFDRSxDQUFDRCxPQUFPLENBQUNZLE1BQU0sQ0FBQ0MsT0FBTyxJQUN2QixDQUFDYixPQUFPLENBQUNZLE1BQU0sQ0FBQ3VILEdBQUcsSUFDbkIsQ0FBQ25JLE9BQU8sQ0FBQ1MsSUFBSSxJQUNiLENBQUNULE9BQU8sQ0FBQ1MsSUFBSSxDQUFDK0csS0FBSyxJQUNuQixDQUFDeEgsT0FBTyxDQUFDUyxJQUFJLENBQUMrRyxLQUFLLENBQUMwQixjQUFjLElBQ2xDLENBQUNsSixPQUFPLENBQUNTLElBQUksQ0FBQytHLEtBQUssQ0FBQzlCLElBQUksSUFDdkIxRixPQUFPLENBQUNZLE1BQU0sQ0FBQ3VILEdBQUcsSUFBSSxDQUFDbkksT0FBTyxDQUFDWSxNQUFNLENBQUN1SCxHQUFHLENBQUNoSCxRQUFRLENBQUMsVUFBVSxDQUFFLEVBQ2hFO1FBQ0EsTUFBTSxJQUFJVCxLQUFLLENBQUMsNENBQTRDLENBQUM7TUFDL0Q7TUFFQSxNQUFNZ0MsSUFBSSxHQUFHMUMsT0FBTyxDQUFDWSxNQUFNLENBQUN1SCxHQUFHLENBQUM1RyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BRTdDLE1BQU1nSCxJQUFJLEdBQUdZLHFDQUFxQixDQUFDekcsSUFBSSxDQUFDO01BQ3hDLE1BQU04RSxLQUFLLEdBQUd4SCxPQUFPLENBQUNTLElBQUksQ0FBQytHLEtBQUssQ0FBQzBCLGNBQWM7TUFDL0MsTUFBTXhELElBQUksR0FBRzFGLE9BQU8sQ0FBQ1MsSUFBSSxDQUFDK0csS0FBSyxDQUFDOUIsSUFBSTtNQUNwQyxNQUFNMEQsVUFBVSxHQUFHcEosT0FBTyxDQUFDUyxJQUFJLENBQUMrRyxLQUFLLENBQUNDLFdBQVc7TUFFakQsTUFBTTtRQUFFOUIsRUFBRSxFQUFFMEQsU0FBUztRQUFFdkcsS0FBSyxFQUFFd0c7TUFBWSxDQUFDLEdBQUd0SixPQUFPLENBQUNTLElBQUksQ0FBQ0ksT0FBTztNQUVsRSxNQUFNa0ksR0FBRyxHQUFHLE1BQU0sSUFBSSxDQUFDeEIsNkJBQTZCLENBQ2xEZ0IsSUFBSSxFQUNKYyxTQUFTLEVBQ1Q3QixLQUFLLEVBQ0w5QixJQUFJLEVBQ0owRCxVQUFVLEVBQ1ZFLFdBQVcsQ0FDWjtNQUVELE9BQU9ySixRQUFRLENBQUNnQyxFQUFFLENBQUM7UUFDakJ4QixJQUFJLEVBQUU7VUFBRXVJLFdBQVcsRUFBRSxJQUFJO1VBQUVELEdBQUcsRUFBRUE7UUFBSTtNQUN0QyxDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBTzNHLEtBQUssRUFBRTtNQUNkLElBQUFOLFdBQUcsRUFBQyxnQ0FBZ0MsRUFBRU0sS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssQ0FBQztNQUM3RCxPQUFPLElBQUFFLDRCQUFhLEVBQUNGLEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRW5DLFFBQVEsQ0FBQztJQUNuRTtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNc0osZ0JBQWdCQSxDQUFDeEosT0FBOEIsRUFBRUMsT0FBc0IsRUFBRUMsUUFBK0IsRUFBRTtJQUM5RyxJQUFJO01BQ0Y7TUFDQSxNQUFNK0UsT0FBTyxHQUFHLE1BQU1xQyxPQUFPLENBQUNtQyxHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDQyxxREFBMEMsQ0FBQyxDQUN0RkMsR0FBRyxDQUFFbEssUUFBUSxJQUFLSyxPQUFPLENBQUNJLElBQUksQ0FBQ0MsYUFBYSxDQUFDQyxNQUFNLENBQUM4RCxhQUFhLENBQUMwRixPQUFPLENBQUNDLE1BQU0sQ0FBQztRQUNoRnpGLEtBQUssRUFBRSxJQUFJLENBQUM1RSwwQkFBMEIsQ0FBQ0MsUUFBUTtNQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQ04sT0FBT08sUUFBUSxDQUFDZ0MsRUFBRSxDQUFDO1FBQ2pCeEIsSUFBSSxFQUFFO1VBQUVzSixxQkFBcUIsRUFBRS9FLE9BQU8sQ0FBQ2dGLElBQUksQ0FBQ0MsTUFBTSxJQUFJQSxNQUFNLENBQUN4SixJQUFJO1FBQUU7TUFDckUsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU8yQixLQUFLLEVBQUU7TUFDZCxPQUFPLElBQUFFLDRCQUFhLEVBQUMsa0NBQWtDLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRXJDLFFBQVEsQ0FBQztJQUMvRTtFQUNGO0VBQ0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1pSywwQkFBMEJBLENBQUNuSyxPQUE4QixFQUFFQyxPQUE0QyxFQUFFQyxRQUErQixFQUFFO0lBQzlJLElBQUk7TUFDRixNQUFNa0ssaUJBQWlCLEdBQUcsSUFBSSxDQUFDMUssMEJBQTBCLENBQUNPLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDbEIsUUFBUSxDQUFDO01BQ2xGO01BQ0EsTUFBTTBLLGlCQUFpQixHQUFHLE1BQU1ySyxPQUFPLENBQUNJLElBQUksQ0FBQ0MsYUFBYSxDQUFDQyxNQUFNLENBQUM4RCxhQUFhLENBQUMwRixPQUFPLENBQUNDLE1BQU0sQ0FBQztRQUM3RnpGLEtBQUssRUFBRThGO01BQ1QsQ0FBQyxDQUFDO01BQ0YsT0FBT2xLLFFBQVEsQ0FBQ2dDLEVBQUUsQ0FBQztRQUNqQnhCLElBQUksRUFBRTtVQUFFNEQsS0FBSyxFQUFFOEYsaUJBQWlCO1VBQUVMLE1BQU0sRUFBRU0saUJBQWlCLENBQUMzSjtRQUFLO01BQ25FLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPMkIsS0FBSyxFQUFFO01BQ2QsSUFBQU4sV0FBRyxFQUNELDBDQUEwQyxFQUN6QyxzREFBcURNLEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFNLEVBQUMsQ0FDL0U7TUFFRCxNQUFNLENBQUNGLFVBQVUsRUFBRW1JLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQ0MsZUFBZSxDQUFDbEksS0FBSyxDQUFDO01BQzlELE9BQU8sSUFBQUUsNEJBQWEsRUFBRSxzREFBcUQrSCxZQUFZLElBQUlqSSxLQUFNLEVBQUMsRUFBRSxJQUFJLEVBQUVGLFVBQVUsRUFBRWpDLFFBQVEsQ0FBQztJQUNqSTtFQUNGO0VBQ0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU1zSyxrQkFBa0JBLENBQUN4SyxPQUE4QixFQUFFQyxPQUE0QyxFQUFFQyxRQUErQixFQUFFO0lBQ3RJLE1BQU1rSyxpQkFBaUIsR0FBRyxJQUFJLENBQUMxSywwQkFBMEIsQ0FBQ08sT0FBTyxDQUFDWSxNQUFNLENBQUNsQixRQUFRLENBQUM7SUFFbEYsSUFBSTtNQUNGO01BQ0EsTUFBTThLLEtBQUssR0FBRyxJQUFBQyw0QkFBb0IsRUFBQ3pLLE9BQU8sQ0FBQzBLLE9BQU8sQ0FBQ0MsTUFBTSxFQUFFLFVBQVUsQ0FBQztNQUN0RSxJQUFJLENBQUNILEtBQUssRUFBRTtRQUNWLE9BQU8sSUFBQWxJLDRCQUFhLEVBQUMsbUJBQW1CLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRXJDLFFBQVEsQ0FBQztNQUMvRDtNQUFDO01BQ0QsTUFBTTJLLFlBQVksR0FBRyxJQUFBQyxrQkFBUyxFQUFDTCxLQUFLLENBQUM7TUFDckMsSUFBSSxDQUFDSSxZQUFZLEVBQUU7UUFDakIsT0FBTyxJQUFBdEksNEJBQWEsRUFBQyx5QkFBeUIsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFckMsUUFBUSxDQUFDO01BQ3JFO01BQUM7TUFDRCxJQUFJLENBQUMySyxZQUFZLENBQUNFLFVBQVUsSUFBSSxDQUFDRixZQUFZLENBQUNFLFVBQVUsQ0FBQzNKLFFBQVEsQ0FBQzRKLHNDQUEyQixDQUFDLEVBQUU7UUFDOUYsT0FBTyxJQUFBekksNEJBQWEsRUFBQyx1QkFBdUIsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFckMsUUFBUSxDQUFDO01BQ25FO01BQUM7TUFDRDtNQUNBLE1BQU0rSyxTQUFTLEdBQUcsSUFBQVAsNEJBQW9CLEVBQUN6SyxPQUFPLENBQUMwSyxPQUFPLENBQUNDLE1BQU0sRUFBRSxRQUFRLENBQUM7TUFDeEUsSUFBSSxDQUFDSyxTQUFTLEVBQUU7UUFDZCxPQUFPLElBQUExSSw0QkFBYSxFQUFDLG9CQUFvQixFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUVyQyxRQUFRLENBQUM7TUFDaEU7TUFBQztNQUNELE1BQU1nTCxzQkFBc0IsR0FBRyxNQUFNbEwsT0FBTyxDQUFDK0YsS0FBSyxDQUFDb0YsR0FBRyxDQUFDN0ssTUFBTSxDQUFDOEQsYUFBYSxDQUFDbkUsT0FBTyxDQUFDLEtBQUssRUFBRyxJQUFHLEVBQUUsQ0FBQyxDQUFDLEVBQUU7UUFBRWdMO01BQVUsQ0FBQyxDQUFDO01BQ25ILElBQUlDLHNCQUFzQixDQUFDOUksTUFBTSxLQUFLLEdBQUcsRUFBRTtRQUN6QyxPQUFPLElBQUFHLDRCQUFhLEVBQUMsb0JBQW9CLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRXJDLFFBQVEsQ0FBQztNQUNoRTtNQUFDO01BRUQsTUFBTWtMLFVBQVUsR0FBRzVGLElBQUksQ0FBQ2lCLFNBQVMsQ0FBQztRQUNoQ25DLEtBQUssRUFBRTtVQUNMK0csTUFBTSxFQUFFakI7UUFDVjtNQUNGLENBQUMsQ0FBQztNQUNGLE1BQU1rQixtQkFBbUIsR0FBR3JMLE9BQU8sQ0FBQ1MsSUFBSSxJQUFJVCxPQUFPLENBQUNTLElBQUksQ0FBQ0csTUFBTSxJQUFJLENBQUMsQ0FBQztNQUVyRSxNQUFNMEssWUFBWSxHQUFHM0IscURBQTBDLENBQUMzSixPQUFPLENBQUNZLE1BQU0sQ0FBQ2xCLFFBQVEsQ0FBQyxDQUFDa0ssR0FBRyxDQUFFMkIsU0FBUyxJQUFLLElBQUFDLG9DQUFjLEVBQUM7UUFBRSxHQUFHRCxTQUFTO1FBQUUsR0FBR0Y7TUFBb0IsQ0FBQyxFQUFFckwsT0FBTyxDQUFDUyxJQUFJLENBQUNnTCxNQUFNLElBQUlGLFNBQVMsQ0FBQ0UsTUFBTSxJQUFJQyxvREFBeUMsQ0FBQyxDQUFDLENBQUNDLElBQUksRUFBRTtNQUNsUSxNQUFNQyxJQUFJLEdBQUdOLFlBQVksQ0FBQzFCLEdBQUcsQ0FBQ2lDLFdBQVcsSUFBSyxHQUFFVixVQUFXLEtBQUk1RixJQUFJLENBQUNpQixTQUFTLENBQUNxRixXQUFXLENBQUUsSUFBRyxDQUFDLENBQUNDLElBQUksQ0FBQyxFQUFFLENBQUM7O01BRXhHOztNQUVBO01BQ0EsTUFBTTFCLGlCQUFpQixHQUFHLE1BQU1ySyxPQUFPLENBQUNJLElBQUksQ0FBQ0MsYUFBYSxDQUFDQyxNQUFNLENBQUM4RCxhQUFhLENBQUMwRixPQUFPLENBQUNDLE1BQU0sQ0FBQztRQUM3RnpGLEtBQUssRUFBRThGO01BQ1QsQ0FBQyxDQUFDO01BQ0YsSUFBSSxDQUFDQyxpQkFBaUIsQ0FBQzNKLElBQUksRUFBRTtRQUMzQjs7UUFFQSxNQUFNc0wsYUFBYSxHQUFHO1VBQ3BCQyxRQUFRLEVBQUU7WUFDUjNILEtBQUssRUFBRTtjQUNMNEgsZ0JBQWdCLEVBQUVDLDJDQUFnQztjQUNsREMsa0JBQWtCLEVBQUVDO1lBQ3RCO1VBQ0Y7UUFDRixDQUFDO1FBRUQsTUFBTXJNLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDQyxhQUFhLENBQUNDLE1BQU0sQ0FBQzhELGFBQWEsQ0FBQzBGLE9BQU8sQ0FBQ3dDLE1BQU0sQ0FBQztVQUNuRWhJLEtBQUssRUFBRThGLGlCQUFpQjtVQUN4QjFKLElBQUksRUFBRXNMO1FBQ1IsQ0FBQyxDQUFDO1FBQ0YsSUFBQWpLLFdBQUcsRUFDRCxrQ0FBa0MsRUFDakMsV0FBVXFJLGlCQUFrQixRQUFPLEVBQ3BDLE9BQU8sQ0FDUjtNQUNIO01BRUEsTUFBTXBLLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDQyxhQUFhLENBQUNDLE1BQU0sQ0FBQzhELGFBQWEsQ0FBQ3lILElBQUksQ0FBQztRQUN6RHZILEtBQUssRUFBRThGLGlCQUFpQjtRQUN4QjFKLElBQUksRUFBRW1MO01BQ1IsQ0FBQyxDQUFDO01BQ0YsSUFBQTlKLFdBQUcsRUFDRCxrQ0FBa0MsRUFDakMsMEJBQXlCcUksaUJBQWtCLFFBQU8sRUFDbkQsT0FBTyxDQUNSO01BQ0QsT0FBT2xLLFFBQVEsQ0FBQ2dDLEVBQUUsQ0FBQztRQUNqQnhCLElBQUksRUFBRTtVQUFFNEQsS0FBSyxFQUFFOEYsaUJBQWlCO1VBQUVtQyxVQUFVLEVBQUVoQixZQUFZLENBQUN4SztRQUFPO01BQ3BFLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPc0IsS0FBSyxFQUFFO01BQ2QsSUFBQU4sV0FBRyxFQUNELGtDQUFrQyxFQUNqQyxpQ0FBZ0NxSSxpQkFBa0IsV0FBVS9ILEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFNLEVBQUMsQ0FDdEY7TUFFRCxNQUFNLENBQUNGLFVBQVUsRUFBRW1JLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQ0MsZUFBZSxDQUFDbEksS0FBSyxDQUFDO01BRTlELE9BQU8sSUFBQUUsNEJBQWEsRUFBQytILFlBQVksSUFBSWpJLEtBQUssRUFBRSxJQUFJLEVBQUVGLFVBQVUsRUFBRWpDLFFBQVEsQ0FBQztJQUN6RTtFQUNGO0VBQ0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNc00sa0JBQWtCQSxDQUFDeE0sT0FBOEIsRUFBRUMsT0FBNEMsRUFBRUMsUUFBK0IsRUFBRTtJQUN0STs7SUFFQSxNQUFNa0ssaUJBQWlCLEdBQUcsSUFBSSxDQUFDMUssMEJBQTBCLENBQUNPLE9BQU8sQ0FBQ1ksTUFBTSxDQUFDbEIsUUFBUSxDQUFDO0lBRWxGLElBQUk7TUFDRjtNQUNBLE1BQU04SyxLQUFLLEdBQUcsSUFBQUMsNEJBQW9CLEVBQUN6SyxPQUFPLENBQUMwSyxPQUFPLENBQUNDLE1BQU0sRUFBRSxVQUFVLENBQUM7TUFDdEUsSUFBSSxDQUFDSCxLQUFLLEVBQUU7UUFDVixPQUFPLElBQUFsSSw0QkFBYSxFQUFDLG1CQUFtQixFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUVyQyxRQUFRLENBQUM7TUFDL0Q7TUFBQztNQUNELE1BQU0ySyxZQUFZLEdBQUcsSUFBQUMsa0JBQVMsRUFBQ0wsS0FBSyxDQUFDO01BQ3JDLElBQUksQ0FBQ0ksWUFBWSxFQUFFO1FBQ2pCLE9BQU8sSUFBQXRJLDRCQUFhLEVBQUMseUJBQXlCLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRXJDLFFBQVEsQ0FBQztNQUNyRTtNQUFDO01BQ0QsSUFBSSxDQUFDMkssWUFBWSxDQUFDRSxVQUFVLElBQUksQ0FBQ0YsWUFBWSxDQUFDRSxVQUFVLENBQUMzSixRQUFRLENBQUM0SixzQ0FBMkIsQ0FBQyxFQUFFO1FBQzlGLE9BQU8sSUFBQXpJLDRCQUFhLEVBQUMsdUJBQXVCLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRXJDLFFBQVEsQ0FBQztNQUNuRTtNQUFDO01BQ0Q7TUFDQSxNQUFNK0ssU0FBUyxHQUFHLElBQUFQLDRCQUFvQixFQUFDekssT0FBTyxDQUFDMEssT0FBTyxDQUFDQyxNQUFNLEVBQUUsUUFBUSxDQUFDO01BQ3hFLElBQUksQ0FBQ0ssU0FBUyxFQUFFO1FBQ2QsT0FBTyxJQUFBMUksNEJBQWEsRUFBQyxvQkFBb0IsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFckMsUUFBUSxDQUFDO01BQ2hFO01BQUM7TUFDRCxNQUFNZ0wsc0JBQXNCLEdBQUcsTUFBTWxMLE9BQU8sQ0FBQytGLEtBQUssQ0FBQ29GLEdBQUcsQ0FBQzdLLE1BQU0sQ0FBQzhELGFBQWEsQ0FBQ25FLE9BQU8sQ0FBQyxLQUFLLEVBQUcsSUFBRyxFQUFFLENBQUMsQ0FBQyxFQUFFO1FBQUVnTDtNQUFVLENBQUMsQ0FBQztNQUNuSCxJQUFJQyxzQkFBc0IsQ0FBQzlJLE1BQU0sS0FBSyxHQUFHLEVBQUU7UUFDekMsT0FBTyxJQUFBRyw0QkFBYSxFQUFDLG9CQUFvQixFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUVyQyxRQUFRLENBQUM7TUFDaEU7TUFBQzs7TUFFRDtNQUNBLE1BQU1tSyxpQkFBaUIsR0FBRyxNQUFNckssT0FBTyxDQUFDSSxJQUFJLENBQUNDLGFBQWEsQ0FBQ0MsTUFBTSxDQUFDOEQsYUFBYSxDQUFDMEYsT0FBTyxDQUFDQyxNQUFNLENBQUM7UUFDN0Z6RixLQUFLLEVBQUU4RjtNQUNULENBQUMsQ0FBQztNQUNGLElBQUlDLGlCQUFpQixDQUFDM0osSUFBSSxFQUFFO1FBQzFCO1FBQ0EsTUFBTVYsT0FBTyxDQUFDSSxJQUFJLENBQUNDLGFBQWEsQ0FBQ0MsTUFBTSxDQUFDOEQsYUFBYSxDQUFDMEYsT0FBTyxDQUFDMkMsTUFBTSxDQUFDO1VBQUVuSSxLQUFLLEVBQUU4RjtRQUFrQixDQUFDLENBQUM7UUFDbEcsSUFBQXJJLFdBQUcsRUFDRCxrQ0FBa0MsRUFDakMsV0FBVXFJLGlCQUFrQixRQUFPLEVBQ3BDLE9BQU8sQ0FDUjtRQUNELE9BQU9sSyxRQUFRLENBQUNnQyxFQUFFLENBQUM7VUFDakJ4QixJQUFJLEVBQUU7WUFBRXdKLE1BQU0sRUFBRSxTQUFTO1lBQUU1RixLQUFLLEVBQUU4RjtVQUFrQjtRQUN0RCxDQUFDLENBQUM7TUFDSixDQUFDLE1BQU07UUFDTCxPQUFPLElBQUE3SCw0QkFBYSxFQUFFLEdBQUU2SCxpQkFBa0Isc0JBQXFCLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRWxLLFFBQVEsQ0FBQztNQUN2RjtJQUNGLENBQUMsQ0FBQyxPQUFPbUMsS0FBSyxFQUFFO01BQ2QsSUFBQU4sV0FBRyxFQUNELGtDQUFrQyxFQUNqQyxtQ0FBa0NxSSxpQkFBa0IsV0FBVS9ILEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFNLEVBQUMsQ0FDeEY7TUFDRCxNQUFNLENBQUNGLFVBQVUsRUFBRW1JLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQ0MsZUFBZSxDQUFDbEksS0FBSyxDQUFDO01BRTlELE9BQU8sSUFBQUUsNEJBQWEsRUFBQytILFlBQVksSUFBSWpJLEtBQUssRUFBRSxJQUFJLEVBQUVGLFVBQVUsRUFBRWpDLFFBQVEsQ0FBQztJQUN6RTtFQUNGO0VBRUEsTUFBTXdMLE1BQU1BLENBQUMxTCxPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBQ3BHLElBQUk7TUFDRixNQUFNQyxJQUFJLEdBQUcsTUFBTUgsT0FBTyxDQUFDSSxJQUFJLENBQUNDLGFBQWEsQ0FBQ0MsTUFBTSxDQUFDOEQsYUFBYSxDQUFDQyxNQUFNLENBQUNwRSxPQUFPLENBQUNTLElBQUksQ0FBQztNQUN2RixPQUFPUixRQUFRLENBQUNnQyxFQUFFLENBQUM7UUFDakJ4QixJQUFJLEVBQUVQLElBQUksQ0FBQ087TUFDYixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBTzJCLEtBQUssRUFBRTtNQUNkLElBQUFOLFdBQUcsRUFBQyxzQkFBc0IsRUFBRU0sS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssQ0FBQztNQUNuRCxPQUFPLElBQUFFLDRCQUFhLEVBQUNGLEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRW5DLFFBQVEsQ0FBQztJQUNuRTtFQUNGOztFQUVBO0VBQ0EsTUFBTXdNLHNCQUFzQkEsQ0FBQzFNLE9BQThCLEVBQUVDLE9BQXNCLEVBQUVDLFFBQStCLEVBQUU7SUFDcEgsSUFBSTtNQUNGLE1BQU1OLE1BQU0sR0FBRyxJQUFBQyxrQ0FBZ0IsR0FBRTtNQUNqQyxNQUFNOE0saUJBQWlCLEdBQUksR0FBRS9NLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxPQUFRLElBQUdBLE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLFlBQWEsR0FBRSxDQUFDLENBQUM7TUFDMUgsTUFBTWdOLFVBQVUsR0FBRyxNQUFNNU0sT0FBTyxDQUFDSSxJQUFJLENBQUNDLGFBQWEsQ0FBQ0MsTUFBTSxDQUFDOEQsYUFBYSxDQUFDMEYsT0FBTyxDQUFDQyxNQUFNLENBQUM7UUFDdEZ6RixLQUFLLEVBQUVxSSxpQkFBaUI7UUFDeEJFLGdCQUFnQixFQUFFO01BQ3BCLENBQUMsQ0FBQztNQUNGLE9BQU8zTSxRQUFRLENBQUNnQyxFQUFFLENBQUM7UUFDakJ4QixJQUFJLEVBQUVrTSxVQUFVLENBQUNsTTtNQUNuQixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBTzJCLEtBQUssRUFBRTtNQUNkLElBQUFOLFdBQUcsRUFBQyx1Q0FBdUMsRUFBRU0sS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssQ0FBQztNQUNwRSxPQUFPLElBQUFFLDRCQUFhLEVBQUNGLEtBQUssQ0FBQ0MsT0FBTyxJQUFJRCxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRW5DLFFBQVEsQ0FBQztJQUNuRTtFQUNGOztFQUVBO0VBQ0EsTUFBTTRNLHNCQUFzQkEsQ0FBQzlNLE9BQThCLEVBQUVDLE9BQXNCLEVBQUVDLFFBQStCLEVBQUU7SUFDcEgsSUFBSTtNQUNGLE1BQU1OLE1BQU0sR0FBRyxJQUFBQyxrQ0FBZ0IsR0FBRTtNQUNqQyxNQUFNa04sc0JBQXNCLEdBQUduTixNQUFNLENBQUMsMEJBQTBCLENBQUMsSUFBSSxJQUFBRSxnQ0FBc0IsRUFBQywwQkFBMEIsQ0FBQztNQUN2SCxNQUFNOE0sVUFBVSxHQUFHLE1BQU01TSxPQUFPLENBQUNJLElBQUksQ0FBQ0MsYUFBYSxDQUFDQyxNQUFNLENBQUM4RCxhQUFhLENBQUMwRixPQUFPLENBQUNDLE1BQU0sQ0FBQztRQUN0RnpGLEtBQUssRUFBRXlJLHNCQUFzQjtRQUM3QkYsZ0JBQWdCLEVBQUU7TUFDcEIsQ0FBQyxDQUFDO01BQ0YsT0FBTzNNLFFBQVEsQ0FBQ2dDLEVBQUUsQ0FBQztRQUNqQnhCLElBQUksRUFBRWtNLFVBQVUsQ0FBQ2xNO01BQ25CLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPMkIsS0FBSyxFQUFFO01BQ2QsSUFBQU4sV0FBRyxFQUFDLHVDQUF1QyxFQUFFTSxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSyxDQUFDO01BQ3BFLE9BQU8sSUFBQUUsNEJBQWEsRUFBQ0YsS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFbkMsUUFBUSxDQUFDO0lBQ25FO0VBQ0Y7RUFFQSxNQUFNOE0sZ0JBQWdCQSxDQUFDaE4sT0FBTyxFQUFFO0lBQzlCLElBQUk7TUFDRixNQUFNRyxJQUFJLEdBQUcsTUFBTUgsT0FBTyxDQUFDSSxJQUFJLENBQUNDLGFBQWEsQ0FBQ0MsTUFBTSxDQUFDQyxjQUFjLENBQUMyRCxPQUFPLENBQUMrSSxXQUFXLENBQ3JGO1FBQUVDLGdCQUFnQixFQUFFO01BQUssQ0FBQyxDQUMzQjtNQUNELE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDL00sSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFTyxJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUV5TSxRQUFRLElBQUksQ0FBQyxDQUFDLEVBQUVDLEtBQUssSUFBSSxDQUFDLENBQUMsRUFBRXBILFFBQVEsSUFBSSxDQUFDLENBQUMsRUFBRXFILElBQUksS0FBSyxJQUFJO0lBQ2hHLENBQUMsQ0FBQyxPQUFPaEwsS0FBSyxFQUFFO01BQ2QsT0FBT2lGLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDbEYsS0FBSyxDQUFDO0lBQzlCO0VBQ0Y7RUFFQWtJLGVBQWVBLENBQUNsSSxLQUFLLEVBQUM7SUFBQSxJQUFBaUwsV0FBQTtJQUNwQixNQUFNbkwsVUFBVSxHQUFHLENBQUFFLEtBQUssYUFBTEEsS0FBSyx3QkFBQWlMLFdBQUEsR0FBTGpMLEtBQUssQ0FBRWtMLElBQUksY0FBQUQsV0FBQSx1QkFBWEEsV0FBQSxDQUFhbkwsVUFBVSxLQUFJLEdBQUc7SUFDakQsSUFBSW1JLFlBQVksR0FBR2pJLEtBQUssQ0FBQ0MsT0FBTztJQUVoQyxJQUFHSCxVQUFVLEtBQUssR0FBRyxFQUFDO01BQUEsSUFBQXFMLFlBQUEsRUFBQUMsaUJBQUEsRUFBQUMscUJBQUE7TUFDcEJwRCxZQUFZLEdBQUcsQ0FBQWpJLEtBQUssYUFBTEEsS0FBSyx3QkFBQW1MLFlBQUEsR0FBTG5MLEtBQUssQ0FBRWtMLElBQUksY0FBQUMsWUFBQSx3QkFBQUMsaUJBQUEsR0FBWEQsWUFBQSxDQUFhOU0sSUFBSSxjQUFBK00saUJBQUEsd0JBQUFDLHFCQUFBLEdBQWpCRCxpQkFBQSxDQUFtQnBMLEtBQUssY0FBQXFMLHFCQUFBLHVCQUF4QkEscUJBQUEsQ0FBMEJDLE1BQU0sS0FBSSxtQkFBbUI7SUFDeEU7SUFFQSxPQUFPLENBQUN4TCxVQUFVLEVBQUVtSSxZQUFZLENBQUM7RUFDbkM7QUFDRjtBQUFDc0QsT0FBQSxDQUFBMU8sZ0JBQUEsR0FBQUEsZ0JBQUEifQ==