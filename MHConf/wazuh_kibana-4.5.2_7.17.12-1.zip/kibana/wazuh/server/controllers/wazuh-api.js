"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhApiCtrl = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _errorResponse = require("../lib/error-response");
var _json2csv = require("json2csv");
var _logger = require("../lib/logger");
var _csvKeyEquivalence = require("../../common/csv-key-equivalence");
var _apiErrorsEquivalence = require("../lib/api-errors-equivalence");
var _endpoints = _interopRequireDefault(require("../../common/api-info/endpoints"));
var _constants = require("../../common/constants");
var _settings = require("../../common/services/settings");
var _queue = require("../start/queue");
var _fs = _interopRequireDefault(require("fs"));
var _manageHosts = require("../lib/manage-hosts");
var _updateRegistry = require("../lib/update-registry");
var _jwtDecode = _interopRequireDefault(require("jwt-decode"));
var _cacheApiUserHasRunAs = require("../lib/cache-api-user-has-run-as");
var _cookie = require("../lib/cookie");
var _getConfiguration = require("../lib/get-configuration");
/*
 * Wazuh app - Class for Wazuh-API functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */

// Require some libraries

class WazuhApiCtrl {
  constructor() {
    (0, _defineProperty2.default)(this, "manageHosts", void 0);
    (0, _defineProperty2.default)(this, "updateRegistry", void 0);
    this.manageHosts = new _manageHosts.ManageHosts();
    this.updateRegistry = new _updateRegistry.UpdateRegistry();
  }
  async getToken(context, request, response) {
    try {
      const {
        force,
        idHost
      } = request.body;
      const {
        username
      } = await context.wazuh.security.getCurrentUser(request, context);
      if (!force && request.headers.cookie && username === (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-user') && idHost === (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api')) {
        const wzToken = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-token');
        if (wzToken) {
          try {
            // if the current token is not a valid jwt token we ask for a new one
            const decodedToken = (0, _jwtDecode.default)(wzToken);
            const expirationTime = decodedToken.exp - Date.now() / 1000;
            if (wzToken && expirationTime > 0) {
              return response.ok({
                body: {
                  token: wzToken
                }
              });
            }
          } catch (error) {
            (0, _logger.log)('wazuh-api:getToken', error.message || error);
          }
        }
      }
      let token;
      if ((await _cacheApiUserHasRunAs.APIUserAllowRunAs.canUse(idHost)) == _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.ENABLED) {
        token = await context.wazuh.api.client.asCurrentUser.authenticate(idHost);
      } else {
        token = await context.wazuh.api.client.asInternalUser.authenticate(idHost);
      }
      ;
      let textSecure = '';
      if (context.wazuh.server.info.protocol === 'https') {
        textSecure = ';Secure';
      }
      return response.ok({
        headers: {
          'set-cookie': [`wz-token=${token};Path=/;HttpOnly${textSecure}`, `wz-user=${username};Path=/;HttpOnly${textSecure}`, `wz-api=${idHost};Path=/;HttpOnly`]
        },
        body: {
          token
        }
      });
    } catch (error) {
      var _error$response;
      const errorMessage = ((error.response || {}).data || {}).detail || error.message || error;
      (0, _logger.log)('wazuh-api:getToken', errorMessage);
      return (0, _errorResponse.ErrorResponse)(`Error getting the authorization token: ${errorMessage}`, 3000, (error === null || error === void 0 ? void 0 : (_error$response = error.response) === null || _error$response === void 0 ? void 0 : _error$response.status) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  /**
   * Returns if the wazuh-api configuration is working
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */
  async checkStoredAPI(context, request, response) {
    try {
      // Get config from wazuh.yml
      const id = request.body.id;
      const api = await this.manageHosts.getHostById(id);
      // Check Manage Hosts
      if (!Object.keys(api).length) {
        throw new Error('Could not find Wazuh API entry on wazuh.yml');
      }
      (0, _logger.log)('wazuh-api:checkStoredAPI', `${id} exists`, 'debug');

      // Fetch needed information about the cluster and the manager itself
      const responseManagerInfo = await context.wazuh.api.client.asInternalUser.request('get', `/manager/info`, {}, {
        apiHostID: id,
        forceRefresh: true
      });

      // Look for socket-related errors
      if (this.checkResponseIsDown(responseManagerInfo)) {
        return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${responseManagerInfo.data.detail || 'Wazuh not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
      }

      // If we have a valid response from the Wazuh API
      if (responseManagerInfo.status === _constants.HTTP_STATUS_CODES.OK && responseManagerInfo.data) {
        // Clear and update cluster information before being sent back to frontend
        delete api.cluster_info;
        const responseAgents = await context.wazuh.api.client.asInternalUser.request('GET', `/agents`, {
          params: {
            agents_list: '000'
          }
        }, {
          apiHostID: id
        });
        if (responseAgents.status === _constants.HTTP_STATUS_CODES.OK) {
          const managerName = responseAgents.data.data.affected_items[0].manager;
          const responseClusterStatus = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/status`, {}, {
            apiHostID: id
          });
          if (responseClusterStatus.status === _constants.HTTP_STATUS_CODES.OK) {
            if (responseClusterStatus.data.data.enabled === 'yes') {
              const responseClusterLocalInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/local/info`, {}, {
                apiHostID: id
              });
              if (responseClusterLocalInfo.status === _constants.HTTP_STATUS_CODES.OK) {
                const clusterEnabled = responseClusterStatus.data.data.enabled === 'yes';
                api.cluster_info = {
                  status: clusterEnabled ? 'enabled' : 'disabled',
                  manager: managerName,
                  node: responseClusterLocalInfo.data.data.affected_items[0].node,
                  cluster: clusterEnabled ? responseClusterLocalInfo.data.data.affected_items[0].cluster : 'Disabled'
                };
              }
            } else {
              // Cluster mode is not active
              api.cluster_info = {
                status: 'disabled',
                manager: managerName,
                cluster: 'Disabled'
              };
            }
          } else {
            // Cluster mode is not active
            api.cluster_info = {
              status: 'disabled',
              manager: managerName,
              cluster: 'Disabled'
            };
          }
          if (api.cluster_info) {
            // Update cluster information in the wazuh-registry.json
            await this.updateRegistry.updateClusterInfo(id, api.cluster_info);

            // Hide Wazuh API secret, username, password
            const copied = {
              ...api
            };
            copied.secret = '****';
            copied.password = '****';
            return response.ok({
              body: {
                statusCode: _constants.HTTP_STATUS_CODES.OK,
                data: copied,
                idChanged: request.body.idChanged || null
              }
            });
          }
        }
      }

      // If we have an invalid response from the Wazuh API
      throw new Error(responseManagerInfo.data.detail || `${api.url}:${api.port} is unreachable`);
    } catch (error) {
      if (error.code === 'EPROTO') {
        return response.ok({
          body: {
            statusCode: _constants.HTTP_STATUS_CODES.OK,
            data: {
              apiIsDown: true
            }
          }
        });
      } else if (error.code === 'ECONNREFUSED') {
        return response.ok({
          body: {
            statusCode: _constants.HTTP_STATUS_CODES.OK,
            data: {
              apiIsDown: true
            }
          }
        });
      } else {
        var _error$response3;
        try {
          const apis = await this.manageHosts.getHosts();
          for (const api of apis) {
            try {
              const id = Object.keys(api)[0];
              const responseManagerInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/manager/info`, {}, {
                apiHostID: id
              });
              if (this.checkResponseIsDown(responseManagerInfo)) {
                return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${response.data.detail || 'Wazuh not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
              }
              if (responseManagerInfo.status === _constants.HTTP_STATUS_CODES.OK) {
                request.body.id = id;
                request.body.idChanged = id;
                return await this.checkStoredAPI(context, request, response);
              }
            } catch (error) {} // eslint-disable-line
          }
        } catch (error) {
          var _error$response2;
          (0, _logger.log)('wazuh-api:checkStoredAPI', error.message || error);
          return (0, _errorResponse.ErrorResponse)(error.message || error, 3020, (error === null || error === void 0 ? void 0 : (_error$response2 = error.response) === null || _error$response2 === void 0 ? void 0 : _error$response2.status) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
        }
        (0, _logger.log)('wazuh-api:checkStoredAPI', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 3002, (error === null || error === void 0 ? void 0 : (_error$response3 = error.response) === null || _error$response3 === void 0 ? void 0 : _error$response3.status) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }
    }
  }

  /**
   * This perfoms a validation of API params
   * @param {Object} body API params
   */
  validateCheckApiParams(body) {
    if (!('username' in body)) {
      return 'Missing param: API USERNAME';
    }
    if (!('password' in body) && !('id' in body)) {
      return 'Missing param: API PASSWORD';
    }
    if (!('url' in body)) {
      return 'Missing param: API URL';
    }
    if (!('port' in body)) {
      return 'Missing param: API PORT';
    }
    if (!body.url.includes('https://') && !body.url.includes('http://')) {
      return 'protocol_error';
    }
    return false;
  }

  /**
   * This check the wazuh-api configuration received in the POST body will work
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} status obj or ErrorResponse
   */
  async checkAPI(context, request, response) {
    try {
      let apiAvailable = null;
      // const notValid = this.validateCheckApiParams(request.body);
      // if (notValid) return ErrorResponse(notValid, 3003, HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      (0, _logger.log)('wazuh-api:checkAPI', `${request.body.id} is valid`, 'debug');
      // Check if a Wazuh API id is given (already stored API)
      const data = await this.manageHosts.getHostById(request.body.id);
      if (data) {
        apiAvailable = data;
      } else {
        (0, _logger.log)('wazuh-api:checkAPI', `API ${request.body.id} not found`);
        return (0, _errorResponse.ErrorResponse)(`The API ${request.body.id} was not found`, 3029, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }
      const options = {
        apiHostID: request.body.id
      };
      if (request.body.forceRefresh) {
        options["forceRefresh"] = request.body.forceRefresh;
      }
      let responseManagerInfo;
      try {
        responseManagerInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/manager/info`, {}, options);
      } catch (error) {
        var _error$response4, _error$response4$data, _error$response5;
        return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${((_error$response4 = error.response) === null || _error$response4 === void 0 ? void 0 : (_error$response4$data = _error$response4.data) === null || _error$response4$data === void 0 ? void 0 : _error$response4$data.detail) || 'Wazuh not ready yet'}`, 3099, (error === null || error === void 0 ? void 0 : (_error$response5 = error.response) === null || _error$response5 === void 0 ? void 0 : _error$response5.status) || _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
      }
      (0, _logger.log)('wazuh-api:checkAPI', `${request.body.id} credentials are valid`, 'debug');
      if (responseManagerInfo.status === _constants.HTTP_STATUS_CODES.OK && responseManagerInfo.data) {
        let responseAgents = await context.wazuh.api.client.asInternalUser.request('GET', `/agents`, {
          params: {
            agents_list: '000'
          }
        }, {
          apiHostID: request.body.id
        });
        if (responseAgents.status === _constants.HTTP_STATUS_CODES.OK) {
          const managerName = responseAgents.data.data.affected_items[0].manager;
          let responseCluster = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/status`, {}, {
            apiHostID: request.body.id
          });

          // Check the run_as for the API user and update it
          let apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.ALL_DISABLED;
          const responseApiUserAllowRunAs = await context.wazuh.api.client.asInternalUser.request('GET', `/security/users/me`, {}, {
            apiHostID: request.body.id
          });
          if (responseApiUserAllowRunAs.status === _constants.HTTP_STATUS_CODES.OK) {
            const allow_run_as = responseApiUserAllowRunAs.data.data.affected_items[0].allow_run_as;
            if (allow_run_as && apiAvailable && apiAvailable.run_as)
              // HOST AND USER ENABLED
              apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.ENABLED;else if (!allow_run_as && apiAvailable && apiAvailable.run_as)
              // HOST ENABLED AND USER DISABLED
              apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.USER_NOT_ALLOWED;else if (allow_run_as && (!apiAvailable || !apiAvailable.run_as))
              // USER ENABLED AND HOST DISABLED
              apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.HOST_DISABLED;else if (!allow_run_as && (!apiAvailable || !apiAvailable.run_as))
              // HOST AND USER DISABLED
              apiUserAllowRunAs = _cacheApiUserHasRunAs.API_USER_STATUS_RUN_AS.ALL_DISABLED;
          }
          _cacheApiUserHasRunAs.CacheInMemoryAPIUserAllowRunAs.set(request.body.id, apiAvailable.username, apiUserAllowRunAs);
          if (responseCluster.status === _constants.HTTP_STATUS_CODES.OK) {
            (0, _logger.log)('wazuh-api:checkStoredAPI', `Wazuh API response is valid`, 'debug');
            if (responseCluster.data.data.enabled === 'yes') {
              // If cluster mode is active
              let responseClusterLocal = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/local/info`, {}, {
                apiHostID: request.body.id
              });
              if (responseClusterLocal.status === _constants.HTTP_STATUS_CODES.OK) {
                return response.ok({
                  body: {
                    manager: managerName,
                    node: responseClusterLocal.data.data.affected_items[0].node,
                    cluster: responseClusterLocal.data.data.affected_items[0].cluster,
                    status: 'enabled',
                    allow_run_as: apiUserAllowRunAs
                  }
                });
              }
            } else {
              // Cluster mode is not active
              return response.ok({
                body: {
                  manager: managerName,
                  cluster: 'Disabled',
                  status: 'disabled',
                  allow_run_as: apiUserAllowRunAs
                }
              });
            }
          }
        }
      }
    } catch (error) {
      var _error$response6;
      (0, _logger.log)('wazuh-api:checkAPI', error.message || error);
      if (error && error.response && error.response.status === _constants.HTTP_STATUS_CODES.UNAUTHORIZED) {
        return (0, _errorResponse.ErrorResponse)(`Unathorized. Please check API credentials. ${error.response.data.message}`, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, response);
      }
      if (error && error.response && error.response.data && error.response.data.detail) {
        return (0, _errorResponse.ErrorResponse)(error.response.data.detail, error.response.status || _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, error.response.status || _constants.HTTP_STATUS_CODES.SERVICE_UNAVAILABLE, response);
      }
      if (error.code === 'EPROTO') {
        return (0, _errorResponse.ErrorResponse)('Wrong protocol being used to connect to the Wazuh API', 3005, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
      }
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3005, (error === null || error === void 0 ? void 0 : (_error$response6 = error.response) === null || _error$response6 === void 0 ? void 0 : _error$response6.status) || _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
  checkResponseIsDown(response) {
    if (response.status !== _constants.HTTP_STATUS_CODES.OK) {
      // Avoid "Error communicating with socket" like errors
      const socketErrorCodes = [1013, 1014, 1017, 1018, 1019];
      const status = (response.data || {}).status || 1;
      const isDown = socketErrorCodes.includes(status);
      isDown && (0, _logger.log)('wazuh-api:makeRequest', 'Wazuh API is online but Wazuh is not ready yet');
      return isDown;
    }
    return false;
  }

  /**
   * Check main Wazuh daemons status
   * @param {*} context Endpoint context
   * @param {*} api API entry stored in .wazuh
   * @param {*} path Optional. Wazuh API target path.
   */
  async checkDaemons(context, api, path) {
    try {
      const response = await context.wazuh.api.client.asInternalUser.request('GET', '/manager/status', {}, {
        apiHostID: api.id
      });
      const daemons = ((((response || {}).data || {}).data || {}).affected_items || [])[0] || {};
      const isCluster = ((api || {}).cluster_info || {}).status === 'enabled' && typeof daemons['wazuh-clusterd'] !== 'undefined';
      const wazuhdbExists = typeof daemons['wazuh-db'] !== 'undefined';
      const execd = daemons['wazuh-execd'] === 'running';
      const modulesd = daemons['wazuh-modulesd'] === 'running';
      const wazuhdb = wazuhdbExists ? daemons['wazuh-db'] === 'running' : true;
      const clusterd = isCluster ? daemons['wazuh-clusterd'] === 'running' : true;
      const isValid = execd && modulesd && wazuhdb && clusterd;
      isValid && (0, _logger.log)('wazuh-api:checkDaemons', `Wazuh is ready`, 'debug');
      if (path === '/ping') {
        return {
          isValid
        };
      }
      if (!isValid) {
        throw new Error('Wazuh not ready yet');
      }
    } catch (error) {
      (0, _logger.log)('wazuh-api:checkDaemons', error.message || error);
      return Promise.reject(error);
    }
  }
  sleep(timeMs) {
    // eslint-disable-next-line
    return new Promise((resolve, reject) => {
      setTimeout(resolve, timeMs);
    });
  }

  /**
   * Helper method for Dev Tools.
   * https://documentation.wazuh.com/current/user-manual/api/reference.html
   * Depending on the method and the path some parameters should be an array or not.
   * Since we allow the user to write the request using both comma-separated and array as well,
   * we need to check if it should be transformed or not.
   * @param {*} method The request method
   * @param {*} path The Wazuh API path
   */
  shouldKeepArrayAsIt(method, path) {
    // Methods that we must respect a do not transform them
    const isAgentsRestart = method === 'POST' && path === '/agents/restart';
    const isActiveResponse = method === 'PUT' && path.startsWith('/active-response');
    const isAddingAgentsToGroup = method === 'POST' && path.startsWith('/agents/group/');

    // Returns true only if one of the above conditions is true
    return isAgentsRestart || isActiveResponse || isAddingAgentsToGroup;
  }

  /**
   * This performs a request over Wazuh API and returns its response
   * @param {String} method Method: GET, PUT, POST, DELETE
   * @param {String} path API route
   * @param {Object} data data and params to perform the request
   * @param {String} id API id
   * @param {Object} response
   * @returns {Object} API response or ErrorResponse
   */
  async makeRequest(context, method, path, data, id, response) {
    const devTools = !!(data || {}).devTools;
    try {
      const api = await this.manageHosts.getHostById(id);
      if (devTools) {
        delete data.devTools;
      }
      if (!Object.keys(api).length) {
        (0, _logger.log)('wazuh-api:makeRequest', 'Could not get host credentials');
        //Can not get credentials from wazuh-hosts
        return (0, _errorResponse.ErrorResponse)('Could not get host credentials', 3011, _constants.HTTP_STATUS_CODES.NOT_FOUND, response);
      }
      if (!data) {
        data = {};
      }
      ;
      if (!data.headers) {
        data.headers = {};
      }
      ;
      const options = {
        apiHostID: id
      };

      // Set content type application/xml if needed
      if (typeof (data || {}).body === 'string' && (data || {}).origin === 'xmleditor') {
        data.headers['content-type'] = 'application/xml';
        delete data.origin;
      }
      if (typeof (data || {}).body === 'string' && (data || {}).origin === 'json') {
        data.headers['content-type'] = 'application/json';
        delete data.origin;
      }
      if (typeof (data || {}).body === 'string' && (data || {}).origin === 'raw') {
        data.headers['content-type'] = 'application/octet-stream';
        delete data.origin;
      }
      const delay = (data || {}).delay || 0;
      if (delay) {
        (0, _queue.addJobToQueue)({
          startAt: new Date(Date.now() + delay),
          run: async () => {
            try {
              await context.wazuh.api.client.asCurrentUser.request(method, path, data, options);
            } catch (error) {
              (0, _logger.log)('queue:delayApiRequest', `An error ocurred in the delayed request: "${method} ${path}": ${error.message || error}`);
            }
            ;
          }
        });
        return response.ok({
          body: {
            error: 0,
            message: 'Success'
          }
        });
      }
      if (path === '/ping') {
        try {
          const check = await this.checkDaemons(context, api, path);
          return check;
        } catch (error) {
          const isDown = (error || {}).code === 'ECONNREFUSED';
          if (!isDown) {
            (0, _logger.log)('wazuh-api:makeRequest', 'Wazuh API is online but Wazuh is not ready yet');
            return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${error.message || 'Wazuh not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
          }
        }
      }
      (0, _logger.log)('wazuh-api:makeRequest', `${method} ${path}`, 'debug');

      // Extract keys from parameters
      const dataProperties = Object.keys(data);

      // Transform arrays into comma-separated string if applicable.
      // The reason is that we are accepting arrays for comma-separated
      // parameters in the Dev Tools
      if (!this.shouldKeepArrayAsIt(method, path)) {
        for (const key of dataProperties) {
          if (Array.isArray(data[key])) {
            data[key] = data[key].join();
          }
        }
      }
      const responseToken = await context.wazuh.api.client.asCurrentUser.request(method, path, data, options);
      const responseIsDown = this.checkResponseIsDown(responseToken);
      if (responseIsDown) {
        return (0, _errorResponse.ErrorResponse)(`ERROR3099 - ${response.body.message || 'Wazuh not ready yet'}`, 3099, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }
      let responseBody = (responseToken || {}).data || {};
      if (!responseBody) {
        responseBody = typeof responseBody === 'string' && path.includes('/files') && method === 'GET' ? ' ' : false;
        response.data = responseBody;
      }
      const responseError = response.status !== _constants.HTTP_STATUS_CODES.OK ? response.status : false;
      if (!responseError && responseBody) {
        //cleanKeys(response);
        return response.ok({
          body: responseToken.data
        });
      }
      if (responseError && devTools) {
        return response.ok({
          body: response.data
        });
      }
      throw responseError && responseBody.detail ? {
        message: responseBody.detail,
        code: responseError
      } : new Error('Unexpected error fetching data from the Wazuh API');
    } catch (error) {
      if (error && error.response && error.response.status === _constants.HTTP_STATUS_CODES.UNAUTHORIZED) {
        return (0, _errorResponse.ErrorResponse)(error.message || error, error.code ? `Wazuh API error: ${error.code}` : 3013, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, response);
      }
      const errorMsg = (error.response || {}).data || error.message;
      (0, _logger.log)('wazuh-api:makeRequest', errorMsg || error);
      if (devTools) {
        return response.ok({
          body: {
            error: '3013',
            message: errorMsg || error
          }
        });
      } else {
        if ((error || {}).code && _apiErrorsEquivalence.ApiErrorEquivalence[error.code]) {
          error.message = _apiErrorsEquivalence.ApiErrorEquivalence[error.code];
        }
        return (0, _errorResponse.ErrorResponse)(errorMsg.detail || error, error.code ? `Wazuh API error: ${error.code}` : 3013, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
      }
    }
  }

  /**
   * This make a request to API
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} api response or ErrorResponse
   */
  requestApi(context, request, response) {
    const idApi = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');
    if (idApi !== request.body.id) {
      // if the current token belongs to a different API id, we relogin to obtain a new token
      return (0, _errorResponse.ErrorResponse)('status code 401', _constants.HTTP_STATUS_CODES.UNAUTHORIZED, _constants.HTTP_STATUS_CODES.UNAUTHORIZED, response);
    }
    if (!request.body.method) {
      return (0, _errorResponse.ErrorResponse)('Missing param: method', 3015, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else if (!request.body.method.match(/^(?:GET|PUT|POST|DELETE)$/)) {
      (0, _logger.log)('wazuh-api:makeRequest', 'Request method is not valid.');
      //Method is not a valid HTTP request method
      return (0, _errorResponse.ErrorResponse)('Request method is not valid.', 3015, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else if (!request.body.path) {
      return (0, _errorResponse.ErrorResponse)('Missing param: path', 3016, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else if (!request.body.path.startsWith('/')) {
      (0, _logger.log)('wazuh-api:makeRequest', 'Request path is not valid.');
      //Path doesn't start with '/'
      return (0, _errorResponse.ErrorResponse)('Request path is not valid.', 3015, _constants.HTTP_STATUS_CODES.BAD_REQUEST, response);
    } else {
      return this.makeRequest(context, request.body.method, request.body.path, request.body.body, request.body.id, response);
    }
  }

  /**
   * Get full data on CSV format from a list Wazuh API endpoint
   * @param {Object} ctx
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} csv or ErrorResponse
   */
  async csv(context, request, response) {
    try {
      if (!request.body || !request.body.path) throw new Error('Field path is required');
      if (!request.body.id) throw new Error('Field id is required');
      const filters = Array.isArray(((request || {}).body || {}).filters) ? request.body.filters : [];
      let tmpPath = request.body.path;
      if (tmpPath && typeof tmpPath === 'string') {
        tmpPath = tmpPath[0] === '/' ? tmpPath.substr(1) : tmpPath;
      }
      if (!tmpPath) throw new Error('An error occurred parsing path field');
      (0, _logger.log)('wazuh-api:csv', `Report ${tmpPath}`, 'debug');
      // Real limit, regardless the user query
      const params = {
        limit: 500
      };
      if (filters.length) {
        for (const filter of filters) {
          if (!filter.name || !filter.value) continue;
          params[filter.name] = filter.value;
        }
      }
      let itemsArray = [];
      const output = await context.wazuh.api.client.asCurrentUser.request('GET', `/${tmpPath}`, {
        params: params
      }, {
        apiHostID: request.body.id
      });
      const isList = request.body.path.includes('/lists') && request.body.filters && request.body.filters.length && request.body.filters.find(filter => filter._isCDBList);
      const totalItems = (((output || {}).data || {}).data || {}).total_affected_items;
      if (totalItems && !isList) {
        params.offset = 0;
        itemsArray.push(...output.data.data.affected_items);
        while (itemsArray.length < totalItems && params.offset < totalItems) {
          params.offset += params.limit;
          const tmpData = await context.wazuh.api.client.asCurrentUser.request('GET', `/${tmpPath}`, {
            params: params
          }, {
            apiHostID: request.body.id
          });
          itemsArray.push(...tmpData.data.data.affected_items);
        }
      }
      if (totalItems) {
        const {
          path,
          filters
        } = request.body;
        const isArrayOfLists = path.includes('/lists') && !isList;
        const isAgents = path.includes('/agents') && !path.includes('groups');
        const isAgentsOfGroup = path.startsWith('/agents/groups/');
        const isFiles = path.endsWith('/files');
        let fields = Object.keys(output.data.data.affected_items[0]);
        if (isAgents || isAgentsOfGroup) {
          if (isFiles) {
            fields = ['filename', 'hash'];
          } else {
            fields = ['id', 'status', 'name', 'ip', 'group', 'manager', 'node_name', 'dateAdd', 'version', 'lastKeepAlive', 'os.arch', 'os.build', 'os.codename', 'os.major', 'os.minor', 'os.name', 'os.platform', 'os.uname', 'os.version'];
          }
        }
        if (isArrayOfLists) {
          const flatLists = [];
          for (const list of itemsArray) {
            const {
              relative_dirname,
              items
            } = list;
            flatLists.push(...items.map(item => ({
              relative_dirname,
              key: item.key,
              value: item.value
            })));
          }
          fields = ['relative_dirname', 'key', 'value'];
          itemsArray = [...flatLists];
        }
        if (isList) {
          fields = ['key', 'value'];
          itemsArray = output.data.data.affected_items[0].items;
        }
        fields = fields.map(item => ({
          value: item,
          default: '-'
        }));
        const json2csvParser = new _json2csv.Parser({
          fields
        });
        let csv = json2csvParser.parse(itemsArray);
        for (const field of fields) {
          const {
            value
          } = field;
          if (csv.includes(value)) {
            csv = csv.replace(value, _csvKeyEquivalence.KeyEquivalence[value] || value);
          }
        }
        return response.ok({
          headers: {
            'Content-Type': 'text/csv'
          },
          body: csv
        });
      } else if (output && output.data && output.data.data && !output.data.data.total_affected_items) {
        throw new Error('No results');
      } else {
        throw new Error(`An error occurred fetching data from the Wazuh API${output && output.data && output.data.detail ? `: ${output.body.detail}` : ''}`);
      }
    } catch (error) {
      (0, _logger.log)('wazuh-api:csv', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3034, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  // Get de list of available requests in the API
  getRequestList(context, request, response) {
    //Read a static JSON until the api call has implemented
    return response.ok({
      body: _endpoints.default
    });
  }

  /**
   * This get the timestamp field
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} timestamp field or ErrorResponse
   */
  getTimeStamp(context, request, response) {
    try {
      const source = JSON.parse(_fs.default.readFileSync(this.updateRegistry.file, 'utf8'));
      if (source.installationDate && source.lastRestart) {
        (0, _logger.log)('wazuh-api:getTimeStamp', `Installation date: ${source.installationDate}. Last restart: ${source.lastRestart}`, 'debug');
        return response.ok({
          body: {
            installationDate: source.installationDate,
            lastRestart: source.lastRestart
          }
        });
      } else {
        throw new Error('Could not fetch wazuh-version registry');
      }
    } catch (error) {
      (0, _logger.log)('wazuh-api:getTimeStamp', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || 'Could not fetch wazuh-version registry', 4001, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  /**
   * This get the extensions
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} extensions object or ErrorResponse
   */
  async setExtensions(context, request, response) {
    try {
      const {
        id,
        extensions
      } = request.body;
      // Update cluster information in the wazuh-registry.json
      await this.updateRegistry.updateAPIExtensions(id, extensions);
      return response.ok({
        body: {
          statusCode: _constants.HTTP_STATUS_CODES.OK
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:setExtensions', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || 'Could not set extensions', 4001, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  /**
   * This get the extensions
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} extensions object or ErrorResponse
   */
  getExtensions(context, request, response) {
    try {
      const source = JSON.parse(_fs.default.readFileSync(this.updateRegistry.file, 'utf8'));
      return response.ok({
        body: {
          extensions: (source.hosts[request.params.id] || {}).extensions || {}
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:getExtensions', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || 'Could not fetch wazuh-version registry', 4001, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  /**
   * This get the wazuh setup settings
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} setup info or ErrorResponse
   */
  async getSetupInfo(context, request, response) {
    try {
      const source = JSON.parse(_fs.default.readFileSync(this.updateRegistry.file, 'utf8'));
      return response.ok({
        body: {
          statusCode: _constants.HTTP_STATUS_CODES.OK,
          data: !Object.values(source).length ? '' : source
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:getSetupInfo', error.message || error);
      return (0, _errorResponse.ErrorResponse)(`Could not get data from wazuh-version registry due to ${error.message || error}`, 4005, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  /**
   * Get basic syscollector information for given agent.
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Object} Basic syscollector information
   */
  async getSyscollector(context, request, response) {
    try {
      const apiHostID = (0, _cookie.getCookieValueByName)(request.headers.cookie, 'wz-api');
      if (!request.params || !apiHostID || !request.params.agent) {
        throw new Error('Agent ID and API ID are required');
      }
      const {
        agent
      } = request.params;
      const data = await Promise.all([context.wazuh.api.client.asInternalUser.request('GET', `/syscollector/${agent}/hardware`, {}, {
        apiHostID
      }), context.wazuh.api.client.asInternalUser.request('GET', `/syscollector/${agent}/os`, {}, {
        apiHostID
      })]);
      const result = data.map(item => (item.data || {}).data || []);
      const [hardwareResponse, osResponse] = result;

      // Fill syscollector object
      const syscollector = {
        hardware: typeof hardwareResponse === 'object' && Object.keys(hardwareResponse).length ? {
          ...hardwareResponse.affected_items[0]
        } : false,
        os: typeof osResponse === 'object' && Object.keys(osResponse).length ? {
          ...osResponse.affected_items[0]
        } : false
      };
      return response.ok({
        body: syscollector
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:getSyscollector', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3035, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
  /**
   * Check if user assigned roles disable Wazuh Plugin
   * @param context
   * @param request
   * @param response
   * @returns {object} Returns { isWazuhDisabled: boolean parsed integer }
   */
  async isWazuhDisabled(context, request, response) {
    try {
      const disabledRoles = (await (0, _getConfiguration.getConfiguration)())['disabled_roles'] || [];
      const logoSidebar = (await (0, _getConfiguration.getConfiguration)())['customization.logo.sidebar'];
      const data = (await context.wazuh.security.getCurrentUser(request, context)).authContext;
      const isWazuhDisabled = +(data.roles || []).some(role => disabledRoles.includes(role));
      return response.ok({
        body: {
          isWazuhDisabled,
          logoSidebar
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:isWazuhDisabled', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3035, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }

  /**
   * Gets custom logos configuration (path)
   * @param context
   * @param request
   * @param response
   */
  async getAppLogos(context, request, response) {
    try {
      const configuration = (0, _getConfiguration.getConfiguration)();
      const SIDEBAR_LOGO = 'customization.logo.sidebar';
      const APP_LOGO = 'customization.logo.app';
      const HEALTHCHECK_LOGO = 'customization.logo.healthcheck';
      const logos = {
        [SIDEBAR_LOGO]: (0, _settings.getCustomizationSetting)(configuration, SIDEBAR_LOGO),
        [APP_LOGO]: (0, _settings.getCustomizationSetting)(configuration, APP_LOGO),
        [HEALTHCHECK_LOGO]: (0, _settings.getCustomizationSetting)(configuration, HEALTHCHECK_LOGO)
      };
      return response.ok({
        body: {
          logos
        }
      });
    } catch (error) {
      (0, _logger.log)('wazuh-api:getAppLogos', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 3035, _constants.HTTP_STATUS_CODES.INTERNAL_SERVER_ERROR, response);
    }
  }
}
exports.WazuhApiCtrl = WazuhApiCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfZXJyb3JSZXNwb25zZSIsInJlcXVpcmUiLCJfanNvbjJjc3YiLCJfbG9nZ2VyIiwiX2NzdktleUVxdWl2YWxlbmNlIiwiX2FwaUVycm9yc0VxdWl2YWxlbmNlIiwiX2VuZHBvaW50cyIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJfY29uc3RhbnRzIiwiX3NldHRpbmdzIiwiX3F1ZXVlIiwiX2ZzIiwiX21hbmFnZUhvc3RzIiwiX3VwZGF0ZVJlZ2lzdHJ5IiwiX2p3dERlY29kZSIsIl9jYWNoZUFwaVVzZXJIYXNSdW5BcyIsIl9jb29raWUiLCJfZ2V0Q29uZmlndXJhdGlvbiIsIldhenVoQXBpQ3RybCIsImNvbnN0cnVjdG9yIiwiX2RlZmluZVByb3BlcnR5MiIsImRlZmF1bHQiLCJtYW5hZ2VIb3N0cyIsIk1hbmFnZUhvc3RzIiwidXBkYXRlUmVnaXN0cnkiLCJVcGRhdGVSZWdpc3RyeSIsImdldFRva2VuIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImZvcmNlIiwiaWRIb3N0IiwiYm9keSIsInVzZXJuYW1lIiwid2F6dWgiLCJzZWN1cml0eSIsImdldEN1cnJlbnRVc2VyIiwiaGVhZGVycyIsImNvb2tpZSIsImdldENvb2tpZVZhbHVlQnlOYW1lIiwid3pUb2tlbiIsImRlY29kZWRUb2tlbiIsImp3dERlY29kZSIsImV4cGlyYXRpb25UaW1lIiwiZXhwIiwiRGF0ZSIsIm5vdyIsIm9rIiwidG9rZW4iLCJlcnJvciIsImxvZyIsIm1lc3NhZ2UiLCJBUElVc2VyQWxsb3dSdW5BcyIsImNhblVzZSIsIkFQSV9VU0VSX1NUQVRVU19SVU5fQVMiLCJFTkFCTEVEIiwiYXBpIiwiY2xpZW50IiwiYXNDdXJyZW50VXNlciIsImF1dGhlbnRpY2F0ZSIsImFzSW50ZXJuYWxVc2VyIiwidGV4dFNlY3VyZSIsInNlcnZlciIsImluZm8iLCJwcm90b2NvbCIsIl9lcnJvciRyZXNwb25zZSIsImVycm9yTWVzc2FnZSIsImRhdGEiLCJkZXRhaWwiLCJFcnJvclJlc3BvbnNlIiwic3RhdHVzIiwiSFRUUF9TVEFUVVNfQ09ERVMiLCJJTlRFUk5BTF9TRVJWRVJfRVJST1IiLCJjaGVja1N0b3JlZEFQSSIsImlkIiwiZ2V0SG9zdEJ5SWQiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiRXJyb3IiLCJyZXNwb25zZU1hbmFnZXJJbmZvIiwiYXBpSG9zdElEIiwiZm9yY2VSZWZyZXNoIiwiY2hlY2tSZXNwb25zZUlzRG93biIsIlNFUlZJQ0VfVU5BVkFJTEFCTEUiLCJPSyIsImNsdXN0ZXJfaW5mbyIsInJlc3BvbnNlQWdlbnRzIiwicGFyYW1zIiwiYWdlbnRzX2xpc3QiLCJtYW5hZ2VyTmFtZSIsImFmZmVjdGVkX2l0ZW1zIiwibWFuYWdlciIsInJlc3BvbnNlQ2x1c3RlclN0YXR1cyIsImVuYWJsZWQiLCJyZXNwb25zZUNsdXN0ZXJMb2NhbEluZm8iLCJjbHVzdGVyRW5hYmxlZCIsIm5vZGUiLCJjbHVzdGVyIiwidXBkYXRlQ2x1c3RlckluZm8iLCJjb3BpZWQiLCJzZWNyZXQiLCJwYXNzd29yZCIsInN0YXR1c0NvZGUiLCJpZENoYW5nZWQiLCJ1cmwiLCJwb3J0IiwiY29kZSIsImFwaUlzRG93biIsIl9lcnJvciRyZXNwb25zZTMiLCJhcGlzIiwiZ2V0SG9zdHMiLCJfZXJyb3IkcmVzcG9uc2UyIiwidmFsaWRhdGVDaGVja0FwaVBhcmFtcyIsImluY2x1ZGVzIiwiY2hlY2tBUEkiLCJhcGlBdmFpbGFibGUiLCJvcHRpb25zIiwiX2Vycm9yJHJlc3BvbnNlNCIsIl9lcnJvciRyZXNwb25zZTQkZGF0YSIsIl9lcnJvciRyZXNwb25zZTUiLCJyZXNwb25zZUNsdXN0ZXIiLCJhcGlVc2VyQWxsb3dSdW5BcyIsIkFMTF9ESVNBQkxFRCIsInJlc3BvbnNlQXBpVXNlckFsbG93UnVuQXMiLCJhbGxvd19ydW5fYXMiLCJydW5fYXMiLCJVU0VSX05PVF9BTExPV0VEIiwiSE9TVF9ESVNBQkxFRCIsIkNhY2hlSW5NZW1vcnlBUElVc2VyQWxsb3dSdW5BcyIsInNldCIsInJlc3BvbnNlQ2x1c3RlckxvY2FsIiwiX2Vycm9yJHJlc3BvbnNlNiIsIlVOQVVUSE9SSVpFRCIsIkJBRF9SRVFVRVNUIiwic29ja2V0RXJyb3JDb2RlcyIsImlzRG93biIsImNoZWNrRGFlbW9ucyIsInBhdGgiLCJkYWVtb25zIiwiaXNDbHVzdGVyIiwid2F6dWhkYkV4aXN0cyIsImV4ZWNkIiwibW9kdWxlc2QiLCJ3YXp1aGRiIiwiY2x1c3RlcmQiLCJpc1ZhbGlkIiwiUHJvbWlzZSIsInJlamVjdCIsInNsZWVwIiwidGltZU1zIiwicmVzb2x2ZSIsInNldFRpbWVvdXQiLCJzaG91bGRLZWVwQXJyYXlBc0l0IiwibWV0aG9kIiwiaXNBZ2VudHNSZXN0YXJ0IiwiaXNBY3RpdmVSZXNwb25zZSIsInN0YXJ0c1dpdGgiLCJpc0FkZGluZ0FnZW50c1RvR3JvdXAiLCJtYWtlUmVxdWVzdCIsImRldlRvb2xzIiwiTk9UX0ZPVU5EIiwib3JpZ2luIiwiZGVsYXkiLCJhZGRKb2JUb1F1ZXVlIiwic3RhcnRBdCIsInJ1biIsImNoZWNrIiwiZGF0YVByb3BlcnRpZXMiLCJrZXkiLCJBcnJheSIsImlzQXJyYXkiLCJqb2luIiwicmVzcG9uc2VUb2tlbiIsInJlc3BvbnNlSXNEb3duIiwicmVzcG9uc2VCb2R5IiwicmVzcG9uc2VFcnJvciIsImVycm9yTXNnIiwiQXBpRXJyb3JFcXVpdmFsZW5jZSIsInJlcXVlc3RBcGkiLCJpZEFwaSIsIm1hdGNoIiwiY3N2IiwiZmlsdGVycyIsInRtcFBhdGgiLCJzdWJzdHIiLCJsaW1pdCIsImZpbHRlciIsIm5hbWUiLCJ2YWx1ZSIsIml0ZW1zQXJyYXkiLCJvdXRwdXQiLCJpc0xpc3QiLCJmaW5kIiwiX2lzQ0RCTGlzdCIsInRvdGFsSXRlbXMiLCJ0b3RhbF9hZmZlY3RlZF9pdGVtcyIsIm9mZnNldCIsInB1c2giLCJ0bXBEYXRhIiwiaXNBcnJheU9mTGlzdHMiLCJpc0FnZW50cyIsImlzQWdlbnRzT2ZHcm91cCIsImlzRmlsZXMiLCJlbmRzV2l0aCIsImZpZWxkcyIsImZsYXRMaXN0cyIsImxpc3QiLCJyZWxhdGl2ZV9kaXJuYW1lIiwiaXRlbXMiLCJtYXAiLCJpdGVtIiwianNvbjJjc3ZQYXJzZXIiLCJQYXJzZXIiLCJwYXJzZSIsImZpZWxkIiwicmVwbGFjZSIsIktleUVxdWl2YWxlbmNlIiwiZ2V0UmVxdWVzdExpc3QiLCJhcGlSZXF1ZXN0TGlzdCIsImdldFRpbWVTdGFtcCIsInNvdXJjZSIsIkpTT04iLCJmcyIsInJlYWRGaWxlU3luYyIsImZpbGUiLCJpbnN0YWxsYXRpb25EYXRlIiwibGFzdFJlc3RhcnQiLCJzZXRFeHRlbnNpb25zIiwiZXh0ZW5zaW9ucyIsInVwZGF0ZUFQSUV4dGVuc2lvbnMiLCJnZXRFeHRlbnNpb25zIiwiaG9zdHMiLCJnZXRTZXR1cEluZm8iLCJ2YWx1ZXMiLCJnZXRTeXNjb2xsZWN0b3IiLCJhZ2VudCIsImFsbCIsInJlc3VsdCIsImhhcmR3YXJlUmVzcG9uc2UiLCJvc1Jlc3BvbnNlIiwic3lzY29sbGVjdG9yIiwiaGFyZHdhcmUiLCJvcyIsImlzV2F6dWhEaXNhYmxlZCIsImRpc2FibGVkUm9sZXMiLCJnZXRDb25maWd1cmF0aW9uIiwibG9nb1NpZGViYXIiLCJhdXRoQ29udGV4dCIsInJvbGVzIiwic29tZSIsInJvbGUiLCJnZXRBcHBMb2dvcyIsImNvbmZpZ3VyYXRpb24iLCJTSURFQkFSX0xPR08iLCJBUFBfTE9HTyIsIkhFQUxUSENIRUNLX0xPR08iLCJsb2dvcyIsImdldEN1c3RvbWl6YXRpb25TZXR0aW5nIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbIndhenVoLWFwaS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gQ2xhc3MgZm9yIFdhenVoLUFQSSBmdW5jdGlvbnNcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXG4gKlxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxuICovXG5cbi8vIFJlcXVpcmUgc29tZSBsaWJyYXJpZXNcbmltcG9ydCB7IEVycm9yUmVzcG9uc2UgfSBmcm9tICcuLi9saWIvZXJyb3ItcmVzcG9uc2UnO1xuaW1wb3J0IHsgUGFyc2VyIH0gZnJvbSAnanNvbjJjc3YnO1xuaW1wb3J0IHsgbG9nIH0gZnJvbSAnLi4vbGliL2xvZ2dlcic7XG5pbXBvcnQgeyBLZXlFcXVpdmFsZW5jZSB9IGZyb20gJy4uLy4uL2NvbW1vbi9jc3Yta2V5LWVxdWl2YWxlbmNlJztcbmltcG9ydCB7IEFwaUVycm9yRXF1aXZhbGVuY2UgfSBmcm9tICcuLi9saWIvYXBpLWVycm9ycy1lcXVpdmFsZW5jZSc7XG5pbXBvcnQgYXBpUmVxdWVzdExpc3QgZnJvbSAnLi4vLi4vY29tbW9uL2FwaS1pbmZvL2VuZHBvaW50cyc7XG5pbXBvcnQgeyBIVFRQX1NUQVRVU19DT0RFUyB9IGZyb20gJy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xuaW1wb3J0IHsgZ2V0Q3VzdG9taXphdGlvblNldHRpbmcgfSBmcm9tICcuLi8uLi9jb21tb24vc2VydmljZXMvc2V0dGluZ3MnO1xuaW1wb3J0IHsgYWRkSm9iVG9RdWV1ZSB9IGZyb20gJy4uL3N0YXJ0L3F1ZXVlJztcbmltcG9ydCBmcyBmcm9tICdmcyc7XG5pbXBvcnQgeyBNYW5hZ2VIb3N0cyB9IGZyb20gJy4uL2xpYi9tYW5hZ2UtaG9zdHMnO1xuaW1wb3J0IHsgVXBkYXRlUmVnaXN0cnkgfSBmcm9tICcuLi9saWIvdXBkYXRlLXJlZ2lzdHJ5JztcbmltcG9ydCBqd3REZWNvZGUgZnJvbSAnand0LWRlY29kZSc7XG5pbXBvcnQgeyBLaWJhbmFSZXF1ZXN0LCBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIEtpYmFuYVJlc3BvbnNlRmFjdG9yeSB9IGZyb20gJ3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBBUElVc2VyQWxsb3dSdW5BcywgQ2FjaGVJbk1lbW9yeUFQSVVzZXJBbGxvd1J1bkFzLCBBUElfVVNFUl9TVEFUVVNfUlVOX0FTIH0gZnJvbSAnLi4vbGliL2NhY2hlLWFwaS11c2VyLWhhcy1ydW4tYXMnO1xuaW1wb3J0IHsgZ2V0Q29va2llVmFsdWVCeU5hbWUgfSBmcm9tICcuLi9saWIvY29va2llJztcbmltcG9ydCB7IFNlY3VyaXR5T2JqIH0gZnJvbSAnLi4vbGliL3NlY3VyaXR5LWZhY3RvcnknO1xuaW1wb3J0IHsgZ2V0Q29uZmlndXJhdGlvbiB9IGZyb20gJy4uL2xpYi9nZXQtY29uZmlndXJhdGlvbic7XG5cbmV4cG9ydCBjbGFzcyBXYXp1aEFwaUN0cmwge1xuICBtYW5hZ2VIb3N0czogTWFuYWdlSG9zdHNcbiAgdXBkYXRlUmVnaXN0cnk6IFVwZGF0ZVJlZ2lzdHJ5XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5tYW5hZ2VIb3N0cyA9IG5ldyBNYW5hZ2VIb3N0cygpO1xuICAgIHRoaXMudXBkYXRlUmVnaXN0cnkgPSBuZXcgVXBkYXRlUmVnaXN0cnkoKTtcbiAgfVxuXG4gIGFzeW5jIGdldFRva2VuKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdCwgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGZvcmNlLCBpZEhvc3QgfSA9IHJlcXVlc3QuYm9keTtcbiAgICAgIGNvbnN0IHsgdXNlcm5hbWUgfSA9IGF3YWl0IGNvbnRleHQud2F6dWguc2VjdXJpdHkuZ2V0Q3VycmVudFVzZXIocmVxdWVzdCwgY29udGV4dCk7XG4gICAgICBpZiAoIWZvcmNlICYmIHJlcXVlc3QuaGVhZGVycy5jb29raWUgJiYgdXNlcm5hbWUgPT09IGdldENvb2tpZVZhbHVlQnlOYW1lKHJlcXVlc3QuaGVhZGVycy5jb29raWUsICd3ei11c2VyJykgJiYgaWRIb3N0ID09PSBnZXRDb29raWVWYWx1ZUJ5TmFtZShyZXF1ZXN0LmhlYWRlcnMuY29va2llLCd3ei1hcGknKSkge1xuICAgICAgICBjb25zdCB3elRva2VuID0gZ2V0Q29va2llVmFsdWVCeU5hbWUocmVxdWVzdC5oZWFkZXJzLmNvb2tpZSwgJ3d6LXRva2VuJyk7XG4gICAgICAgIGlmICh3elRva2VuKSB7XG4gICAgICAgICAgdHJ5IHsgLy8gaWYgdGhlIGN1cnJlbnQgdG9rZW4gaXMgbm90IGEgdmFsaWQgand0IHRva2VuIHdlIGFzayBmb3IgYSBuZXcgb25lXG4gICAgICAgICAgICBjb25zdCBkZWNvZGVkVG9rZW4gPSBqd3REZWNvZGUod3pUb2tlbik7XG4gICAgICAgICAgICBjb25zdCBleHBpcmF0aW9uVGltZSA9IChkZWNvZGVkVG9rZW4uZXhwIC0gKERhdGUubm93KCkgLyAxMDAwKSk7XG4gICAgICAgICAgICBpZiAod3pUb2tlbiAmJiBleHBpcmF0aW9uVGltZSA+IDApIHtcbiAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICAgICAgICBib2R5OiB7IHRva2VuOiB3elRva2VuIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGxvZygnd2F6dWgtYXBpOmdldFRva2VuJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBsZXQgdG9rZW47XG4gICAgICBpZiAoYXdhaXQgQVBJVXNlckFsbG93UnVuQXMuY2FuVXNlKGlkSG9zdCkgPT0gQVBJX1VTRVJfU1RBVFVTX1JVTl9BUy5FTkFCTEVEKSB7XG4gICAgICAgIHRva2VuID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIuYXV0aGVudGljYXRlKGlkSG9zdCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0b2tlbiA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5hdXRoZW50aWNhdGUoaWRIb3N0KTtcbiAgICAgIH07XG5cbiAgICAgIGxldCB0ZXh0U2VjdXJlPScnO1xuICAgICAgaWYoY29udGV4dC53YXp1aC5zZXJ2ZXIuaW5mby5wcm90b2NvbCA9PT0gJ2h0dHBzJyl7XG4gICAgICAgIHRleHRTZWN1cmUgPSAnO1NlY3VyZSc7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAnc2V0LWNvb2tpZSc6IFtcbiAgICAgICAgICAgIGB3ei10b2tlbj0ke3Rva2VufTtQYXRoPS87SHR0cE9ubHkke3RleHRTZWN1cmV9YCxcbiAgICAgICAgICAgIGB3ei11c2VyPSR7dXNlcm5hbWV9O1BhdGg9LztIdHRwT25seSR7dGV4dFNlY3VyZX1gLFxuICAgICAgICAgICAgYHd6LWFwaT0ke2lkSG9zdH07UGF0aD0vO0h0dHBPbmx5YCxcbiAgICAgICAgICBdLFxuICAgICAgICB9LFxuICAgICAgICBib2R5OiB7IHRva2VuIH1cbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSAoKGVycm9yLnJlc3BvbnNlIHx8IHt9KS5kYXRhIHx8IHt9KS5kZXRhaWwgfHwgZXJyb3IubWVzc2FnZSB8fCBlcnJvcjtcbiAgICAgIGxvZygnd2F6dWgtYXBpOmdldFRva2VuJywgZXJyb3JNZXNzYWdlKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICBgRXJyb3IgZ2V0dGluZyB0aGUgYXV0aG9yaXphdGlvbiB0b2tlbjogJHtlcnJvck1lc3NhZ2V9YCxcbiAgICAgICAgMzAwMCxcbiAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxuICAgICAgICByZXNwb25zZVxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBpZiB0aGUgd2F6dWgtYXBpIGNvbmZpZ3VyYXRpb24gaXMgd29ya2luZ1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gc3RhdHVzIG9iaiBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBjaGVja1N0b3JlZEFQSShjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3QsIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnkpIHtcbiAgICB0cnkge1xuICAgICAgLy8gR2V0IGNvbmZpZyBmcm9tIHdhenVoLnltbFxuICAgICAgY29uc3QgaWQgPSByZXF1ZXN0LmJvZHkuaWQ7XG4gICAgICBjb25zdCBhcGkgPSBhd2FpdCB0aGlzLm1hbmFnZUhvc3RzLmdldEhvc3RCeUlkKGlkKTtcbiAgICAgIC8vIENoZWNrIE1hbmFnZSBIb3N0c1xuICAgICAgaWYgKCFPYmplY3Qua2V5cyhhcGkpLmxlbmd0aCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NvdWxkIG5vdCBmaW5kIFdhenVoIEFQSSBlbnRyeSBvbiB3YXp1aC55bWwnKTtcbiAgICAgIH1cblxuICAgICAgbG9nKCd3YXp1aC1hcGk6Y2hlY2tTdG9yZWRBUEknLCBgJHtpZH0gZXhpc3RzYCwgJ2RlYnVnJyk7XG5cbiAgICAgIC8vIEZldGNoIG5lZWRlZCBpbmZvcm1hdGlvbiBhYm91dCB0aGUgY2x1c3RlciBhbmQgdGhlIG1hbmFnZXIgaXRzZWxmXG4gICAgICBjb25zdCByZXNwb25zZU1hbmFnZXJJbmZvID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXG4gICAgICAgICdnZXQnLFxuICAgICAgICBgL21hbmFnZXIvaW5mb2AsXG4gICAgICAgIHt9LFxuICAgICAgICB7IGFwaUhvc3RJRDogaWQsIGZvcmNlUmVmcmVzaDogdHJ1ZSB9XG4gICAgICApO1xuXG4gICAgICAvLyBMb29rIGZvciBzb2NrZXQtcmVsYXRlZCBlcnJvcnNcbiAgICAgIGlmICh0aGlzLmNoZWNrUmVzcG9uc2VJc0Rvd24ocmVzcG9uc2VNYW5hZ2VySW5mbykpIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICAgYEVSUk9SMzA5OSAtICR7cmVzcG9uc2VNYW5hZ2VySW5mby5kYXRhLmRldGFpbCB8fCAnV2F6dWggbm90IHJlYWR5IHlldCd9YCxcbiAgICAgICAgICAzMDk5LFxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlNFUlZJQ0VfVU5BVkFJTEFCTEUsXG4gICAgICAgICAgcmVzcG9uc2VcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgLy8gSWYgd2UgaGF2ZSBhIHZhbGlkIHJlc3BvbnNlIGZyb20gdGhlIFdhenVoIEFQSVxuICAgICAgaWYgKHJlc3BvbnNlTWFuYWdlckluZm8uc3RhdHVzID09PSBIVFRQX1NUQVRVU19DT0RFUy5PSyAmJiByZXNwb25zZU1hbmFnZXJJbmZvLmRhdGEpIHtcbiAgICAgICAgLy8gQ2xlYXIgYW5kIHVwZGF0ZSBjbHVzdGVyIGluZm9ybWF0aW9uIGJlZm9yZSBiZWluZyBzZW50IGJhY2sgdG8gZnJvbnRlbmRcbiAgICAgICAgZGVsZXRlIGFwaS5jbHVzdGVyX2luZm87XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQWdlbnRzID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgYC9hZ2VudHNgLFxuICAgICAgICAgIHsgcGFyYW1zOiB7IGFnZW50c19saXN0OiAnMDAwJyB9IH0sXG4gICAgICAgICAgeyBhcGlIb3N0SUQ6IGlkIH1cbiAgICAgICAgKTtcblxuICAgICAgICBpZiAocmVzcG9uc2VBZ2VudHMuc3RhdHVzID09PSBIVFRQX1NUQVRVU19DT0RFUy5PSykge1xuICAgICAgICAgIGNvbnN0IG1hbmFnZXJOYW1lID0gcmVzcG9uc2VBZ2VudHMuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zWzBdLm1hbmFnZXI7XG5cbiAgICAgICAgICBjb25zdCByZXNwb25zZUNsdXN0ZXJTdGF0dXMgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcbiAgICAgICAgICAgICdHRVQnLFxuICAgICAgICAgICAgYC9jbHVzdGVyL3N0YXR1c2AsXG4gICAgICAgICAgICB7fSxcbiAgICAgICAgICAgIHsgYXBpSG9zdElEOiBpZCB9XG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAocmVzcG9uc2VDbHVzdGVyU3RhdHVzLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuT0spIHtcbiAgICAgICAgICAgIGlmIChyZXNwb25zZUNsdXN0ZXJTdGF0dXMuZGF0YS5kYXRhLmVuYWJsZWQgPT09ICd5ZXMnKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHJlc3BvbnNlQ2x1c3RlckxvY2FsSW5mbyA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxuICAgICAgICAgICAgICAgICdHRVQnLFxuICAgICAgICAgICAgICAgIGAvY2x1c3Rlci9sb2NhbC9pbmZvYCxcbiAgICAgICAgICAgICAgICB7fSxcbiAgICAgICAgICAgICAgICB7IGFwaUhvc3RJRDogaWQgfVxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICBpZiAocmVzcG9uc2VDbHVzdGVyTG9jYWxJbmZvLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuT0spIHtcbiAgICAgICAgICAgICAgICBjb25zdCBjbHVzdGVyRW5hYmxlZCA9IHJlc3BvbnNlQ2x1c3RlclN0YXR1cy5kYXRhLmRhdGEuZW5hYmxlZCA9PT0gJ3llcyc7XG4gICAgICAgICAgICAgICAgYXBpLmNsdXN0ZXJfaW5mbyA9IHtcbiAgICAgICAgICAgICAgICAgIHN0YXR1czogY2x1c3RlckVuYWJsZWQgPyAnZW5hYmxlZCcgOiAnZGlzYWJsZWQnLFxuICAgICAgICAgICAgICAgICAgbWFuYWdlcjogbWFuYWdlck5hbWUsXG4gICAgICAgICAgICAgICAgICBub2RlOiByZXNwb25zZUNsdXN0ZXJMb2NhbEluZm8uZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zWzBdLm5vZGUsXG4gICAgICAgICAgICAgICAgICBjbHVzdGVyOiBjbHVzdGVyRW5hYmxlZFxuICAgICAgICAgICAgICAgICAgICA/IHJlc3BvbnNlQ2x1c3RlckxvY2FsSW5mby5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0uY2x1c3RlclxuICAgICAgICAgICAgICAgICAgICA6ICdEaXNhYmxlZCcsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy8gQ2x1c3RlciBtb2RlIGlzIG5vdCBhY3RpdmVcbiAgICAgICAgICAgICAgYXBpLmNsdXN0ZXJfaW5mbyA9IHtcbiAgICAgICAgICAgICAgICBzdGF0dXM6ICdkaXNhYmxlZCcsXG4gICAgICAgICAgICAgICAgbWFuYWdlcjogbWFuYWdlck5hbWUsXG4gICAgICAgICAgICAgICAgY2x1c3RlcjogJ0Rpc2FibGVkJyxcbiAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gQ2x1c3RlciBtb2RlIGlzIG5vdCBhY3RpdmVcbiAgICAgICAgICAgIGFwaS5jbHVzdGVyX2luZm8gPSB7XG4gICAgICAgICAgICAgIHN0YXR1czogJ2Rpc2FibGVkJyxcbiAgICAgICAgICAgICAgbWFuYWdlcjogbWFuYWdlck5hbWUsXG4gICAgICAgICAgICAgIGNsdXN0ZXI6ICdEaXNhYmxlZCcsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChhcGkuY2x1c3Rlcl9pbmZvKSB7XG4gICAgICAgICAgICAvLyBVcGRhdGUgY2x1c3RlciBpbmZvcm1hdGlvbiBpbiB0aGUgd2F6dWgtcmVnaXN0cnkuanNvblxuICAgICAgICAgICAgYXdhaXQgdGhpcy51cGRhdGVSZWdpc3RyeS51cGRhdGVDbHVzdGVySW5mbyhpZCwgYXBpLmNsdXN0ZXJfaW5mbyk7XG5cbiAgICAgICAgICAgIC8vIEhpZGUgV2F6dWggQVBJIHNlY3JldCwgdXNlcm5hbWUsIHBhc3N3b3JkXG4gICAgICAgICAgICBjb25zdCBjb3BpZWQgPSB7IC4uLmFwaSB9O1xuICAgICAgICAgICAgY29waWVkLnNlY3JldCA9ICcqKioqJztcbiAgICAgICAgICAgIGNvcGllZC5wYXNzd29yZCA9ICcqKioqJztcblxuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICAgIHN0YXR1c0NvZGU6IEhUVFBfU1RBVFVTX0NPREVTLk9LLFxuICAgICAgICAgICAgICAgIGRhdGE6IGNvcGllZCxcbiAgICAgICAgICAgICAgICBpZENoYW5nZWQ6IHJlcXVlc3QuYm9keS5pZENoYW5nZWQgfHwgbnVsbCxcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIElmIHdlIGhhdmUgYW4gaW52YWxpZCByZXNwb25zZSBmcm9tIHRoZSBXYXp1aCBBUElcbiAgICAgIHRocm93IG5ldyBFcnJvcihyZXNwb25zZU1hbmFnZXJJbmZvLmRhdGEuZGV0YWlsIHx8IGAke2FwaS51cmx9OiR7YXBpLnBvcnR9IGlzIHVucmVhY2hhYmxlYCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvci5jb2RlID09PSAnRVBST1RPJykge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IEhUVFBfU1RBVFVTX0NPREVTLk9LLFxuICAgICAgICAgICAgZGF0YTogeyBhcGlJc0Rvd246IHRydWUgfSxcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIGlmIChlcnJvci5jb2RlID09PSAnRUNPTk5SRUZVU0VEJykge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIHN0YXR1c0NvZGU6IEhUVFBfU1RBVFVTX0NPREVTLk9LLFxuICAgICAgICAgICAgZGF0YTogeyBhcGlJc0Rvd246IHRydWUgfSxcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBhcGlzID0gYXdhaXQgdGhpcy5tYW5hZ2VIb3N0cy5nZXRIb3N0cygpO1xuICAgICAgICAgIGZvciAoY29uc3QgYXBpIG9mIGFwaXMpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGNvbnN0IGlkID0gT2JqZWN0LmtleXMoYXBpKVswXTtcblxuICAgICAgICAgICAgICBjb25zdCByZXNwb25zZU1hbmFnZXJJbmZvID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICAgICAgYC9tYW5hZ2VyL2luZm9gLFxuICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgIHsgYXBpSG9zdElEOiBpZCB9XG4gICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgaWYgKHRoaXMuY2hlY2tSZXNwb25zZUlzRG93bihyZXNwb25zZU1hbmFnZXJJbmZvKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAgICAgICAgICAgYEVSUk9SMzA5OSAtICR7cmVzcG9uc2UuZGF0YS5kZXRhaWwgfHwgJ1dhenVoIG5vdCByZWFkeSB5ZXQnfWAsXG4gICAgICAgICAgICAgICAgICAzMDk5LFxuICAgICAgICAgICAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuU0VSVklDRV9VTkFWQUlMQUJMRSxcbiAgICAgICAgICAgICAgICAgIHJlc3BvbnNlXG4gICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZiAocmVzcG9uc2VNYW5hZ2VySW5mby5zdGF0dXMgPT09IEhUVFBfU1RBVFVTX0NPREVTLk9LKSB7XG4gICAgICAgICAgICAgICAgcmVxdWVzdC5ib2R5LmlkID0gaWQ7XG4gICAgICAgICAgICAgICAgcmVxdWVzdC5ib2R5LmlkQ2hhbmdlZCA9IGlkO1xuICAgICAgICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmNoZWNrU3RvcmVkQVBJKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHsgfSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gICAgICAgICAgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGxvZygnd2F6dWgtYXBpOmNoZWNrU3RvcmVkQVBJJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yLFxuICAgICAgICAgICAgMzAyMCxcbiAgICAgICAgICAgIGVycm9yPy5yZXNwb25zZT8uc3RhdHVzIHx8IEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgICAgIHJlc3BvbnNlXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBsb2coJ3dhenVoLWFwaTpjaGVja1N0b3JlZEFQSScsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICBlcnJvci5tZXNzYWdlIHx8IGVycm9yLFxuICAgICAgICAgIDMwMDIsXG4gICAgICAgICAgZXJyb3I/LnJlc3BvbnNlPy5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxuICAgICAgICAgIHJlc3BvbnNlXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgcGVyZm9tcyBhIHZhbGlkYXRpb24gb2YgQVBJIHBhcmFtc1xuICAgKiBAcGFyYW0ge09iamVjdH0gYm9keSBBUEkgcGFyYW1zXG4gICAqL1xuICB2YWxpZGF0ZUNoZWNrQXBpUGFyYW1zKGJvZHkpIHtcbiAgICBpZiAoISgndXNlcm5hbWUnIGluIGJvZHkpKSB7XG4gICAgICByZXR1cm4gJ01pc3NpbmcgcGFyYW06IEFQSSBVU0VSTkFNRSc7XG4gICAgfVxuXG4gICAgaWYgKCEoJ3Bhc3N3b3JkJyBpbiBib2R5KSAmJiAhKCdpZCcgaW4gYm9keSkpIHtcbiAgICAgIHJldHVybiAnTWlzc2luZyBwYXJhbTogQVBJIFBBU1NXT1JEJztcbiAgICB9XG5cbiAgICBpZiAoISgndXJsJyBpbiBib2R5KSkge1xuICAgICAgcmV0dXJuICdNaXNzaW5nIHBhcmFtOiBBUEkgVVJMJztcbiAgICB9XG5cbiAgICBpZiAoISgncG9ydCcgaW4gYm9keSkpIHtcbiAgICAgIHJldHVybiAnTWlzc2luZyBwYXJhbTogQVBJIFBPUlQnO1xuICAgIH1cblxuICAgIGlmICghYm9keS51cmwuaW5jbHVkZXMoJ2h0dHBzOi8vJykgJiYgIWJvZHkudXJsLmluY2x1ZGVzKCdodHRwOi8vJykpIHtcbiAgICAgIHJldHVybiAncHJvdG9jb2xfZXJyb3InO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGNoZWNrIHRoZSB3YXp1aC1hcGkgY29uZmlndXJhdGlvbiByZWNlaXZlZCBpbiB0aGUgUE9TVCBib2R5IHdpbGwgd29ya1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gc3RhdHVzIG9iaiBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBjaGVja0FQSShjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3QsIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnkpIHtcbiAgICB0cnkge1xuICAgICAgbGV0IGFwaUF2YWlsYWJsZSA9IG51bGw7XG4gICAgICAvLyBjb25zdCBub3RWYWxpZCA9IHRoaXMudmFsaWRhdGVDaGVja0FwaVBhcmFtcyhyZXF1ZXN0LmJvZHkpO1xuICAgICAgLy8gaWYgKG5vdFZhbGlkKSByZXR1cm4gRXJyb3JSZXNwb25zZShub3RWYWxpZCwgMzAwMywgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLCByZXNwb25zZSk7XG4gICAgICBsb2coJ3dhenVoLWFwaTpjaGVja0FQSScsIGAke3JlcXVlc3QuYm9keS5pZH0gaXMgdmFsaWRgLCAnZGVidWcnKTtcbiAgICAgIC8vIENoZWNrIGlmIGEgV2F6dWggQVBJIGlkIGlzIGdpdmVuIChhbHJlYWR5IHN0b3JlZCBBUEkpXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgdGhpcy5tYW5hZ2VIb3N0cy5nZXRIb3N0QnlJZChyZXF1ZXN0LmJvZHkuaWQpO1xuICAgICAgaWYgKGRhdGEpIHtcbiAgICAgICAgYXBpQXZhaWxhYmxlID0gZGF0YTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGxvZygnd2F6dWgtYXBpOmNoZWNrQVBJJywgYEFQSSAke3JlcXVlc3QuYm9keS5pZH0gbm90IGZvdW5kYCk7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAgIGBUaGUgQVBJICR7cmVxdWVzdC5ib2R5LmlkfSB3YXMgbm90IGZvdW5kYCxcbiAgICAgICAgICAzMDI5LFxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgICByZXNwb25zZVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgY29uc3Qgb3B0aW9ucyA9IHsgYXBpSG9zdElEOiByZXF1ZXN0LmJvZHkuaWQgfTtcbiAgICAgIGlmIChyZXF1ZXN0LmJvZHkuZm9yY2VSZWZyZXNoKSB7XG4gICAgICAgIG9wdGlvbnNbXCJmb3JjZVJlZnJlc2hcIl0gPSByZXF1ZXN0LmJvZHkuZm9yY2VSZWZyZXNoO1xuICAgICAgfVxuICAgICAgbGV0IHJlc3BvbnNlTWFuYWdlckluZm87XG4gICAgICB0cnl7XG4gICAgICAgIHJlc3BvbnNlTWFuYWdlckluZm8gPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcbiAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICBgL21hbmFnZXIvaW5mb2AsXG4gICAgICAgICAge30sXG4gICAgICAgICAgb3B0aW9uc1xuICAgICAgICApO1xuICAgICAgfWNhdGNoKGVycm9yKXtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICAgYEVSUk9SMzA5OSAtICR7ZXJyb3IucmVzcG9uc2U/LmRhdGE/LmRldGFpbCB8fCAnV2F6dWggbm90IHJlYWR5IHlldCd9YCxcbiAgICAgICAgICAzMDk5LFxuICAgICAgICAgIGVycm9yPy5yZXNwb25zZT8uc3RhdHVzIHx8IEhUVFBfU1RBVFVTX0NPREVTLlNFUlZJQ0VfVU5BVkFJTEFCTEUsXG4gICAgICAgICAgcmVzcG9uc2VcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgbG9nKCd3YXp1aC1hcGk6Y2hlY2tBUEknLCBgJHtyZXF1ZXN0LmJvZHkuaWR9IGNyZWRlbnRpYWxzIGFyZSB2YWxpZGAsICdkZWJ1ZycpO1xuICAgICAgaWYgKHJlc3BvbnNlTWFuYWdlckluZm8uc3RhdHVzID09PSBIVFRQX1NUQVRVU19DT0RFUy5PSyAmJiByZXNwb25zZU1hbmFnZXJJbmZvLmRhdGEpIHtcbiAgICAgICAgbGV0IHJlc3BvbnNlQWdlbnRzID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgYC9hZ2VudHNgLFxuICAgICAgICAgIHsgcGFyYW1zOiB7IGFnZW50c19saXN0OiAnMDAwJyB9IH0sXG4gICAgICAgICAgeyBhcGlIb3N0SUQ6IHJlcXVlc3QuYm9keS5pZCB9XG4gICAgICAgICk7XG5cbiAgICAgICAgaWYgKHJlc3BvbnNlQWdlbnRzLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuT0spIHtcbiAgICAgICAgICBjb25zdCBtYW5hZ2VyTmFtZSA9IHJlc3BvbnNlQWdlbnRzLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS5tYW5hZ2VyO1xuXG4gICAgICAgICAgbGV0IHJlc3BvbnNlQ2x1c3RlciA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxuICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICBgL2NsdXN0ZXIvc3RhdHVzYCxcbiAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IHJlcXVlc3QuYm9keS5pZCB9XG4gICAgICAgICAgKTtcblxuICAgICAgICAgIC8vIENoZWNrIHRoZSBydW5fYXMgZm9yIHRoZSBBUEkgdXNlciBhbmQgdXBkYXRlIGl0XG4gICAgICAgICAgbGV0IGFwaVVzZXJBbGxvd1J1bkFzID0gQVBJX1VTRVJfU1RBVFVTX1JVTl9BUy5BTExfRElTQUJMRUQ7XG4gICAgICAgICAgY29uc3QgcmVzcG9uc2VBcGlVc2VyQWxsb3dSdW5BcyA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0ludGVybmFsVXNlci5yZXF1ZXN0KFxuICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICBgL3NlY3VyaXR5L3VzZXJzL21lYCxcbiAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IHJlcXVlc3QuYm9keS5pZCB9XG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAocmVzcG9uc2VBcGlVc2VyQWxsb3dSdW5Bcy5zdGF0dXMgPT09IEhUVFBfU1RBVFVTX0NPREVTLk9LKSB7XG4gICAgICAgICAgICBjb25zdCBhbGxvd19ydW5fYXMgPSByZXNwb25zZUFwaVVzZXJBbGxvd1J1bkFzLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS5hbGxvd19ydW5fYXM7XG5cbiAgICAgICAgICAgIGlmIChhbGxvd19ydW5fYXMgJiYgYXBpQXZhaWxhYmxlICYmIGFwaUF2YWlsYWJsZS5ydW5fYXMpIC8vIEhPU1QgQU5EIFVTRVIgRU5BQkxFRFxuICAgICAgICAgICAgICBhcGlVc2VyQWxsb3dSdW5BcyA9IEFQSV9VU0VSX1NUQVRVU19SVU5fQVMuRU5BQkxFRDtcblxuICAgICAgICAgICAgZWxzZSBpZiAoIWFsbG93X3J1bl9hcyAmJiBhcGlBdmFpbGFibGUgJiYgYXBpQXZhaWxhYmxlLnJ1bl9hcykvLyBIT1NUIEVOQUJMRUQgQU5EIFVTRVIgRElTQUJMRURcbiAgICAgICAgICAgICAgYXBpVXNlckFsbG93UnVuQXMgPSBBUElfVVNFUl9TVEFUVVNfUlVOX0FTLlVTRVJfTk9UX0FMTE9XRUQ7XG5cbiAgICAgICAgICAgIGVsc2UgaWYgKGFsbG93X3J1bl9hcyAmJiAoICFhcGlBdmFpbGFibGUgfHwgIWFwaUF2YWlsYWJsZS5ydW5fYXMgKSkgLy8gVVNFUiBFTkFCTEVEIEFORCBIT1NUIERJU0FCTEVEXG4gICAgICAgICAgICAgIGFwaVVzZXJBbGxvd1J1bkFzID0gQVBJX1VTRVJfU1RBVFVTX1JVTl9BUy5IT1NUX0RJU0FCTEVEO1xuXG4gICAgICAgICAgICBlbHNlIGlmICghYWxsb3dfcnVuX2FzICYmICggIWFwaUF2YWlsYWJsZSB8fCAhYXBpQXZhaWxhYmxlLnJ1bl9hcyApKSAvLyBIT1NUIEFORCBVU0VSIERJU0FCTEVEXG4gICAgICAgICAgICAgIGFwaVVzZXJBbGxvd1J1bkFzID0gQVBJX1VTRVJfU1RBVFVTX1JVTl9BUy5BTExfRElTQUJMRUQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIENhY2hlSW5NZW1vcnlBUElVc2VyQWxsb3dSdW5Bcy5zZXQoXG4gICAgICAgICAgICByZXF1ZXN0LmJvZHkuaWQsXG4gICAgICAgICAgICBhcGlBdmFpbGFibGUudXNlcm5hbWUsXG4gICAgICAgICAgICBhcGlVc2VyQWxsb3dSdW5Bc1xuICAgICAgICAgICk7XG5cbiAgICAgICAgICBpZiAocmVzcG9uc2VDbHVzdGVyLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuT0spIHtcbiAgICAgICAgICAgIGxvZygnd2F6dWgtYXBpOmNoZWNrU3RvcmVkQVBJJywgYFdhenVoIEFQSSByZXNwb25zZSBpcyB2YWxpZGAsICdkZWJ1ZycpO1xuICAgICAgICAgICAgaWYgKHJlc3BvbnNlQ2x1c3Rlci5kYXRhLmRhdGEuZW5hYmxlZCA9PT0gJ3llcycpIHtcbiAgICAgICAgICAgICAgLy8gSWYgY2x1c3RlciBtb2RlIGlzIGFjdGl2ZVxuICAgICAgICAgICAgICBsZXQgcmVzcG9uc2VDbHVzdGVyTG9jYWwgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcbiAgICAgICAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICAgICAgICBgL2NsdXN0ZXIvbG9jYWwvaW5mb2AsXG4gICAgICAgICAgICAgICAge30sXG4gICAgICAgICAgICAgICAgeyBhcGlIb3N0SUQ6IHJlcXVlc3QuYm9keS5pZCB9XG4gICAgICAgICAgICAgICk7XG5cbiAgICAgICAgICAgICAgaWYgKHJlc3BvbnNlQ2x1c3RlckxvY2FsLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuT0spIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICAgICAgICBtYW5hZ2VyOiBtYW5hZ2VyTmFtZSxcbiAgICAgICAgICAgICAgICAgICAgbm9kZTogcmVzcG9uc2VDbHVzdGVyTG9jYWwuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zWzBdLm5vZGUsXG4gICAgICAgICAgICAgICAgICAgIGNsdXN0ZXI6IHJlc3BvbnNlQ2x1c3RlckxvY2FsLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS5jbHVzdGVyLFxuICAgICAgICAgICAgICAgICAgICBzdGF0dXM6ICdlbmFibGVkJyxcbiAgICAgICAgICAgICAgICAgICAgYWxsb3dfcnVuX2FzOiBhcGlVc2VyQWxsb3dSdW5BcyxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIENsdXN0ZXIgbW9kZSBpcyBub3QgYWN0aXZlXG4gICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICAgICAgbWFuYWdlcjogbWFuYWdlck5hbWUsXG4gICAgICAgICAgICAgICAgICBjbHVzdGVyOiAnRGlzYWJsZWQnLFxuICAgICAgICAgICAgICAgICAgc3RhdHVzOiAnZGlzYWJsZWQnLFxuICAgICAgICAgICAgICAgICAgYWxsb3dfcnVuX2FzOiBhcGlVc2VyQWxsb3dSdW5BcyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCd3YXp1aC1hcGk6Y2hlY2tBUEknLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcblxuICAgICAgaWYgKGVycm9yICYmIGVycm9yLnJlc3BvbnNlICYmIGVycm9yLnJlc3BvbnNlLnN0YXR1cyA9PT0gSFRUUF9TVEFUVVNfQ09ERVMuVU5BVVRIT1JJWkVEKSB7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAgIGBVbmF0aG9yaXplZC4gUGxlYXNlIGNoZWNrIEFQSSBjcmVkZW50aWFscy4gJHtlcnJvci5yZXNwb25zZS5kYXRhLm1lc3NhZ2V9YCxcbiAgICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5VTkFVVEhPUklaRUQsXG4gICAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuVU5BVVRIT1JJWkVELFxuICAgICAgICAgIHJlc3BvbnNlXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoZXJyb3IgJiYgZXJyb3IucmVzcG9uc2UgJiYgZXJyb3IucmVzcG9uc2UuZGF0YSAmJiBlcnJvci5yZXNwb25zZS5kYXRhLmRldGFpbCkge1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICBlcnJvci5yZXNwb25zZS5kYXRhLmRldGFpbCxcbiAgICAgICAgICBlcnJvci5yZXNwb25zZS5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuU0VSVklDRV9VTkFWQUlMQUJMRSxcbiAgICAgICAgICBlcnJvci5yZXNwb25zZS5zdGF0dXMgfHwgSFRUUF9TVEFUVVNfQ09ERVMuU0VSVklDRV9VTkFWQUlMQUJMRSxcbiAgICAgICAgICByZXNwb25zZVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYgKGVycm9yLmNvZGUgPT09ICdFUFJPVE8nKSB7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICAgICdXcm9uZyBwcm90b2NvbCBiZWluZyB1c2VkIHRvIGNvbm5lY3QgdG8gdGhlIFdhenVoIEFQSScsXG4gICAgICAgICAgMzAwNSxcbiAgICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5CQURfUkVRVUVTVCxcbiAgICAgICAgICByZXNwb25zZVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsXG4gICAgICAgIDMwMDUsXG4gICAgICAgIGVycm9yPy5yZXNwb25zZT8uc3RhdHVzIHx8IEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgcmVzcG9uc2VcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgY2hlY2tSZXNwb25zZUlzRG93bihyZXNwb25zZSkge1xuICAgIGlmIChyZXNwb25zZS5zdGF0dXMgIT09IEhUVFBfU1RBVFVTX0NPREVTLk9LKSB7XG4gICAgICAvLyBBdm9pZCBcIkVycm9yIGNvbW11bmljYXRpbmcgd2l0aCBzb2NrZXRcIiBsaWtlIGVycm9yc1xuICAgICAgY29uc3Qgc29ja2V0RXJyb3JDb2RlcyA9IFsxMDEzLCAxMDE0LCAxMDE3LCAxMDE4LCAxMDE5XTtcbiAgICAgIGNvbnN0IHN0YXR1cyA9IChyZXNwb25zZS5kYXRhIHx8IHt9KS5zdGF0dXMgfHwgMVxuICAgICAgY29uc3QgaXNEb3duID0gc29ja2V0RXJyb3JDb2Rlcy5pbmNsdWRlcyhzdGF0dXMpO1xuXG4gICAgICBpc0Rvd24gJiYgbG9nKCd3YXp1aC1hcGk6bWFrZVJlcXVlc3QnLCAnV2F6dWggQVBJIGlzIG9ubGluZSBidXQgV2F6dWggaXMgbm90IHJlYWR5IHlldCcpO1xuXG4gICAgICByZXR1cm4gaXNEb3duO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgbWFpbiBXYXp1aCBkYWVtb25zIHN0YXR1c1xuICAgKiBAcGFyYW0geyp9IGNvbnRleHQgRW5kcG9pbnQgY29udGV4dFxuICAgKiBAcGFyYW0geyp9IGFwaSBBUEkgZW50cnkgc3RvcmVkIGluIC53YXp1aFxuICAgKiBAcGFyYW0geyp9IHBhdGggT3B0aW9uYWwuIFdhenVoIEFQSSB0YXJnZXQgcGF0aC5cbiAgICovXG4gIGFzeW5jIGNoZWNrRGFlbW9ucyhjb250ZXh0LCBhcGksIHBhdGgpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcbiAgICAgICAgJ0dFVCcsXG4gICAgICAgICcvbWFuYWdlci9zdGF0dXMnLFxuICAgICAgICB7fSxcbiAgICAgICAgeyBhcGlIb3N0SUQ6IGFwaS5pZCB9XG4gICAgICApO1xuXG4gICAgICBjb25zdCBkYWVtb25zID0gKCgoKHJlc3BvbnNlIHx8IHt9KS5kYXRhIHx8IHt9KS5kYXRhIHx8IHt9KS5hZmZlY3RlZF9pdGVtcyB8fCBbXSlbMF0gfHwge307XG5cbiAgICAgIGNvbnN0IGlzQ2x1c3RlciA9XG4gICAgICAgICgoYXBpIHx8IHt9KS5jbHVzdGVyX2luZm8gfHwge30pLnN0YXR1cyA9PT0gJ2VuYWJsZWQnICYmXG4gICAgICAgIHR5cGVvZiBkYWVtb25zWyd3YXp1aC1jbHVzdGVyZCddICE9PSAndW5kZWZpbmVkJztcbiAgICAgIGNvbnN0IHdhenVoZGJFeGlzdHMgPSB0eXBlb2YgZGFlbW9uc1snd2F6dWgtZGInXSAhPT0gJ3VuZGVmaW5lZCc7XG5cbiAgICAgIGNvbnN0IGV4ZWNkID0gZGFlbW9uc1snd2F6dWgtZXhlY2QnXSA9PT0gJ3J1bm5pbmcnO1xuICAgICAgY29uc3QgbW9kdWxlc2QgPSBkYWVtb25zWyd3YXp1aC1tb2R1bGVzZCddID09PSAncnVubmluZyc7XG4gICAgICBjb25zdCB3YXp1aGRiID0gd2F6dWhkYkV4aXN0cyA/IGRhZW1vbnNbJ3dhenVoLWRiJ10gPT09ICdydW5uaW5nJyA6IHRydWU7XG4gICAgICBjb25zdCBjbHVzdGVyZCA9IGlzQ2x1c3RlciA/IGRhZW1vbnNbJ3dhenVoLWNsdXN0ZXJkJ10gPT09ICdydW5uaW5nJyA6IHRydWU7XG5cbiAgICAgIGNvbnN0IGlzVmFsaWQgPSBleGVjZCAmJiBtb2R1bGVzZCAmJiB3YXp1aGRiICYmIGNsdXN0ZXJkO1xuXG4gICAgICBpc1ZhbGlkICYmIGxvZygnd2F6dWgtYXBpOmNoZWNrRGFlbW9ucycsIGBXYXp1aCBpcyByZWFkeWAsICdkZWJ1ZycpO1xuXG4gICAgICBpZiAocGF0aCA9PT0gJy9waW5nJykge1xuICAgICAgICByZXR1cm4geyBpc1ZhbGlkIH07XG4gICAgICB9XG5cbiAgICAgIGlmICghaXNWYWxpZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1dhenVoIG5vdCByZWFkeSB5ZXQnKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCd3YXp1aC1hcGk6Y2hlY2tEYWVtb25zJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHNsZWVwKHRpbWVNcykge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBzZXRUaW1lb3V0KHJlc29sdmUsIHRpbWVNcyk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogSGVscGVyIG1ldGhvZCBmb3IgRGV2IFRvb2xzLlxuICAgKiBodHRwczovL2RvY3VtZW50YXRpb24ud2F6dWguY29tL2N1cnJlbnQvdXNlci1tYW51YWwvYXBpL3JlZmVyZW5jZS5odG1sXG4gICAqIERlcGVuZGluZyBvbiB0aGUgbWV0aG9kIGFuZCB0aGUgcGF0aCBzb21lIHBhcmFtZXRlcnMgc2hvdWxkIGJlIGFuIGFycmF5IG9yIG5vdC5cbiAgICogU2luY2Ugd2UgYWxsb3cgdGhlIHVzZXIgdG8gd3JpdGUgdGhlIHJlcXVlc3QgdXNpbmcgYm90aCBjb21tYS1zZXBhcmF0ZWQgYW5kIGFycmF5IGFzIHdlbGwsXG4gICAqIHdlIG5lZWQgdG8gY2hlY2sgaWYgaXQgc2hvdWxkIGJlIHRyYW5zZm9ybWVkIG9yIG5vdC5cbiAgICogQHBhcmFtIHsqfSBtZXRob2QgVGhlIHJlcXVlc3QgbWV0aG9kXG4gICAqIEBwYXJhbSB7Kn0gcGF0aCBUaGUgV2F6dWggQVBJIHBhdGhcbiAgICovXG4gIHNob3VsZEtlZXBBcnJheUFzSXQobWV0aG9kLCBwYXRoKSB7XG4gICAgLy8gTWV0aG9kcyB0aGF0IHdlIG11c3QgcmVzcGVjdCBhIGRvIG5vdCB0cmFuc2Zvcm0gdGhlbVxuICAgIGNvbnN0IGlzQWdlbnRzUmVzdGFydCA9IG1ldGhvZCA9PT0gJ1BPU1QnICYmIHBhdGggPT09ICcvYWdlbnRzL3Jlc3RhcnQnO1xuICAgIGNvbnN0IGlzQWN0aXZlUmVzcG9uc2UgPSBtZXRob2QgPT09ICdQVVQnICYmIHBhdGguc3RhcnRzV2l0aCgnL2FjdGl2ZS1yZXNwb25zZScpO1xuICAgIGNvbnN0IGlzQWRkaW5nQWdlbnRzVG9Hcm91cCA9IG1ldGhvZCA9PT0gJ1BPU1QnICYmIHBhdGguc3RhcnRzV2l0aCgnL2FnZW50cy9ncm91cC8nKTtcblxuICAgIC8vIFJldHVybnMgdHJ1ZSBvbmx5IGlmIG9uZSBvZiB0aGUgYWJvdmUgY29uZGl0aW9ucyBpcyB0cnVlXG4gICAgcmV0dXJuIGlzQWdlbnRzUmVzdGFydCB8fCBpc0FjdGl2ZVJlc3BvbnNlIHx8IGlzQWRkaW5nQWdlbnRzVG9Hcm91cDtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIHBlcmZvcm1zIGEgcmVxdWVzdCBvdmVyIFdhenVoIEFQSSBhbmQgcmV0dXJucyBpdHMgcmVzcG9uc2VcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1ldGhvZCBNZXRob2Q6IEdFVCwgUFVULCBQT1NULCBERUxFVEVcbiAgICogQHBhcmFtIHtTdHJpbmd9IHBhdGggQVBJIHJvdXRlXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIGRhdGEgYW5kIHBhcmFtcyB0byBwZXJmb3JtIHRoZSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7U3RyaW5nfSBpZCBBUEkgaWRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IEFQSSByZXNwb25zZSBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBtYWtlUmVxdWVzdChjb250ZXh0LCBtZXRob2QsIHBhdGgsIGRhdGEsIGlkLCByZXNwb25zZSkge1xuXG4gICAgY29uc3QgZGV2VG9vbHMgPSAhIShkYXRhIHx8IHt9KS5kZXZUb29scztcbiAgICB0cnkge1xuICAgICAgY29uc3QgYXBpID0gYXdhaXQgdGhpcy5tYW5hZ2VIb3N0cy5nZXRIb3N0QnlJZChpZCk7XG4gICAgICBpZiAoZGV2VG9vbHMpIHtcbiAgICAgICAgZGVsZXRlIGRhdGEuZGV2VG9vbHM7XG4gICAgICB9XG5cbiAgICAgIGlmICghT2JqZWN0LmtleXMoYXBpKS5sZW5ndGgpIHtcbiAgICAgICAgbG9nKCd3YXp1aC1hcGk6bWFrZVJlcXVlc3QnLCAnQ291bGQgbm90IGdldCBob3N0IGNyZWRlbnRpYWxzJyk7XG4gICAgICAgIC8vQ2FuIG5vdCBnZXQgY3JlZGVudGlhbHMgZnJvbSB3YXp1aC1ob3N0c1xuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnQ291bGQgbm90IGdldCBob3N0IGNyZWRlbnRpYWxzJywgMzAxMSwgSFRUUF9TVEFUVVNfQ09ERVMuTk9UX0ZPVU5ELCByZXNwb25zZSk7XG4gICAgICB9XG5cbiAgICAgIGlmICghZGF0YSkge1xuICAgICAgICBkYXRhID0ge307XG4gICAgICB9O1xuXG4gICAgICBpZiAoIWRhdGEuaGVhZGVycykge1xuICAgICAgICBkYXRhLmhlYWRlcnMgPSB7fTtcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICAgIGFwaUhvc3RJRDogaWRcbiAgICAgIH07XG5cbiAgICAgIC8vIFNldCBjb250ZW50IHR5cGUgYXBwbGljYXRpb24veG1sIGlmIG5lZWRlZFxuICAgICAgaWYgKHR5cGVvZiAoZGF0YSB8fCB7fSkuYm9keSA9PT0gJ3N0cmluZycgJiYgKGRhdGEgfHwge30pLm9yaWdpbiA9PT0gJ3htbGVkaXRvcicpIHtcbiAgICAgICAgZGF0YS5oZWFkZXJzWydjb250ZW50LXR5cGUnXSA9ICdhcHBsaWNhdGlvbi94bWwnO1xuICAgICAgICBkZWxldGUgZGF0YS5vcmlnaW47XG4gICAgICB9XG5cbiAgICAgIGlmICh0eXBlb2YgKGRhdGEgfHwge30pLmJvZHkgPT09ICdzdHJpbmcnICYmIChkYXRhIHx8IHt9KS5vcmlnaW4gPT09ICdqc29uJykge1xuICAgICAgICBkYXRhLmhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddID0gJ2FwcGxpY2F0aW9uL2pzb24nO1xuICAgICAgICBkZWxldGUgZGF0YS5vcmlnaW47XG4gICAgICB9XG5cbiAgICAgIGlmICh0eXBlb2YgKGRhdGEgfHwge30pLmJvZHkgPT09ICdzdHJpbmcnICYmIChkYXRhIHx8IHt9KS5vcmlnaW4gPT09ICdyYXcnKSB7XG4gICAgICAgIGRhdGEuaGVhZGVyc1snY29udGVudC10eXBlJ10gPSAnYXBwbGljYXRpb24vb2N0ZXQtc3RyZWFtJztcbiAgICAgICAgZGVsZXRlIGRhdGEub3JpZ2luO1xuICAgICAgfVxuICAgICAgY29uc3QgZGVsYXkgPSAoZGF0YSB8fCB7fSkuZGVsYXkgfHwgMDtcbiAgICAgIGlmIChkZWxheSkge1xuICAgICAgICBhZGRKb2JUb1F1ZXVlKHtcbiAgICAgICAgICBzdGFydEF0OiBuZXcgRGF0ZShEYXRlLm5vdygpICsgZGVsYXkpLFxuICAgICAgICAgIHJ1bjogYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgdHJ5e1xuICAgICAgICAgICAgICBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KG1ldGhvZCwgcGF0aCwgZGF0YSwgb3B0aW9ucyk7XG4gICAgICAgICAgICB9Y2F0Y2goZXJyb3Ipe1xuICAgICAgICAgICAgICBsb2coJ3F1ZXVlOmRlbGF5QXBpUmVxdWVzdCcsYEFuIGVycm9yIG9jdXJyZWQgaW4gdGhlIGRlbGF5ZWQgcmVxdWVzdDogXCIke21ldGhvZH0gJHtwYXRofVwiOiAke2Vycm9yLm1lc3NhZ2UgfHwgZXJyb3J9YCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogeyBlcnJvcjogMCwgbWVzc2FnZTogJ1N1Y2Nlc3MnIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGlmIChwYXRoID09PSAnL3BpbmcnKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgY2hlY2sgPSBhd2FpdCB0aGlzLmNoZWNrRGFlbW9ucyhjb250ZXh0LCBhcGksIHBhdGgpO1xuICAgICAgICAgIHJldHVybiBjaGVjaztcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBjb25zdCBpc0Rvd24gPSAoZXJyb3IgfHwge30pLmNvZGUgPT09ICdFQ09OTlJFRlVTRUQnO1xuICAgICAgICAgIGlmICghaXNEb3duKSB7XG4gICAgICAgICAgICBsb2coJ3dhenVoLWFwaTptYWtlUmVxdWVzdCcsICdXYXp1aCBBUEkgaXMgb25saW5lIGJ1dCBXYXp1aCBpcyBub3QgcmVhZHkgeWV0Jyk7XG4gICAgICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICAgICAgYEVSUk9SMzA5OSAtICR7ZXJyb3IubWVzc2FnZSB8fCAnV2F6dWggbm90IHJlYWR5IHlldCd9YCxcbiAgICAgICAgICAgICAgMzA5OSxcbiAgICAgICAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxuICAgICAgICAgICAgICByZXNwb25zZVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbG9nKCd3YXp1aC1hcGk6bWFrZVJlcXVlc3QnLCBgJHttZXRob2R9ICR7cGF0aH1gLCAnZGVidWcnKTtcblxuICAgICAgLy8gRXh0cmFjdCBrZXlzIGZyb20gcGFyYW1ldGVyc1xuICAgICAgY29uc3QgZGF0YVByb3BlcnRpZXMgPSBPYmplY3Qua2V5cyhkYXRhKTtcblxuICAgICAgLy8gVHJhbnNmb3JtIGFycmF5cyBpbnRvIGNvbW1hLXNlcGFyYXRlZCBzdHJpbmcgaWYgYXBwbGljYWJsZS5cbiAgICAgIC8vIFRoZSByZWFzb24gaXMgdGhhdCB3ZSBhcmUgYWNjZXB0aW5nIGFycmF5cyBmb3IgY29tbWEtc2VwYXJhdGVkXG4gICAgICAvLyBwYXJhbWV0ZXJzIGluIHRoZSBEZXYgVG9vbHNcbiAgICAgIGlmICghdGhpcy5zaG91bGRLZWVwQXJyYXlBc0l0KG1ldGhvZCwgcGF0aCkpIHtcbiAgICAgICAgZm9yIChjb25zdCBrZXkgb2YgZGF0YVByb3BlcnRpZXMpIHtcbiAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShkYXRhW2tleV0pKSB7XG4gICAgICAgICAgICBkYXRhW2tleV0gPSBkYXRhW2tleV0uam9pbigpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBjb25zdCByZXNwb25zZVRva2VuID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChtZXRob2QsIHBhdGgsIGRhdGEsIG9wdGlvbnMpO1xuICAgICAgY29uc3QgcmVzcG9uc2VJc0Rvd24gPSB0aGlzLmNoZWNrUmVzcG9uc2VJc0Rvd24ocmVzcG9uc2VUb2tlbik7XG4gICAgICBpZiAocmVzcG9uc2VJc0Rvd24pIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICAgYEVSUk9SMzA5OSAtICR7cmVzcG9uc2UuYm9keS5tZXNzYWdlIHx8ICdXYXp1aCBub3QgcmVhZHkgeWV0J31gLFxuICAgICAgICAgIDMwOTksXG4gICAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxuICAgICAgICAgIHJlc3BvbnNlXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBsZXQgcmVzcG9uc2VCb2R5ID0gKHJlc3BvbnNlVG9rZW4gfHwge30pLmRhdGEgfHwge307XG4gICAgICBpZiAoIXJlc3BvbnNlQm9keSkge1xuICAgICAgICByZXNwb25zZUJvZHkgPVxuICAgICAgICAgIHR5cGVvZiByZXNwb25zZUJvZHkgPT09ICdzdHJpbmcnICYmIHBhdGguaW5jbHVkZXMoJy9maWxlcycpICYmIG1ldGhvZCA9PT0gJ0dFVCdcbiAgICAgICAgICAgID8gJyAnXG4gICAgICAgICAgICA6IGZhbHNlO1xuICAgICAgICByZXNwb25zZS5kYXRhID0gcmVzcG9uc2VCb2R5O1xuICAgICAgfVxuICAgICAgY29uc3QgcmVzcG9uc2VFcnJvciA9IHJlc3BvbnNlLnN0YXR1cyAhPT0gSFRUUF9TVEFUVVNfQ09ERVMuT0sgPyByZXNwb25zZS5zdGF0dXMgOiBmYWxzZTtcblxuICAgICAgaWYgKCFyZXNwb25zZUVycm9yICYmIHJlc3BvbnNlQm9keSkge1xuICAgICAgICAvL2NsZWFuS2V5cyhyZXNwb25zZSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogcmVzcG9uc2VUb2tlbi5kYXRhXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBpZiAocmVzcG9uc2VFcnJvciAmJiBkZXZUb29scykge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHJlc3BvbnNlLmRhdGFcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICB0aHJvdyByZXNwb25zZUVycm9yICYmIHJlc3BvbnNlQm9keS5kZXRhaWxcbiAgICAgICAgPyB7IG1lc3NhZ2U6IHJlc3BvbnNlQm9keS5kZXRhaWwsIGNvZGU6IHJlc3BvbnNlRXJyb3IgfVxuICAgICAgICA6IG5ldyBFcnJvcignVW5leHBlY3RlZCBlcnJvciBmZXRjaGluZyBkYXRhIGZyb20gdGhlIFdhenVoIEFQSScpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBpZiAoZXJyb3IgJiYgZXJyb3IucmVzcG9uc2UgJiYgZXJyb3IucmVzcG9uc2Uuc3RhdHVzID09PSBIVFRQX1NUQVRVU19DT0RFUy5VTkFVVEhPUklaRUQpIHtcbiAgICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgICAgZXJyb3IubWVzc2FnZSB8fCBlcnJvcixcbiAgICAgICAgICBlcnJvci5jb2RlID8gYFdhenVoIEFQSSBlcnJvcjogJHtlcnJvci5jb2RlfWAgOiAzMDEzLFxuICAgICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlVOQVVUSE9SSVpFRCxcbiAgICAgICAgICByZXNwb25zZVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgY29uc3QgZXJyb3JNc2cgPSAoZXJyb3IucmVzcG9uc2UgfHwge30pLmRhdGEgfHwgZXJyb3IubWVzc2FnZVxuICAgICAgbG9nKCd3YXp1aC1hcGk6bWFrZVJlcXVlc3QnLCBlcnJvck1zZyB8fCBlcnJvcik7XG4gICAgICBpZiAoZGV2VG9vbHMpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICBib2R5OiB7IGVycm9yOiAnMzAxMycsIG1lc3NhZ2U6IGVycm9yTXNnIHx8IGVycm9yIH1cbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoKGVycm9yIHx8IHt9KS5jb2RlICYmIEFwaUVycm9yRXF1aXZhbGVuY2VbZXJyb3IuY29kZV0pIHtcbiAgICAgICAgICBlcnJvci5tZXNzYWdlID0gQXBpRXJyb3JFcXVpdmFsZW5jZVtlcnJvci5jb2RlXTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgICBlcnJvck1zZy5kZXRhaWwgfHwgZXJyb3IsXG4gICAgICAgICAgZXJyb3IuY29kZSA/IGBXYXp1aCBBUEkgZXJyb3I6ICR7ZXJyb3IuY29kZX1gIDogMzAxMyxcbiAgICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1IsXG4gICAgICAgICAgcmVzcG9uc2VcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBtYWtlIGEgcmVxdWVzdCB0byBBUElcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IGFwaSByZXNwb25zZSBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICByZXF1ZXN0QXBpKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdCwgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSkge1xuXG4gICAgY29uc3QgaWRBcGkgPSBnZXRDb29raWVWYWx1ZUJ5TmFtZShyZXF1ZXN0LmhlYWRlcnMuY29va2llLCAnd3otYXBpJyk7XG4gICAgaWYgKGlkQXBpICE9PSByZXF1ZXN0LmJvZHkuaWQpIHsgLy8gaWYgdGhlIGN1cnJlbnQgdG9rZW4gYmVsb25ncyB0byBhIGRpZmZlcmVudCBBUEkgaWQsIHdlIHJlbG9naW4gdG8gb2J0YWluIGEgbmV3IHRva2VuXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgJ3N0YXR1cyBjb2RlIDQwMScsXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLlVOQVVUSE9SSVpFRCxcbiAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuVU5BVVRIT1JJWkVELFxuICAgICAgICByZXNwb25zZVxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKCFyZXF1ZXN0LmJvZHkubWV0aG9kKSB7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnTWlzc2luZyBwYXJhbTogbWV0aG9kJywgMzAxNSwgSFRUUF9TVEFUVVNfQ09ERVMuQkFEX1JFUVVFU1QsIHJlc3BvbnNlKTtcbiAgICB9IGVsc2UgaWYgKCFyZXF1ZXN0LmJvZHkubWV0aG9kLm1hdGNoKC9eKD86R0VUfFBVVHxQT1NUfERFTEVURSkkLykpIHtcbiAgICAgIGxvZygnd2F6dWgtYXBpOm1ha2VSZXF1ZXN0JywgJ1JlcXVlc3QgbWV0aG9kIGlzIG5vdCB2YWxpZC4nKTtcbiAgICAgIC8vTWV0aG9kIGlzIG5vdCBhIHZhbGlkIEhUVFAgcmVxdWVzdCBtZXRob2RcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKCdSZXF1ZXN0IG1ldGhvZCBpcyBub3QgdmFsaWQuJywgMzAxNSwgSFRUUF9TVEFUVVNfQ09ERVMuQkFEX1JFUVVFU1QsIHJlc3BvbnNlKTtcbiAgICB9IGVsc2UgaWYgKCFyZXF1ZXN0LmJvZHkucGF0aCkge1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoJ01pc3NpbmcgcGFyYW06IHBhdGgnLCAzMDE2LCBIVFRQX1NUQVRVU19DT0RFUy5CQURfUkVRVUVTVCwgcmVzcG9uc2UpO1xuICAgIH0gZWxzZSBpZiAoIXJlcXVlc3QuYm9keS5wYXRoLnN0YXJ0c1dpdGgoJy8nKSkge1xuICAgICAgbG9nKCd3YXp1aC1hcGk6bWFrZVJlcXVlc3QnLCAnUmVxdWVzdCBwYXRoIGlzIG5vdCB2YWxpZC4nKTtcbiAgICAgIC8vUGF0aCBkb2Vzbid0IHN0YXJ0IHdpdGggJy8nXG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZSgnUmVxdWVzdCBwYXRoIGlzIG5vdCB2YWxpZC4nLCAzMDE1LCBIVFRQX1NUQVRVU19DT0RFUy5CQURfUkVRVUVTVCwgcmVzcG9uc2UpO1xuICAgIH0gZWxzZSB7XG5cbiAgICAgIHJldHVybiB0aGlzLm1ha2VSZXF1ZXN0KFxuICAgICAgICBjb250ZXh0LFxuICAgICAgICByZXF1ZXN0LmJvZHkubWV0aG9kLFxuICAgICAgICByZXF1ZXN0LmJvZHkucGF0aCxcbiAgICAgICAgcmVxdWVzdC5ib2R5LmJvZHksXG4gICAgICAgIHJlcXVlc3QuYm9keS5pZCxcbiAgICAgICAgcmVzcG9uc2VcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldCBmdWxsIGRhdGEgb24gQ1NWIGZvcm1hdCBmcm9tIGEgbGlzdCBXYXp1aCBBUEkgZW5kcG9pbnRcbiAgICogQHBhcmFtIHtPYmplY3R9IGN0eFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gY3N2IG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGNzdihjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3QsIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnkpIHtcbiAgICB0cnkge1xuICAgICAgaWYgKCFyZXF1ZXN0LmJvZHkgfHwgIXJlcXVlc3QuYm9keS5wYXRoKSB0aHJvdyBuZXcgRXJyb3IoJ0ZpZWxkIHBhdGggaXMgcmVxdWlyZWQnKTtcbiAgICAgIGlmICghcmVxdWVzdC5ib2R5LmlkKSB0aHJvdyBuZXcgRXJyb3IoJ0ZpZWxkIGlkIGlzIHJlcXVpcmVkJyk7XG5cbiAgICAgIGNvbnN0IGZpbHRlcnMgPSBBcnJheS5pc0FycmF5KCgocmVxdWVzdCB8fCB7fSkuYm9keSB8fCB7fSkuZmlsdGVycykgPyByZXF1ZXN0LmJvZHkuZmlsdGVycyA6IFtdO1xuXG4gICAgICBsZXQgdG1wUGF0aCA9IHJlcXVlc3QuYm9keS5wYXRoO1xuXG4gICAgICBpZiAodG1wUGF0aCAmJiB0eXBlb2YgdG1wUGF0aCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgdG1wUGF0aCA9IHRtcFBhdGhbMF0gPT09ICcvJyA/IHRtcFBhdGguc3Vic3RyKDEpIDogdG1wUGF0aDtcbiAgICAgIH1cblxuICAgICAgaWYgKCF0bXBQYXRoKSB0aHJvdyBuZXcgRXJyb3IoJ0FuIGVycm9yIG9jY3VycmVkIHBhcnNpbmcgcGF0aCBmaWVsZCcpO1xuXG4gICAgICBsb2coJ3dhenVoLWFwaTpjc3YnLCBgUmVwb3J0ICR7dG1wUGF0aH1gLCAnZGVidWcnKTtcbiAgICAgIC8vIFJlYWwgbGltaXQsIHJlZ2FyZGxlc3MgdGhlIHVzZXIgcXVlcnlcbiAgICAgIGNvbnN0IHBhcmFtcyA9IHsgbGltaXQ6IDUwMCB9O1xuXG4gICAgICBpZiAoZmlsdGVycy5sZW5ndGgpIHtcbiAgICAgICAgZm9yIChjb25zdCBmaWx0ZXIgb2YgZmlsdGVycykge1xuICAgICAgICAgIGlmICghZmlsdGVyLm5hbWUgfHwgIWZpbHRlci52YWx1ZSkgY29udGludWU7XG4gICAgICAgICAgcGFyYW1zW2ZpbHRlci5uYW1lXSA9IGZpbHRlci52YWx1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBsZXQgaXRlbXNBcnJheSA9IFtdO1xuXG4gICAgICBjb25zdCBvdXRwdXQgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAnR0VUJyxcbiAgICAgICAgYC8ke3RtcFBhdGh9YCxcbiAgICAgICAgeyBwYXJhbXM6IHBhcmFtcyB9LFxuICAgICAgICB7IGFwaUhvc3RJRDogcmVxdWVzdC5ib2R5LmlkIH1cbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IGlzTGlzdCA9IHJlcXVlc3QuYm9keS5wYXRoLmluY2x1ZGVzKCcvbGlzdHMnKSAmJiByZXF1ZXN0LmJvZHkuZmlsdGVycyAmJiByZXF1ZXN0LmJvZHkuZmlsdGVycy5sZW5ndGggJiYgcmVxdWVzdC5ib2R5LmZpbHRlcnMuZmluZChmaWx0ZXIgPT4gZmlsdGVyLl9pc0NEQkxpc3QpO1xuXG4gICAgICBjb25zdCB0b3RhbEl0ZW1zID0gKCgob3V0cHV0IHx8IHt9KS5kYXRhIHx8IHt9KS5kYXRhIHx8IHt9KS50b3RhbF9hZmZlY3RlZF9pdGVtcztcblxuICAgICAgaWYgKHRvdGFsSXRlbXMgJiYgIWlzTGlzdCkge1xuICAgICAgICBwYXJhbXMub2Zmc2V0ID0gMDtcbiAgICAgICAgaXRlbXNBcnJheS5wdXNoKC4uLm91dHB1dC5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXMpO1xuICAgICAgICB3aGlsZSAoaXRlbXNBcnJheS5sZW5ndGggPCB0b3RhbEl0ZW1zICYmIHBhcmFtcy5vZmZzZXQgPCB0b3RhbEl0ZW1zKSB7XG4gICAgICAgICAgcGFyYW1zLm9mZnNldCArPSBwYXJhbXMubGltaXQ7XG4gICAgICAgICAgY29uc3QgdG1wRGF0YSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICAgIGAvJHt0bXBQYXRofWAsXG4gICAgICAgICAgICB7IHBhcmFtczogcGFyYW1zIH0sXG4gICAgICAgICAgICB7IGFwaUhvc3RJRDogcmVxdWVzdC5ib2R5LmlkIH1cbiAgICAgICAgICApO1xuICAgICAgICAgIGl0ZW1zQXJyYXkucHVzaCguLi50bXBEYXRhLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtcyk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgaWYgKHRvdGFsSXRlbXMpIHtcbiAgICAgICAgY29uc3QgeyBwYXRoLCBmaWx0ZXJzIH0gPSByZXF1ZXN0LmJvZHk7XG4gICAgICAgIGNvbnN0IGlzQXJyYXlPZkxpc3RzID1cbiAgICAgICAgICBwYXRoLmluY2x1ZGVzKCcvbGlzdHMnKSAmJiAhaXNMaXN0O1xuICAgICAgICBjb25zdCBpc0FnZW50cyA9IHBhdGguaW5jbHVkZXMoJy9hZ2VudHMnKSAmJiAhcGF0aC5pbmNsdWRlcygnZ3JvdXBzJyk7XG4gICAgICAgIGNvbnN0IGlzQWdlbnRzT2ZHcm91cCA9IHBhdGguc3RhcnRzV2l0aCgnL2FnZW50cy9ncm91cHMvJyk7XG4gICAgICAgIGNvbnN0IGlzRmlsZXMgPSBwYXRoLmVuZHNXaXRoKCcvZmlsZXMnKTtcbiAgICAgICAgbGV0IGZpZWxkcyA9IE9iamVjdC5rZXlzKG91dHB1dC5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0pO1xuXG4gICAgICAgIGlmIChpc0FnZW50cyB8fCBpc0FnZW50c09mR3JvdXApIHtcbiAgICAgICAgICBpZiAoaXNGaWxlcykge1xuICAgICAgICAgICAgZmllbGRzID0gWydmaWxlbmFtZScsICdoYXNoJ107XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGZpZWxkcyA9IFtcbiAgICAgICAgICAgICAgJ2lkJyxcbiAgICAgICAgICAgICAgJ3N0YXR1cycsXG4gICAgICAgICAgICAgICduYW1lJyxcbiAgICAgICAgICAgICAgJ2lwJyxcbiAgICAgICAgICAgICAgJ2dyb3VwJyxcbiAgICAgICAgICAgICAgJ21hbmFnZXInLFxuICAgICAgICAgICAgICAnbm9kZV9uYW1lJyxcbiAgICAgICAgICAgICAgJ2RhdGVBZGQnLFxuICAgICAgICAgICAgICAndmVyc2lvbicsXG4gICAgICAgICAgICAgICdsYXN0S2VlcEFsaXZlJyxcbiAgICAgICAgICAgICAgJ29zLmFyY2gnLFxuICAgICAgICAgICAgICAnb3MuYnVpbGQnLFxuICAgICAgICAgICAgICAnb3MuY29kZW5hbWUnLFxuICAgICAgICAgICAgICAnb3MubWFqb3InLFxuICAgICAgICAgICAgICAnb3MubWlub3InLFxuICAgICAgICAgICAgICAnb3MubmFtZScsXG4gICAgICAgICAgICAgICdvcy5wbGF0Zm9ybScsXG4gICAgICAgICAgICAgICdvcy51bmFtZScsXG4gICAgICAgICAgICAgICdvcy52ZXJzaW9uJyxcbiAgICAgICAgICAgIF07XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlzQXJyYXlPZkxpc3RzKSB7XG4gICAgICAgICAgY29uc3QgZmxhdExpc3RzID0gW107XG4gICAgICAgICAgZm9yIChjb25zdCBsaXN0IG9mIGl0ZW1zQXJyYXkpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgcmVsYXRpdmVfZGlybmFtZSwgaXRlbXMgfSA9IGxpc3Q7XG4gICAgICAgICAgICBmbGF0TGlzdHMucHVzaCguLi5pdGVtcy5tYXAoaXRlbSA9PiAoeyByZWxhdGl2ZV9kaXJuYW1lLCBrZXk6IGl0ZW0ua2V5LCB2YWx1ZTogaXRlbS52YWx1ZSB9KSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBmaWVsZHMgPSBbJ3JlbGF0aXZlX2Rpcm5hbWUnLCAna2V5JywgJ3ZhbHVlJ107XG4gICAgICAgICAgaXRlbXNBcnJheSA9IFsuLi5mbGF0TGlzdHNdO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGlzTGlzdCkge1xuICAgICAgICAgIGZpZWxkcyA9IFsna2V5JywgJ3ZhbHVlJ107XG4gICAgICAgICAgaXRlbXNBcnJheSA9IG91dHB1dC5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXNbMF0uaXRlbXM7XG4gICAgICAgIH1cbiAgICAgICAgZmllbGRzID0gZmllbGRzLm1hcChpdGVtID0+ICh7IHZhbHVlOiBpdGVtLCBkZWZhdWx0OiAnLScgfSkpO1xuXG4gICAgICAgIGNvbnN0IGpzb24yY3N2UGFyc2VyID0gbmV3IFBhcnNlcih7IGZpZWxkcyB9KTtcblxuICAgICAgICBsZXQgY3N2ID0ganNvbjJjc3ZQYXJzZXIucGFyc2UoaXRlbXNBcnJheSk7XG4gICAgICAgIGZvciAoY29uc3QgZmllbGQgb2YgZmllbGRzKSB7XG4gICAgICAgICAgY29uc3QgeyB2YWx1ZSB9ID0gZmllbGQ7XG4gICAgICAgICAgaWYgKGNzdi5pbmNsdWRlcyh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGNzdiA9IGNzdi5yZXBsYWNlKHZhbHVlLCBLZXlFcXVpdmFsZW5jZVt2YWx1ZV0gfHwgdmFsdWUpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ3RleHQvY3N2JyB9LFxuICAgICAgICAgIGJvZHk6IGNzdlxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAob3V0cHV0ICYmIG91dHB1dC5kYXRhICYmIG91dHB1dC5kYXRhLmRhdGEgJiYgIW91dHB1dC5kYXRhLmRhdGEudG90YWxfYWZmZWN0ZWRfaXRlbXMpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyByZXN1bHRzJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEFuIGVycm9yIG9jY3VycmVkIGZldGNoaW5nIGRhdGEgZnJvbSB0aGUgV2F6dWggQVBJJHtvdXRwdXQgJiYgb3V0cHV0LmRhdGEgJiYgb3V0cHV0LmRhdGEuZGV0YWlsID8gYDogJHtvdXRwdXQuYm9keS5kZXRhaWx9YCA6ICcnfWApO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coJ3dhenVoLWFwaTpjc3YnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDMwMzQsIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUiwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfVxuXG4gIC8vIEdldCBkZSBsaXN0IG9mIGF2YWlsYWJsZSByZXF1ZXN0cyBpbiB0aGUgQVBJXG4gIGdldFJlcXVlc3RMaXN0KGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdCwgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSkge1xuICAgIC8vUmVhZCBhIHN0YXRpYyBKU09OIHVudGlsIHRoZSBhcGkgY2FsbCBoYXMgaW1wbGVtZW50ZWRcbiAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgYm9keTogYXBpUmVxdWVzdExpc3RcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIGdldCB0aGUgdGltZXN0YW1wIGZpZWxkXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7T2JqZWN0fSB0aW1lc3RhbXAgZmllbGQgb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgZ2V0VGltZVN0YW1wKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdCwgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzb3VyY2UgPSBKU09OLnBhcnNlKGZzLnJlYWRGaWxlU3luYyh0aGlzLnVwZGF0ZVJlZ2lzdHJ5LmZpbGUsICd1dGY4JykpO1xuICAgICAgaWYgKHNvdXJjZS5pbnN0YWxsYXRpb25EYXRlICYmIHNvdXJjZS5sYXN0UmVzdGFydCkge1xuICAgICAgICBsb2coXG4gICAgICAgICAgJ3dhenVoLWFwaTpnZXRUaW1lU3RhbXAnLFxuICAgICAgICAgIGBJbnN0YWxsYXRpb24gZGF0ZTogJHtzb3VyY2UuaW5zdGFsbGF0aW9uRGF0ZX0uIExhc3QgcmVzdGFydDogJHtzb3VyY2UubGFzdFJlc3RhcnR9YCxcbiAgICAgICAgICAnZGVidWcnXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgaW5zdGFsbGF0aW9uRGF0ZTogc291cmNlLmluc3RhbGxhdGlvbkRhdGUsXG4gICAgICAgICAgICBsYXN0UmVzdGFydDogc291cmNlLmxhc3RSZXN0YXJ0LFxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0NvdWxkIG5vdCBmZXRjaCB3YXp1aC12ZXJzaW9uIHJlZ2lzdHJ5Jyk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygnd2F6dWgtYXBpOmdldFRpbWVTdGFtcCcsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoXG4gICAgICAgIGVycm9yLm1lc3NhZ2UgfHwgJ0NvdWxkIG5vdCBmZXRjaCB3YXp1aC12ZXJzaW9uIHJlZ2lzdHJ5JyxcbiAgICAgICAgNDAwMSxcbiAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxuICAgICAgICByZXNwb25zZVxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBnZXQgdGhlIGV4dGVuc2lvbnNcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IGV4dGVuc2lvbnMgb2JqZWN0IG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIHNldEV4dGVuc2lvbnMoY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBLaWJhbmFSZXF1ZXN0LCByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5KSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgaWQsIGV4dGVuc2lvbnMgfSA9IHJlcXVlc3QuYm9keTtcbiAgICAgIC8vIFVwZGF0ZSBjbHVzdGVyIGluZm9ybWF0aW9uIGluIHRoZSB3YXp1aC1yZWdpc3RyeS5qc29uXG4gICAgICBhd2FpdCB0aGlzLnVwZGF0ZVJlZ2lzdHJ5LnVwZGF0ZUFQSUV4dGVuc2lvbnMoaWQsIGV4dGVuc2lvbnMpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHN0YXR1c0NvZGU6IEhUVFBfU1RBVFVTX0NPREVTLk9LXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coJ3dhenVoLWFwaTpzZXRFeHRlbnNpb25zJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgZXJyb3IubWVzc2FnZSB8fCAnQ291bGQgbm90IHNldCBleHRlbnNpb25zJyxcbiAgICAgICAgNDAwMSxcbiAgICAgICAgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLFxuICAgICAgICByZXNwb25zZVxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBnZXQgdGhlIGV4dGVuc2lvbnNcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IGV4dGVuc2lvbnMgb2JqZWN0IG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGdldEV4dGVuc2lvbnMoY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBLaWJhbmFSZXF1ZXN0LCByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5KSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNvdXJjZSA9IEpTT04ucGFyc2UoXG4gICAgICAgIGZzLnJlYWRGaWxlU3luYyh0aGlzLnVwZGF0ZVJlZ2lzdHJ5LmZpbGUsICd1dGY4JylcbiAgICAgICk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgZXh0ZW5zaW9uczogKHNvdXJjZS5ob3N0c1tyZXF1ZXN0LnBhcmFtcy5pZF0gfHwge30pLmV4dGVuc2lvbnMgfHwge31cbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygnd2F6dWgtYXBpOmdldEV4dGVuc2lvbnMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKFxuICAgICAgICBlcnJvci5tZXNzYWdlIHx8ICdDb3VsZCBub3QgZmV0Y2ggd2F6dWgtdmVyc2lvbiByZWdpc3RyeScsXG4gICAgICAgIDQwMDEsXG4gICAgICAgIEhUVFBfU1RBVFVTX0NPREVTLklOVEVSTkFMX1NFUlZFUl9FUlJPUixcbiAgICAgICAgcmVzcG9uc2VcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgZ2V0IHRoZSB3YXp1aCBzZXR1cCBzZXR0aW5nc1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gc2V0dXAgaW5mbyBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBhc3luYyBnZXRTZXR1cEluZm8oY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LCByZXF1ZXN0OiBLaWJhbmFSZXF1ZXN0LCByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5KSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNvdXJjZSA9IEpTT04ucGFyc2UoZnMucmVhZEZpbGVTeW5jKHRoaXMudXBkYXRlUmVnaXN0cnkuZmlsZSwgJ3V0ZjgnKSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgc3RhdHVzQ29kZTogSFRUUF9TVEFUVVNfQ09ERVMuT0ssXG4gICAgICAgICAgZGF0YTogIU9iamVjdC52YWx1ZXMoc291cmNlKS5sZW5ndGggPyAnJyA6IHNvdXJjZVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCd3YXp1aC1hcGk6Z2V0U2V0dXBJbmZvJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShcbiAgICAgICAgYENvdWxkIG5vdCBnZXQgZGF0YSBmcm9tIHdhenVoLXZlcnNpb24gcmVnaXN0cnkgZHVlIHRvICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gLFxuICAgICAgICA0MDA1LFxuICAgICAgICBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1IsXG4gICAgICAgIHJlc3BvbnNlXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgYmFzaWMgc3lzY29sbGVjdG9yIGluZm9ybWF0aW9uIGZvciBnaXZlbiBhZ2VudC5cbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHtPYmplY3R9IEJhc2ljIHN5c2NvbGxlY3RvciBpbmZvcm1hdGlvblxuICAgKi9cbiAgYXN5bmMgZ2V0U3lzY29sbGVjdG9yKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdCwgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBhcGlIb3N0SUQgPSBnZXRDb29raWVWYWx1ZUJ5TmFtZShyZXF1ZXN0LmhlYWRlcnMuY29va2llLCd3ei1hcGknKTtcbiAgICAgIGlmICghcmVxdWVzdC5wYXJhbXMgfHwgIWFwaUhvc3RJRCB8fCAhcmVxdWVzdC5wYXJhbXMuYWdlbnQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdBZ2VudCBJRCBhbmQgQVBJIElEIGFyZSByZXF1aXJlZCcpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCB7IGFnZW50IH0gPSByZXF1ZXN0LnBhcmFtcztcblxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoJ0dFVCcsIGAvc3lzY29sbGVjdG9yLyR7YWdlbnR9L2hhcmR3YXJlYCwge30sIHsgYXBpSG9zdElEIH0pLFxuICAgICAgICBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdCgnR0VUJywgYC9zeXNjb2xsZWN0b3IvJHthZ2VudH0vb3NgLCB7fSwgeyBhcGlIb3N0SUQgfSlcbiAgICAgIF0pO1xuXG4gICAgICBjb25zdCByZXN1bHQgPSBkYXRhLm1hcChpdGVtID0+IChpdGVtLmRhdGEgfHwge30pLmRhdGEgfHwgW10pO1xuICAgICAgY29uc3QgW2hhcmR3YXJlUmVzcG9uc2UsIG9zUmVzcG9uc2VdID0gcmVzdWx0O1xuXG4gICAgICAvLyBGaWxsIHN5c2NvbGxlY3RvciBvYmplY3RcbiAgICAgIGNvbnN0IHN5c2NvbGxlY3RvciA9IHtcbiAgICAgICAgaGFyZHdhcmU6XG4gICAgICAgICAgdHlwZW9mIGhhcmR3YXJlUmVzcG9uc2UgPT09ICdvYmplY3QnICYmIE9iamVjdC5rZXlzKGhhcmR3YXJlUmVzcG9uc2UpLmxlbmd0aFxuICAgICAgICAgICAgPyB7IC4uLmhhcmR3YXJlUmVzcG9uc2UuYWZmZWN0ZWRfaXRlbXNbMF0gfVxuICAgICAgICAgICAgOiBmYWxzZSxcbiAgICAgICAgb3M6XG4gICAgICAgICAgdHlwZW9mIG9zUmVzcG9uc2UgPT09ICdvYmplY3QnICYmIE9iamVjdC5rZXlzKG9zUmVzcG9uc2UpLmxlbmd0aFxuICAgICAgICAgICAgPyB7IC4uLm9zUmVzcG9uc2UuYWZmZWN0ZWRfaXRlbXNbMF0gfVxuICAgICAgICAgICAgOiBmYWxzZSxcbiAgICAgIH07XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHN5c2NvbGxlY3RvclxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygnd2F6dWgtYXBpOmdldFN5c2NvbGxlY3RvcicsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgMzAzNSwgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBDaGVjayBpZiB1c2VyIGFzc2lnbmVkIHJvbGVzIGRpc2FibGUgV2F6dWggUGx1Z2luXG4gICAqIEBwYXJhbSBjb250ZXh0XG4gICAqIEBwYXJhbSByZXF1ZXN0XG4gICAqIEBwYXJhbSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7b2JqZWN0fSBSZXR1cm5zIHsgaXNXYXp1aERpc2FibGVkOiBib29sZWFuIHBhcnNlZCBpbnRlZ2VyIH1cbiAgICovXG4gIGFzeW5jIGlzV2F6dWhEaXNhYmxlZChjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3QsIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnkpIHtcbiAgICB0cnkge1xuXG4gICAgICBjb25zdCBkaXNhYmxlZFJvbGVzID0gKCBhd2FpdCBnZXRDb25maWd1cmF0aW9uKCkgKVsnZGlzYWJsZWRfcm9sZXMnXSB8fCBbXTtcbiAgICAgIGNvbnN0IGxvZ29TaWRlYmFyID0gKCBhd2FpdCBnZXRDb25maWd1cmF0aW9uKCkgKVsnY3VzdG9taXphdGlvbi5sb2dvLnNpZGViYXInXTtcbiAgICAgIGNvbnN0IGRhdGEgPSAoYXdhaXQgY29udGV4dC53YXp1aC5zZWN1cml0eS5nZXRDdXJyZW50VXNlcihyZXF1ZXN0LCBjb250ZXh0KSkuYXV0aENvbnRleHQ7XG5cbiAgICAgIGNvbnN0IGlzV2F6dWhEaXNhYmxlZCA9ICsoZGF0YS5yb2xlcyB8fCBbXSkuc29tZSgocm9sZSkgPT4gZGlzYWJsZWRSb2xlcy5pbmNsdWRlcyhyb2xlKSk7XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHsgaXNXYXp1aERpc2FibGVkLCBsb2dvU2lkZWJhciB9XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCd3YXp1aC1hcGk6aXNXYXp1aERpc2FibGVkJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAzMDM1LCBIVFRQX1NUQVRVU19DT0RFUy5JTlRFUk5BTF9TRVJWRVJfRVJST1IsIHJlc3BvbnNlKTtcbiAgICB9XG5cbiAgfVxuXG4gIC8qKlxuICAgKiBHZXRzIGN1c3RvbSBsb2dvcyBjb25maWd1cmF0aW9uIChwYXRoKVxuICAgKiBAcGFyYW0gY29udGV4dFxuICAgKiBAcGFyYW0gcmVxdWVzdFxuICAgKiBAcGFyYW0gcmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGdldEFwcExvZ29zKGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCwgcmVxdWVzdDogS2liYW5hUmVxdWVzdCwgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjb25maWd1cmF0aW9uID0gZ2V0Q29uZmlndXJhdGlvbigpO1xuICAgICAgY29uc3QgU0lERUJBUl9MT0dPID0gJ2N1c3RvbWl6YXRpb24ubG9nby5zaWRlYmFyJztcbiAgICAgIGNvbnN0IEFQUF9MT0dPID0gJ2N1c3RvbWl6YXRpb24ubG9nby5hcHAnO1xuICAgICAgY29uc3QgSEVBTFRIQ0hFQ0tfTE9HTyA9ICdjdXN0b21pemF0aW9uLmxvZ28uaGVhbHRoY2hlY2snO1xuXG4gICAgICBjb25zdCBsb2dvcz0ge1xuICAgICAgICBbU0lERUJBUl9MT0dPXTogZ2V0Q3VzdG9taXphdGlvblNldHRpbmcoY29uZmlndXJhdGlvbiwgU0lERUJBUl9MT0dPKSxcbiAgICAgICAgW0FQUF9MT0dPXTogZ2V0Q3VzdG9taXphdGlvblNldHRpbmcoY29uZmlndXJhdGlvbiwgQVBQX0xPR08pLFxuICAgICAgICBbSEVBTFRIQ0hFQ0tfTE9HT106IGdldEN1c3RvbWl6YXRpb25TZXR0aW5nKGNvbmZpZ3VyYXRpb24sIEhFQUxUSENIRUNLX0xPR08pLFxuICAgICAgfVxuXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7IGxvZ29zIH1cbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coJ3dhenVoLWFwaTpnZXRBcHBMb2dvcycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgMzAzNSwgSFRUUF9TVEFUVVNfQ09ERVMuSU5URVJOQUxfU0VSVkVSX0VSUk9SLCByZXNwb25zZSk7XG4gICAgfVxuXG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFhQSxJQUFBQSxjQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxTQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxrQkFBQSxHQUFBSCxPQUFBO0FBQ0EsSUFBQUkscUJBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFVBQUEsR0FBQUMsc0JBQUEsQ0FBQU4sT0FBQTtBQUNBLElBQUFPLFVBQUEsR0FBQVAsT0FBQTtBQUNBLElBQUFRLFNBQUEsR0FBQVIsT0FBQTtBQUNBLElBQUFTLE1BQUEsR0FBQVQsT0FBQTtBQUNBLElBQUFVLEdBQUEsR0FBQUosc0JBQUEsQ0FBQU4sT0FBQTtBQUNBLElBQUFXLFlBQUEsR0FBQVgsT0FBQTtBQUNBLElBQUFZLGVBQUEsR0FBQVosT0FBQTtBQUNBLElBQUFhLFVBQUEsR0FBQVAsc0JBQUEsQ0FBQU4sT0FBQTtBQUVBLElBQUFjLHFCQUFBLEdBQUFkLE9BQUE7QUFDQSxJQUFBZSxPQUFBLEdBQUFmLE9BQUE7QUFFQSxJQUFBZ0IsaUJBQUEsR0FBQWhCLE9BQUE7QUE5QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFvQk8sTUFBTWlCLFlBQVksQ0FBQztFQUl4QkMsV0FBV0EsQ0FBQSxFQUFHO0lBQUEsSUFBQUMsZ0JBQUEsQ0FBQUMsT0FBQTtJQUFBLElBQUFELGdCQUFBLENBQUFDLE9BQUE7SUFDWixJQUFJLENBQUNDLFdBQVcsR0FBRyxJQUFJQyx3QkFBVyxFQUFFO0lBQ3BDLElBQUksQ0FBQ0MsY0FBYyxHQUFHLElBQUlDLDhCQUFjLEVBQUU7RUFDNUM7RUFFQSxNQUFNQyxRQUFRQSxDQUFDQyxPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBQ3RHLElBQUk7TUFDRixNQUFNO1FBQUVDLEtBQUs7UUFBRUM7TUFBTyxDQUFDLEdBQUdILE9BQU8sQ0FBQ0ksSUFBSTtNQUN0QyxNQUFNO1FBQUVDO01BQVMsQ0FBQyxHQUFHLE1BQU1OLE9BQU8sQ0FBQ08sS0FBSyxDQUFDQyxRQUFRLENBQUNDLGNBQWMsQ0FBQ1IsT0FBTyxFQUFFRCxPQUFPLENBQUM7TUFDbEYsSUFBSSxDQUFDRyxLQUFLLElBQUlGLE9BQU8sQ0FBQ1MsT0FBTyxDQUFDQyxNQUFNLElBQUlMLFFBQVEsS0FBSyxJQUFBTSw0QkFBb0IsRUFBQ1gsT0FBTyxDQUFDUyxPQUFPLENBQUNDLE1BQU0sRUFBRSxTQUFTLENBQUMsSUFBSVAsTUFBTSxLQUFLLElBQUFRLDRCQUFvQixFQUFDWCxPQUFPLENBQUNTLE9BQU8sQ0FBQ0MsTUFBTSxFQUFDLFFBQVEsQ0FBQyxFQUFFO1FBQ2hMLE1BQU1FLE9BQU8sR0FBRyxJQUFBRCw0QkFBb0IsRUFBQ1gsT0FBTyxDQUFDUyxPQUFPLENBQUNDLE1BQU0sRUFBRSxVQUFVLENBQUM7UUFDeEUsSUFBSUUsT0FBTyxFQUFFO1VBQ1gsSUFBSTtZQUFFO1lBQ0osTUFBTUMsWUFBWSxHQUFHLElBQUFDLGtCQUFTLEVBQUNGLE9BQU8sQ0FBQztZQUN2QyxNQUFNRyxjQUFjLEdBQUlGLFlBQVksQ0FBQ0csR0FBRyxHQUFJQyxJQUFJLENBQUNDLEdBQUcsRUFBRSxHQUFHLElBQU07WUFDL0QsSUFBSU4sT0FBTyxJQUFJRyxjQUFjLEdBQUcsQ0FBQyxFQUFFO2NBQ2pDLE9BQU9kLFFBQVEsQ0FBQ2tCLEVBQUUsQ0FBQztnQkFDakJmLElBQUksRUFBRTtrQkFBRWdCLEtBQUssRUFBRVI7Z0JBQVE7Y0FDekIsQ0FBQyxDQUFDO1lBQ0o7VUFDRixDQUFDLENBQUMsT0FBT1MsS0FBSyxFQUFFO1lBQ2QsSUFBQUMsV0FBRyxFQUFDLG9CQUFvQixFQUFFRCxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO1VBQ25EO1FBQ0Y7TUFDRjtNQUNBLElBQUlELEtBQUs7TUFDVCxJQUFJLE9BQU1JLHVDQUFpQixDQUFDQyxNQUFNLENBQUN0QixNQUFNLENBQUMsS0FBSXVCLDRDQUFzQixDQUFDQyxPQUFPLEVBQUU7UUFDNUVQLEtBQUssR0FBRyxNQUFNckIsT0FBTyxDQUFDTyxLQUFLLENBQUNzQixHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDQyxZQUFZLENBQUM1QixNQUFNLENBQUM7TUFDM0UsQ0FBQyxNQUFNO1FBQ0xpQixLQUFLLEdBQUcsTUFBTXJCLE9BQU8sQ0FBQ08sS0FBSyxDQUFDc0IsR0FBRyxDQUFDQyxNQUFNLENBQUNHLGNBQWMsQ0FBQ0QsWUFBWSxDQUFDNUIsTUFBTSxDQUFDO01BQzVFO01BQUM7TUFFRCxJQUFJOEIsVUFBVSxHQUFDLEVBQUU7TUFDakIsSUFBR2xDLE9BQU8sQ0FBQ08sS0FBSyxDQUFDNEIsTUFBTSxDQUFDQyxJQUFJLENBQUNDLFFBQVEsS0FBSyxPQUFPLEVBQUM7UUFDaERILFVBQVUsR0FBRyxTQUFTO01BQ3hCO01BRUEsT0FBT2hDLFFBQVEsQ0FBQ2tCLEVBQUUsQ0FBQztRQUNqQlYsT0FBTyxFQUFFO1VBQ1AsWUFBWSxFQUFFLENBQ1gsWUFBV1csS0FBTSxtQkFBa0JhLFVBQVcsRUFBQyxFQUMvQyxXQUFVNUIsUUFBUyxtQkFBa0I0QixVQUFXLEVBQUMsRUFDakQsVUFBUzlCLE1BQU8sa0JBQWlCO1FBRXRDLENBQUM7UUFDREMsSUFBSSxFQUFFO1VBQUVnQjtRQUFNO01BQ2hCLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPQyxLQUFLLEVBQUU7TUFBQSxJQUFBZ0IsZUFBQTtNQUNkLE1BQU1DLFlBQVksR0FBRyxDQUFDLENBQUNqQixLQUFLLENBQUNwQixRQUFRLElBQUksQ0FBQyxDQUFDLEVBQUVzQyxJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUVDLE1BQU0sSUFBSW5CLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLO01BQ3pGLElBQUFDLFdBQUcsRUFBQyxvQkFBb0IsRUFBRWdCLFlBQVksQ0FBQztNQUN2QyxPQUFPLElBQUFHLDRCQUFhLEVBQ2pCLDBDQUF5Q0gsWUFBYSxFQUFDLEVBQ3hELElBQUksRUFDSixDQUFBakIsS0FBSyxhQUFMQSxLQUFLLHdCQUFBZ0IsZUFBQSxHQUFMaEIsS0FBSyxDQUFFcEIsUUFBUSxjQUFBb0MsZUFBQSx1QkFBZkEsZUFBQSxDQUFpQkssTUFBTSxLQUFJQyw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ2xFM0MsUUFBUSxDQUNUO0lBQ0g7RUFDRjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU00QyxjQUFjQSxDQUFDOUMsT0FBOEIsRUFBRUMsT0FBc0IsRUFBRUMsUUFBK0IsRUFBRTtJQUM1RyxJQUFJO01BQ0Y7TUFDQSxNQUFNNkMsRUFBRSxHQUFHOUMsT0FBTyxDQUFDSSxJQUFJLENBQUMwQyxFQUFFO01BQzFCLE1BQU1sQixHQUFHLEdBQUcsTUFBTSxJQUFJLENBQUNsQyxXQUFXLENBQUNxRCxXQUFXLENBQUNELEVBQUUsQ0FBQztNQUNsRDtNQUNBLElBQUksQ0FBQ0UsTUFBTSxDQUFDQyxJQUFJLENBQUNyQixHQUFHLENBQUMsQ0FBQ3NCLE1BQU0sRUFBRTtRQUM1QixNQUFNLElBQUlDLEtBQUssQ0FBQyw2Q0FBNkMsQ0FBQztNQUNoRTtNQUVBLElBQUE3QixXQUFHLEVBQUMsMEJBQTBCLEVBQUcsR0FBRXdCLEVBQUcsU0FBUSxFQUFFLE9BQU8sQ0FBQzs7TUFFeEQ7TUFDQSxNQUFNTSxtQkFBbUIsR0FBRyxNQUFNckQsT0FBTyxDQUFDTyxLQUFLLENBQUNzQixHQUFHLENBQUNDLE1BQU0sQ0FBQ0csY0FBYyxDQUFDaEMsT0FBTyxDQUMvRSxLQUFLLEVBQ0osZUFBYyxFQUNmLENBQUMsQ0FBQyxFQUNGO1FBQUVxRCxTQUFTLEVBQUVQLEVBQUU7UUFBRVEsWUFBWSxFQUFFO01BQUssQ0FBQyxDQUN0Qzs7TUFFRDtNQUNBLElBQUksSUFBSSxDQUFDQyxtQkFBbUIsQ0FBQ0gsbUJBQW1CLENBQUMsRUFBRTtRQUNqRCxPQUFPLElBQUFYLDRCQUFhLEVBQ2pCLGVBQWNXLG1CQUFtQixDQUFDYixJQUFJLENBQUNDLE1BQU0sSUFBSSxxQkFBc0IsRUFBQyxFQUN6RSxJQUFJLEVBQ0pHLDRCQUFpQixDQUFDYSxtQkFBbUIsRUFDckN2RCxRQUFRLENBQ1Q7TUFDSDs7TUFFQTtNQUNBLElBQUltRCxtQkFBbUIsQ0FBQ1YsTUFBTSxLQUFLQyw0QkFBaUIsQ0FBQ2MsRUFBRSxJQUFJTCxtQkFBbUIsQ0FBQ2IsSUFBSSxFQUFFO1FBQ25GO1FBQ0EsT0FBT1gsR0FBRyxDQUFDOEIsWUFBWTtRQUN2QixNQUFNQyxjQUFjLEdBQUcsTUFBTTVELE9BQU8sQ0FBQ08sS0FBSyxDQUFDc0IsR0FBRyxDQUFDQyxNQUFNLENBQUNHLGNBQWMsQ0FBQ2hDLE9BQU8sQ0FDMUUsS0FBSyxFQUNKLFNBQVEsRUFDVDtVQUFFNEQsTUFBTSxFQUFFO1lBQUVDLFdBQVcsRUFBRTtVQUFNO1FBQUUsQ0FBQyxFQUNsQztVQUFFUixTQUFTLEVBQUVQO1FBQUcsQ0FBQyxDQUNsQjtRQUVELElBQUlhLGNBQWMsQ0FBQ2pCLE1BQU0sS0FBS0MsNEJBQWlCLENBQUNjLEVBQUUsRUFBRTtVQUNsRCxNQUFNSyxXQUFXLEdBQUdILGNBQWMsQ0FBQ3BCLElBQUksQ0FBQ0EsSUFBSSxDQUFDd0IsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxPQUFPO1VBRXRFLE1BQU1DLHFCQUFxQixHQUFHLE1BQU1sRSxPQUFPLENBQUNPLEtBQUssQ0FBQ3NCLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDRyxjQUFjLENBQUNoQyxPQUFPLENBQ2pGLEtBQUssRUFDSixpQkFBZ0IsRUFDakIsQ0FBQyxDQUFDLEVBQ0Y7WUFBRXFELFNBQVMsRUFBRVA7VUFBRyxDQUFDLENBQ2xCO1VBQ0QsSUFBSW1CLHFCQUFxQixDQUFDdkIsTUFBTSxLQUFLQyw0QkFBaUIsQ0FBQ2MsRUFBRSxFQUFFO1lBQ3pELElBQUlRLHFCQUFxQixDQUFDMUIsSUFBSSxDQUFDQSxJQUFJLENBQUMyQixPQUFPLEtBQUssS0FBSyxFQUFFO2NBQ3JELE1BQU1DLHdCQUF3QixHQUFHLE1BQU1wRSxPQUFPLENBQUNPLEtBQUssQ0FBQ3NCLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDRyxjQUFjLENBQUNoQyxPQUFPLENBQ3BGLEtBQUssRUFDSixxQkFBb0IsRUFDckIsQ0FBQyxDQUFDLEVBQ0Y7Z0JBQUVxRCxTQUFTLEVBQUVQO2NBQUcsQ0FBQyxDQUNsQjtjQUNELElBQUlxQix3QkFBd0IsQ0FBQ3pCLE1BQU0sS0FBS0MsNEJBQWlCLENBQUNjLEVBQUUsRUFBRTtnQkFDNUQsTUFBTVcsY0FBYyxHQUFHSCxxQkFBcUIsQ0FBQzFCLElBQUksQ0FBQ0EsSUFBSSxDQUFDMkIsT0FBTyxLQUFLLEtBQUs7Z0JBQ3hFdEMsR0FBRyxDQUFDOEIsWUFBWSxHQUFHO2tCQUNqQmhCLE1BQU0sRUFBRTBCLGNBQWMsR0FBRyxTQUFTLEdBQUcsVUFBVTtrQkFDL0NKLE9BQU8sRUFBRUYsV0FBVztrQkFDcEJPLElBQUksRUFBRUYsd0JBQXdCLENBQUM1QixJQUFJLENBQUNBLElBQUksQ0FBQ3dCLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQ00sSUFBSTtrQkFDL0RDLE9BQU8sRUFBRUYsY0FBYyxHQUNuQkQsd0JBQXdCLENBQUM1QixJQUFJLENBQUNBLElBQUksQ0FBQ3dCLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQ08sT0FBTyxHQUM1RDtnQkFDTixDQUFDO2NBQ0g7WUFDRixDQUFDLE1BQU07Y0FDTDtjQUNBMUMsR0FBRyxDQUFDOEIsWUFBWSxHQUFHO2dCQUNqQmhCLE1BQU0sRUFBRSxVQUFVO2dCQUNsQnNCLE9BQU8sRUFBRUYsV0FBVztnQkFDcEJRLE9BQU8sRUFBRTtjQUNYLENBQUM7WUFDSDtVQUNGLENBQUMsTUFBTTtZQUNMO1lBQ0ExQyxHQUFHLENBQUM4QixZQUFZLEdBQUc7Y0FDakJoQixNQUFNLEVBQUUsVUFBVTtjQUNsQnNCLE9BQU8sRUFBRUYsV0FBVztjQUNwQlEsT0FBTyxFQUFFO1lBQ1gsQ0FBQztVQUNIO1VBRUEsSUFBSTFDLEdBQUcsQ0FBQzhCLFlBQVksRUFBRTtZQUNwQjtZQUNBLE1BQU0sSUFBSSxDQUFDOUQsY0FBYyxDQUFDMkUsaUJBQWlCLENBQUN6QixFQUFFLEVBQUVsQixHQUFHLENBQUM4QixZQUFZLENBQUM7O1lBRWpFO1lBQ0EsTUFBTWMsTUFBTSxHQUFHO2NBQUUsR0FBRzVDO1lBQUksQ0FBQztZQUN6QjRDLE1BQU0sQ0FBQ0MsTUFBTSxHQUFHLE1BQU07WUFDdEJELE1BQU0sQ0FBQ0UsUUFBUSxHQUFHLE1BQU07WUFFeEIsT0FBT3pFLFFBQVEsQ0FBQ2tCLEVBQUUsQ0FBQztjQUNqQmYsSUFBSSxFQUFFO2dCQUNKdUUsVUFBVSxFQUFFaEMsNEJBQWlCLENBQUNjLEVBQUU7Z0JBQ2hDbEIsSUFBSSxFQUFFaUMsTUFBTTtnQkFDWkksU0FBUyxFQUFFNUUsT0FBTyxDQUFDSSxJQUFJLENBQUN3RSxTQUFTLElBQUk7Y0FDdkM7WUFDRixDQUFDLENBQUM7VUFDSjtRQUNGO01BQ0Y7O01BRUE7TUFDQSxNQUFNLElBQUl6QixLQUFLLENBQUNDLG1CQUFtQixDQUFDYixJQUFJLENBQUNDLE1BQU0sSUFBSyxHQUFFWixHQUFHLENBQUNpRCxHQUFJLElBQUdqRCxHQUFHLENBQUNrRCxJQUFLLGlCQUFnQixDQUFDO0lBQzdGLENBQUMsQ0FBQyxPQUFPekQsS0FBSyxFQUFFO01BQ2QsSUFBSUEsS0FBSyxDQUFDMEQsSUFBSSxLQUFLLFFBQVEsRUFBRTtRQUMzQixPQUFPOUUsUUFBUSxDQUFDa0IsRUFBRSxDQUFDO1VBQ2pCZixJQUFJLEVBQUU7WUFDSnVFLFVBQVUsRUFBRWhDLDRCQUFpQixDQUFDYyxFQUFFO1lBQ2hDbEIsSUFBSSxFQUFFO2NBQUV5QyxTQUFTLEVBQUU7WUFBSztVQUMxQjtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsTUFBTSxJQUFJM0QsS0FBSyxDQUFDMEQsSUFBSSxLQUFLLGNBQWMsRUFBRTtRQUN4QyxPQUFPOUUsUUFBUSxDQUFDa0IsRUFBRSxDQUFDO1VBQ2pCZixJQUFJLEVBQUU7WUFDSnVFLFVBQVUsRUFBRWhDLDRCQUFpQixDQUFDYyxFQUFFO1lBQ2hDbEIsSUFBSSxFQUFFO2NBQUV5QyxTQUFTLEVBQUU7WUFBSztVQUMxQjtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsTUFBTTtRQUFBLElBQUFDLGdCQUFBO1FBQ0wsSUFBSTtVQUNGLE1BQU1DLElBQUksR0FBRyxNQUFNLElBQUksQ0FBQ3hGLFdBQVcsQ0FBQ3lGLFFBQVEsRUFBRTtVQUM5QyxLQUFLLE1BQU12RCxHQUFHLElBQUlzRCxJQUFJLEVBQUU7WUFDdEIsSUFBSTtjQUNGLE1BQU1wQyxFQUFFLEdBQUdFLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDckIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBRTlCLE1BQU13QixtQkFBbUIsR0FBRyxNQUFNckQsT0FBTyxDQUFDTyxLQUFLLENBQUNzQixHQUFHLENBQUNDLE1BQU0sQ0FBQ0csY0FBYyxDQUFDaEMsT0FBTyxDQUMvRSxLQUFLLEVBQ0osZUFBYyxFQUNmLENBQUMsQ0FBQyxFQUNGO2dCQUFFcUQsU0FBUyxFQUFFUDtjQUFHLENBQUMsQ0FDbEI7Y0FFRCxJQUFJLElBQUksQ0FBQ1MsbUJBQW1CLENBQUNILG1CQUFtQixDQUFDLEVBQUU7Z0JBQ2pELE9BQU8sSUFBQVgsNEJBQWEsRUFDakIsZUFBY3hDLFFBQVEsQ0FBQ3NDLElBQUksQ0FBQ0MsTUFBTSxJQUFJLHFCQUFzQixFQUFDLEVBQzlELElBQUksRUFDSkcsNEJBQWlCLENBQUNhLG1CQUFtQixFQUNyQ3ZELFFBQVEsQ0FDVDtjQUNIO2NBQ0EsSUFBSW1ELG1CQUFtQixDQUFDVixNQUFNLEtBQUtDLDRCQUFpQixDQUFDYyxFQUFFLEVBQUU7Z0JBQ3ZEekQsT0FBTyxDQUFDSSxJQUFJLENBQUMwQyxFQUFFLEdBQUdBLEVBQUU7Z0JBQ3BCOUMsT0FBTyxDQUFDSSxJQUFJLENBQUN3RSxTQUFTLEdBQUc5QixFQUFFO2dCQUMzQixPQUFPLE1BQU0sSUFBSSxDQUFDRCxjQUFjLENBQUM5QyxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxDQUFDO2NBQzlEO1lBQ0YsQ0FBQyxDQUFDLE9BQU9vQixLQUFLLEVBQUUsQ0FBRSxDQUFDLENBQUM7VUFDdEI7UUFDRixDQUFDLENBQUMsT0FBT0EsS0FBSyxFQUFFO1VBQUEsSUFBQStELGdCQUFBO1VBQ2QsSUFBQTlELFdBQUcsRUFBQywwQkFBMEIsRUFBRUQsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztVQUN2RCxPQUFPLElBQUFvQiw0QkFBYSxFQUNsQnBCLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLEVBQ3RCLElBQUksRUFDSixDQUFBQSxLQUFLLGFBQUxBLEtBQUssd0JBQUErRCxnQkFBQSxHQUFML0QsS0FBSyxDQUFFcEIsUUFBUSxjQUFBbUYsZ0JBQUEsdUJBQWZBLGdCQUFBLENBQWlCMUMsTUFBTSxLQUFJQyw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ2xFM0MsUUFBUSxDQUNUO1FBQ0g7UUFDQSxJQUFBcUIsV0FBRyxFQUFDLDBCQUEwQixFQUFFRCxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO1FBQ3ZELE9BQU8sSUFBQW9CLDRCQUFhLEVBQ2xCcEIsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssRUFDdEIsSUFBSSxFQUNKLENBQUFBLEtBQUssYUFBTEEsS0FBSyx3QkFBQTRELGdCQUFBLEdBQUw1RCxLQUFLLENBQUVwQixRQUFRLGNBQUFnRixnQkFBQSx1QkFBZkEsZ0JBQUEsQ0FBaUJ2QyxNQUFNLEtBQUlDLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDbEUzQyxRQUFRLENBQ1Q7TUFDSDtJQUNGO0VBQ0Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7RUFDRW9GLHNCQUFzQkEsQ0FBQ2pGLElBQUksRUFBRTtJQUMzQixJQUFJLEVBQUUsVUFBVSxJQUFJQSxJQUFJLENBQUMsRUFBRTtNQUN6QixPQUFPLDZCQUE2QjtJQUN0QztJQUVBLElBQUksRUFBRSxVQUFVLElBQUlBLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxJQUFJQSxJQUFJLENBQUMsRUFBRTtNQUM1QyxPQUFPLDZCQUE2QjtJQUN0QztJQUVBLElBQUksRUFBRSxLQUFLLElBQUlBLElBQUksQ0FBQyxFQUFFO01BQ3BCLE9BQU8sd0JBQXdCO0lBQ2pDO0lBRUEsSUFBSSxFQUFFLE1BQU0sSUFBSUEsSUFBSSxDQUFDLEVBQUU7TUFDckIsT0FBTyx5QkFBeUI7SUFDbEM7SUFFQSxJQUFJLENBQUNBLElBQUksQ0FBQ3lFLEdBQUcsQ0FBQ1MsUUFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUNsRixJQUFJLENBQUN5RSxHQUFHLENBQUNTLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtNQUNuRSxPQUFPLGdCQUFnQjtJQUN6QjtJQUVBLE9BQU8sS0FBSztFQUNkOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTUMsUUFBUUEsQ0FBQ3hGLE9BQThCLEVBQUVDLE9BQXNCLEVBQUVDLFFBQStCLEVBQUU7SUFDdEcsSUFBSTtNQUNGLElBQUl1RixZQUFZLEdBQUcsSUFBSTtNQUN2QjtNQUNBO01BQ0EsSUFBQWxFLFdBQUcsRUFBQyxvQkFBb0IsRUFBRyxHQUFFdEIsT0FBTyxDQUFDSSxJQUFJLENBQUMwQyxFQUFHLFdBQVUsRUFBRSxPQUFPLENBQUM7TUFDakU7TUFDQSxNQUFNUCxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUM3QyxXQUFXLENBQUNxRCxXQUFXLENBQUMvQyxPQUFPLENBQUNJLElBQUksQ0FBQzBDLEVBQUUsQ0FBQztNQUNoRSxJQUFJUCxJQUFJLEVBQUU7UUFDUmlELFlBQVksR0FBR2pELElBQUk7TUFDckIsQ0FBQyxNQUFNO1FBQ0wsSUFBQWpCLFdBQUcsRUFBQyxvQkFBb0IsRUFBRyxPQUFNdEIsT0FBTyxDQUFDSSxJQUFJLENBQUMwQyxFQUFHLFlBQVcsQ0FBQztRQUM3RCxPQUFPLElBQUFMLDRCQUFhLEVBQ2pCLFdBQVV6QyxPQUFPLENBQUNJLElBQUksQ0FBQzBDLEVBQUcsZ0JBQWUsRUFDMUMsSUFBSSxFQUNKSCw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ3ZDM0MsUUFBUSxDQUNUO01BQ0g7TUFDQSxNQUFNd0YsT0FBTyxHQUFHO1FBQUVwQyxTQUFTLEVBQUVyRCxPQUFPLENBQUNJLElBQUksQ0FBQzBDO01BQUcsQ0FBQztNQUM5QyxJQUFJOUMsT0FBTyxDQUFDSSxJQUFJLENBQUNrRCxZQUFZLEVBQUU7UUFDN0JtQyxPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUd6RixPQUFPLENBQUNJLElBQUksQ0FBQ2tELFlBQVk7TUFDckQ7TUFDQSxJQUFJRixtQkFBbUI7TUFDdkIsSUFBRztRQUNEQSxtQkFBbUIsR0FBRyxNQUFNckQsT0FBTyxDQUFDTyxLQUFLLENBQUNzQixHQUFHLENBQUNDLE1BQU0sQ0FBQ0csY0FBYyxDQUFDaEMsT0FBTyxDQUN6RSxLQUFLLEVBQ0osZUFBYyxFQUNmLENBQUMsQ0FBQyxFQUNGeUYsT0FBTyxDQUNSO01BQ0gsQ0FBQyxRQUFNcEUsS0FBSyxFQUFDO1FBQUEsSUFBQXFFLGdCQUFBLEVBQUFDLHFCQUFBLEVBQUFDLGdCQUFBO1FBQ1gsT0FBTyxJQUFBbkQsNEJBQWEsRUFDakIsZUFBYyxFQUFBaUQsZ0JBQUEsR0FBQXJFLEtBQUssQ0FBQ3BCLFFBQVEsY0FBQXlGLGdCQUFBLHdCQUFBQyxxQkFBQSxHQUFkRCxnQkFBQSxDQUFnQm5ELElBQUksY0FBQW9ELHFCQUFBLHVCQUFwQkEscUJBQUEsQ0FBc0JuRCxNQUFNLEtBQUkscUJBQXNCLEVBQUMsRUFDdEUsSUFBSSxFQUNKLENBQUFuQixLQUFLLGFBQUxBLEtBQUssd0JBQUF1RSxnQkFBQSxHQUFMdkUsS0FBSyxDQUFFcEIsUUFBUSxjQUFBMkYsZ0JBQUEsdUJBQWZBLGdCQUFBLENBQWlCbEQsTUFBTSxLQUFJQyw0QkFBaUIsQ0FBQ2EsbUJBQW1CLEVBQ2hFdkQsUUFBUSxDQUNUO01BQ0g7TUFFQSxJQUFBcUIsV0FBRyxFQUFDLG9CQUFvQixFQUFHLEdBQUV0QixPQUFPLENBQUNJLElBQUksQ0FBQzBDLEVBQUcsd0JBQXVCLEVBQUUsT0FBTyxDQUFDO01BQzlFLElBQUlNLG1CQUFtQixDQUFDVixNQUFNLEtBQUtDLDRCQUFpQixDQUFDYyxFQUFFLElBQUlMLG1CQUFtQixDQUFDYixJQUFJLEVBQUU7UUFDbkYsSUFBSW9CLGNBQWMsR0FBRyxNQUFNNUQsT0FBTyxDQUFDTyxLQUFLLENBQUNzQixHQUFHLENBQUNDLE1BQU0sQ0FBQ0csY0FBYyxDQUFDaEMsT0FBTyxDQUN4RSxLQUFLLEVBQ0osU0FBUSxFQUNUO1VBQUU0RCxNQUFNLEVBQUU7WUFBRUMsV0FBVyxFQUFFO1VBQU07UUFBRSxDQUFDLEVBQ2xDO1VBQUVSLFNBQVMsRUFBRXJELE9BQU8sQ0FBQ0ksSUFBSSxDQUFDMEM7UUFBRyxDQUFDLENBQy9CO1FBRUQsSUFBSWEsY0FBYyxDQUFDakIsTUFBTSxLQUFLQyw0QkFBaUIsQ0FBQ2MsRUFBRSxFQUFFO1VBQ2xELE1BQU1LLFdBQVcsR0FBR0gsY0FBYyxDQUFDcEIsSUFBSSxDQUFDQSxJQUFJLENBQUN3QixjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUNDLE9BQU87VUFFdEUsSUFBSTZCLGVBQWUsR0FBRyxNQUFNOUYsT0FBTyxDQUFDTyxLQUFLLENBQUNzQixHQUFHLENBQUNDLE1BQU0sQ0FBQ0csY0FBYyxDQUFDaEMsT0FBTyxDQUN6RSxLQUFLLEVBQ0osaUJBQWdCLEVBQ2pCLENBQUMsQ0FBQyxFQUNGO1lBQUVxRCxTQUFTLEVBQUVyRCxPQUFPLENBQUNJLElBQUksQ0FBQzBDO1VBQUcsQ0FBQyxDQUMvQjs7VUFFRDtVQUNBLElBQUlnRCxpQkFBaUIsR0FBR3BFLDRDQUFzQixDQUFDcUUsWUFBWTtVQUMzRCxNQUFNQyx5QkFBeUIsR0FBRyxNQUFNakcsT0FBTyxDQUFDTyxLQUFLLENBQUNzQixHQUFHLENBQUNDLE1BQU0sQ0FBQ0csY0FBYyxDQUFDaEMsT0FBTyxDQUNyRixLQUFLLEVBQ0osb0JBQW1CLEVBQ3BCLENBQUMsQ0FBQyxFQUNGO1lBQUVxRCxTQUFTLEVBQUVyRCxPQUFPLENBQUNJLElBQUksQ0FBQzBDO1VBQUcsQ0FBQyxDQUMvQjtVQUNELElBQUlrRCx5QkFBeUIsQ0FBQ3RELE1BQU0sS0FBS0MsNEJBQWlCLENBQUNjLEVBQUUsRUFBRTtZQUM3RCxNQUFNd0MsWUFBWSxHQUFHRCx5QkFBeUIsQ0FBQ3pELElBQUksQ0FBQ0EsSUFBSSxDQUFDd0IsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDa0MsWUFBWTtZQUV2RixJQUFJQSxZQUFZLElBQUlULFlBQVksSUFBSUEsWUFBWSxDQUFDVSxNQUFNO2NBQUU7Y0FDdkRKLGlCQUFpQixHQUFHcEUsNENBQXNCLENBQUNDLE9BQU8sQ0FBQyxLQUVoRCxJQUFJLENBQUNzRSxZQUFZLElBQUlULFlBQVksSUFBSUEsWUFBWSxDQUFDVSxNQUFNO2NBQUM7Y0FDNURKLGlCQUFpQixHQUFHcEUsNENBQXNCLENBQUN5RSxnQkFBZ0IsQ0FBQyxLQUV6RCxJQUFJRixZQUFZLEtBQU0sQ0FBQ1QsWUFBWSxJQUFJLENBQUNBLFlBQVksQ0FBQ1UsTUFBTSxDQUFFO2NBQUU7Y0FDbEVKLGlCQUFpQixHQUFHcEUsNENBQXNCLENBQUMwRSxhQUFhLENBQUMsS0FFdEQsSUFBSSxDQUFDSCxZQUFZLEtBQU0sQ0FBQ1QsWUFBWSxJQUFJLENBQUNBLFlBQVksQ0FBQ1UsTUFBTSxDQUFFO2NBQUU7Y0FDbkVKLGlCQUFpQixHQUFHcEUsNENBQXNCLENBQUNxRSxZQUFZO1VBQzNEO1VBQ0FNLG9EQUE4QixDQUFDQyxHQUFHLENBQ2hDdEcsT0FBTyxDQUFDSSxJQUFJLENBQUMwQyxFQUFFLEVBQ2YwQyxZQUFZLENBQUNuRixRQUFRLEVBQ3JCeUYsaUJBQWlCLENBQ2xCO1VBRUQsSUFBSUQsZUFBZSxDQUFDbkQsTUFBTSxLQUFLQyw0QkFBaUIsQ0FBQ2MsRUFBRSxFQUFFO1lBQ25ELElBQUFuQyxXQUFHLEVBQUMsMEJBQTBCLEVBQUcsNkJBQTRCLEVBQUUsT0FBTyxDQUFDO1lBQ3ZFLElBQUl1RSxlQUFlLENBQUN0RCxJQUFJLENBQUNBLElBQUksQ0FBQzJCLE9BQU8sS0FBSyxLQUFLLEVBQUU7Y0FDL0M7Y0FDQSxJQUFJcUMsb0JBQW9CLEdBQUcsTUFBTXhHLE9BQU8sQ0FBQ08sS0FBSyxDQUFDc0IsR0FBRyxDQUFDQyxNQUFNLENBQUNHLGNBQWMsQ0FBQ2hDLE9BQU8sQ0FDOUUsS0FBSyxFQUNKLHFCQUFvQixFQUNyQixDQUFDLENBQUMsRUFDRjtnQkFBRXFELFNBQVMsRUFBRXJELE9BQU8sQ0FBQ0ksSUFBSSxDQUFDMEM7Y0FBRyxDQUFDLENBQy9CO2NBRUQsSUFBSXlELG9CQUFvQixDQUFDN0QsTUFBTSxLQUFLQyw0QkFBaUIsQ0FBQ2MsRUFBRSxFQUFFO2dCQUN4RCxPQUFPeEQsUUFBUSxDQUFDa0IsRUFBRSxDQUFDO2tCQUNqQmYsSUFBSSxFQUFFO29CQUNKNEQsT0FBTyxFQUFFRixXQUFXO29CQUNwQk8sSUFBSSxFQUFFa0Msb0JBQW9CLENBQUNoRSxJQUFJLENBQUNBLElBQUksQ0FBQ3dCLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQ00sSUFBSTtvQkFDM0RDLE9BQU8sRUFBRWlDLG9CQUFvQixDQUFDaEUsSUFBSSxDQUFDQSxJQUFJLENBQUN3QixjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUNPLE9BQU87b0JBQ2pFNUIsTUFBTSxFQUFFLFNBQVM7b0JBQ2pCdUQsWUFBWSxFQUFFSDtrQkFDaEI7Z0JBQ0YsQ0FBQyxDQUFDO2NBQ0o7WUFDRixDQUFDLE1BQU07Y0FDTDtjQUNBLE9BQU83RixRQUFRLENBQUNrQixFQUFFLENBQUM7Z0JBQ2pCZixJQUFJLEVBQUU7a0JBQ0o0RCxPQUFPLEVBQUVGLFdBQVc7a0JBQ3BCUSxPQUFPLEVBQUUsVUFBVTtrQkFDbkI1QixNQUFNLEVBQUUsVUFBVTtrQkFDbEJ1RCxZQUFZLEVBQUVIO2dCQUNoQjtjQUNGLENBQUMsQ0FBQztZQUNKO1VBQ0Y7UUFDRjtNQUNGO0lBQ0YsQ0FBQyxDQUFDLE9BQU96RSxLQUFLLEVBQUU7TUFBQSxJQUFBbUYsZ0JBQUE7TUFDZCxJQUFBbEYsV0FBRyxFQUFDLG9CQUFvQixFQUFFRCxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO01BRWpELElBQUlBLEtBQUssSUFBSUEsS0FBSyxDQUFDcEIsUUFBUSxJQUFJb0IsS0FBSyxDQUFDcEIsUUFBUSxDQUFDeUMsTUFBTSxLQUFLQyw0QkFBaUIsQ0FBQzhELFlBQVksRUFBRTtRQUN2RixPQUFPLElBQUFoRSw0QkFBYSxFQUNqQiw4Q0FBNkNwQixLQUFLLENBQUNwQixRQUFRLENBQUNzQyxJQUFJLENBQUNoQixPQUFRLEVBQUMsRUFDM0VvQiw0QkFBaUIsQ0FBQzhELFlBQVksRUFDOUI5RCw0QkFBaUIsQ0FBQzhELFlBQVksRUFDOUJ4RyxRQUFRLENBQ1Q7TUFDSDtNQUNBLElBQUlvQixLQUFLLElBQUlBLEtBQUssQ0FBQ3BCLFFBQVEsSUFBSW9CLEtBQUssQ0FBQ3BCLFFBQVEsQ0FBQ3NDLElBQUksSUFBSWxCLEtBQUssQ0FBQ3BCLFFBQVEsQ0FBQ3NDLElBQUksQ0FBQ0MsTUFBTSxFQUFFO1FBQ2hGLE9BQU8sSUFBQUMsNEJBQWEsRUFDbEJwQixLQUFLLENBQUNwQixRQUFRLENBQUNzQyxJQUFJLENBQUNDLE1BQU0sRUFDMUJuQixLQUFLLENBQUNwQixRQUFRLENBQUN5QyxNQUFNLElBQUlDLDRCQUFpQixDQUFDYSxtQkFBbUIsRUFDOURuQyxLQUFLLENBQUNwQixRQUFRLENBQUN5QyxNQUFNLElBQUlDLDRCQUFpQixDQUFDYSxtQkFBbUIsRUFDOUR2RCxRQUFRLENBQ1Q7TUFDSDtNQUNBLElBQUlvQixLQUFLLENBQUMwRCxJQUFJLEtBQUssUUFBUSxFQUFFO1FBQzNCLE9BQU8sSUFBQXRDLDRCQUFhLEVBQ2xCLHVEQUF1RCxFQUN2RCxJQUFJLEVBQ0pFLDRCQUFpQixDQUFDK0QsV0FBVyxFQUM3QnpHLFFBQVEsQ0FDVDtNQUNIO01BQ0EsT0FBTyxJQUFBd0MsNEJBQWEsRUFDbEJwQixLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxFQUN0QixJQUFJLEVBQ0osQ0FBQUEsS0FBSyxhQUFMQSxLQUFLLHdCQUFBbUYsZ0JBQUEsR0FBTG5GLEtBQUssQ0FBRXBCLFFBQVEsY0FBQXVHLGdCQUFBLHVCQUFmQSxnQkFBQSxDQUFpQjlELE1BQU0sS0FBSUMsNEJBQWlCLENBQUNDLHFCQUFxQixFQUNsRTNDLFFBQVEsQ0FDVDtJQUNIO0VBQ0Y7RUFFQXNELG1CQUFtQkEsQ0FBQ3RELFFBQVEsRUFBRTtJQUM1QixJQUFJQSxRQUFRLENBQUN5QyxNQUFNLEtBQUtDLDRCQUFpQixDQUFDYyxFQUFFLEVBQUU7TUFDNUM7TUFDQSxNQUFNa0QsZ0JBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDO01BQ3ZELE1BQU1qRSxNQUFNLEdBQUcsQ0FBQ3pDLFFBQVEsQ0FBQ3NDLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRUcsTUFBTSxJQUFJLENBQUM7TUFDaEQsTUFBTWtFLE1BQU0sR0FBR0QsZ0JBQWdCLENBQUNyQixRQUFRLENBQUM1QyxNQUFNLENBQUM7TUFFaERrRSxNQUFNLElBQUksSUFBQXRGLFdBQUcsRUFBQyx1QkFBdUIsRUFBRSxnREFBZ0QsQ0FBQztNQUV4RixPQUFPc0YsTUFBTTtJQUNmO0lBQ0EsT0FBTyxLQUFLO0VBQ2Q7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTUMsWUFBWUEsQ0FBQzlHLE9BQU8sRUFBRTZCLEdBQUcsRUFBRWtGLElBQUksRUFBRTtJQUNyQyxJQUFJO01BQ0YsTUFBTTdHLFFBQVEsR0FBRyxNQUFNRixPQUFPLENBQUNPLEtBQUssQ0FBQ3NCLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDRyxjQUFjLENBQUNoQyxPQUFPLENBQ3BFLEtBQUssRUFDTCxpQkFBaUIsRUFDakIsQ0FBQyxDQUFDLEVBQ0Y7UUFBRXFELFNBQVMsRUFBRXpCLEdBQUcsQ0FBQ2tCO01BQUcsQ0FBQyxDQUN0QjtNQUVELE1BQU1pRSxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzlHLFFBQVEsSUFBSSxDQUFDLENBQUMsRUFBRXNDLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRUEsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFd0IsY0FBYyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7TUFFMUYsTUFBTWlELFNBQVMsR0FDYixDQUFDLENBQUNwRixHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUU4QixZQUFZLElBQUksQ0FBQyxDQUFDLEVBQUVoQixNQUFNLEtBQUssU0FBUyxJQUNyRCxPQUFPcUUsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEtBQUssV0FBVztNQUNsRCxNQUFNRSxhQUFhLEdBQUcsT0FBT0YsT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLFdBQVc7TUFFaEUsTUFBTUcsS0FBSyxHQUFHSCxPQUFPLENBQUMsYUFBYSxDQUFDLEtBQUssU0FBUztNQUNsRCxNQUFNSSxRQUFRLEdBQUdKLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLFNBQVM7TUFDeEQsTUFBTUssT0FBTyxHQUFHSCxhQUFhLEdBQUdGLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxTQUFTLEdBQUcsSUFBSTtNQUN4RSxNQUFNTSxRQUFRLEdBQUdMLFNBQVMsR0FBR0QsT0FBTyxDQUFDLGdCQUFnQixDQUFDLEtBQUssU0FBUyxHQUFHLElBQUk7TUFFM0UsTUFBTU8sT0FBTyxHQUFHSixLQUFLLElBQUlDLFFBQVEsSUFBSUMsT0FBTyxJQUFJQyxRQUFRO01BRXhEQyxPQUFPLElBQUksSUFBQWhHLFdBQUcsRUFBQyx3QkFBd0IsRUFBRyxnQkFBZSxFQUFFLE9BQU8sQ0FBQztNQUVuRSxJQUFJd0YsSUFBSSxLQUFLLE9BQU8sRUFBRTtRQUNwQixPQUFPO1VBQUVRO1FBQVEsQ0FBQztNQUNwQjtNQUVBLElBQUksQ0FBQ0EsT0FBTyxFQUFFO1FBQ1osTUFBTSxJQUFJbkUsS0FBSyxDQUFDLHFCQUFxQixDQUFDO01BQ3hDO0lBQ0YsQ0FBQyxDQUFDLE9BQU85QixLQUFLLEVBQUU7TUFDZCxJQUFBQyxXQUFHLEVBQUMsd0JBQXdCLEVBQUVELEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLENBQUM7TUFDckQsT0FBT2tHLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDbkcsS0FBSyxDQUFDO0lBQzlCO0VBQ0Y7RUFFQW9HLEtBQUtBLENBQUNDLE1BQU0sRUFBRTtJQUNaO0lBQ0EsT0FBTyxJQUFJSCxPQUFPLENBQUMsQ0FBQ0ksT0FBTyxFQUFFSCxNQUFNLEtBQUs7TUFDdENJLFVBQVUsQ0FBQ0QsT0FBTyxFQUFFRCxNQUFNLENBQUM7SUFDN0IsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0VHLG1CQUFtQkEsQ0FBQ0MsTUFBTSxFQUFFaEIsSUFBSSxFQUFFO0lBQ2hDO0lBQ0EsTUFBTWlCLGVBQWUsR0FBR0QsTUFBTSxLQUFLLE1BQU0sSUFBSWhCLElBQUksS0FBSyxpQkFBaUI7SUFDdkUsTUFBTWtCLGdCQUFnQixHQUFHRixNQUFNLEtBQUssS0FBSyxJQUFJaEIsSUFBSSxDQUFDbUIsVUFBVSxDQUFDLGtCQUFrQixDQUFDO0lBQ2hGLE1BQU1DLHFCQUFxQixHQUFHSixNQUFNLEtBQUssTUFBTSxJQUFJaEIsSUFBSSxDQUFDbUIsVUFBVSxDQUFDLGdCQUFnQixDQUFDOztJQUVwRjtJQUNBLE9BQU9GLGVBQWUsSUFBSUMsZ0JBQWdCLElBQUlFLHFCQUFxQjtFQUNyRTs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxNQUFNQyxXQUFXQSxDQUFDcEksT0FBTyxFQUFFK0gsTUFBTSxFQUFFaEIsSUFBSSxFQUFFdkUsSUFBSSxFQUFFTyxFQUFFLEVBQUU3QyxRQUFRLEVBQUU7SUFFM0QsTUFBTW1JLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQzdGLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRTZGLFFBQVE7SUFDeEMsSUFBSTtNQUNGLE1BQU14RyxHQUFHLEdBQUcsTUFBTSxJQUFJLENBQUNsQyxXQUFXLENBQUNxRCxXQUFXLENBQUNELEVBQUUsQ0FBQztNQUNsRCxJQUFJc0YsUUFBUSxFQUFFO1FBQ1osT0FBTzdGLElBQUksQ0FBQzZGLFFBQVE7TUFDdEI7TUFFQSxJQUFJLENBQUNwRixNQUFNLENBQUNDLElBQUksQ0FBQ3JCLEdBQUcsQ0FBQyxDQUFDc0IsTUFBTSxFQUFFO1FBQzVCLElBQUE1QixXQUFHLEVBQUMsdUJBQXVCLEVBQUUsZ0NBQWdDLENBQUM7UUFDOUQ7UUFDQSxPQUFPLElBQUFtQiw0QkFBYSxFQUFDLGdDQUFnQyxFQUFFLElBQUksRUFBRUUsNEJBQWlCLENBQUMwRixTQUFTLEVBQUVwSSxRQUFRLENBQUM7TUFDckc7TUFFQSxJQUFJLENBQUNzQyxJQUFJLEVBQUU7UUFDVEEsSUFBSSxHQUFHLENBQUMsQ0FBQztNQUNYO01BQUM7TUFFRCxJQUFJLENBQUNBLElBQUksQ0FBQzlCLE9BQU8sRUFBRTtRQUNqQjhCLElBQUksQ0FBQzlCLE9BQU8sR0FBRyxDQUFDLENBQUM7TUFDbkI7TUFBQztNQUVELE1BQU1nRixPQUFPLEdBQUc7UUFDZHBDLFNBQVMsRUFBRVA7TUFDYixDQUFDOztNQUVEO01BQ0EsSUFBSSxPQUFPLENBQUNQLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRW5DLElBQUksS0FBSyxRQUFRLElBQUksQ0FBQ21DLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRStGLE1BQU0sS0FBSyxXQUFXLEVBQUU7UUFDaEYvRixJQUFJLENBQUM5QixPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUcsaUJBQWlCO1FBQ2hELE9BQU84QixJQUFJLENBQUMrRixNQUFNO01BQ3BCO01BRUEsSUFBSSxPQUFPLENBQUMvRixJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUVuQyxJQUFJLEtBQUssUUFBUSxJQUFJLENBQUNtQyxJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUUrRixNQUFNLEtBQUssTUFBTSxFQUFFO1FBQzNFL0YsSUFBSSxDQUFDOUIsT0FBTyxDQUFDLGNBQWMsQ0FBQyxHQUFHLGtCQUFrQjtRQUNqRCxPQUFPOEIsSUFBSSxDQUFDK0YsTUFBTTtNQUNwQjtNQUVBLElBQUksT0FBTyxDQUFDL0YsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFbkMsSUFBSSxLQUFLLFFBQVEsSUFBSSxDQUFDbUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFK0YsTUFBTSxLQUFLLEtBQUssRUFBRTtRQUMxRS9GLElBQUksQ0FBQzlCLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRywwQkFBMEI7UUFDekQsT0FBTzhCLElBQUksQ0FBQytGLE1BQU07TUFDcEI7TUFDQSxNQUFNQyxLQUFLLEdBQUcsQ0FBQ2hHLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRWdHLEtBQUssSUFBSSxDQUFDO01BQ3JDLElBQUlBLEtBQUssRUFBRTtRQUNULElBQUFDLG9CQUFhLEVBQUM7VUFDWkMsT0FBTyxFQUFFLElBQUl4SCxJQUFJLENBQUNBLElBQUksQ0FBQ0MsR0FBRyxFQUFFLEdBQUdxSCxLQUFLLENBQUM7VUFDckNHLEdBQUcsRUFBRSxNQUFBQSxDQUFBLEtBQVk7WUFDZixJQUFHO2NBQ0QsTUFBTTNJLE9BQU8sQ0FBQ08sS0FBSyxDQUFDc0IsR0FBRyxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQzlCLE9BQU8sQ0FBQzhILE1BQU0sRUFBRWhCLElBQUksRUFBRXZFLElBQUksRUFBRWtELE9BQU8sQ0FBQztZQUNuRixDQUFDLFFBQU1wRSxLQUFLLEVBQUM7Y0FDWCxJQUFBQyxXQUFHLEVBQUMsdUJBQXVCLEVBQUUsNkNBQTRDd0csTUFBTyxJQUFHaEIsSUFBSyxNQUFLekYsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQU0sRUFBQyxDQUFDO1lBQ3hIO1lBQUM7VUFDSDtRQUNGLENBQUMsQ0FBQztRQUNGLE9BQU9wQixRQUFRLENBQUNrQixFQUFFLENBQUM7VUFDakJmLElBQUksRUFBRTtZQUFFaUIsS0FBSyxFQUFFLENBQUM7WUFBRUUsT0FBTyxFQUFFO1VBQVU7UUFDdkMsQ0FBQyxDQUFDO01BQ0o7TUFFQSxJQUFJdUYsSUFBSSxLQUFLLE9BQU8sRUFBRTtRQUNwQixJQUFJO1VBQ0YsTUFBTTZCLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQzlCLFlBQVksQ0FBQzlHLE9BQU8sRUFBRTZCLEdBQUcsRUFBRWtGLElBQUksQ0FBQztVQUN6RCxPQUFPNkIsS0FBSztRQUNkLENBQUMsQ0FBQyxPQUFPdEgsS0FBSyxFQUFFO1VBQ2QsTUFBTXVGLE1BQU0sR0FBRyxDQUFDdkYsS0FBSyxJQUFJLENBQUMsQ0FBQyxFQUFFMEQsSUFBSSxLQUFLLGNBQWM7VUFDcEQsSUFBSSxDQUFDNkIsTUFBTSxFQUFFO1lBQ1gsSUFBQXRGLFdBQUcsRUFBQyx1QkFBdUIsRUFBRSxnREFBZ0QsQ0FBQztZQUM5RSxPQUFPLElBQUFtQiw0QkFBYSxFQUNqQixlQUFjcEIsS0FBSyxDQUFDRSxPQUFPLElBQUkscUJBQXNCLEVBQUMsRUFDdkQsSUFBSSxFQUNKb0IsNEJBQWlCLENBQUNDLHFCQUFxQixFQUN2QzNDLFFBQVEsQ0FDVDtVQUNIO1FBQ0Y7TUFDRjtNQUVBLElBQUFxQixXQUFHLEVBQUMsdUJBQXVCLEVBQUcsR0FBRXdHLE1BQU8sSUFBR2hCLElBQUssRUFBQyxFQUFFLE9BQU8sQ0FBQzs7TUFFMUQ7TUFDQSxNQUFNOEIsY0FBYyxHQUFHNUYsTUFBTSxDQUFDQyxJQUFJLENBQUNWLElBQUksQ0FBQzs7TUFFeEM7TUFDQTtNQUNBO01BQ0EsSUFBSSxDQUFDLElBQUksQ0FBQ3NGLG1CQUFtQixDQUFDQyxNQUFNLEVBQUVoQixJQUFJLENBQUMsRUFBRTtRQUMzQyxLQUFLLE1BQU0rQixHQUFHLElBQUlELGNBQWMsRUFBRTtVQUNoQyxJQUFJRSxLQUFLLENBQUNDLE9BQU8sQ0FBQ3hHLElBQUksQ0FBQ3NHLEdBQUcsQ0FBQyxDQUFDLEVBQUU7WUFDNUJ0RyxJQUFJLENBQUNzRyxHQUFHLENBQUMsR0FBR3RHLElBQUksQ0FBQ3NHLEdBQUcsQ0FBQyxDQUFDRyxJQUFJLEVBQUU7VUFDOUI7UUFDRjtNQUNGO01BRUEsTUFBTUMsYUFBYSxHQUFHLE1BQU1sSixPQUFPLENBQUNPLEtBQUssQ0FBQ3NCLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDQyxhQUFhLENBQUM5QixPQUFPLENBQUM4SCxNQUFNLEVBQUVoQixJQUFJLEVBQUV2RSxJQUFJLEVBQUVrRCxPQUFPLENBQUM7TUFDdkcsTUFBTXlELGNBQWMsR0FBRyxJQUFJLENBQUMzRixtQkFBbUIsQ0FBQzBGLGFBQWEsQ0FBQztNQUM5RCxJQUFJQyxjQUFjLEVBQUU7UUFDbEIsT0FBTyxJQUFBekcsNEJBQWEsRUFDakIsZUFBY3hDLFFBQVEsQ0FBQ0csSUFBSSxDQUFDbUIsT0FBTyxJQUFJLHFCQUFzQixFQUFDLEVBQy9ELElBQUksRUFDSm9CLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDdkMzQyxRQUFRLENBQ1Q7TUFDSDtNQUNBLElBQUlrSixZQUFZLEdBQUcsQ0FBQ0YsYUFBYSxJQUFJLENBQUMsQ0FBQyxFQUFFMUcsSUFBSSxJQUFJLENBQUMsQ0FBQztNQUNuRCxJQUFJLENBQUM0RyxZQUFZLEVBQUU7UUFDakJBLFlBQVksR0FDVixPQUFPQSxZQUFZLEtBQUssUUFBUSxJQUFJckMsSUFBSSxDQUFDeEIsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJd0MsTUFBTSxLQUFLLEtBQUssR0FDM0UsR0FBRyxHQUNILEtBQUs7UUFDWDdILFFBQVEsQ0FBQ3NDLElBQUksR0FBRzRHLFlBQVk7TUFDOUI7TUFDQSxNQUFNQyxhQUFhLEdBQUduSixRQUFRLENBQUN5QyxNQUFNLEtBQUtDLDRCQUFpQixDQUFDYyxFQUFFLEdBQUd4RCxRQUFRLENBQUN5QyxNQUFNLEdBQUcsS0FBSztNQUV4RixJQUFJLENBQUMwRyxhQUFhLElBQUlELFlBQVksRUFBRTtRQUNsQztRQUNBLE9BQU9sSixRQUFRLENBQUNrQixFQUFFLENBQUM7VUFDakJmLElBQUksRUFBRTZJLGFBQWEsQ0FBQzFHO1FBQ3RCLENBQUMsQ0FBQztNQUNKO01BRUEsSUFBSTZHLGFBQWEsSUFBSWhCLFFBQVEsRUFBRTtRQUM3QixPQUFPbkksUUFBUSxDQUFDa0IsRUFBRSxDQUFDO1VBQ2pCZixJQUFJLEVBQUVILFFBQVEsQ0FBQ3NDO1FBQ2pCLENBQUMsQ0FBQztNQUNKO01BQ0EsTUFBTTZHLGFBQWEsSUFBSUQsWUFBWSxDQUFDM0csTUFBTSxHQUN0QztRQUFFakIsT0FBTyxFQUFFNEgsWUFBWSxDQUFDM0csTUFBTTtRQUFFdUMsSUFBSSxFQUFFcUU7TUFBYyxDQUFDLEdBQ3JELElBQUlqRyxLQUFLLENBQUMsbURBQW1ELENBQUM7SUFDcEUsQ0FBQyxDQUFDLE9BQU85QixLQUFLLEVBQUU7TUFDZCxJQUFJQSxLQUFLLElBQUlBLEtBQUssQ0FBQ3BCLFFBQVEsSUFBSW9CLEtBQUssQ0FBQ3BCLFFBQVEsQ0FBQ3lDLE1BQU0sS0FBS0MsNEJBQWlCLENBQUM4RCxZQUFZLEVBQUU7UUFDdkYsT0FBTyxJQUFBaEUsNEJBQWEsRUFDbEJwQixLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxFQUN0QkEsS0FBSyxDQUFDMEQsSUFBSSxHQUFJLG9CQUFtQjFELEtBQUssQ0FBQzBELElBQUssRUFBQyxHQUFHLElBQUksRUFDcERwQyw0QkFBaUIsQ0FBQzhELFlBQVksRUFDOUJ4RyxRQUFRLENBQ1Q7TUFDSDtNQUNBLE1BQU1vSixRQUFRLEdBQUcsQ0FBQ2hJLEtBQUssQ0FBQ3BCLFFBQVEsSUFBSSxDQUFDLENBQUMsRUFBRXNDLElBQUksSUFBSWxCLEtBQUssQ0FBQ0UsT0FBTztNQUM3RCxJQUFBRCxXQUFHLEVBQUMsdUJBQXVCLEVBQUUrSCxRQUFRLElBQUloSSxLQUFLLENBQUM7TUFDL0MsSUFBSStHLFFBQVEsRUFBRTtRQUNaLE9BQU9uSSxRQUFRLENBQUNrQixFQUFFLENBQUM7VUFDakJmLElBQUksRUFBRTtZQUFFaUIsS0FBSyxFQUFFLE1BQU07WUFBRUUsT0FBTyxFQUFFOEgsUUFBUSxJQUFJaEk7VUFBTTtRQUNwRCxDQUFDLENBQUM7TUFDSixDQUFDLE1BQU07UUFDTCxJQUFJLENBQUNBLEtBQUssSUFBSSxDQUFDLENBQUMsRUFBRTBELElBQUksSUFBSXVFLHlDQUFtQixDQUFDakksS0FBSyxDQUFDMEQsSUFBSSxDQUFDLEVBQUU7VUFDekQxRCxLQUFLLENBQUNFLE9BQU8sR0FBRytILHlDQUFtQixDQUFDakksS0FBSyxDQUFDMEQsSUFBSSxDQUFDO1FBQ2pEO1FBQ0EsT0FBTyxJQUFBdEMsNEJBQWEsRUFDbEI0RyxRQUFRLENBQUM3RyxNQUFNLElBQUluQixLQUFLLEVBQ3hCQSxLQUFLLENBQUMwRCxJQUFJLEdBQUksb0JBQW1CMUQsS0FBSyxDQUFDMEQsSUFBSyxFQUFDLEdBQUcsSUFBSSxFQUNwRHBDLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDdkMzQyxRQUFRLENBQ1Q7TUFDSDtJQUNGO0VBQ0Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRXNKLFVBQVVBLENBQUN4SixPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBRWxHLE1BQU11SixLQUFLLEdBQUcsSUFBQTdJLDRCQUFvQixFQUFDWCxPQUFPLENBQUNTLE9BQU8sQ0FBQ0MsTUFBTSxFQUFFLFFBQVEsQ0FBQztJQUNwRSxJQUFJOEksS0FBSyxLQUFLeEosT0FBTyxDQUFDSSxJQUFJLENBQUMwQyxFQUFFLEVBQUU7TUFBRTtNQUMvQixPQUFPLElBQUFMLDRCQUFhLEVBQ2xCLGlCQUFpQixFQUNqQkUsNEJBQWlCLENBQUM4RCxZQUFZLEVBQzlCOUQsNEJBQWlCLENBQUM4RCxZQUFZLEVBQzlCeEcsUUFBUSxDQUNUO0lBQ0g7SUFDQSxJQUFJLENBQUNELE9BQU8sQ0FBQ0ksSUFBSSxDQUFDMEgsTUFBTSxFQUFFO01BQ3hCLE9BQU8sSUFBQXJGLDRCQUFhLEVBQUMsdUJBQXVCLEVBQUUsSUFBSSxFQUFFRSw0QkFBaUIsQ0FBQytELFdBQVcsRUFBRXpHLFFBQVEsQ0FBQztJQUM5RixDQUFDLE1BQU0sSUFBSSxDQUFDRCxPQUFPLENBQUNJLElBQUksQ0FBQzBILE1BQU0sQ0FBQzJCLEtBQUssQ0FBQywyQkFBMkIsQ0FBQyxFQUFFO01BQ2xFLElBQUFuSSxXQUFHLEVBQUMsdUJBQXVCLEVBQUUsOEJBQThCLENBQUM7TUFDNUQ7TUFDQSxPQUFPLElBQUFtQiw0QkFBYSxFQUFDLDhCQUE4QixFQUFFLElBQUksRUFBRUUsNEJBQWlCLENBQUMrRCxXQUFXLEVBQUV6RyxRQUFRLENBQUM7SUFDckcsQ0FBQyxNQUFNLElBQUksQ0FBQ0QsT0FBTyxDQUFDSSxJQUFJLENBQUMwRyxJQUFJLEVBQUU7TUFDN0IsT0FBTyxJQUFBckUsNEJBQWEsRUFBQyxxQkFBcUIsRUFBRSxJQUFJLEVBQUVFLDRCQUFpQixDQUFDK0QsV0FBVyxFQUFFekcsUUFBUSxDQUFDO0lBQzVGLENBQUMsTUFBTSxJQUFJLENBQUNELE9BQU8sQ0FBQ0ksSUFBSSxDQUFDMEcsSUFBSSxDQUFDbUIsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFO01BQzdDLElBQUEzRyxXQUFHLEVBQUMsdUJBQXVCLEVBQUUsNEJBQTRCLENBQUM7TUFDMUQ7TUFDQSxPQUFPLElBQUFtQiw0QkFBYSxFQUFDLDRCQUE0QixFQUFFLElBQUksRUFBRUUsNEJBQWlCLENBQUMrRCxXQUFXLEVBQUV6RyxRQUFRLENBQUM7SUFDbkcsQ0FBQyxNQUFNO01BRUwsT0FBTyxJQUFJLENBQUNrSSxXQUFXLENBQ3JCcEksT0FBTyxFQUNQQyxPQUFPLENBQUNJLElBQUksQ0FBQzBILE1BQU0sRUFDbkI5SCxPQUFPLENBQUNJLElBQUksQ0FBQzBHLElBQUksRUFDakI5RyxPQUFPLENBQUNJLElBQUksQ0FBQ0EsSUFBSSxFQUNqQkosT0FBTyxDQUFDSSxJQUFJLENBQUMwQyxFQUFFLEVBQ2Y3QyxRQUFRLENBQ1Q7SUFDSDtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTXlKLEdBQUdBLENBQUMzSixPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBQ2pHLElBQUk7TUFDRixJQUFJLENBQUNELE9BQU8sQ0FBQ0ksSUFBSSxJQUFJLENBQUNKLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDMEcsSUFBSSxFQUFFLE1BQU0sSUFBSTNELEtBQUssQ0FBQyx3QkFBd0IsQ0FBQztNQUNsRixJQUFJLENBQUNuRCxPQUFPLENBQUNJLElBQUksQ0FBQzBDLEVBQUUsRUFBRSxNQUFNLElBQUlLLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQztNQUU3RCxNQUFNd0csT0FBTyxHQUFHYixLQUFLLENBQUNDLE9BQU8sQ0FBQyxDQUFDLENBQUMvSSxPQUFPLElBQUksQ0FBQyxDQUFDLEVBQUVJLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRXVKLE9BQU8sQ0FBQyxHQUFHM0osT0FBTyxDQUFDSSxJQUFJLENBQUN1SixPQUFPLEdBQUcsRUFBRTtNQUUvRixJQUFJQyxPQUFPLEdBQUc1SixPQUFPLENBQUNJLElBQUksQ0FBQzBHLElBQUk7TUFFL0IsSUFBSThDLE9BQU8sSUFBSSxPQUFPQSxPQUFPLEtBQUssUUFBUSxFQUFFO1FBQzFDQSxPQUFPLEdBQUdBLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUdBLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHRCxPQUFPO01BQzVEO01BRUEsSUFBSSxDQUFDQSxPQUFPLEVBQUUsTUFBTSxJQUFJekcsS0FBSyxDQUFDLHNDQUFzQyxDQUFDO01BRXJFLElBQUE3QixXQUFHLEVBQUMsZUFBZSxFQUFHLFVBQVNzSSxPQUFRLEVBQUMsRUFBRSxPQUFPLENBQUM7TUFDbEQ7TUFDQSxNQUFNaEcsTUFBTSxHQUFHO1FBQUVrRyxLQUFLLEVBQUU7TUFBSSxDQUFDO01BRTdCLElBQUlILE9BQU8sQ0FBQ3pHLE1BQU0sRUFBRTtRQUNsQixLQUFLLE1BQU02RyxNQUFNLElBQUlKLE9BQU8sRUFBRTtVQUM1QixJQUFJLENBQUNJLE1BQU0sQ0FBQ0MsSUFBSSxJQUFJLENBQUNELE1BQU0sQ0FBQ0UsS0FBSyxFQUFFO1VBQ25DckcsTUFBTSxDQUFDbUcsTUFBTSxDQUFDQyxJQUFJLENBQUMsR0FBR0QsTUFBTSxDQUFDRSxLQUFLO1FBQ3BDO01BQ0Y7TUFFQSxJQUFJQyxVQUFVLEdBQUcsRUFBRTtNQUVuQixNQUFNQyxNQUFNLEdBQUcsTUFBTXBLLE9BQU8sQ0FBQ08sS0FBSyxDQUFDc0IsR0FBRyxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQzlCLE9BQU8sQ0FDakUsS0FBSyxFQUNKLElBQUc0SixPQUFRLEVBQUMsRUFDYjtRQUFFaEcsTUFBTSxFQUFFQTtNQUFPLENBQUMsRUFDbEI7UUFBRVAsU0FBUyxFQUFFckQsT0FBTyxDQUFDSSxJQUFJLENBQUMwQztNQUFHLENBQUMsQ0FDL0I7TUFFRCxNQUFNc0gsTUFBTSxHQUFHcEssT0FBTyxDQUFDSSxJQUFJLENBQUMwRyxJQUFJLENBQUN4QixRQUFRLENBQUMsUUFBUSxDQUFDLElBQUl0RixPQUFPLENBQUNJLElBQUksQ0FBQ3VKLE9BQU8sSUFBSTNKLE9BQU8sQ0FBQ0ksSUFBSSxDQUFDdUosT0FBTyxDQUFDekcsTUFBTSxJQUFJbEQsT0FBTyxDQUFDSSxJQUFJLENBQUN1SixPQUFPLENBQUNVLElBQUksQ0FBQ04sTUFBTSxJQUFJQSxNQUFNLENBQUNPLFVBQVUsQ0FBQztNQUVwSyxNQUFNQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUNKLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBRTVILElBQUksSUFBSSxDQUFDLENBQUMsRUFBRUEsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFaUksb0JBQW9CO01BRWhGLElBQUlELFVBQVUsSUFBSSxDQUFDSCxNQUFNLEVBQUU7UUFDekJ4RyxNQUFNLENBQUM2RyxNQUFNLEdBQUcsQ0FBQztRQUNqQlAsVUFBVSxDQUFDUSxJQUFJLENBQUMsR0FBR1AsTUFBTSxDQUFDNUgsSUFBSSxDQUFDQSxJQUFJLENBQUN3QixjQUFjLENBQUM7UUFDbkQsT0FBT21HLFVBQVUsQ0FBQ2hILE1BQU0sR0FBR3FILFVBQVUsSUFBSTNHLE1BQU0sQ0FBQzZHLE1BQU0sR0FBR0YsVUFBVSxFQUFFO1VBQ25FM0csTUFBTSxDQUFDNkcsTUFBTSxJQUFJN0csTUFBTSxDQUFDa0csS0FBSztVQUM3QixNQUFNYSxPQUFPLEdBQUcsTUFBTTVLLE9BQU8sQ0FBQ08sS0FBSyxDQUFDc0IsR0FBRyxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQzlCLE9BQU8sQ0FDbEUsS0FBSyxFQUNKLElBQUc0SixPQUFRLEVBQUMsRUFDYjtZQUFFaEcsTUFBTSxFQUFFQTtVQUFPLENBQUMsRUFDbEI7WUFBRVAsU0FBUyxFQUFFckQsT0FBTyxDQUFDSSxJQUFJLENBQUMwQztVQUFHLENBQUMsQ0FDL0I7VUFDRG9ILFVBQVUsQ0FBQ1EsSUFBSSxDQUFDLEdBQUdDLE9BQU8sQ0FBQ3BJLElBQUksQ0FBQ0EsSUFBSSxDQUFDd0IsY0FBYyxDQUFDO1FBQ3REO01BQ0Y7TUFFQSxJQUFJd0csVUFBVSxFQUFFO1FBQ2QsTUFBTTtVQUFFekQsSUFBSTtVQUFFNkM7UUFBUSxDQUFDLEdBQUczSixPQUFPLENBQUNJLElBQUk7UUFDdEMsTUFBTXdLLGNBQWMsR0FDbEI5RCxJQUFJLENBQUN4QixRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQzhFLE1BQU07UUFDcEMsTUFBTVMsUUFBUSxHQUFHL0QsSUFBSSxDQUFDeEIsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUN3QixJQUFJLENBQUN4QixRQUFRLENBQUMsUUFBUSxDQUFDO1FBQ3JFLE1BQU13RixlQUFlLEdBQUdoRSxJQUFJLENBQUNtQixVQUFVLENBQUMsaUJBQWlCLENBQUM7UUFDMUQsTUFBTThDLE9BQU8sR0FBR2pFLElBQUksQ0FBQ2tFLFFBQVEsQ0FBQyxRQUFRLENBQUM7UUFDdkMsSUFBSUMsTUFBTSxHQUFHakksTUFBTSxDQUFDQyxJQUFJLENBQUNrSCxNQUFNLENBQUM1SCxJQUFJLENBQUNBLElBQUksQ0FBQ3dCLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUU1RCxJQUFJOEcsUUFBUSxJQUFJQyxlQUFlLEVBQUU7VUFDL0IsSUFBSUMsT0FBTyxFQUFFO1lBQ1hFLE1BQU0sR0FBRyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUM7VUFDL0IsQ0FBQyxNQUFNO1lBQ0xBLE1BQU0sR0FBRyxDQUNQLElBQUksRUFDSixRQUFRLEVBQ1IsTUFBTSxFQUNOLElBQUksRUFDSixPQUFPLEVBQ1AsU0FBUyxFQUNULFdBQVcsRUFDWCxTQUFTLEVBQ1QsU0FBUyxFQUNULGVBQWUsRUFDZixTQUFTLEVBQ1QsVUFBVSxFQUNWLGFBQWEsRUFDYixVQUFVLEVBQ1YsVUFBVSxFQUNWLFNBQVMsRUFDVCxhQUFhLEVBQ2IsVUFBVSxFQUNWLFlBQVksQ0FDYjtVQUNIO1FBQ0Y7UUFFQSxJQUFJTCxjQUFjLEVBQUU7VUFDbEIsTUFBTU0sU0FBUyxHQUFHLEVBQUU7VUFDcEIsS0FBSyxNQUFNQyxJQUFJLElBQUlqQixVQUFVLEVBQUU7WUFDN0IsTUFBTTtjQUFFa0IsZ0JBQWdCO2NBQUVDO1lBQU0sQ0FBQyxHQUFHRixJQUFJO1lBQ3hDRCxTQUFTLENBQUNSLElBQUksQ0FBQyxHQUFHVyxLQUFLLENBQUNDLEdBQUcsQ0FBQ0MsSUFBSSxLQUFLO2NBQUVILGdCQUFnQjtjQUFFdkMsR0FBRyxFQUFFMEMsSUFBSSxDQUFDMUMsR0FBRztjQUFFb0IsS0FBSyxFQUFFc0IsSUFBSSxDQUFDdEI7WUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQ2hHO1VBQ0FnQixNQUFNLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDO1VBQzdDZixVQUFVLEdBQUcsQ0FBQyxHQUFHZ0IsU0FBUyxDQUFDO1FBQzdCO1FBRUEsSUFBSWQsTUFBTSxFQUFFO1VBQ1ZhLE1BQU0sR0FBRyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUM7VUFDekJmLFVBQVUsR0FBR0MsTUFBTSxDQUFDNUgsSUFBSSxDQUFDQSxJQUFJLENBQUN3QixjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUNzSCxLQUFLO1FBQ3ZEO1FBQ0FKLE1BQU0sR0FBR0EsTUFBTSxDQUFDSyxHQUFHLENBQUNDLElBQUksS0FBSztVQUFFdEIsS0FBSyxFQUFFc0IsSUFBSTtVQUFFOUwsT0FBTyxFQUFFO1FBQUksQ0FBQyxDQUFDLENBQUM7UUFFNUQsTUFBTStMLGNBQWMsR0FBRyxJQUFJQyxnQkFBTSxDQUFDO1VBQUVSO1FBQU8sQ0FBQyxDQUFDO1FBRTdDLElBQUl2QixHQUFHLEdBQUc4QixjQUFjLENBQUNFLEtBQUssQ0FBQ3hCLFVBQVUsQ0FBQztRQUMxQyxLQUFLLE1BQU15QixLQUFLLElBQUlWLE1BQU0sRUFBRTtVQUMxQixNQUFNO1lBQUVoQjtVQUFNLENBQUMsR0FBRzBCLEtBQUs7VUFDdkIsSUFBSWpDLEdBQUcsQ0FBQ3BFLFFBQVEsQ0FBQzJFLEtBQUssQ0FBQyxFQUFFO1lBQ3ZCUCxHQUFHLEdBQUdBLEdBQUcsQ0FBQ2tDLE9BQU8sQ0FBQzNCLEtBQUssRUFBRTRCLGlDQUFjLENBQUM1QixLQUFLLENBQUMsSUFBSUEsS0FBSyxDQUFDO1VBQzFEO1FBQ0Y7UUFFQSxPQUFPaEssUUFBUSxDQUFDa0IsRUFBRSxDQUFDO1VBQ2pCVixPQUFPLEVBQUU7WUFBRSxjQUFjLEVBQUU7VUFBVyxDQUFDO1VBQ3ZDTCxJQUFJLEVBQUVzSjtRQUNSLENBQUMsQ0FBQztNQUNKLENBQUMsTUFBTSxJQUFJUyxNQUFNLElBQUlBLE1BQU0sQ0FBQzVILElBQUksSUFBSTRILE1BQU0sQ0FBQzVILElBQUksQ0FBQ0EsSUFBSSxJQUFJLENBQUM0SCxNQUFNLENBQUM1SCxJQUFJLENBQUNBLElBQUksQ0FBQ2lJLG9CQUFvQixFQUFFO1FBQzlGLE1BQU0sSUFBSXJILEtBQUssQ0FBQyxZQUFZLENBQUM7TUFDL0IsQ0FBQyxNQUFNO1FBQ0wsTUFBTSxJQUFJQSxLQUFLLENBQUUscURBQW9EZ0gsTUFBTSxJQUFJQSxNQUFNLENBQUM1SCxJQUFJLElBQUk0SCxNQUFNLENBQUM1SCxJQUFJLENBQUNDLE1BQU0sR0FBSSxLQUFJMkgsTUFBTSxDQUFDL0osSUFBSSxDQUFDb0MsTUFBTyxFQUFDLEdBQUcsRUFBRyxFQUFDLENBQUM7TUFDdEo7SUFDRixDQUFDLENBQUMsT0FBT25CLEtBQUssRUFBRTtNQUNkLElBQUFDLFdBQUcsRUFBQyxlQUFlLEVBQUVELEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLENBQUM7TUFDNUMsT0FBTyxJQUFBb0IsNEJBQWEsRUFBQ3BCLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLEVBQUUsSUFBSSxFQUFFc0IsNEJBQWlCLENBQUNDLHFCQUFxQixFQUFFM0MsUUFBUSxDQUFDO0lBQ3ZHO0VBQ0Y7O0VBRUE7RUFDQTZMLGNBQWNBLENBQUMvTCxPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBQ3RHO0lBQ0EsT0FBT0EsUUFBUSxDQUFDa0IsRUFBRSxDQUFDO01BQ2pCZixJQUFJLEVBQUUyTDtJQUNSLENBQUMsQ0FBQztFQUNKOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0VDLFlBQVlBLENBQUNqTSxPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBQ3BHLElBQUk7TUFDRixNQUFNZ00sTUFBTSxHQUFHQyxJQUFJLENBQUNSLEtBQUssQ0FBQ1MsV0FBRSxDQUFDQyxZQUFZLENBQUMsSUFBSSxDQUFDeE0sY0FBYyxDQUFDeU0sSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO01BQzVFLElBQUlKLE1BQU0sQ0FBQ0ssZ0JBQWdCLElBQUlMLE1BQU0sQ0FBQ00sV0FBVyxFQUFFO1FBQ2pELElBQUFqTCxXQUFHLEVBQ0Qsd0JBQXdCLEVBQ3ZCLHNCQUFxQjJLLE1BQU0sQ0FBQ0ssZ0JBQWlCLG1CQUFrQkwsTUFBTSxDQUFDTSxXQUFZLEVBQUMsRUFDcEYsT0FBTyxDQUNSO1FBQ0QsT0FBT3RNLFFBQVEsQ0FBQ2tCLEVBQUUsQ0FBQztVQUNqQmYsSUFBSSxFQUFFO1lBQ0prTSxnQkFBZ0IsRUFBRUwsTUFBTSxDQUFDSyxnQkFBZ0I7WUFDekNDLFdBQVcsRUFBRU4sTUFBTSxDQUFDTTtVQUN0QjtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsTUFBTTtRQUNMLE1BQU0sSUFBSXBKLEtBQUssQ0FBQyx3Q0FBd0MsQ0FBQztNQUMzRDtJQUNGLENBQUMsQ0FBQyxPQUFPOUIsS0FBSyxFQUFFO01BQ2QsSUFBQUMsV0FBRyxFQUFDLHdCQUF3QixFQUFFRCxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO01BQ3JELE9BQU8sSUFBQW9CLDRCQUFhLEVBQ2xCcEIsS0FBSyxDQUFDRSxPQUFPLElBQUksd0NBQXdDLEVBQ3pELElBQUksRUFDSm9CLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDdkMzQyxRQUFRLENBQ1Q7SUFDSDtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTXVNLGFBQWFBLENBQUN6TSxPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBQzNHLElBQUk7TUFDRixNQUFNO1FBQUU2QyxFQUFFO1FBQUUySjtNQUFXLENBQUMsR0FBR3pNLE9BQU8sQ0FBQ0ksSUFBSTtNQUN2QztNQUNBLE1BQU0sSUFBSSxDQUFDUixjQUFjLENBQUM4TSxtQkFBbUIsQ0FBQzVKLEVBQUUsRUFBRTJKLFVBQVUsQ0FBQztNQUM3RCxPQUFPeE0sUUFBUSxDQUFDa0IsRUFBRSxDQUFDO1FBQ2pCZixJQUFJLEVBQUU7VUFDSnVFLFVBQVUsRUFBRWhDLDRCQUFpQixDQUFDYztRQUNoQztNQUNGLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPcEMsS0FBSyxFQUFFO01BQ2QsSUFBQUMsV0FBRyxFQUFDLHlCQUF5QixFQUFFRCxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO01BQ3RELE9BQU8sSUFBQW9CLDRCQUFhLEVBQ2xCcEIsS0FBSyxDQUFDRSxPQUFPLElBQUksMEJBQTBCLEVBQzNDLElBQUksRUFDSm9CLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDdkMzQyxRQUFRLENBQ1Q7SUFDSDtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UwTSxhQUFhQSxDQUFDNU0sT0FBOEIsRUFBRUMsT0FBc0IsRUFBRUMsUUFBK0IsRUFBRTtJQUNyRyxJQUFJO01BQ0YsTUFBTWdNLE1BQU0sR0FBR0MsSUFBSSxDQUFDUixLQUFLLENBQ3ZCUyxXQUFFLENBQUNDLFlBQVksQ0FBQyxJQUFJLENBQUN4TSxjQUFjLENBQUN5TSxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQ2xEO01BQ0QsT0FBT3BNLFFBQVEsQ0FBQ2tCLEVBQUUsQ0FBQztRQUNqQmYsSUFBSSxFQUFFO1VBQ0pxTSxVQUFVLEVBQUUsQ0FBQ1IsTUFBTSxDQUFDVyxLQUFLLENBQUM1TSxPQUFPLENBQUM0RCxNQUFNLENBQUNkLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFMkosVUFBVSxJQUFJLENBQUM7UUFDckU7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBT3BMLEtBQUssRUFBRTtNQUNkLElBQUFDLFdBQUcsRUFBQyx5QkFBeUIsRUFBRUQsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztNQUN0RCxPQUFPLElBQUFvQiw0QkFBYSxFQUNsQnBCLEtBQUssQ0FBQ0UsT0FBTyxJQUFJLHdDQUF3QyxFQUN6RCxJQUFJLEVBQ0pvQiw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQ3ZDM0MsUUFBUSxDQUNUO0lBQ0g7RUFDRjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQU00TSxZQUFZQSxDQUFDOU0sT0FBOEIsRUFBRUMsT0FBc0IsRUFBRUMsUUFBK0IsRUFBRTtJQUMxRyxJQUFJO01BQ0YsTUFBTWdNLE1BQU0sR0FBR0MsSUFBSSxDQUFDUixLQUFLLENBQUNTLFdBQUUsQ0FBQ0MsWUFBWSxDQUFDLElBQUksQ0FBQ3hNLGNBQWMsQ0FBQ3lNLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztNQUM1RSxPQUFPcE0sUUFBUSxDQUFDa0IsRUFBRSxDQUFDO1FBQ2pCZixJQUFJLEVBQUU7VUFDSnVFLFVBQVUsRUFBRWhDLDRCQUFpQixDQUFDYyxFQUFFO1VBQ2hDbEIsSUFBSSxFQUFFLENBQUNTLE1BQU0sQ0FBQzhKLE1BQU0sQ0FBQ2IsTUFBTSxDQUFDLENBQUMvSSxNQUFNLEdBQUcsRUFBRSxHQUFHK0k7UUFDN0M7TUFDRixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBTzVLLEtBQUssRUFBRTtNQUNkLElBQUFDLFdBQUcsRUFBQyx3QkFBd0IsRUFBRUQsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztNQUNyRCxPQUFPLElBQUFvQiw0QkFBYSxFQUNqQix5REFBd0RwQixLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBTSxFQUFDLEVBQ2pGLElBQUksRUFDSnNCLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFDdkMzQyxRQUFRLENBQ1Q7SUFDSDtFQUNGOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTThNLGVBQWVBLENBQUNoTixPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBQzdHLElBQUk7TUFDRixNQUFNb0QsU0FBUyxHQUFHLElBQUExQyw0QkFBb0IsRUFBQ1gsT0FBTyxDQUFDUyxPQUFPLENBQUNDLE1BQU0sRUFBQyxRQUFRLENBQUM7TUFDdkUsSUFBSSxDQUFDVixPQUFPLENBQUM0RCxNQUFNLElBQUksQ0FBQ1AsU0FBUyxJQUFJLENBQUNyRCxPQUFPLENBQUM0RCxNQUFNLENBQUNvSixLQUFLLEVBQUU7UUFDMUQsTUFBTSxJQUFJN0osS0FBSyxDQUFDLGtDQUFrQyxDQUFDO01BQ3JEO01BRUEsTUFBTTtRQUFFNko7TUFBTSxDQUFDLEdBQUdoTixPQUFPLENBQUM0RCxNQUFNO01BRWhDLE1BQU1yQixJQUFJLEdBQUcsTUFBTWdGLE9BQU8sQ0FBQzBGLEdBQUcsQ0FBQyxDQUM3QmxOLE9BQU8sQ0FBQ08sS0FBSyxDQUFDc0IsR0FBRyxDQUFDQyxNQUFNLENBQUNHLGNBQWMsQ0FBQ2hDLE9BQU8sQ0FBQyxLQUFLLEVBQUcsaUJBQWdCZ04sS0FBTSxXQUFVLEVBQUUsQ0FBQyxDQUFDLEVBQUU7UUFBRTNKO01BQVUsQ0FBQyxDQUFDLEVBQzVHdEQsT0FBTyxDQUFDTyxLQUFLLENBQUNzQixHQUFHLENBQUNDLE1BQU0sQ0FBQ0csY0FBYyxDQUFDaEMsT0FBTyxDQUFDLEtBQUssRUFBRyxpQkFBZ0JnTixLQUFNLEtBQUksRUFBRSxDQUFDLENBQUMsRUFBRTtRQUFFM0o7TUFBVSxDQUFDLENBQUMsQ0FDdkcsQ0FBQztNQUVGLE1BQU02SixNQUFNLEdBQUczSyxJQUFJLENBQUMrSSxHQUFHLENBQUNDLElBQUksSUFBSSxDQUFDQSxJQUFJLENBQUNoSixJQUFJLElBQUksQ0FBQyxDQUFDLEVBQUVBLElBQUksSUFBSSxFQUFFLENBQUM7TUFDN0QsTUFBTSxDQUFDNEssZ0JBQWdCLEVBQUVDLFVBQVUsQ0FBQyxHQUFHRixNQUFNOztNQUU3QztNQUNBLE1BQU1HLFlBQVksR0FBRztRQUNuQkMsUUFBUSxFQUNOLE9BQU9ILGdCQUFnQixLQUFLLFFBQVEsSUFBSW5LLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDa0ssZ0JBQWdCLENBQUMsQ0FBQ2pLLE1BQU0sR0FDeEU7VUFBRSxHQUFHaUssZ0JBQWdCLENBQUNwSixjQUFjLENBQUMsQ0FBQztRQUFFLENBQUMsR0FDekMsS0FBSztRQUNYd0osRUFBRSxFQUNBLE9BQU9ILFVBQVUsS0FBSyxRQUFRLElBQUlwSyxNQUFNLENBQUNDLElBQUksQ0FBQ21LLFVBQVUsQ0FBQyxDQUFDbEssTUFBTSxHQUM1RDtVQUFFLEdBQUdrSyxVQUFVLENBQUNySixjQUFjLENBQUMsQ0FBQztRQUFFLENBQUMsR0FDbkM7TUFDUixDQUFDO01BRUQsT0FBTzlELFFBQVEsQ0FBQ2tCLEVBQUUsQ0FBQztRQUNqQmYsSUFBSSxFQUFFaU47TUFDUixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBT2hNLEtBQUssRUFBRTtNQUNkLElBQUFDLFdBQUcsRUFBQywyQkFBMkIsRUFBRUQsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztNQUN4RCxPQUFPLElBQUFvQiw0QkFBYSxFQUFDcEIsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssRUFBRSxJQUFJLEVBQUVzQiw0QkFBaUIsQ0FBQ0MscUJBQXFCLEVBQUUzQyxRQUFRLENBQUM7SUFDdkc7RUFDRjtFQUNBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTXVOLGVBQWVBLENBQUN6TixPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBQzdHLElBQUk7TUFFRixNQUFNd04sYUFBYSxHQUFHLENBQUUsTUFBTSxJQUFBQyxrQ0FBZ0IsR0FBRSxFQUFHLGdCQUFnQixDQUFDLElBQUksRUFBRTtNQUMxRSxNQUFNQyxXQUFXLEdBQUcsQ0FBRSxNQUFNLElBQUFELGtDQUFnQixHQUFFLEVBQUcsNEJBQTRCLENBQUM7TUFDOUUsTUFBTW5MLElBQUksR0FBRyxDQUFDLE1BQU14QyxPQUFPLENBQUNPLEtBQUssQ0FBQ0MsUUFBUSxDQUFDQyxjQUFjLENBQUNSLE9BQU8sRUFBRUQsT0FBTyxDQUFDLEVBQUU2TixXQUFXO01BRXhGLE1BQU1KLGVBQWUsR0FBRyxDQUFDLENBQUNqTCxJQUFJLENBQUNzTCxLQUFLLElBQUksRUFBRSxFQUFFQyxJQUFJLENBQUVDLElBQUksSUFBS04sYUFBYSxDQUFDbkksUUFBUSxDQUFDeUksSUFBSSxDQUFDLENBQUM7TUFFeEYsT0FBTzlOLFFBQVEsQ0FBQ2tCLEVBQUUsQ0FBQztRQUNqQmYsSUFBSSxFQUFFO1VBQUVvTixlQUFlO1VBQUVHO1FBQVk7TUFDdkMsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU90TSxLQUFLLEVBQUU7TUFDZCxJQUFBQyxXQUFHLEVBQUMsMkJBQTJCLEVBQUVELEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLENBQUM7TUFDeEQsT0FBTyxJQUFBb0IsNEJBQWEsRUFBQ3BCLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLLEVBQUUsSUFBSSxFQUFFc0IsNEJBQWlCLENBQUNDLHFCQUFxQixFQUFFM0MsUUFBUSxDQUFDO0lBQ3ZHO0VBRUY7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTStOLFdBQVdBLENBQUNqTyxPQUE4QixFQUFFQyxPQUFzQixFQUFFQyxRQUErQixFQUFFO0lBQ3pHLElBQUk7TUFDRixNQUFNZ08sYUFBYSxHQUFHLElBQUFQLGtDQUFnQixHQUFFO01BQ3hDLE1BQU1RLFlBQVksR0FBRyw0QkFBNEI7TUFDakQsTUFBTUMsUUFBUSxHQUFHLHdCQUF3QjtNQUN6QyxNQUFNQyxnQkFBZ0IsR0FBRyxnQ0FBZ0M7TUFFekQsTUFBTUMsS0FBSyxHQUFFO1FBQ1gsQ0FBQ0gsWUFBWSxHQUFHLElBQUFJLGlDQUF1QixFQUFDTCxhQUFhLEVBQUVDLFlBQVksQ0FBQztRQUNwRSxDQUFDQyxRQUFRLEdBQUcsSUFBQUcsaUNBQXVCLEVBQUNMLGFBQWEsRUFBRUUsUUFBUSxDQUFDO1FBQzVELENBQUNDLGdCQUFnQixHQUFHLElBQUFFLGlDQUF1QixFQUFDTCxhQUFhLEVBQUVHLGdCQUFnQjtNQUM3RSxDQUFDO01BRUQsT0FBT25PLFFBQVEsQ0FBQ2tCLEVBQUUsQ0FBQztRQUNqQmYsSUFBSSxFQUFFO1VBQUVpTztRQUFNO01BQ2hCLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQyxPQUFPaE4sS0FBSyxFQUFFO01BQ2QsSUFBQUMsV0FBRyxFQUFDLHVCQUF1QixFQUFFRCxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO01BQ3BELE9BQU8sSUFBQW9CLDRCQUFhLEVBQUNwQixLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxFQUFFLElBQUksRUFBRXNCLDRCQUFpQixDQUFDQyxxQkFBcUIsRUFBRTNDLFFBQVEsQ0FBQztJQUN2RztFQUVGO0FBQ0Y7QUFBQ3NPLE9BQUEsQ0FBQWpQLFlBQUEsR0FBQUEsWUFBQSJ9