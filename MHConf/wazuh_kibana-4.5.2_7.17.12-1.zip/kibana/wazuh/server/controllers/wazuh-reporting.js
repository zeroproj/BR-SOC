"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhReportingCtrl = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _path = _interopRequireDefault(require("path"));
var _fs = _interopRequireDefault(require("fs"));
var _wazuhModules = require("../../common/wazuh-modules");
var TimSort = _interopRequireWildcard(require("timsort"));
var _errorResponse = require("../lib/error-response");
var _processStateEquivalence = _interopRequireDefault(require("../lib/process-state-equivalence"));
var _csvKeyEquivalence = require("../../common/csv-key-equivalence");
var _agentConfiguration = require("../lib/reporting/agent-configuration");
var _extendedInformation = require("../lib/reporting/extended-information");
var _printer = require("../lib/reporting/printer");
var _logger = require("../lib/logger");
var _constants = require("../../common/constants");
var _filesystem = require("../lib/filesystem");
var _wz_agent_status = require("../../common/services/wz_agent_status");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
/*
 * Wazuh app - Class for Wazuh reporting controller
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */

class WazuhReportingCtrl {
  constructor() {
    /**
     * Create a report for the modules
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {*} reports list or ErrorResponse
     */
    (0, _defineProperty2.default)(this, "createReportsModules", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:createReportsModules', `Report started`, 'info');
        const {
          array,
          agents,
          browserTimezone,
          searchBar,
          filters,
          serverSideQuery,
          time,
          tables,
          section,
          indexPatternTitle,
          apiId
        } = request.body;
        const {
          moduleID
        } = request.params;
        const {
          from,
          to
        } = time || {};
        let additionalTables = [];
        // Init
        const printer = new _printer.ReportPrinter();
        (0, _filesystem.createDataDirectoryIfNotExists)();
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, context.wazuhEndpointParams.hashUsername));
        await this.renderHeader(context, printer, section, moduleID, agents, apiId);
        const [sanitizedFilters, agentsFilter] = filters ? this.sanitizeKibanaFilters(filters, searchBar) : [false, null];
        if (time && sanitizedFilters) {
          printer.addTimeRangeAndFilters(from, to, sanitizedFilters, browserTimezone);
        }
        if (time) {
          additionalTables = await (0, _extendedInformation.extendedInformation)(context, printer, section, moduleID, apiId, new Date(from).getTime(), new Date(to).getTime(), serverSideQuery, agentsFilter, indexPatternTitle, agents);
        }
        printer.addVisualizations(array, agents, moduleID);
        if (tables) {
          printer.addTables([...tables, ...(additionalTables || [])]);
        }

        //add authorized agents
        if (agentsFilter !== null && agentsFilter !== void 0 && agentsFilter.agentsText) {
          printer.addAgentsFilters(agentsFilter.agentsText);
        }
        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`
          }
        });
      } catch (error) {
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      body: {
        agents
      },
      params: {
        moduleID
      }
    }) => `wazuh-module-${agents ? `agents-${agents}` : 'overview'}-${moduleID}-${this.generateReportTimestamp()}.pdf`));
    /**
     * Create a report for the groups
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {*} reports list or ErrorResponse
     */
    (0, _defineProperty2.default)(this, "createReportsGroups", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:createReportsGroups', `Report started`, 'info');
        const {
          components,
          apiId
        } = request.body;
        const {
          groupID
        } = request.params;
        // Init
        const printer = new _printer.ReportPrinter();
        (0, _filesystem.createDataDirectoryIfNotExists)();
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, context.wazuhEndpointParams.hashUsername));
        let tables = [];
        const equivalences = {
          localfile: 'Local files',
          osquery: 'Osquery',
          command: 'Command',
          syscheck: 'Syscheck',
          'open-scap': 'OpenSCAP',
          'cis-cat': 'CIS-CAT',
          syscollector: 'Syscollector',
          rootcheck: 'Rootcheck',
          labels: 'Labels',
          sca: 'Security configuration assessment'
        };
        printer.addContent({
          text: `Group ${groupID} configuration`,
          style: 'h1'
        });

        // Group configuration
        if (components['0']) {
          const {
            data: {
              data: configuration
            }
          } = await context.wazuh.api.client.asCurrentUser.request('GET', `/groups/${groupID}/configuration`, {}, {
            apiHostID: apiId
          });
          if (configuration.affected_items.length > 0 && Object.keys(configuration.affected_items[0].config).length) {
            printer.addContent({
              text: 'Configurations',
              style: {
                fontSize: 14,
                color: '#000'
              },
              margin: [0, 10, 0, 15]
            });
            const section = {
              labels: [],
              isGroupConfig: true
            };
            for (let config of configuration.affected_items) {
              let filterTitle = '';
              let index = 0;
              for (let filter of Object.keys(config.filters)) {
                filterTitle = filterTitle.concat(`${filter}: ${config.filters[filter]}`);
                if (index < Object.keys(config.filters).length - 1) {
                  filterTitle = filterTitle.concat(' | ');
                }
                index++;
              }
              printer.addContent({
                text: filterTitle,
                style: 'h4',
                margin: [0, 0, 0, 10]
              });
              let idx = 0;
              section.tabs = [];
              for (let _d of Object.keys(config.config)) {
                for (let c of _agentConfiguration.AgentConfiguration.configurations) {
                  for (let s of c.sections) {
                    section.opts = s.opts || {};
                    for (let cn of s.config || []) {
                      if (cn.configuration === _d) {
                        section.labels = s.labels || [[]];
                      }
                    }
                    for (let wo of s.wodle || []) {
                      if (wo.name === _d) {
                        section.labels = s.labels || [[]];
                      }
                    }
                  }
                }
                section.labels[0]['pack'] = 'Packs';
                section.labels[0]['content'] = 'Evaluations';
                section.labels[0]['7'] = 'Scan listening netwotk ports';
                section.tabs.push(equivalences[_d]);
                if (Array.isArray(config.config[_d])) {
                  /* LOG COLLECTOR */
                  if (_d === 'localfile') {
                    let groups = [];
                    config.config[_d].forEach(obj => {
                      if (!groups[obj.logformat]) {
                        groups[obj.logformat] = [];
                      }
                      groups[obj.logformat].push(obj);
                    });
                    Object.keys(groups).forEach(group => {
                      let saveidx = 0;
                      groups[group].forEach((x, i) => {
                        if (Object.keys(x).length > Object.keys(groups[group][saveidx]).length) {
                          saveidx = i;
                        }
                      });
                      const columns = Object.keys(groups[group][saveidx]);
                      const rows = groups[group].map(x => {
                        let row = [];
                        columns.forEach(key => {
                          row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
                            return x + '\n';
                          }) : JSON.stringify(x[key]));
                        });
                        return row;
                      });
                      columns.forEach((col, i) => {
                        columns[i] = col[0].toUpperCase() + col.slice(1);
                      });
                      tables.push({
                        title: 'Local files',
                        type: 'table',
                        columns,
                        rows
                      });
                    });
                  } else if (_d === 'labels') {
                    const obj = config.config[_d][0].label;
                    const columns = Object.keys(obj[0]);
                    if (!columns.includes('hidden')) {
                      columns.push('hidden');
                    }
                    const rows = obj.map(x => {
                      let row = [];
                      columns.forEach(key => {
                        row.push(x[key]);
                      });
                      return row;
                    });
                    columns.forEach((col, i) => {
                      columns[i] = col[0].toUpperCase() + col.slice(1);
                    });
                    tables.push({
                      title: 'Labels',
                      type: 'table',
                      columns,
                      rows
                    });
                  } else {
                    for (let _d2 of config.config[_d]) {
                      tables.push(...this.getConfigTables(_d2, section, idx));
                    }
                  }
                } else {
                  /*INTEGRITY MONITORING MONITORED DIRECTORIES */
                  if (config.config[_d].directories) {
                    const directories = config.config[_d].directories;
                    delete config.config[_d].directories;
                    tables.push(...this.getConfigTables(config.config[_d], section, idx));
                    let diffOpts = [];
                    Object.keys(section.opts).forEach(x => {
                      diffOpts.push(x);
                    });
                    const columns = ['', ...diffOpts.filter(x => x !== 'check_all' && x !== 'check_sum')];
                    let rows = [];
                    directories.forEach(x => {
                      let row = [];
                      row.push(x.path);
                      columns.forEach(y => {
                        if (y !== '') {
                          y = y !== 'check_whodata' ? y : 'whodata';
                          row.push(x[y] ? x[y] : 'no');
                        }
                      });
                      row.push(x.recursion_level);
                      rows.push(row);
                    });
                    columns.forEach((x, idx) => {
                      columns[idx] = section.opts[x];
                    });
                    columns.push('RL');
                    tables.push({
                      title: 'Monitored directories',
                      type: 'table',
                      columns,
                      rows
                    });
                  } else {
                    tables.push(...this.getConfigTables(config.config[_d], section, idx));
                  }
                }
                for (const table of tables) {
                  printer.addConfigTables([table]);
                }
                idx++;
                tables = [];
              }
              tables = [];
            }
          } else {
            printer.addContent({
              text: 'A configuration for this group has not yet been set up.',
              style: {
                fontSize: 12,
                color: '#000'
              },
              margin: [0, 10, 0, 15]
            });
          }
        }

        // Agents in group
        if (components['1']) {
          await this.renderHeader(context, printer, 'groupConfig', groupID, [], apiId);
        }
        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`
          }
        });
      } catch (error) {
        (0, _logger.log)('reporting:createReportsGroups', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      params: {
        groupID
      }
    }) => `wazuh-group-configuration-${groupID}-${this.generateReportTimestamp()}.pdf`));
    /**
     * Create a report for the agents
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {*} reports list or ErrorResponse
     */
    (0, _defineProperty2.default)(this, "createReportsAgentsConfiguration", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:createReportsAgentsConfiguration', `Report started`, 'info');
        const {
          components,
          apiId
        } = request.body;
        const {
          agentID
        } = request.params;
        const printer = new _printer.ReportPrinter();
        (0, _filesystem.createDataDirectoryIfNotExists)();
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, context.wazuhEndpointParams.hashUsername));
        let wmodulesResponse = {};
        let tables = [];
        try {
          wmodulesResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents/${agentID}/config/wmodules/wmodules`, {}, {
            apiHostID: apiId
          });
        } catch (error) {
          (0, _logger.log)('reporting:report', error.message || error, 'debug');
        }
        await this.renderHeader(context, printer, 'agentConfig', 'agentConfig', agentID, apiId);
        let idxComponent = 0;
        for (let config of _agentConfiguration.AgentConfiguration.configurations) {
          let titleOfSection = false;
          (0, _logger.log)('reporting:createReportsAgentsConfiguration', `Iterate over ${config.sections.length} configuration sections`, 'debug');
          for (let section of config.sections) {
            let titleOfSubsection = false;
            if (components[idxComponent] && (section.config || section.wodle)) {
              let idx = 0;
              const configs = (section.config || []).concat(section.wodle || []);
              (0, _logger.log)('reporting:createReportsAgentsConfiguration', `Iterate over ${configs.length} configuration blocks`, 'debug');
              for (let conf of configs) {
                let agentConfigResponse = {};
                try {
                  if (!conf['name']) {
                    agentConfigResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents/${agentID}/config/${conf.component}/${conf.configuration}`, {}, {
                      apiHostID: apiId
                    });
                  } else {
                    for (let wodle of wmodulesResponse.data.data['wmodules']) {
                      if (Object.keys(wodle)[0] === conf['name']) {
                        agentConfigResponse.data = {
                          data: wodle
                        };
                      }
                    }
                  }
                  const agentConfig = agentConfigResponse && agentConfigResponse.data && agentConfigResponse.data.data;
                  if (!titleOfSection) {
                    printer.addContent({
                      text: config.title,
                      style: 'h1',
                      margin: [0, 0, 0, 15]
                    });
                    titleOfSection = true;
                  }
                  if (!titleOfSubsection) {
                    printer.addContent({
                      text: section.subtitle,
                      style: 'h4'
                    });
                    printer.addContent({
                      text: section.desc,
                      style: {
                        fontSize: 12,
                        color: '#000'
                      },
                      margin: [0, 0, 0, 10]
                    });
                    titleOfSubsection = true;
                  }
                  if (agentConfig) {
                    for (let agentConfigKey of Object.keys(agentConfig)) {
                      if (Array.isArray(agentConfig[agentConfigKey])) {
                        /* LOG COLLECTOR */
                        if (conf.filterBy) {
                          let groups = [];
                          agentConfig[agentConfigKey].forEach(obj => {
                            if (!groups[obj.logformat]) {
                              groups[obj.logformat] = [];
                            }
                            groups[obj.logformat].push(obj);
                          });
                          Object.keys(groups).forEach(group => {
                            let saveidx = 0;
                            groups[group].forEach((x, i) => {
                              if (Object.keys(x).length > Object.keys(groups[group][saveidx]).length) {
                                saveidx = i;
                              }
                            });
                            const columns = Object.keys(groups[group][saveidx]);
                            const rows = groups[group].map(x => {
                              let row = [];
                              columns.forEach(key => {
                                row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
                                  return x + '\n';
                                }) : JSON.stringify(x[key]));
                              });
                              return row;
                            });
                            columns.forEach((col, i) => {
                              columns[i] = col[0].toUpperCase() + col.slice(1);
                            });
                            tables.push({
                              title: section.labels[0][group],
                              type: 'table',
                              columns,
                              rows
                            });
                          });
                        } else if (agentConfigKey.configuration !== 'socket') {
                          tables.push(...this.getConfigTables(agentConfig[agentConfigKey], section, idx));
                        } else {
                          for (let _d2 of agentConfig[agentConfigKey]) {
                            tables.push(...this.getConfigTables(_d2, section, idx));
                          }
                        }
                      } else {
                        /*INTEGRITY MONITORING MONITORED DIRECTORIES */
                        if (conf.matrix) {
                          const {
                            directories,
                            diff,
                            synchronization,
                            file_limit,
                            ...rest
                          } = agentConfig[agentConfigKey];
                          tables.push(...this.getConfigTables(rest, section, idx), ...(diff && diff.disk_quota ? this.getConfigTables(diff.disk_quota, {
                            tabs: ['Disk quota']
                          }, 0) : []), ...(diff && diff.file_size ? this.getConfigTables(diff.file_size, {
                            tabs: ['File size']
                          }, 0) : []), ...(synchronization ? this.getConfigTables(synchronization, {
                            tabs: ['Synchronization']
                          }, 0) : []), ...(file_limit ? this.getConfigTables(file_limit, {
                            tabs: ['File limit']
                          }, 0) : []));
                          let diffOpts = [];
                          Object.keys(section.opts).forEach(x => {
                            diffOpts.push(x);
                          });
                          const columns = ['', ...diffOpts.filter(x => x !== 'check_all' && x !== 'check_sum')];
                          let rows = [];
                          directories.forEach(x => {
                            let row = [];
                            row.push(x.dir);
                            columns.forEach(y => {
                              if (y !== '') {
                                row.push(x.opts.indexOf(y) > -1 ? 'yes' : 'no');
                              }
                            });
                            row.push(x.recursion_level);
                            rows.push(row);
                          });
                          columns.forEach((x, idx) => {
                            columns[idx] = section.opts[x];
                          });
                          columns.push('RL');
                          tables.push({
                            title: 'Monitored directories',
                            type: 'table',
                            columns,
                            rows
                          });
                        } else {
                          tables.push(...this.getConfigTables(agentConfig[agentConfigKey], section, idx));
                        }
                      }
                    }
                  } else {
                    // Print no configured module and link to the documentation
                    printer.addContent({
                      text: ['This module is not configured. Please take a look on how to configure it in ', {
                        text: `${section.subtitle.toLowerCase()} configuration.`,
                        link: section.docuLink,
                        style: {
                          fontSize: 12,
                          color: '#1a0dab'
                        }
                      }],
                      margin: [0, 0, 0, 20]
                    });
                  }
                } catch (error) {
                  (0, _logger.log)('reporting:report', error.message || error, 'debug');
                }
                idx++;
              }
              for (const table of tables) {
                printer.addConfigTables([table]);
              }
            }
            idxComponent++;
            tables = [];
          }
        }
        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`
          }
        });
      } catch (error) {
        (0, _logger.log)('reporting:createReportsAgentsConfiguration', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      params: {
        agentID
      }
    }) => `wazuh-agent-configuration-${agentID}-${this.generateReportTimestamp()}.pdf`));
    /**
     * Create a report for the agents
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {*} reports list or ErrorResponse
     */
    (0, _defineProperty2.default)(this, "createReportsAgentsInventory", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:createReportsAgentsInventory', `Report started`, 'info');
        const {
          searchBar,
          filters,
          time,
          indexPatternTitle,
          apiId,
          serverSideQuery
        } = request.body;
        const {
          agentID
        } = request.params;
        const {
          from,
          to
        } = time || {};
        // Init
        const printer = new _printer.ReportPrinter();
        const {
          hashUsername
        } = await context.wazuh.security.getCurrentUser(request, context);
        (0, _filesystem.createDataDirectoryIfNotExists)();
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
        (0, _filesystem.createDirectoryIfNotExists)(_path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, hashUsername));
        (0, _logger.log)('reporting:createReportsAgentsInventory', `Syscollector report`, 'debug');
        const [sanitizedFilters, agentsFilter] = filters ? this.sanitizeKibanaFilters(filters, searchBar) : [false, null];

        // Get the agent OS
        let agentOs = '';
        try {
          const agentResponse = await context.wazuh.api.client.asCurrentUser.request('GET', '/agents', {
            params: {
              q: `id=${agentID}`
            }
          }, {
            apiHostID: apiId
          });
          agentOs = agentResponse.data.data.affected_items[0].os.platform;
        } catch (error) {
          (0, _logger.log)('reporting:createReportsAgentsInventory', error.message || error, 'debug');
        }

        // Add title
        printer.addContentWithNewLine({
          text: 'Inventory data report',
          style: 'h1'
        });

        // Add table with the agent info
        await (0, _extendedInformation.buildAgentsTable)(context, printer, [agentID], apiId);

        // Get syscollector packages and processes
        const agentRequestsInventory = [{
          endpoint: `/syscollector/${agentID}/packages`,
          loggerMessage: `Fetching packages for agent ${agentID}`,
          table: {
            title: 'Packages',
            columns: agentOs === 'windows' ? [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'architecture',
              label: 'Architecture'
            }, {
              id: 'version',
              label: 'Version'
            }, {
              id: 'vendor',
              label: 'Vendor'
            }] : [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'architecture',
              label: 'Architecture'
            }, {
              id: 'version',
              label: 'Version'
            }, {
              id: 'vendor',
              label: 'Vendor'
            }, {
              id: 'description',
              label: 'Description'
            }]
          }
        }, {
          endpoint: `/syscollector/${agentID}/processes`,
          loggerMessage: `Fetching processes for agent ${agentID}`,
          table: {
            title: 'Processes',
            columns: agentOs === 'windows' ? [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'cmd',
              label: 'CMD'
            }, {
              id: 'priority',
              label: 'Priority'
            }, {
              id: 'nlwp',
              label: 'NLWP'
            }] : [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'euser',
              label: 'Effective user'
            }, {
              id: 'nice',
              label: 'Priority'
            }, {
              id: 'state',
              label: 'State'
            }]
          },
          mapResponseItems: item => agentOs === 'windows' ? item : {
            ...item,
            state: _processStateEquivalence.default[item.state]
          }
        }, {
          endpoint: `/syscollector/${agentID}/ports`,
          loggerMessage: `Fetching ports for agent ${agentID}`,
          table: {
            title: 'Network ports',
            columns: agentOs === 'windows' ? [{
              id: 'local_ip',
              label: 'Local IP address'
            }, {
              id: 'local_port',
              label: 'Local port'
            }, {
              id: 'process',
              label: 'Process'
            }, {
              id: 'state',
              label: 'State'
            }, {
              id: 'protocol',
              label: 'Protocol'
            }] : [{
              id: 'local_ip',
              label: 'Local IP address'
            }, {
              id: 'local_port',
              label: 'Local port'
            }, {
              id: 'state',
              label: 'State'
            }, {
              id: 'protocol',
              label: 'Protocol'
            }]
          },
          mapResponseItems: item => ({
            ...item,
            local_ip: item.local.ip,
            local_port: item.local.port
          })
        }, {
          endpoint: `/syscollector/${agentID}/netiface`,
          loggerMessage: `Fetching netiface for agent ${agentID}`,
          table: {
            title: 'Network interfaces',
            columns: [{
              id: 'name',
              label: 'Name'
            }, {
              id: 'mac',
              label: 'Mac'
            }, {
              id: 'state',
              label: 'State'
            }, {
              id: 'mtu',
              label: 'MTU'
            }, {
              id: 'type',
              label: 'Type'
            }]
          }
        }, {
          endpoint: `/syscollector/${agentID}/netaddr`,
          loggerMessage: `Fetching netaddr for agent ${agentID}`,
          table: {
            title: 'Network settings',
            columns: [{
              id: 'iface',
              label: 'Interface'
            }, {
              id: 'address',
              label: 'Address'
            }, {
              id: 'netmask',
              label: 'Netmask'
            }, {
              id: 'proto',
              label: 'Protocol'
            }, {
              id: 'broadcast',
              label: 'Broadcast'
            }]
          }
        }];
        agentOs === 'windows' && agentRequestsInventory.push({
          endpoint: `/syscollector/${agentID}/hotfixes`,
          loggerMessage: `Fetching hotfixes for agent ${agentID}`,
          table: {
            title: 'Windows updates',
            columns: [{
              id: 'hotfix',
              label: 'Update code'
            }]
          }
        });
        const requestInventory = async agentRequestInventory => {
          try {
            (0, _logger.log)('reporting:createReportsAgentsInventory', agentRequestInventory.loggerMessage, 'debug');
            const inventoryResponse = await context.wazuh.api.client.asCurrentUser.request('GET', agentRequestInventory.endpoint, {}, {
              apiHostID: apiId
            });
            const inventory = inventoryResponse && inventoryResponse.data && inventoryResponse.data.data && inventoryResponse.data.data.affected_items;
            if (inventory) {
              return {
                ...agentRequestInventory.table,
                items: agentRequestInventory.mapResponseItems ? inventory.map(agentRequestInventory.mapResponseItems) : inventory
              };
            }
          } catch (error) {
            (0, _logger.log)('reporting:createReportsAgentsInventory', error.message || error, 'debug');
          }
        };
        if (time) {
          var _serverSideQuery$bool, _serverSideQuery$bool2, _serverSideQuery$bool3;
          // Add Vulnerability Detector filter to the Server Side Query
          serverSideQuery === null || serverSideQuery === void 0 ? void 0 : (_serverSideQuery$bool = serverSideQuery.bool) === null || _serverSideQuery$bool === void 0 ? void 0 : (_serverSideQuery$bool2 = _serverSideQuery$bool.must) === null || _serverSideQuery$bool2 === void 0 ? void 0 : (_serverSideQuery$bool3 = _serverSideQuery$bool2.push) === null || _serverSideQuery$bool3 === void 0 ? void 0 : _serverSideQuery$bool3.call(_serverSideQuery$bool2, {
            match_phrase: {
              "rule.groups": {
                query: "vulnerability-detector"
              }
            }
          });
          await (0, _extendedInformation.extendedInformation)(context, printer, 'agents', 'syscollector', apiId, from, to, serverSideQuery, agentsFilter, indexPatternTitle, agentID);
        }

        // Add inventory tables
        (await Promise.all(agentRequestsInventory.map(requestInventory))).filter(table => table).forEach(table => printer.addSimpleTable(table));

        // Print the document
        await printer.print(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          body: {
            success: true,
            message: `Report ${context.wazuhEndpointParams.filename} was created`
          }
        });
      } catch (error) {
        (0, _logger.log)('reporting:createReportsAgents', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5029, 500, response);
      }
    }, ({
      params: {
        agentID
      }
    }) => `wazuh-agent-inventory-${agentID}-${this.generateReportTimestamp()}.pdf`));
    /**
     * Fetch specific report
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {Object} report or ErrorResponse
     */
    (0, _defineProperty2.default)(this, "getReportByName", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:getReportByName', `Getting ${context.wazuhEndpointParams.pathFilename} report`, 'debug');
        const reportFileBuffer = _fs.default.readFileSync(context.wazuhEndpointParams.pathFilename);
        return response.ok({
          headers: {
            'Content-Type': 'application/pdf'
          },
          body: reportFileBuffer
        });
      } catch (error) {
        (0, _logger.log)('reporting:getReportByName', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5030, 500, response);
      }
    }, request => request.params.name));
    /**
     * Delete specific report
     * @param {Object} context
     * @param {Object} request
     * @param {Object} response
     * @returns {Object} status obj or ErrorResponse
     */
    (0, _defineProperty2.default)(this, "deleteReportByName", this.checkReportsUserDirectoryIsValidRouteDecorator(async (context, request, response) => {
      try {
        (0, _logger.log)('reporting:deleteReportByName', `Deleting ${context.wazuhEndpointParams.pathFilename} report`, 'debug');
        _fs.default.unlinkSync(context.wazuhEndpointParams.pathFilename);
        (0, _logger.log)('reporting:deleteReportByName', `${context.wazuhEndpointParams.pathFilename} report was deleted`, 'info');
        return response.ok({
          body: {
            error: 0
          }
        });
      } catch (error) {
        (0, _logger.log)('reporting:deleteReportByName', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5032, 500, response);
      }
    }, request => request.params.name));
  }
  /**
   * This do format to filters
   * @param {String} filters E.g: cluster.name: wazuh AND rule.groups: vulnerability
   * @param {String} searchBar search term
   */
  sanitizeKibanaFilters(filters, searchBar) {
    (0, _logger.log)('reporting:sanitizeKibanaFilters', `Started to sanitize filters`, 'info');
    (0, _logger.log)('reporting:sanitizeKibanaFilters', `filters: ${filters.length}, searchBar: ${searchBar}`, 'debug');
    let str = '';
    const agentsFilter = {
      query: {},
      agentsText: ''
    };
    const agentsList = [];

    //separate agents filter
    filters = filters.filter(filter => {
      if (filter.meta.controlledBy === _constants.AUTHORIZED_AGENTS) {
        agentsFilter.query = filter.query;
        agentsList.push(filter);
        return false;
      }
      return filter;
    });
    const len = filters.length;
    for (let i = 0; i < len; i++) {
      const {
        negate,
        key,
        value,
        params,
        type
      } = filters[i].meta;
      str += `${negate ? 'NOT ' : ''}`;
      str += `${key}: `;
      str += `${type === 'range' ? `${params.gte}-${params.lt}` : type === 'phrases' ? '(' + params.join(" OR ") + ')' : type === 'exists' ? '*' : !!value ? value : (params || {}).query}`;
      str += `${i === len - 1 ? '' : ' AND '}`;
    }
    if (searchBar) {
      str += ` AND (${searchBar})`;
    }
    agentsFilter.agentsText = agentsList.map(filter => filter.meta.value).join(',');
    (0, _logger.log)('reporting:sanitizeKibanaFilters', `str: ${str}, agentsFilterStr: ${agentsFilter.agentsText}`, 'debug');
    return [str, agentsFilter];
  }

  /**
   * This performs the rendering of given header
   * @param {String} printer section target
   * @param {String} section section target
   * @param {Object} tab tab target
   * @param {Boolean} isAgents is agents section
   * @param {String} apiId ID of API
   */
  async renderHeader(context, printer, section, tab, isAgents, apiId) {
    try {
      (0, _logger.log)('reporting:renderHeader', `section: ${section}, tab: ${tab}, isAgents: ${isAgents}, apiId: ${apiId}`, 'debug');
      if (section && typeof section === 'string') {
        if (!['agentConfig', 'groupConfig'].includes(section)) {
          printer.addContent({
            text: _wazuhModules.WAZUH_MODULES[tab].title + ' report',
            style: 'h1'
          });
        } else if (section === 'agentConfig') {
          printer.addContent({
            text: `Agent ${isAgents} configuration`,
            style: 'h1'
          });
        } else if (section === 'groupConfig') {
          printer.addContent({
            text: 'Agents in group',
            style: 'h1'
          });
        }
        printer.addNewLine();
      }
      if (isAgents && typeof isAgents === 'object') {
        await (0, _extendedInformation.buildAgentsTable)(context, printer, isAgents, apiId, section === 'groupConfig' ? tab : '');
      }
      if (isAgents && typeof isAgents === 'string') {
        const agentResponse = await context.wazuh.api.client.asCurrentUser.request('GET', `/agents`, {
          params: {
            agents_list: isAgents
          }
        }, {
          apiHostID: apiId
        });
        const agentData = agentResponse.data.data.affected_items[0];
        if (agentData && agentData.status !== _constants.API_NAME_AGENT_STATUS.ACTIVE) {
          printer.addContentWithNewLine({
            text: `Warning. Agent is ${(0, _wz_agent_status.agentStatusLabelByAgentStatus)(agentData.status).toLowerCase()}`,
            style: 'standard'
          });
        }
        await (0, _extendedInformation.buildAgentsTable)(context, printer, [isAgents], apiId);
        if (agentData && agentData.group) {
          const agentGroups = agentData.group.join(', ');
          printer.addContentWithNewLine({
            text: `Group${agentData.group.length > 1 ? 's' : ''}: ${agentGroups}`,
            style: 'standard'
          });
        }
      }
      if (_wazuhModules.WAZUH_MODULES[tab] && _wazuhModules.WAZUH_MODULES[tab].description) {
        printer.addContentWithNewLine({
          text: _wazuhModules.WAZUH_MODULES[tab].description,
          style: 'standard'
        });
      }
    } catch (error) {
      (0, _logger.log)('reporting:renderHeader', error.message || error);
      return Promise.reject(error);
    }
  }
  getConfigRows(data, labels) {
    (0, _logger.log)('reporting:getConfigRows', `Building configuration rows`, 'info');
    const result = [];
    for (let prop in data || []) {
      if (Array.isArray(data[prop])) {
        data[prop].forEach((x, idx) => {
          if (typeof x === 'object') data[prop][idx] = JSON.stringify(x);
        });
      }
      result.push([(labels || {})[prop] || _csvKeyEquivalence.KeyEquivalence[prop] || prop, data[prop] || '-']);
    }
    return result;
  }
  getConfigTables(data, section, tab, array = []) {
    (0, _logger.log)('reporting:getConfigTables', `Building configuration tables`, 'info');
    let plainData = {};
    const nestedData = [];
    const tableData = [];
    if (data.length === 1 && Array.isArray(data)) {
      tableData[section.config[tab].configuration] = data;
    } else {
      for (let key in data) {
        if (typeof data[key] !== 'object' && !Array.isArray(data[key]) || Array.isArray(data[key]) && typeof data[key][0] !== 'object') {
          plainData[key] = Array.isArray(data[key]) && typeof data[key][0] !== 'object' ? data[key].map(x => {
            return typeof x === 'object' ? JSON.stringify(x) : x + '\n';
          }) : data[key];
        } else if (Array.isArray(data[key]) && typeof data[key][0] === 'object') {
          tableData[key] = data[key];
        } else {
          if (section.isGroupConfig && ['pack', 'content'].includes(key)) {
            tableData[key] = [data[key]];
          } else {
            nestedData.push(data[key]);
          }
        }
      }
    }
    array.push({
      title: (section.options || {}).hideHeader ? '' : (section.tabs || [])[tab] || (section.isGroupConfig ? ((section.labels || [])[0] || [])[tab] : ''),
      columns: ['', ''],
      type: 'config',
      rows: this.getConfigRows(plainData, (section.labels || [])[0])
    });
    for (let key in tableData) {
      const columns = Object.keys(tableData[key][0]);
      columns.forEach((col, i) => {
        columns[i] = col[0].toUpperCase() + col.slice(1);
      });
      const rows = tableData[key].map(x => {
        let row = [];
        for (let key in x) {
          row.push(typeof x[key] !== 'object' ? x[key] : Array.isArray(x[key]) ? x[key].map(x => {
            return x + '\n';
          }) : JSON.stringify(x[key]));
        }
        while (row.length < columns.length) {
          row.push('-');
        }
        return row;
      });
      array.push({
        title: ((section.labels || [])[0] || [])[key] || '',
        type: 'table',
        columns,
        rows
      });
    }
    nestedData.forEach(nest => {
      this.getConfigTables(nest, section, tab + 1, array);
    });
    return array;
  }
  /**
   * Fetch the reports list
   * @param {Object} context
   * @param {Object} request
   * @param {Object} response
   * @returns {Array<Object>} reports list or ErrorResponse
   */
  async getReports(context, request, response) {
    try {
      (0, _logger.log)('reporting:getReports', `Fetching created reports`, 'info');
      const {
        hashUsername
      } = await context.wazuh.security.getCurrentUser(request, context);
      (0, _filesystem.createDataDirectoryIfNotExists)();
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH);
      (0, _filesystem.createDirectoryIfNotExists)(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH);
      const userReportsDirectoryPath = _path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, hashUsername);
      (0, _filesystem.createDirectoryIfNotExists)(userReportsDirectoryPath);
      (0, _logger.log)('reporting:getReports', `Directory: ${userReportsDirectoryPath}`, 'debug');
      const sortReportsByDate = (a, b) => a.date < b.date ? 1 : a.date > b.date ? -1 : 0;
      const reports = _fs.default.readdirSync(userReportsDirectoryPath).map(file => {
        const stats = _fs.default.statSync(userReportsDirectoryPath + '/' + file);
        // Get the file creation time (bithtime). It returns the first value that is a truthy value of next file stats: birthtime, mtime, ctime and atime.
        // This solves some OSs can have the bithtimeMs equal to 0 and returns the date like 1970-01-01
        const birthTimeField = ['birthtime', 'mtime', 'ctime', 'atime'].find(time => stats[`${time}Ms`]);
        return {
          name: file,
          size: stats.size,
          date: stats[birthTimeField]
        };
      });
      (0, _logger.log)('reporting:getReports', `Using TimSort for sorting ${reports.length} items`, 'debug');
      TimSort.sort(reports, sortReportsByDate);
      (0, _logger.log)('reporting:getReports', `Total reports: ${reports.length}`, 'debug');
      return response.ok({
        body: {
          reports
        }
      });
    } catch (error) {
      (0, _logger.log)('reporting:getReports', error.message || error);
      return (0, _errorResponse.ErrorResponse)(error.message || error, 5031, 500, response);
    }
  }
  checkReportsUserDirectoryIsValidRouteDecorator(routeHandler, reportFileNameAccessor) {
    return async (context, request, response) => {
      try {
        const {
          username,
          hashUsername
        } = await context.wazuh.security.getCurrentUser(request, context);
        const userReportsDirectoryPath = _path.default.join(_constants.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH, hashUsername);
        const filename = reportFileNameAccessor(request);
        const pathFilename = _path.default.join(userReportsDirectoryPath, filename);
        (0, _logger.log)('reporting:checkReportsUserDirectoryIsValidRouteDecorator', `Checking the user ${username}(${hashUsername}) can do actions in the reports file: ${pathFilename}`, 'debug');
        if (!pathFilename.startsWith(userReportsDirectoryPath) || pathFilename.includes('../')) {
          (0, _logger.log)('security:reporting:checkReportsUserDirectoryIsValidRouteDecorator', `User ${username}(${hashUsername}) tried to access to a non user report file: ${pathFilename}`, 'warn');
          return response.badRequest({
            body: {
              message: '5040 - You shall not pass!'
            }
          });
        }
        ;
        (0, _logger.log)('reporting:checkReportsUserDirectoryIsValidRouteDecorator', 'Checking the user can do actions in the reports file', 'debug');
        return await routeHandler.bind(this)({
          ...context,
          wazuhEndpointParams: {
            hashUsername,
            filename,
            pathFilename
          }
        }, request, response);
      } catch (error) {
        (0, _logger.log)('reporting:checkReportsUserDirectoryIsValidRouteDecorator', error.message || error);
        return (0, _errorResponse.ErrorResponse)(error.message || error, 5040, 500, response);
      }
    };
  }
  generateReportTimestamp() {
    return `${Date.now() / 1000 | 0}`;
  }
}
exports.WazuhReportingCtrl = WazuhReportingCtrl;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGF0aCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2ZzIiwiX3dhenVoTW9kdWxlcyIsIlRpbVNvcnQiLCJfaW50ZXJvcFJlcXVpcmVXaWxkY2FyZCIsIl9lcnJvclJlc3BvbnNlIiwiX3Byb2Nlc3NTdGF0ZUVxdWl2YWxlbmNlIiwiX2NzdktleUVxdWl2YWxlbmNlIiwiX2FnZW50Q29uZmlndXJhdGlvbiIsIl9leHRlbmRlZEluZm9ybWF0aW9uIiwiX3ByaW50ZXIiLCJfbG9nZ2VyIiwiX2NvbnN0YW50cyIsIl9maWxlc3lzdGVtIiwiX3d6X2FnZW50X3N0YXR1cyIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsIm5vZGVJbnRlcm9wIiwiV2Vha01hcCIsImNhY2hlQmFiZWxJbnRlcm9wIiwiY2FjaGVOb2RlSW50ZXJvcCIsIm9iaiIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiY2FjaGUiLCJoYXMiLCJnZXQiLCJuZXdPYmoiLCJoYXNQcm9wZXJ0eURlc2NyaXB0b3IiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsImtleSIsInByb3RvdHlwZSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImRlc2MiLCJzZXQiLCJXYXp1aFJlcG9ydGluZ0N0cmwiLCJjb25zdHJ1Y3RvciIsIl9kZWZpbmVQcm9wZXJ0eTIiLCJjaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImxvZyIsImFycmF5IiwiYWdlbnRzIiwiYnJvd3NlclRpbWV6b25lIiwic2VhcmNoQmFyIiwiZmlsdGVycyIsInNlcnZlclNpZGVRdWVyeSIsInRpbWUiLCJ0YWJsZXMiLCJzZWN0aW9uIiwiaW5kZXhQYXR0ZXJuVGl0bGUiLCJhcGlJZCIsImJvZHkiLCJtb2R1bGVJRCIsInBhcmFtcyIsImZyb20iLCJ0byIsImFkZGl0aW9uYWxUYWJsZXMiLCJwcmludGVyIiwiUmVwb3J0UHJpbnRlciIsImNyZWF0ZURhdGFEaXJlY3RvcnlJZk5vdEV4aXN0cyIsImNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzIiwiV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEgiLCJXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRIIiwicGF0aCIsImpvaW4iLCJ3YXp1aEVuZHBvaW50UGFyYW1zIiwiaGFzaFVzZXJuYW1lIiwicmVuZGVySGVhZGVyIiwic2FuaXRpemVkRmlsdGVycyIsImFnZW50c0ZpbHRlciIsInNhbml0aXplS2liYW5hRmlsdGVycyIsImFkZFRpbWVSYW5nZUFuZEZpbHRlcnMiLCJleHRlbmRlZEluZm9ybWF0aW9uIiwiRGF0ZSIsImdldFRpbWUiLCJhZGRWaXN1YWxpemF0aW9ucyIsImFkZFRhYmxlcyIsImFnZW50c1RleHQiLCJhZGRBZ2VudHNGaWx0ZXJzIiwicHJpbnQiLCJwYXRoRmlsZW5hbWUiLCJvayIsInN1Y2Nlc3MiLCJtZXNzYWdlIiwiZmlsZW5hbWUiLCJlcnJvciIsIkVycm9yUmVzcG9uc2UiLCJnZW5lcmF0ZVJlcG9ydFRpbWVzdGFtcCIsImNvbXBvbmVudHMiLCJncm91cElEIiwiZXF1aXZhbGVuY2VzIiwibG9jYWxmaWxlIiwib3NxdWVyeSIsImNvbW1hbmQiLCJzeXNjaGVjayIsInN5c2NvbGxlY3RvciIsInJvb3RjaGVjayIsImxhYmVscyIsInNjYSIsImFkZENvbnRlbnQiLCJ0ZXh0Iiwic3R5bGUiLCJkYXRhIiwiY29uZmlndXJhdGlvbiIsIndhenVoIiwiYXBpIiwiY2xpZW50IiwiYXNDdXJyZW50VXNlciIsImFwaUhvc3RJRCIsImFmZmVjdGVkX2l0ZW1zIiwibGVuZ3RoIiwia2V5cyIsImNvbmZpZyIsImZvbnRTaXplIiwiY29sb3IiLCJtYXJnaW4iLCJpc0dyb3VwQ29uZmlnIiwiZmlsdGVyVGl0bGUiLCJpbmRleCIsImZpbHRlciIsImNvbmNhdCIsImlkeCIsInRhYnMiLCJfZCIsImMiLCJBZ2VudENvbmZpZ3VyYXRpb24iLCJjb25maWd1cmF0aW9ucyIsInMiLCJzZWN0aW9ucyIsIm9wdHMiLCJjbiIsIndvIiwid29kbGUiLCJuYW1lIiwicHVzaCIsIkFycmF5IiwiaXNBcnJheSIsImdyb3VwcyIsImZvckVhY2giLCJsb2dmb3JtYXQiLCJncm91cCIsInNhdmVpZHgiLCJ4IiwiaSIsImNvbHVtbnMiLCJyb3dzIiwibWFwIiwicm93IiwiSlNPTiIsInN0cmluZ2lmeSIsImNvbCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJ0aXRsZSIsInR5cGUiLCJsYWJlbCIsImluY2x1ZGVzIiwiX2QyIiwiZ2V0Q29uZmlnVGFibGVzIiwiZGlyZWN0b3JpZXMiLCJkaWZmT3B0cyIsInkiLCJyZWN1cnNpb25fbGV2ZWwiLCJ0YWJsZSIsImFkZENvbmZpZ1RhYmxlcyIsImFnZW50SUQiLCJ3bW9kdWxlc1Jlc3BvbnNlIiwiaWR4Q29tcG9uZW50IiwidGl0bGVPZlNlY3Rpb24iLCJ0aXRsZU9mU3Vic2VjdGlvbiIsImNvbmZpZ3MiLCJjb25mIiwiYWdlbnRDb25maWdSZXNwb25zZSIsImNvbXBvbmVudCIsImFnZW50Q29uZmlnIiwic3VidGl0bGUiLCJhZ2VudENvbmZpZ0tleSIsImZpbHRlckJ5IiwibWF0cml4IiwiZGlmZiIsInN5bmNocm9uaXphdGlvbiIsImZpbGVfbGltaXQiLCJyZXN0IiwiZGlza19xdW90YSIsImZpbGVfc2l6ZSIsImRpciIsImluZGV4T2YiLCJ0b0xvd2VyQ2FzZSIsImxpbmsiLCJkb2N1TGluayIsInNlY3VyaXR5IiwiZ2V0Q3VycmVudFVzZXIiLCJhZ2VudE9zIiwiYWdlbnRSZXNwb25zZSIsInEiLCJvcyIsInBsYXRmb3JtIiwiYWRkQ29udGVudFdpdGhOZXdMaW5lIiwiYnVpbGRBZ2VudHNUYWJsZSIsImFnZW50UmVxdWVzdHNJbnZlbnRvcnkiLCJlbmRwb2ludCIsImxvZ2dlck1lc3NhZ2UiLCJpZCIsIm1hcFJlc3BvbnNlSXRlbXMiLCJpdGVtIiwic3RhdGUiLCJQcm9jZXNzRXF1aXZhbGVuY2UiLCJsb2NhbF9pcCIsImxvY2FsIiwiaXAiLCJsb2NhbF9wb3J0IiwicG9ydCIsInJlcXVlc3RJbnZlbnRvcnkiLCJhZ2VudFJlcXVlc3RJbnZlbnRvcnkiLCJpbnZlbnRvcnlSZXNwb25zZSIsImludmVudG9yeSIsIml0ZW1zIiwiX3NlcnZlclNpZGVRdWVyeSRib29sIiwiX3NlcnZlclNpZGVRdWVyeSRib29sMiIsIl9zZXJ2ZXJTaWRlUXVlcnkkYm9vbDMiLCJib29sIiwibXVzdCIsIm1hdGNoX3BocmFzZSIsInF1ZXJ5IiwiUHJvbWlzZSIsImFsbCIsImFkZFNpbXBsZVRhYmxlIiwicmVwb3J0RmlsZUJ1ZmZlciIsImZzIiwicmVhZEZpbGVTeW5jIiwiaGVhZGVycyIsInVubGlua1N5bmMiLCJzdHIiLCJhZ2VudHNMaXN0IiwibWV0YSIsImNvbnRyb2xsZWRCeSIsIkFVVEhPUklaRURfQUdFTlRTIiwibGVuIiwibmVnYXRlIiwidmFsdWUiLCJndGUiLCJsdCIsInRhYiIsImlzQWdlbnRzIiwiV0FaVUhfTU9EVUxFUyIsImFkZE5ld0xpbmUiLCJhZ2VudHNfbGlzdCIsImFnZW50RGF0YSIsInN0YXR1cyIsIkFQSV9OQU1FX0FHRU5UX1NUQVRVUyIsIkFDVElWRSIsImFnZW50U3RhdHVzTGFiZWxCeUFnZW50U3RhdHVzIiwiYWdlbnRHcm91cHMiLCJkZXNjcmlwdGlvbiIsInJlamVjdCIsImdldENvbmZpZ1Jvd3MiLCJyZXN1bHQiLCJwcm9wIiwiS2V5RXF1aXZhbGVuY2UiLCJwbGFpbkRhdGEiLCJuZXN0ZWREYXRhIiwidGFibGVEYXRhIiwib3B0aW9ucyIsImhpZGVIZWFkZXIiLCJuZXN0IiwiZ2V0UmVwb3J0cyIsInVzZXJSZXBvcnRzRGlyZWN0b3J5UGF0aCIsInNvcnRSZXBvcnRzQnlEYXRlIiwiYSIsImIiLCJkYXRlIiwicmVwb3J0cyIsInJlYWRkaXJTeW5jIiwiZmlsZSIsInN0YXRzIiwic3RhdFN5bmMiLCJiaXJ0aFRpbWVGaWVsZCIsImZpbmQiLCJzaXplIiwic29ydCIsInJvdXRlSGFuZGxlciIsInJlcG9ydEZpbGVOYW1lQWNjZXNzb3IiLCJ1c2VybmFtZSIsInN0YXJ0c1dpdGgiLCJiYWRSZXF1ZXN0IiwiYmluZCIsIm5vdyIsImV4cG9ydHMiXSwic291cmNlcyI6WyJ3YXp1aC1yZXBvcnRpbmcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIGFwcCAtIENsYXNzIGZvciBXYXp1aCByZXBvcnRpbmcgY29udHJvbGxlclxuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IGZzIGZyb20gJ2ZzJztcbmltcG9ydCB7IFdBWlVIX01PRFVMRVMgfSBmcm9tICcuLi8uLi9jb21tb24vd2F6dWgtbW9kdWxlcyc7XG5pbXBvcnQgKiBhcyBUaW1Tb3J0IGZyb20gJ3RpbXNvcnQnO1xuaW1wb3J0IHsgRXJyb3JSZXNwb25zZSB9IGZyb20gJy4uL2xpYi9lcnJvci1yZXNwb25zZSc7XG5pbXBvcnQgUHJvY2Vzc0VxdWl2YWxlbmNlIGZyb20gJy4uL2xpYi9wcm9jZXNzLXN0YXRlLWVxdWl2YWxlbmNlJztcbmltcG9ydCB7IEtleUVxdWl2YWxlbmNlIH0gZnJvbSAnLi4vLi4vY29tbW9uL2Nzdi1rZXktZXF1aXZhbGVuY2UnO1xuaW1wb3J0IHsgQWdlbnRDb25maWd1cmF0aW9uIH0gZnJvbSAnLi4vbGliL3JlcG9ydGluZy9hZ2VudC1jb25maWd1cmF0aW9uJztcbmltcG9ydCB7IGV4dGVuZGVkSW5mb3JtYXRpb24sIGJ1aWxkQWdlbnRzVGFibGUgfSBmcm9tICcuLi9saWIvcmVwb3J0aW5nL2V4dGVuZGVkLWluZm9ybWF0aW9uJztcbmltcG9ydCB7IFJlcG9ydFByaW50ZXIgfSBmcm9tICcuLi9saWIvcmVwb3J0aW5nL3ByaW50ZXInO1xuaW1wb3J0IHsgbG9nIH0gZnJvbSAnLi4vbGliL2xvZ2dlcic7XG5pbXBvcnQgeyBLaWJhbmFSZXF1ZXN0LCBSZXF1ZXN0SGFuZGxlckNvbnRleHQsIEtpYmFuYVJlc3BvbnNlRmFjdG9yeSB9IGZyb20gJ3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQge1xuICBXQVpVSF9EQVRBX0RPV05MT0FEU19ESVJFQ1RPUllfUEFUSCxcbiAgV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCxcbiAgQVVUSE9SSVpFRF9BR0VOVFMsXG4gIEFQSV9OQU1FX0FHRU5UX1NUQVRVUyxcbn0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQgeyBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cywgY3JlYXRlRGF0YURpcmVjdG9yeUlmTm90RXhpc3RzIH0gZnJvbSAnLi4vbGliL2ZpbGVzeXN0ZW0nO1xuaW1wb3J0IHsgYWdlbnRTdGF0dXNMYWJlbEJ5QWdlbnRTdGF0dXMgfSBmcm9tICcuLi8uLi9jb21tb24vc2VydmljZXMvd3pfYWdlbnRfc3RhdHVzJztcblxuaW50ZXJmYWNlIEFnZW50c0ZpbHRlciB7XG4gIHF1ZXJ5OiBhbnk7XG4gIGFnZW50c1RleHQ6IHN0cmluZztcbn1cblxuZXhwb3J0IGNsYXNzIFdhenVoUmVwb3J0aW5nQ3RybCB7XG4gIGNvbnN0cnVjdG9yKCkge31cbiAgLyoqXG4gICAqIFRoaXMgZG8gZm9ybWF0IHRvIGZpbHRlcnNcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlcnMgRS5nOiBjbHVzdGVyLm5hbWU6IHdhenVoIEFORCBydWxlLmdyb3VwczogdnVsbmVyYWJpbGl0eVxuICAgKiBAcGFyYW0ge1N0cmluZ30gc2VhcmNoQmFyIHNlYXJjaCB0ZXJtXG4gICAqL1xuICBwcml2YXRlIHNhbml0aXplS2liYW5hRmlsdGVycyhmaWx0ZXJzOiBhbnksIHNlYXJjaEJhcj86IHN0cmluZyk6IFtzdHJpbmcsIEFnZW50c0ZpbHRlcl0ge1xuICAgIGxvZygncmVwb3J0aW5nOnNhbml0aXplS2liYW5hRmlsdGVycycsIGBTdGFydGVkIHRvIHNhbml0aXplIGZpbHRlcnNgLCAnaW5mbycpO1xuICAgIGxvZyhcbiAgICAgICdyZXBvcnRpbmc6c2FuaXRpemVLaWJhbmFGaWx0ZXJzJyxcbiAgICAgIGBmaWx0ZXJzOiAke2ZpbHRlcnMubGVuZ3RofSwgc2VhcmNoQmFyOiAke3NlYXJjaEJhcn1gLFxuICAgICAgJ2RlYnVnJ1xuICAgICk7XG4gICAgbGV0IHN0ciA9ICcnO1xuXG4gICAgY29uc3QgYWdlbnRzRmlsdGVyOiBBZ2VudHNGaWx0ZXIgPSB7IHF1ZXJ5OiB7fSwgYWdlbnRzVGV4dDogJycgfTtcbiAgICBjb25zdCBhZ2VudHNMaXN0OiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgLy9zZXBhcmF0ZSBhZ2VudHMgZmlsdGVyXG4gICAgZmlsdGVycyA9IGZpbHRlcnMuZmlsdGVyKChmaWx0ZXIpID0+IHtcbiAgICAgIGlmIChmaWx0ZXIubWV0YS5jb250cm9sbGVkQnkgPT09IEFVVEhPUklaRURfQUdFTlRTKSB7XG4gICAgICAgIGFnZW50c0ZpbHRlci5xdWVyeSA9IGZpbHRlci5xdWVyeTtcbiAgICAgICAgYWdlbnRzTGlzdC5wdXNoKGZpbHRlcik7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBmaWx0ZXI7XG4gICAgfSk7XG5cbiAgICBjb25zdCBsZW4gPSBmaWx0ZXJzLmxlbmd0aDtcblxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICAgIGNvbnN0IHsgbmVnYXRlLCBrZXksIHZhbHVlLCBwYXJhbXMsIHR5cGUgfSA9IGZpbHRlcnNbaV0ubWV0YTtcbiAgICAgIHN0ciArPSBgJHtuZWdhdGUgPyAnTk9UICcgOiAnJ31gO1xuICAgICAgc3RyICs9IGAke2tleX06IGA7XG4gICAgICBzdHIgKz0gYCR7XG4gICAgICAgIHR5cGUgPT09ICdyYW5nZSdcbiAgICAgICAgICA/IGAke3BhcmFtcy5ndGV9LSR7cGFyYW1zLmx0fWBcbiAgICAgICAgICA6IHR5cGUgPT09ICdwaHJhc2VzJ1xuICAgICAgICAgICAgPyAnKCcgKyBwYXJhbXMuam9pbihcIiBPUiBcIikgKyAnKSdcbiAgICAgICAgICAgIDogdHlwZSA9PT0gJ2V4aXN0cydcbiAgICAgICAgICAgICAgPyAnKidcbiAgICAgICAgICAgICAgOiAhIXZhbHVlXG4gICAgICAgICAgPyB2YWx1ZVxuICAgICAgICAgIDogKHBhcmFtcyB8fCB7fSkucXVlcnlcbiAgICAgIH1gO1xuICAgICAgc3RyICs9IGAke2kgPT09IGxlbiAtIDEgPyAnJyA6ICcgQU5EICd9YDtcbiAgICB9XG5cbiAgICBpZiAoc2VhcmNoQmFyKSB7XG4gICAgICBzdHIgKz0gYCBBTkQgKCR7IHNlYXJjaEJhcn0pYDtcbiAgICB9XG5cbiAgICBhZ2VudHNGaWx0ZXIuYWdlbnRzVGV4dCA9IGFnZW50c0xpc3QubWFwKChmaWx0ZXIpID0+IGZpbHRlci5tZXRhLnZhbHVlKS5qb2luKCcsJyk7XG5cbiAgICBsb2coXG4gICAgICAncmVwb3J0aW5nOnNhbml0aXplS2liYW5hRmlsdGVycycsXG4gICAgICBgc3RyOiAke3N0cn0sIGFnZW50c0ZpbHRlclN0cjogJHthZ2VudHNGaWx0ZXIuYWdlbnRzVGV4dH1gLFxuICAgICAgJ2RlYnVnJ1xuICAgICk7XG5cbiAgICByZXR1cm4gW3N0ciwgYWdlbnRzRmlsdGVyXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIHBlcmZvcm1zIHRoZSByZW5kZXJpbmcgb2YgZ2l2ZW4gaGVhZGVyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBwcmludGVyIHNlY3Rpb24gdGFyZ2V0XG4gICAqIEBwYXJhbSB7U3RyaW5nfSBzZWN0aW9uIHNlY3Rpb24gdGFyZ2V0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSB0YWIgdGFiIHRhcmdldFxuICAgKiBAcGFyYW0ge0Jvb2xlYW59IGlzQWdlbnRzIGlzIGFnZW50cyBzZWN0aW9uXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBhcGlJZCBJRCBvZiBBUElcbiAgICovXG4gIHByaXZhdGUgYXN5bmMgcmVuZGVySGVhZGVyKGNvbnRleHQsIHByaW50ZXIsIHNlY3Rpb24sIHRhYiwgaXNBZ2VudHMsIGFwaUlkKSB7XG4gICAgdHJ5IHtcbiAgICAgIGxvZyhcbiAgICAgICAgJ3JlcG9ydGluZzpyZW5kZXJIZWFkZXInLFxuICAgICAgICBgc2VjdGlvbjogJHtzZWN0aW9ufSwgdGFiOiAke3RhYn0sIGlzQWdlbnRzOiAke2lzQWdlbnRzfSwgYXBpSWQ6ICR7YXBpSWR9YCxcbiAgICAgICAgJ2RlYnVnJ1xuICAgICAgKTtcbiAgICAgIGlmIChzZWN0aW9uICYmIHR5cGVvZiBzZWN0aW9uID09PSAnc3RyaW5nJykge1xuICAgICAgICBpZiAoIVsnYWdlbnRDb25maWcnLCAnZ3JvdXBDb25maWcnXS5pbmNsdWRlcyhzZWN0aW9uKSkge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiBXQVpVSF9NT0RVTEVTW3RhYl0udGl0bGUgKyAnIHJlcG9ydCcsXG4gICAgICAgICAgICBzdHlsZTogJ2gxJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChzZWN0aW9uID09PSAnYWdlbnRDb25maWcnKSB7XG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcbiAgICAgICAgICAgIHRleHQ6IGBBZ2VudCAke2lzQWdlbnRzfSBjb25maWd1cmF0aW9uYCxcbiAgICAgICAgICAgIHN0eWxlOiAnaDEnLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKHNlY3Rpb24gPT09ICdncm91cENvbmZpZycpIHtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgdGV4dDogJ0FnZW50cyBpbiBncm91cCcsXG4gICAgICAgICAgICBzdHlsZTogJ2gxJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBwcmludGVyLmFkZE5ld0xpbmUoKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGlzQWdlbnRzICYmIHR5cGVvZiBpc0FnZW50cyA9PT0gJ29iamVjdCcpIHtcbiAgICAgICAgYXdhaXQgYnVpbGRBZ2VudHNUYWJsZShcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIHByaW50ZXIsXG4gICAgICAgICAgaXNBZ2VudHMsXG4gICAgICAgICAgYXBpSWQsXG4gICAgICAgICAgc2VjdGlvbiA9PT0gJ2dyb3VwQ29uZmlnJyA/IHRhYiA6ICcnXG4gICAgICAgICk7XG4gICAgICB9XG5cbiAgICAgIGlmIChpc0FnZW50cyAmJiB0eXBlb2YgaXNBZ2VudHMgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGNvbnN0IGFnZW50UmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAgICdHRVQnLFxuICAgICAgICAgIGAvYWdlbnRzYCxcbiAgICAgICAgICB7IHBhcmFtczogeyBhZ2VudHNfbGlzdDogaXNBZ2VudHMgfSB9LFxuICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGFnZW50RGF0YSA9IGFnZW50UmVzcG9uc2UuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zWzBdO1xuICAgICAgICBpZiAoYWdlbnREYXRhICYmIGFnZW50RGF0YS5zdGF0dXMgIT09IEFQSV9OQU1FX0FHRU5UX1NUQVRVUy5BQ1RJVkUpIHtcbiAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XG4gICAgICAgICAgICB0ZXh0OiBgV2FybmluZy4gQWdlbnQgaXMgJHthZ2VudFN0YXR1c0xhYmVsQnlBZ2VudFN0YXR1cyhhZ2VudERhdGEuc3RhdHVzKS50b0xvd2VyQ2FzZSgpfWAsXG4gICAgICAgICAgICBzdHlsZTogJ3N0YW5kYXJkJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBhd2FpdCBidWlsZEFnZW50c1RhYmxlKGNvbnRleHQsIHByaW50ZXIsIFtpc0FnZW50c10sIGFwaUlkKTtcblxuICAgICAgICBpZiAoYWdlbnREYXRhICYmIGFnZW50RGF0YS5ncm91cCkge1xuICAgICAgICAgIGNvbnN0IGFnZW50R3JvdXBzID0gYWdlbnREYXRhLmdyb3VwLmpvaW4oJywgJyk7XG4gICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50V2l0aE5ld0xpbmUoe1xuICAgICAgICAgICAgdGV4dDogYEdyb3VwJHthZ2VudERhdGEuZ3JvdXAubGVuZ3RoID4gMSA/ICdzJyA6ICcnfTogJHthZ2VudEdyb3Vwc31gLFxuICAgICAgICAgICAgc3R5bGU6ICdzdGFuZGFyZCcsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChXQVpVSF9NT0RVTEVTW3RhYl0gJiYgV0FaVUhfTU9EVUxFU1t0YWJdLmRlc2NyaXB0aW9uKSB7XG4gICAgICAgIHByaW50ZXIuYWRkQ29udGVudFdpdGhOZXdMaW5lKHtcbiAgICAgICAgICB0ZXh0OiBXQVpVSF9NT0RVTEVTW3RhYl0uZGVzY3JpcHRpb24sXG4gICAgICAgICAgc3R5bGU6ICdzdGFuZGFyZCcsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBsb2coJ3JlcG9ydGluZzpyZW5kZXJIZWFkZXInLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBnZXRDb25maWdSb3dzKGRhdGEsIGxhYmVscykge1xuICAgIGxvZygncmVwb3J0aW5nOmdldENvbmZpZ1Jvd3MnLCBgQnVpbGRpbmcgY29uZmlndXJhdGlvbiByb3dzYCwgJ2luZm8nKTtcbiAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICBmb3IgKGxldCBwcm9wIGluIGRhdGEgfHwgW10pIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGFbcHJvcF0pKSB7XG4gICAgICAgIGRhdGFbcHJvcF0uZm9yRWFjaCgoeCwgaWR4KSA9PiB7XG4gICAgICAgICAgaWYgKHR5cGVvZiB4ID09PSAnb2JqZWN0JykgZGF0YVtwcm9wXVtpZHhdID0gSlNPTi5zdHJpbmdpZnkoeCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgICAgcmVzdWx0LnB1c2goWyhsYWJlbHMgfHwge30pW3Byb3BdIHx8IEtleUVxdWl2YWxlbmNlW3Byb3BdIHx8IHByb3AsIGRhdGFbcHJvcF0gfHwgJy0nXSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICBwcml2YXRlIGdldENvbmZpZ1RhYmxlcyhkYXRhLCBzZWN0aW9uLCB0YWIsIGFycmF5ID0gW10pIHtcbiAgICBsb2coJ3JlcG9ydGluZzpnZXRDb25maWdUYWJsZXMnLCBgQnVpbGRpbmcgY29uZmlndXJhdGlvbiB0YWJsZXNgLCAnaW5mbycpO1xuICAgIGxldCBwbGFpbkRhdGEgPSB7fTtcbiAgICBjb25zdCBuZXN0ZWREYXRhID0gW107XG4gICAgY29uc3QgdGFibGVEYXRhID0gW107XG5cbiAgICBpZiAoZGF0YS5sZW5ndGggPT09IDEgJiYgQXJyYXkuaXNBcnJheShkYXRhKSkge1xuICAgICAgdGFibGVEYXRhW3NlY3Rpb24uY29uZmlnW3RhYl0uY29uZmlndXJhdGlvbl0gPSBkYXRhO1xuICAgIH0gZWxzZSB7XG4gICAgICBmb3IgKGxldCBrZXkgaW4gZGF0YSkge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgKHR5cGVvZiBkYXRhW2tleV0gIT09ICdvYmplY3QnICYmICFBcnJheS5pc0FycmF5KGRhdGFba2V5XSkpIHx8XG4gICAgICAgICAgKEFycmF5LmlzQXJyYXkoZGF0YVtrZXldKSAmJiB0eXBlb2YgZGF0YVtrZXldWzBdICE9PSAnb2JqZWN0JylcbiAgICAgICAgKSB7XG4gICAgICAgICAgcGxhaW5EYXRhW2tleV0gPVxuICAgICAgICAgICAgQXJyYXkuaXNBcnJheShkYXRhW2tleV0pICYmIHR5cGVvZiBkYXRhW2tleV1bMF0gIT09ICdvYmplY3QnXG4gICAgICAgICAgICAgID8gZGF0YVtrZXldLm1hcCgoeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiB4ID09PSAnb2JqZWN0JyA/IEpTT04uc3RyaW5naWZ5KHgpIDogeCArICdcXG4nO1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIDogZGF0YVtrZXldO1xuICAgICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoZGF0YVtrZXldKSAmJiB0eXBlb2YgZGF0YVtrZXldWzBdID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgIHRhYmxlRGF0YVtrZXldID0gZGF0YVtrZXldO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmIChzZWN0aW9uLmlzR3JvdXBDb25maWcgJiYgWydwYWNrJywgJ2NvbnRlbnQnXS5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgICAgICB0YWJsZURhdGFba2V5XSA9IFtkYXRhW2tleV1dO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXN0ZWREYXRhLnB1c2goZGF0YVtrZXldKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgYXJyYXkucHVzaCh7XG4gICAgICB0aXRsZTogKHNlY3Rpb24ub3B0aW9ucyB8fCB7fSkuaGlkZUhlYWRlclxuICAgICAgICA/ICcnXG4gICAgICAgIDogKHNlY3Rpb24udGFicyB8fCBbXSlbdGFiXSB8fFxuICAgICAgICAgIChzZWN0aW9uLmlzR3JvdXBDb25maWcgPyAoKHNlY3Rpb24ubGFiZWxzIHx8IFtdKVswXSB8fCBbXSlbdGFiXSA6ICcnKSxcbiAgICAgIGNvbHVtbnM6IFsnJywgJyddLFxuICAgICAgdHlwZTogJ2NvbmZpZycsXG4gICAgICByb3dzOiB0aGlzLmdldENvbmZpZ1Jvd3MocGxhaW5EYXRhLCAoc2VjdGlvbi5sYWJlbHMgfHwgW10pWzBdKSxcbiAgICB9KTtcbiAgICBmb3IgKGxldCBrZXkgaW4gdGFibGVEYXRhKSB7XG4gICAgICBjb25zdCBjb2x1bW5zID0gT2JqZWN0LmtleXModGFibGVEYXRhW2tleV1bMF0pO1xuICAgICAgY29sdW1ucy5mb3JFYWNoKChjb2wsIGkpID0+IHtcbiAgICAgICAgY29sdW1uc1tpXSA9IGNvbFswXS50b1VwcGVyQ2FzZSgpICsgY29sLnNsaWNlKDEpO1xuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IHJvd3MgPSB0YWJsZURhdGFba2V5XS5tYXAoKHgpID0+IHtcbiAgICAgICAgbGV0IHJvdyA9IFtdO1xuICAgICAgICBmb3IgKGxldCBrZXkgaW4geCkge1xuICAgICAgICAgIHJvdy5wdXNoKFxuICAgICAgICAgICAgdHlwZW9mIHhba2V5XSAhPT0gJ29iamVjdCdcbiAgICAgICAgICAgICAgPyB4W2tleV1cbiAgICAgICAgICAgICAgOiBBcnJheS5pc0FycmF5KHhba2V5XSlcbiAgICAgICAgICAgICAgPyB4W2tleV0ubWFwKCh4KSA9PiB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4geCArICdcXG4nO1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIDogSlNPTi5zdHJpbmdpZnkoeFtrZXldKVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKHJvdy5sZW5ndGggPCBjb2x1bW5zLmxlbmd0aCkge1xuICAgICAgICAgIHJvdy5wdXNoKCctJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJvdztcbiAgICAgIH0pO1xuICAgICAgYXJyYXkucHVzaCh7XG4gICAgICAgIHRpdGxlOiAoKHNlY3Rpb24ubGFiZWxzIHx8IFtdKVswXSB8fCBbXSlba2V5XSB8fCAnJyxcbiAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgY29sdW1ucyxcbiAgICAgICAgcm93cyxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBuZXN0ZWREYXRhLmZvckVhY2gobmVzdCA9PiB7XG4gICAgICB0aGlzLmdldENvbmZpZ1RhYmxlcyhuZXN0LCBzZWN0aW9uLCB0YWIgKyAxLCBhcnJheSk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGFycmF5O1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIHJlcG9ydCBmb3IgdGhlIG1vZHVsZXNcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHsqfSByZXBvcnRzIGxpc3Qgb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgY3JlYXRlUmVwb3J0c01vZHVsZXMgPSB0aGlzLmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3IoYXN5bmMgKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBLaWJhbmFSZXF1ZXN0LFxuICAgIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnlcbiAgKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNNb2R1bGVzJywgYFJlcG9ydCBzdGFydGVkYCwgJ2luZm8nKTtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgYXJyYXksXG4gICAgICAgIGFnZW50cyxcbiAgICAgICAgYnJvd3NlclRpbWV6b25lLFxuICAgICAgICBzZWFyY2hCYXIsXG4gICAgICAgIGZpbHRlcnMsXG4gICAgICAgIHNlcnZlclNpZGVRdWVyeSxcbiAgICAgICAgdGltZSxcbiAgICAgICAgdGFibGVzLFxuICAgICAgICBzZWN0aW9uLFxuICAgICAgICBpbmRleFBhdHRlcm5UaXRsZSxcbiAgICAgICAgYXBpSWRcbiAgICAgIH0gPSByZXF1ZXN0LmJvZHk7XG4gICAgICBjb25zdCB7IG1vZHVsZUlEIH0gPSByZXF1ZXN0LnBhcmFtcztcbiAgICAgIGNvbnN0IHsgZnJvbSwgdG8gfSA9IHRpbWUgfHwge307XG4gICAgICBsZXQgYWRkaXRpb25hbFRhYmxlcyA9IFtdO1xuICAgICAgLy8gSW5pdFxuICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKCk7XG5cbiAgICAgIGNyZWF0ZURhdGFEaXJlY3RvcnlJZk5vdEV4aXN0cygpO1xuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMoV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEgpO1xuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMoV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhwYXRoLmpvaW4oV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCwgY29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLmhhc2hVc2VybmFtZSkpO1xuXG4gICAgICBhd2FpdCB0aGlzLnJlbmRlckhlYWRlcihjb250ZXh0LCBwcmludGVyLCBzZWN0aW9uLCBtb2R1bGVJRCwgYWdlbnRzLCBhcGlJZCk7XG5cbiAgICAgIGNvbnN0IFtzYW5pdGl6ZWRGaWx0ZXJzLCBhZ2VudHNGaWx0ZXJdID0gZmlsdGVyc1xuICAgICAgICA/IHRoaXMuc2FuaXRpemVLaWJhbmFGaWx0ZXJzKGZpbHRlcnMsIHNlYXJjaEJhcilcbiAgICAgICAgOiBbZmFsc2UsIG51bGxdO1xuXG4gICAgICBpZiAodGltZSAmJiBzYW5pdGl6ZWRGaWx0ZXJzKSB7XG4gICAgICAgIHByaW50ZXIuYWRkVGltZVJhbmdlQW5kRmlsdGVycyhmcm9tLCB0bywgc2FuaXRpemVkRmlsdGVycywgYnJvd3NlclRpbWV6b25lKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHRpbWUpIHtcbiAgICAgICAgYWRkaXRpb25hbFRhYmxlcyA9IGF3YWl0IGV4dGVuZGVkSW5mb3JtYXRpb24oXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICBwcmludGVyLFxuICAgICAgICAgIHNlY3Rpb24sXG4gICAgICAgICAgbW9kdWxlSUQsXG4gICAgICAgICAgYXBpSWQsXG4gICAgICAgICAgbmV3IERhdGUoZnJvbSkuZ2V0VGltZSgpLFxuICAgICAgICAgIG5ldyBEYXRlKHRvKS5nZXRUaW1lKCksXG4gICAgICAgICAgc2VydmVyU2lkZVF1ZXJ5LFxuICAgICAgICAgIGFnZW50c0ZpbHRlcixcbiAgICAgICAgICBpbmRleFBhdHRlcm5UaXRsZSxcbiAgICAgICAgICBhZ2VudHNcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgcHJpbnRlci5hZGRWaXN1YWxpemF0aW9ucyhhcnJheSwgYWdlbnRzLCBtb2R1bGVJRCk7XG5cbiAgICAgIGlmICh0YWJsZXMpIHtcbiAgICAgICAgcHJpbnRlci5hZGRUYWJsZXMoWy4uLnRhYmxlcywgLi4uKGFkZGl0aW9uYWxUYWJsZXMgfHwgW10pXSk7XG4gICAgICB9XG5cbiAgICAgIC8vYWRkIGF1dGhvcml6ZWQgYWdlbnRzXG4gICAgICBpZiAoYWdlbnRzRmlsdGVyPy5hZ2VudHNUZXh0KSB7XG4gICAgICAgIHByaW50ZXIuYWRkQWdlbnRzRmlsdGVycyhhZ2VudHNGaWx0ZXIuYWdlbnRzVGV4dCk7XG4gICAgICB9XG5cbiAgICAgIGF3YWl0IHByaW50ZXIucHJpbnQoY29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLnBhdGhGaWxlbmFtZSk7XG5cbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIG1lc3NhZ2U6IGBSZXBvcnQgJHtjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMuZmlsZW5hbWV9IHdhcyBjcmVhdGVkYCxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA1MDI5LCA1MDAsIHJlc3BvbnNlKTtcbiAgICB9XG4gIH0sKHtib2R5OnsgYWdlbnRzIH0sIHBhcmFtczogeyBtb2R1bGVJRCB9fSkgPT4gYHdhenVoLW1vZHVsZS0ke2FnZW50cyA/IGBhZ2VudHMtJHthZ2VudHN9YCA6ICdvdmVydmlldyd9LSR7bW9kdWxlSUR9LSR7dGhpcy5nZW5lcmF0ZVJlcG9ydFRpbWVzdGFtcCgpfS5wZGZgKVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSByZXBvcnQgZm9yIHRoZSBncm91cHNcbiAgICogQHBhcmFtIHtPYmplY3R9IGNvbnRleHRcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlcXVlc3RcbiAgICogQHBhcmFtIHtPYmplY3R9IHJlc3BvbnNlXG4gICAqIEByZXR1cm5zIHsqfSByZXBvcnRzIGxpc3Qgb3IgRXJyb3JSZXNwb25zZVxuICAgKi9cbiAgY3JlYXRlUmVwb3J0c0dyb3VwcyA9IHRoaXMuY2hlY2tSZXBvcnRzVXNlckRpcmVjdG9yeUlzVmFsaWRSb3V0ZURlY29yYXRvcihhc3luYyhcbiAgICBjb250ZXh0OiBSZXF1ZXN0SGFuZGxlckNvbnRleHQsXG4gICAgcmVxdWVzdDogS2liYW5hUmVxdWVzdCxcbiAgICByZXNwb25zZTogS2liYW5hUmVzcG9uc2VGYWN0b3J5XG4gICkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBsb2coJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzR3JvdXBzJywgYFJlcG9ydCBzdGFydGVkYCwgJ2luZm8nKTtcbiAgICAgIGNvbnN0IHsgY29tcG9uZW50cywgYXBpSWQgfSA9IHJlcXVlc3QuYm9keTtcbiAgICAgIGNvbnN0IHsgZ3JvdXBJRCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICAvLyBJbml0XG4gICAgICBjb25zdCBwcmludGVyID0gbmV3IFJlcG9ydFByaW50ZXIoKTtcblxuICAgICAgY3JlYXRlRGF0YURpcmVjdG9yeUlmTm90RXhpc3RzKCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19ESVJFQ1RPUllfUEFUSCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRIKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKHBhdGguam9pbihXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRILCBjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMuaGFzaFVzZXJuYW1lKSk7XG5cbiAgICAgIGxldCB0YWJsZXMgPSBbXTtcbiAgICAgIGNvbnN0IGVxdWl2YWxlbmNlcyA9IHtcbiAgICAgICAgbG9jYWxmaWxlOiAnTG9jYWwgZmlsZXMnLFxuICAgICAgICBvc3F1ZXJ5OiAnT3NxdWVyeScsXG4gICAgICAgIGNvbW1hbmQ6ICdDb21tYW5kJyxcbiAgICAgICAgc3lzY2hlY2s6ICdTeXNjaGVjaycsXG4gICAgICAgICdvcGVuLXNjYXAnOiAnT3BlblNDQVAnLFxuICAgICAgICAnY2lzLWNhdCc6ICdDSVMtQ0FUJyxcbiAgICAgICAgc3lzY29sbGVjdG9yOiAnU3lzY29sbGVjdG9yJyxcbiAgICAgICAgcm9vdGNoZWNrOiAnUm9vdGNoZWNrJyxcbiAgICAgICAgbGFiZWxzOiAnTGFiZWxzJyxcbiAgICAgICAgc2NhOiAnU2VjdXJpdHkgY29uZmlndXJhdGlvbiBhc3Nlc3NtZW50JyxcbiAgICAgIH07XG4gICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICB0ZXh0OiBgR3JvdXAgJHtncm91cElEfSBjb25maWd1cmF0aW9uYCxcbiAgICAgICAgc3R5bGU6ICdoMScsXG4gICAgICB9KTtcblxuICAgICAgLy8gR3JvdXAgY29uZmlndXJhdGlvblxuICAgICAgaWYgKGNvbXBvbmVudHNbJzAnXSkge1xuXG4gICAgICAgIGNvbnN0IHsgZGF0YTogeyBkYXRhOiBjb25maWd1cmF0aW9uIH0gfSA9IGF3YWl0IGNvbnRleHQud2F6dWguYXBpLmNsaWVudC5hc0N1cnJlbnRVc2VyLnJlcXVlc3QoXG4gICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgYC9ncm91cHMvJHtncm91cElEfS9jb25maWd1cmF0aW9uYCxcbiAgICAgICAgICB7fSxcbiAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxuICAgICAgICApO1xuXG4gICAgICAgIGlmIChcbiAgICAgICAgICBjb25maWd1cmF0aW9uLmFmZmVjdGVkX2l0ZW1zLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgICBPYmplY3Qua2V5cyhjb25maWd1cmF0aW9uLmFmZmVjdGVkX2l0ZW1zWzBdLmNvbmZpZykubGVuZ3RoXG4gICAgICAgICkge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiAnQ29uZmlndXJhdGlvbnMnLFxuICAgICAgICAgICAgc3R5bGU6IHsgZm9udFNpemU6IDE0LCBjb2xvcjogJyMwMDAnIH0sXG4gICAgICAgICAgICBtYXJnaW46IFswLCAxMCwgMCwgMTVdLFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbnN0IHNlY3Rpb24gPSB7XG4gICAgICAgICAgICBsYWJlbHM6IFtdLFxuICAgICAgICAgICAgaXNHcm91cENvbmZpZzogdHJ1ZSxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGZvciAobGV0IGNvbmZpZyBvZiBjb25maWd1cmF0aW9uLmFmZmVjdGVkX2l0ZW1zKSB7XG4gICAgICAgICAgICBsZXQgZmlsdGVyVGl0bGUgPSAnJztcbiAgICAgICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgICAgICBmb3IgKGxldCBmaWx0ZXIgb2YgT2JqZWN0LmtleXMoY29uZmlnLmZpbHRlcnMpKSB7XG4gICAgICAgICAgICAgIGZpbHRlclRpdGxlID0gZmlsdGVyVGl0bGUuY29uY2F0KGAke2ZpbHRlcn06ICR7Y29uZmlnLmZpbHRlcnNbZmlsdGVyXX1gKTtcbiAgICAgICAgICAgICAgaWYgKGluZGV4IDwgT2JqZWN0LmtleXMoY29uZmlnLmZpbHRlcnMpLmxlbmd0aCAtIDEpIHtcbiAgICAgICAgICAgICAgICBmaWx0ZXJUaXRsZSA9IGZpbHRlclRpdGxlLmNvbmNhdCgnIHwgJyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaW5kZXgrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICAgIHRleHQ6IGZpbHRlclRpdGxlLFxuICAgICAgICAgICAgICBzdHlsZTogJ2g0JyxcbiAgICAgICAgICAgICAgbWFyZ2luOiBbMCwgMCwgMCwgMTBdLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBsZXQgaWR4ID0gMDtcbiAgICAgICAgICAgIHNlY3Rpb24udGFicyA9IFtdO1xuICAgICAgICAgICAgZm9yIChsZXQgX2Qgb2YgT2JqZWN0LmtleXMoY29uZmlnLmNvbmZpZykpIHtcbiAgICAgICAgICAgICAgZm9yIChsZXQgYyBvZiBBZ2VudENvbmZpZ3VyYXRpb24uY29uZmlndXJhdGlvbnMpIHtcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBzIG9mIGMuc2VjdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgIHNlY3Rpb24ub3B0cyA9IHMub3B0cyB8fCB7fTtcbiAgICAgICAgICAgICAgICAgIGZvciAobGV0IGNuIG9mIHMuY29uZmlnIHx8IFtdKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjbi5jb25maWd1cmF0aW9uID09PSBfZCkge1xuICAgICAgICAgICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzID0gcy5sYWJlbHMgfHwgW1tdXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgZm9yIChsZXQgd28gb2Ygcy53b2RsZSB8fCBbXSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAod28ubmFtZSA9PT0gX2QpIHtcbiAgICAgICAgICAgICAgICAgICAgICBzZWN0aW9uLmxhYmVscyA9IHMubGFiZWxzIHx8IFtbXV07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgc2VjdGlvbi5sYWJlbHNbMF1bJ3BhY2snXSA9ICdQYWNrcyc7XG4gICAgICAgICAgICAgIHNlY3Rpb24ubGFiZWxzWzBdWydjb250ZW50J10gPSAnRXZhbHVhdGlvbnMnO1xuICAgICAgICAgICAgICBzZWN0aW9uLmxhYmVsc1swXVsnNyddID0gJ1NjYW4gbGlzdGVuaW5nIG5ldHdvdGsgcG9ydHMnO1xuICAgICAgICAgICAgICBzZWN0aW9uLnRhYnMucHVzaChlcXVpdmFsZW5jZXNbX2RdKTtcblxuICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShjb25maWcuY29uZmlnW19kXSkpIHtcbiAgICAgICAgICAgICAgICAvKiBMT0cgQ09MTEVDVE9SICovXG4gICAgICAgICAgICAgICAgaWYgKF9kID09PSAnbG9jYWxmaWxlJykge1xuICAgICAgICAgICAgICAgICAgbGV0IGdyb3VwcyA9IFtdO1xuICAgICAgICAgICAgICAgICAgY29uZmlnLmNvbmZpZ1tfZF0uZm9yRWFjaCgob2JqKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghZ3JvdXBzW29iai5sb2dmb3JtYXRdKSB7XG4gICAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW29iai5sb2dmb3JtYXRdID0gW107XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW29iai5sb2dmb3JtYXRdLnB1c2gob2JqKTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXMoZ3JvdXBzKS5mb3JFYWNoKChncm91cCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgc2F2ZWlkeCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIGdyb3Vwc1tncm91cF0uZm9yRWFjaCgoeCwgaSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChPYmplY3Qua2V5cyh4KS5sZW5ndGggPiBPYmplY3Qua2V5cyhncm91cHNbZ3JvdXBdW3NhdmVpZHhdKS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhdmVpZHggPSBpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbHVtbnMgPSBPYmplY3Qua2V5cyhncm91cHNbZ3JvdXBdW3NhdmVpZHhdKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgcm93cyA9IGdyb3Vwc1tncm91cF0ubWFwKCh4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgbGV0IHJvdyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZW9mIHhba2V5XSAhPT0gJ29iamVjdCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHhba2V5XVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogQXJyYXkuaXNBcnJheSh4W2tleV0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB4W2tleV0ubWFwKCh4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB4ICsgJ1xcbic7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogSlNPTi5zdHJpbmdpZnkoeFtrZXldKVxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcm93O1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKChjb2wsIGkpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zW2ldID0gY29sWzBdLnRvVXBwZXJDYXNlKCkgKyBjb2wuc2xpY2UoMSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdMb2NhbCBmaWxlcycsXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLFxuICAgICAgICAgICAgICAgICAgICAgIHJvd3MsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmIChfZCA9PT0gJ2xhYmVscycpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IG9iaiA9IGNvbmZpZy5jb25maWdbX2RdWzBdLmxhYmVsO1xuICAgICAgICAgICAgICAgICAgY29uc3QgY29sdW1ucyA9IE9iamVjdC5rZXlzKG9ialswXSk7XG4gICAgICAgICAgICAgICAgICBpZiAoIWNvbHVtbnMuaW5jbHVkZXMoJ2hpZGRlbicpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMucHVzaCgnaGlkZGVuJyk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjb25zdCByb3dzID0gb2JqLm1hcCgoeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsZXQgcm93ID0gW107XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goeFtrZXldKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByb3c7XG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoY29sLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnNbaV0gPSBjb2xbMF0udG9VcHBlckNhc2UoKSArIGNvbC5zbGljZSgxKTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0xhYmVscycsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6ICd0YWJsZScsXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbnMsXG4gICAgICAgICAgICAgICAgICAgIHJvd3MsXG4gICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgZm9yIChsZXQgX2QyIG9mIGNvbmZpZy5jb25maWdbX2RdKSB7XG4gICAgICAgICAgICAgICAgICAgIHRhYmxlcy5wdXNoKC4uLnRoaXMuZ2V0Q29uZmlnVGFibGVzKF9kMiwgc2VjdGlvbiwgaWR4KSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIC8qSU5URUdSSVRZIE1PTklUT1JJTkcgTU9OSVRPUkVEIERJUkVDVE9SSUVTICovXG4gICAgICAgICAgICAgICAgaWYgKGNvbmZpZy5jb25maWdbX2RdLmRpcmVjdG9yaWVzKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBkaXJlY3RvcmllcyA9IGNvbmZpZy5jb25maWdbX2RdLmRpcmVjdG9yaWVzO1xuICAgICAgICAgICAgICAgICAgZGVsZXRlIGNvbmZpZy5jb25maWdbX2RdLmRpcmVjdG9yaWVzO1xuICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goLi4udGhpcy5nZXRDb25maWdUYWJsZXMoY29uZmlnLmNvbmZpZ1tfZF0sIHNlY3Rpb24sIGlkeCkpO1xuICAgICAgICAgICAgICAgICAgbGV0IGRpZmZPcHRzID0gW107XG4gICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyhzZWN0aW9uLm9wdHMpLmZvckVhY2goKHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZGlmZk9wdHMucHVzaCh4KTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgY29uc3QgY29sdW1ucyA9IFtcbiAgICAgICAgICAgICAgICAgICAgJycsXG4gICAgICAgICAgICAgICAgICAgIC4uLmRpZmZPcHRzLmZpbHRlcigoeCkgPT4geCAhPT0gJ2NoZWNrX2FsbCcgJiYgeCAhPT0gJ2NoZWNrX3N1bScpLFxuICAgICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgICAgICAgIGxldCByb3dzID0gW107XG4gICAgICAgICAgICAgICAgICBkaXJlY3Rvcmllcy5mb3JFYWNoKCh4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGxldCByb3cgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goeC5wYXRoKTtcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKCh5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHkgIT09ICcnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB5ID0geSAhPT0gJ2NoZWNrX3dob2RhdGEnID8geSA6ICd3aG9kYXRhJztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKHhbeV0gPyB4W3ldIDogJ25vJyk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goeC5yZWN1cnNpb25fbGV2ZWwpO1xuICAgICAgICAgICAgICAgICAgICByb3dzLnB1c2gocm93KTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKCh4LCBpZHgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpZHhdID0gc2VjdGlvbi5vcHRzW3hdO1xuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICBjb2x1bW5zLnB1c2goJ1JMJyk7XG4gICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnTW9uaXRvcmVkIGRpcmVjdG9yaWVzJyxcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgICAgICAgICAgICAgY29sdW1ucyxcbiAgICAgICAgICAgICAgICAgICAgcm93cyxcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCguLi50aGlzLmdldENvbmZpZ1RhYmxlcyhjb25maWcuY29uZmlnW19kXSwgc2VjdGlvbiwgaWR4KSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGZvciAoY29uc3QgdGFibGUgb2YgdGFibGVzKSB7XG4gICAgICAgICAgICAgICAgcHJpbnRlci5hZGRDb25maWdUYWJsZXMoW3RhYmxlXSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaWR4Kys7XG4gICAgICAgICAgICAgIHRhYmxlcyA9IFtdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGFibGVzID0gW107XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICB0ZXh0OiAnQSBjb25maWd1cmF0aW9uIGZvciB0aGlzIGdyb3VwIGhhcyBub3QgeWV0IGJlZW4gc2V0IHVwLicsXG4gICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMTIsIGNvbG9yOiAnIzAwMCcgfSxcbiAgICAgICAgICAgIG1hcmdpbjogWzAsIDEwLCAwLCAxNV0sXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gQWdlbnRzIGluIGdyb3VwXG4gICAgICBpZiAoY29tcG9uZW50c1snMSddKSB7XG4gICAgICAgIGF3YWl0IHRoaXMucmVuZGVySGVhZGVyKFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgcHJpbnRlcixcbiAgICAgICAgICAnZ3JvdXBDb25maWcnLFxuICAgICAgICAgIGdyb3VwSUQsXG4gICAgICAgICAgW10sXG4gICAgICAgICAgYXBpSWRcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgYXdhaXQgcHJpbnRlci5wcmludChjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMucGF0aEZpbGVuYW1lKTtcblxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgbWVzc2FnZTogYFJlcG9ydCAke2NvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5maWxlbmFtZX0gd2FzIGNyZWF0ZWRgLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNHcm91cHMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDUwMjksIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfSwgKHtwYXJhbXM6IHsgZ3JvdXBJRCB9fSkgPT4gYHdhenVoLWdyb3VwLWNvbmZpZ3VyYXRpb24tJHtncm91cElEfS0ke3RoaXMuZ2VuZXJhdGVSZXBvcnRUaW1lc3RhbXAoKX0ucGRmYClcblxuICAvKipcbiAgICogQ3JlYXRlIGEgcmVwb3J0IGZvciB0aGUgYWdlbnRzXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7Kn0gcmVwb3J0cyBsaXN0IG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGNyZWF0ZVJlcG9ydHNBZ2VudHNDb25maWd1cmF0aW9uID0gdGhpcy5jaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yKCBhc3luYyAoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3QsXG4gICAgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeVxuICApID0+IHtcbiAgICB0cnkge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0NvbmZpZ3VyYXRpb24nLCBgUmVwb3J0IHN0YXJ0ZWRgLCAnaW5mbycpO1xuICAgICAgY29uc3QgeyBjb21wb25lbnRzLCBhcGlJZCB9ID0gcmVxdWVzdC5ib2R5O1xuICAgICAgY29uc3QgeyBhZ2VudElEIH0gPSByZXF1ZXN0LnBhcmFtcztcblxuICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKCk7XG4gICAgICBjcmVhdGVEYXRhRGlyZWN0b3J5SWZOb3RFeGlzdHMoKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKFdBWlVIX0RBVEFfRE9XTkxPQURTX0RJUkVDVE9SWV9QQVRIKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgpO1xuICAgICAgY3JlYXRlRGlyZWN0b3J5SWZOb3RFeGlzdHMocGF0aC5qb2luKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsIGNvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5oYXNoVXNlcm5hbWUpKTtcblxuICAgICAgbGV0IHdtb2R1bGVzUmVzcG9uc2UgPSB7fTtcbiAgICAgIGxldCB0YWJsZXMgPSBbXTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHdtb2R1bGVzUmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAgICdHRVQnLFxuICAgICAgICAgIGAvYWdlbnRzLyR7YWdlbnRJRH0vY29uZmlnL3dtb2R1bGVzL3dtb2R1bGVzYCxcbiAgICAgICAgICB7fSxcbiAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxuICAgICAgICApO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgbG9nKCdyZXBvcnRpbmc6cmVwb3J0JywgZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgJ2RlYnVnJyk7XG4gICAgICB9XG5cbiAgICAgIGF3YWl0IHRoaXMucmVuZGVySGVhZGVyKGNvbnRleHQsIHByaW50ZXIsICdhZ2VudENvbmZpZycsICdhZ2VudENvbmZpZycsIGFnZW50SUQsIGFwaUlkKTtcblxuICAgICAgbGV0IGlkeENvbXBvbmVudCA9IDA7XG4gICAgICBmb3IgKGxldCBjb25maWcgb2YgQWdlbnRDb25maWd1cmF0aW9uLmNvbmZpZ3VyYXRpb25zKSB7XG4gICAgICAgIGxldCB0aXRsZU9mU2VjdGlvbiA9IGZhbHNlO1xuICAgICAgICBsb2coXG4gICAgICAgICAgJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzQWdlbnRzQ29uZmlndXJhdGlvbicsXG4gICAgICAgICAgYEl0ZXJhdGUgb3ZlciAke2NvbmZpZy5zZWN0aW9ucy5sZW5ndGh9IGNvbmZpZ3VyYXRpb24gc2VjdGlvbnNgLFxuICAgICAgICAgICdkZWJ1ZydcbiAgICAgICAgKTtcbiAgICAgICAgZm9yIChsZXQgc2VjdGlvbiBvZiBjb25maWcuc2VjdGlvbnMpIHtcbiAgICAgICAgICBsZXQgdGl0bGVPZlN1YnNlY3Rpb24gPSBmYWxzZTtcbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICBjb21wb25lbnRzW2lkeENvbXBvbmVudF0gJiZcbiAgICAgICAgICAgIChzZWN0aW9uLmNvbmZpZyB8fCBzZWN0aW9uLndvZGxlKVxuICAgICAgICAgICkge1xuICAgICAgICAgICAgbGV0IGlkeCA9IDA7XG4gICAgICAgICAgICBjb25zdCBjb25maWdzID0gKHNlY3Rpb24uY29uZmlnIHx8IFtdKS5jb25jYXQoc2VjdGlvbi53b2RsZSB8fCBbXSk7XG4gICAgICAgICAgICBsb2coXG4gICAgICAgICAgICAgICdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0NvbmZpZ3VyYXRpb24nLFxuICAgICAgICAgICAgICBgSXRlcmF0ZSBvdmVyICR7Y29uZmlncy5sZW5ndGh9IGNvbmZpZ3VyYXRpb24gYmxvY2tzYCxcbiAgICAgICAgICAgICAgJ2RlYnVnJ1xuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGZvciAobGV0IGNvbmYgb2YgY29uZmlncykge1xuICAgICAgICAgICAgICBsZXQgYWdlbnRDb25maWdSZXNwb25zZSA9IHt9O1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmICghY29uZlsnbmFtZSddKSB7XG4gICAgICAgICAgICAgICAgICBhZ2VudENvbmZpZ1Jlc3BvbnNlID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzQ3VycmVudFVzZXIucmVxdWVzdChcbiAgICAgICAgICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICAgICAgICAgIGAvYWdlbnRzLyR7YWdlbnRJRH0vY29uZmlnLyR7Y29uZi5jb21wb25lbnR9LyR7Y29uZi5jb25maWd1cmF0aW9ufWAsXG4gICAgICAgICAgICAgICAgICAgIHt9LFxuICAgICAgICAgICAgICAgICAgICB7IGFwaUhvc3RJRDogYXBpSWQgfVxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgZm9yIChsZXQgd29kbGUgb2Ygd21vZHVsZXNSZXNwb25zZS5kYXRhLmRhdGFbJ3dtb2R1bGVzJ10pIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKE9iamVjdC5rZXlzKHdvZGxlKVswXSA9PT0gY29uZlsnbmFtZSddKSB7XG4gICAgICAgICAgICAgICAgICAgICAgYWdlbnRDb25maWdSZXNwb25zZS5kYXRhID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGF0YTogd29kbGUsXG4gICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGNvbnN0IGFnZW50Q29uZmlnID1cbiAgICAgICAgICAgICAgICAgIGFnZW50Q29uZmlnUmVzcG9uc2UgJiYgYWdlbnRDb25maWdSZXNwb25zZS5kYXRhICYmIGFnZW50Q29uZmlnUmVzcG9uc2UuZGF0YS5kYXRhO1xuICAgICAgICAgICAgICAgIGlmICghdGl0bGVPZlNlY3Rpb24pIHtcbiAgICAgICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29udGVudCh7XG4gICAgICAgICAgICAgICAgICAgIHRleHQ6IGNvbmZpZy50aXRsZSxcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU6ICdoMScsXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogWzAsIDAsIDAsIDE1XSxcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgdGl0bGVPZlNlY3Rpb24gPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoIXRpdGxlT2ZTdWJzZWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICAgICAgICB0ZXh0OiBzZWN0aW9uLnN1YnRpdGxlLFxuICAgICAgICAgICAgICAgICAgICBzdHlsZTogJ2g0JyxcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgcHJpbnRlci5hZGRDb250ZW50KHtcbiAgICAgICAgICAgICAgICAgICAgdGV4dDogc2VjdGlvbi5kZXNjLFxuICAgICAgICAgICAgICAgICAgICBzdHlsZTogeyBmb250U2l6ZTogMTIsIGNvbG9yOiAnIzAwMCcgfSxcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiBbMCwgMCwgMCwgMTBdLFxuICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICB0aXRsZU9mU3Vic2VjdGlvbiA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChhZ2VudENvbmZpZykge1xuICAgICAgICAgICAgICAgICAgZm9yIChsZXQgYWdlbnRDb25maWdLZXkgb2YgT2JqZWN0LmtleXMoYWdlbnRDb25maWcpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGFnZW50Q29uZmlnW2FnZW50Q29uZmlnS2V5XSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAvKiBMT0cgQ09MTEVDVE9SICovXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbmYuZmlsdGVyQnkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBncm91cHMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFnZW50Q29uZmlnW2FnZW50Q29uZmlnS2V5XS5mb3JFYWNoKChvYmopID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFncm91cHNbb2JqLmxvZ2Zvcm1hdF0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cHNbb2JqLmxvZ2Zvcm1hdF0gPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBncm91cHNbb2JqLmxvZ2Zvcm1hdF0ucHVzaChvYmopO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBPYmplY3Qua2V5cyhncm91cHMpLmZvckVhY2goKGdyb3VwKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGxldCBzYXZlaWR4ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JvdXBzW2dyb3VwXS5mb3JFYWNoKCh4LCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXMoeCkubGVuZ3RoID4gT2JqZWN0LmtleXMoZ3JvdXBzW2dyb3VwXVtzYXZlaWR4XSkubGVuZ3RoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzYXZlaWR4ID0gaTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBjb2x1bW5zID0gT2JqZWN0LmtleXMoZ3JvdXBzW2dyb3VwXVtzYXZlaWR4XSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJvd3MgPSBncm91cHNbZ3JvdXBdLm1hcCgoeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByb3cgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcm93LnB1c2goXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGVvZiB4W2tleV0gIT09ICdvYmplY3QnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyB4W2tleV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEFycmF5LmlzQXJyYXkoeFtrZXldKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8geFtrZXldLm1hcCgoeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4geCArICdcXG4nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IEpTT04uc3RyaW5naWZ5KHhba2V5XSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJvdztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMuZm9yRWFjaCgoY29sLCBpKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1uc1tpXSA9IGNvbFswXS50b1VwcGVyQ2FzZSgpICsgY29sLnNsaWNlKDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiBzZWN0aW9uLmxhYmVsc1swXVtncm91cF0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogJ3RhYmxlJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3MsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmIChhZ2VudENvbmZpZ0tleS5jb25maWd1cmF0aW9uICE9PSAnc29ja2V0Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFibGVzLnB1c2goXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLnRoaXMuZ2V0Q29uZmlnVGFibGVzKGFnZW50Q29uZmlnW2FnZW50Q29uZmlnS2V5XSwgc2VjdGlvbiwgaWR4KVxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgX2QyIG9mIGFnZW50Q29uZmlnW2FnZW50Q29uZmlnS2V5XSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaCguLi50aGlzLmdldENvbmZpZ1RhYmxlcyhfZDIsIHNlY3Rpb24sIGlkeCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAvKklOVEVHUklUWSBNT05JVE9SSU5HIE1PTklUT1JFRCBESVJFQ1RPUklFUyAqL1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChjb25mLm1hdHJpeCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qge2RpcmVjdG9yaWVzLGRpZmYsc3luY2hyb25pemF0aW9uLGZpbGVfbGltaXQsLi4ucmVzdH0gPSBhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV07XG4gICAgICAgICAgICAgICAgICAgICAgICB0YWJsZXMucHVzaChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4udGhpcy5nZXRDb25maWdUYWJsZXMocmVzdCwgc2VjdGlvbiwgaWR4KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKGRpZmYgJiYgZGlmZi5kaXNrX3F1b3RhID8gdGhpcy5nZXRDb25maWdUYWJsZXMoZGlmZi5kaXNrX3F1b3RhLCB7dGFiczpbJ0Rpc2sgcXVvdGEnXX0sIDAgKTogW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi4oZGlmZiAmJiBkaWZmLmZpbGVfc2l6ZSA/IHRoaXMuZ2V0Q29uZmlnVGFibGVzKGRpZmYuZmlsZV9zaXplLCB7dGFiczpbJ0ZpbGUgc2l6ZSddfSwgMCApOiBbXSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC4uLihzeW5jaHJvbml6YXRpb24gPyB0aGlzLmdldENvbmZpZ1RhYmxlcyhzeW5jaHJvbml6YXRpb24sIHt0YWJzOlsnU3luY2hyb25pemF0aW9uJ119LCAwICk6IFtdKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKGZpbGVfbGltaXQgPyB0aGlzLmdldENvbmZpZ1RhYmxlcyhmaWxlX2xpbWl0LCB7dGFiczpbJ0ZpbGUgbGltaXQnXX0sIDAgKTogW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCBkaWZmT3B0cyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmtleXMoc2VjdGlvbi5vcHRzKS5mb3JFYWNoKCh4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGRpZmZPcHRzLnB1c2goeCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvbHVtbnMgPSBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICcnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5kaWZmT3B0cy5maWx0ZXIoKHgpID0+IHggIT09ICdjaGVja19hbGwnICYmIHggIT09ICdjaGVja19zdW0nKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgcm93cyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGlyZWN0b3JpZXMuZm9yRWFjaCgoeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgcm93ID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJvdy5wdXNoKHguZGlyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY29sdW1ucy5mb3JFYWNoKCh5KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHkgIT09ICcnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaCh4Lm9wdHMuaW5kZXhPZih5KSA+IC0xID8gJ3llcycgOiAnbm8nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICByb3cucHVzaCh4LnJlY3Vyc2lvbl9sZXZlbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3MucHVzaChyb3cpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLmZvckVhY2goKHgsIGlkeCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zW2lkeF0gPSBzZWN0aW9uLm9wdHNbeF07XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbHVtbnMucHVzaCgnUkwnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhYmxlcy5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdNb25pdG9yZWQgZGlyZWN0b3JpZXMnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAndGFibGUnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICBjb2x1bW5zLFxuICAgICAgICAgICAgICAgICAgICAgICAgICByb3dzLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhYmxlcy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAuLi50aGlzLmdldENvbmZpZ1RhYmxlcyhhZ2VudENvbmZpZ1thZ2VudENvbmZpZ0tleV0sIHNlY3Rpb24sIGlkeClcbiAgICAgICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgIC8vIFByaW50IG5vIGNvbmZpZ3VyZWQgbW9kdWxlIGFuZCBsaW5rIHRvIHRoZSBkb2N1bWVudGF0aW9uXG4gICAgICAgICAgICAgICAgICBwcmludGVyLmFkZENvbnRlbnQoe1xuICAgICAgICAgICAgICAgICAgICB0ZXh0OiBbXG4gICAgICAgICAgICAgICAgICAgICAgJ1RoaXMgbW9kdWxlIGlzIG5vdCBjb25maWd1cmVkLiBQbGVhc2UgdGFrZSBhIGxvb2sgb24gaG93IHRvIGNvbmZpZ3VyZSBpdCBpbiAnLFxuICAgICAgICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6IGAke3NlY3Rpb24uc3VidGl0bGUudG9Mb3dlckNhc2UoKX0gY29uZmlndXJhdGlvbi5gLFxuICAgICAgICAgICAgICAgICAgICAgICAgbGluazogc2VjdGlvbi5kb2N1TGluayxcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlOiB7IGZvbnRTaXplOiAxMiwgY29sb3I6ICcjMWEwZGFiJyB9LFxuICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbjogWzAsIDAsIDAsIDIwXSxcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBsb2coJ3JlcG9ydGluZzpyZXBvcnQnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAnZGVidWcnKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBpZHgrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZvciAoY29uc3QgdGFibGUgb2YgdGFibGVzKSB7XG4gICAgICAgICAgICAgIHByaW50ZXIuYWRkQ29uZmlnVGFibGVzKFt0YWJsZV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBpZHhDb21wb25lbnQrKztcbiAgICAgICAgICB0YWJsZXMgPSBbXTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBhd2FpdCBwcmludGVyLnByaW50KGNvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWUpO1xuXG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICBtZXNzYWdlOiBgUmVwb3J0ICR7Y29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLmZpbGVuYW1lfSB3YXMgY3JlYXRlZGAsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0NvbmZpZ3VyYXRpb24nLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDUwMjksIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfSwgKHsgcGFyYW1zOiB7IGFnZW50SUQgfX0pID0+IGB3YXp1aC1hZ2VudC1jb25maWd1cmF0aW9uLSR7YWdlbnRJRH0tJHt0aGlzLmdlbmVyYXRlUmVwb3J0VGltZXN0YW1wKCl9LnBkZmApXG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIHJlcG9ydCBmb3IgdGhlIGFnZW50c1xuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMgeyp9IHJlcG9ydHMgbGlzdCBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBjcmVhdGVSZXBvcnRzQWdlbnRzSW52ZW50b3J5ID0gdGhpcy5jaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yKCBhc3luYyAoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3QsXG4gICAgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeVxuICApID0+IHtcbiAgICB0cnkge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0ludmVudG9yeScsIGBSZXBvcnQgc3RhcnRlZGAsICdpbmZvJyk7XG4gICAgICBjb25zdCB7IHNlYXJjaEJhciwgZmlsdGVycywgdGltZSwgaW5kZXhQYXR0ZXJuVGl0bGUsIGFwaUlkLCBzZXJ2ZXJTaWRlUXVlcnkgfSA9IHJlcXVlc3QuYm9keTtcbiAgICAgIGNvbnN0IHsgYWdlbnRJRCB9ID0gcmVxdWVzdC5wYXJhbXM7XG4gICAgICBjb25zdCB7IGZyb20sIHRvIH0gPSB0aW1lIHx8IHt9O1xuICAgICAgLy8gSW5pdFxuICAgICAgY29uc3QgcHJpbnRlciA9IG5ldyBSZXBvcnRQcmludGVyKCk7XG5cbiAgICAgIGNvbnN0IHsgaGFzaFVzZXJuYW1lIH0gPSBhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpO1xuICAgICAgY3JlYXRlRGF0YURpcmVjdG9yeUlmTm90RXhpc3RzKCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19ESVJFQ1RPUllfUEFUSCk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyhXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRIKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKHBhdGguam9pbihXQVpVSF9EQVRBX0RPV05MT0FEU19SRVBPUlRTX0RJUkVDVE9SWV9QQVRILCBoYXNoVXNlcm5hbWUpKTtcblxuICAgICAgbG9nKCdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0ludmVudG9yeScsIGBTeXNjb2xsZWN0b3IgcmVwb3J0YCwgJ2RlYnVnJyk7XG4gICAgICBjb25zdCBbc2FuaXRpemVkRmlsdGVycywgYWdlbnRzRmlsdGVyXSA9IGZpbHRlcnMgPyB0aGlzLnNhbml0aXplS2liYW5hRmlsdGVycyhmaWx0ZXJzLCBzZWFyY2hCYXIpIDogW2ZhbHNlLCBudWxsXTtcblxuICAgICAgLy8gR2V0IHRoZSBhZ2VudCBPU1xuICAgICAgbGV0IGFnZW50T3MgPSAnJztcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGFnZW50UmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAgICdHRVQnLFxuICAgICAgICAgICcvYWdlbnRzJyxcbiAgICAgICAgICB7IHBhcmFtczogeyBxOiBgaWQ9JHthZ2VudElEfWAgfSB9LFxuICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XG4gICAgICAgICk7XG4gICAgICAgIGFnZW50T3MgPSBhZ2VudFJlc3BvbnNlLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS5vcy5wbGF0Zm9ybTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNBZ2VudHNJbnZlbnRvcnknLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yLCAnZGVidWcnKTtcbiAgICAgIH1cblxuICAgICAgLy8gQWRkIHRpdGxlXG4gICAgICBwcmludGVyLmFkZENvbnRlbnRXaXRoTmV3TGluZSh7XG4gICAgICAgIHRleHQ6ICdJbnZlbnRvcnkgZGF0YSByZXBvcnQnLFxuICAgICAgICBzdHlsZTogJ2gxJyxcbiAgICAgIH0pO1xuXG4gICAgICAvLyBBZGQgdGFibGUgd2l0aCB0aGUgYWdlbnQgaW5mb1xuICAgICAgYXdhaXQgYnVpbGRBZ2VudHNUYWJsZShjb250ZXh0LCBwcmludGVyLCBbYWdlbnRJRF0sIGFwaUlkKTtcblxuICAgICAgLy8gR2V0IHN5c2NvbGxlY3RvciBwYWNrYWdlcyBhbmQgcHJvY2Vzc2VzXG4gICAgICBjb25zdCBhZ2VudFJlcXVlc3RzSW52ZW50b3J5ID0gW1xuICAgICAgICB7XG4gICAgICAgICAgZW5kcG9pbnQ6IGAvc3lzY29sbGVjdG9yLyR7YWdlbnRJRH0vcGFja2FnZXNgLFxuICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBwYWNrYWdlcyBmb3IgYWdlbnQgJHthZ2VudElEfWAsXG4gICAgICAgICAgdGFibGU6IHtcbiAgICAgICAgICAgIHRpdGxlOiAnUGFja2FnZXMnLFxuICAgICAgICAgICAgY29sdW1uczpcbiAgICAgICAgICAgICAgYWdlbnRPcyA9PT0gJ3dpbmRvd3MnXG4gICAgICAgICAgICAgICAgPyBbXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICduYW1lJywgbGFiZWw6ICdOYW1lJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnYXJjaGl0ZWN0dXJlJywgbGFiZWw6ICdBcmNoaXRlY3R1cmUnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICd2ZXJzaW9uJywgbGFiZWw6ICdWZXJzaW9uJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAndmVuZG9yJywgbGFiZWw6ICdWZW5kb3InIH0sXG4gICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICduYW1lJywgbGFiZWw6ICdOYW1lJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnYXJjaGl0ZWN0dXJlJywgbGFiZWw6ICdBcmNoaXRlY3R1cmUnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICd2ZXJzaW9uJywgbGFiZWw6ICdWZXJzaW9uJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAndmVuZG9yJywgbGFiZWw6ICdWZW5kb3InIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdkZXNjcmlwdGlvbicsIGxhYmVsOiAnRGVzY3JpcHRpb24nIH0sXG4gICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBlbmRwb2ludDogYC9zeXNjb2xsZWN0b3IvJHthZ2VudElEfS9wcm9jZXNzZXNgLFxuICAgICAgICAgIGxvZ2dlck1lc3NhZ2U6IGBGZXRjaGluZyBwcm9jZXNzZXMgZm9yIGFnZW50ICR7YWdlbnRJRH1gLFxuICAgICAgICAgIHRhYmxlOiB7XG4gICAgICAgICAgICB0aXRsZTogJ1Byb2Nlc3NlcycsXG4gICAgICAgICAgICBjb2x1bW5zOlxuICAgICAgICAgICAgICBhZ2VudE9zID09PSAnd2luZG93cydcbiAgICAgICAgICAgICAgICA/IFtcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ25hbWUnLCBsYWJlbDogJ05hbWUnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdjbWQnLCBsYWJlbDogJ0NNRCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3ByaW9yaXR5JywgbGFiZWw6ICdQcmlvcml0eScgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ25sd3AnLCBsYWJlbDogJ05MV1AnIH0sXG4gICAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgOiBbXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICduYW1lJywgbGFiZWw6ICdOYW1lJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnZXVzZXInLCBsYWJlbDogJ0VmZmVjdGl2ZSB1c2VyJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbmljZScsIGxhYmVsOiAnUHJpb3JpdHknIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdzdGF0ZScsIGxhYmVsOiAnU3RhdGUnIH0sXG4gICAgICAgICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgbWFwUmVzcG9uc2VJdGVtczogKGl0ZW0pID0+XG4gICAgICAgICAgICBhZ2VudE9zID09PSAnd2luZG93cycgPyBpdGVtIDogeyAuLi5pdGVtLCBzdGF0ZTogUHJvY2Vzc0VxdWl2YWxlbmNlW2l0ZW0uc3RhdGVdIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBlbmRwb2ludDogYC9zeXNjb2xsZWN0b3IvJHthZ2VudElEfS9wb3J0c2AsXG4gICAgICAgICAgbG9nZ2VyTWVzc2FnZTogYEZldGNoaW5nIHBvcnRzIGZvciBhZ2VudCAke2FnZW50SUR9YCxcbiAgICAgICAgICB0YWJsZToge1xuICAgICAgICAgICAgdGl0bGU6ICdOZXR3b3JrIHBvcnRzJyxcbiAgICAgICAgICAgIGNvbHVtbnM6XG4gICAgICAgICAgICAgIGFnZW50T3MgPT09ICd3aW5kb3dzJ1xuICAgICAgICAgICAgICAgID8gW1xuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbG9jYWxfaXAnLCBsYWJlbDogJ0xvY2FsIElQIGFkZHJlc3MnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdsb2NhbF9wb3J0JywgbGFiZWw6ICdMb2NhbCBwb3J0JyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAncHJvY2VzcycsIGxhYmVsOiAnUHJvY2VzcycgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3N0YXRlJywgbGFiZWw6ICdTdGF0ZScgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3Byb3RvY29sJywgbGFiZWw6ICdQcm90b2NvbCcgfSxcbiAgICAgICAgICAgICAgICAgIF1cbiAgICAgICAgICAgICAgICA6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ2xvY2FsX2lwJywgbGFiZWw6ICdMb2NhbCBJUCBhZGRyZXNzJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbG9jYWxfcG9ydCcsIGxhYmVsOiAnTG9jYWwgcG9ydCcgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3N0YXRlJywgbGFiZWw6ICdTdGF0ZScgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3Byb3RvY29sJywgbGFiZWw6ICdQcm90b2NvbCcgfSxcbiAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBtYXBSZXNwb25zZUl0ZW1zOiAoaXRlbSkgPT4gKHtcbiAgICAgICAgICAgIC4uLml0ZW0sXG4gICAgICAgICAgICBsb2NhbF9pcDogaXRlbS5sb2NhbC5pcCxcbiAgICAgICAgICAgIGxvY2FsX3BvcnQ6IGl0ZW0ubG9jYWwucG9ydCxcbiAgICAgICAgICB9KSxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIGVuZHBvaW50OiBgL3N5c2NvbGxlY3Rvci8ke2FnZW50SUR9L25ldGlmYWNlYCxcbiAgICAgICAgICBsb2dnZXJNZXNzYWdlOiBgRmV0Y2hpbmcgbmV0aWZhY2UgZm9yIGFnZW50ICR7YWdlbnRJRH1gLFxuICAgICAgICAgIHRhYmxlOiB7XG4gICAgICAgICAgICB0aXRsZTogJ05ldHdvcmsgaW50ZXJmYWNlcycsXG4gICAgICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICAgIHsgaWQ6ICduYW1lJywgbGFiZWw6ICdOYW1lJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnbWFjJywgbGFiZWw6ICdNYWMnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdzdGF0ZScsIGxhYmVsOiAnU3RhdGUnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdtdHUnLCBsYWJlbDogJ01UVScgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ3R5cGUnLCBsYWJlbDogJ1R5cGUnIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICBlbmRwb2ludDogYC9zeXNjb2xsZWN0b3IvJHthZ2VudElEfS9uZXRhZGRyYCxcbiAgICAgICAgICBsb2dnZXJNZXNzYWdlOiBgRmV0Y2hpbmcgbmV0YWRkciBmb3IgYWdlbnQgJHthZ2VudElEfWAsXG4gICAgICAgICAgdGFibGU6IHtcbiAgICAgICAgICAgIHRpdGxlOiAnTmV0d29yayBzZXR0aW5ncycsXG4gICAgICAgICAgICBjb2x1bW5zOiBbXG4gICAgICAgICAgICAgIHsgaWQ6ICdpZmFjZScsIGxhYmVsOiAnSW50ZXJmYWNlJyB9LFxuICAgICAgICAgICAgICB7IGlkOiAnYWRkcmVzcycsIGxhYmVsOiAnQWRkcmVzcycgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ25ldG1hc2snLCBsYWJlbDogJ05ldG1hc2snIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdwcm90bycsIGxhYmVsOiAnUHJvdG9jb2wnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdicm9hZGNhc3QnLCBsYWJlbDogJ0Jyb2FkY2FzdCcgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIF07XG5cbiAgICAgIGFnZW50T3MgPT09ICd3aW5kb3dzJyAmJlxuICAgICAgICBhZ2VudFJlcXVlc3RzSW52ZW50b3J5LnB1c2goe1xuICAgICAgICAgIGVuZHBvaW50OiBgL3N5c2NvbGxlY3Rvci8ke2FnZW50SUR9L2hvdGZpeGVzYCxcbiAgICAgICAgICBsb2dnZXJNZXNzYWdlOiBgRmV0Y2hpbmcgaG90Zml4ZXMgZm9yIGFnZW50ICR7YWdlbnRJRH1gLFxuICAgICAgICAgIHRhYmxlOiB7XG4gICAgICAgICAgICB0aXRsZTogJ1dpbmRvd3MgdXBkYXRlcycsXG4gICAgICAgICAgICBjb2x1bW5zOiBbeyBpZDogJ2hvdGZpeCcsIGxhYmVsOiAnVXBkYXRlIGNvZGUnIH1dLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuXG4gICAgICBjb25zdCByZXF1ZXN0SW52ZW50b3J5ID0gYXN5bmMgKGFnZW50UmVxdWVzdEludmVudG9yeSkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGxvZyhcbiAgICAgICAgICAgICdyZXBvcnRpbmc6Y3JlYXRlUmVwb3J0c0FnZW50c0ludmVudG9yeScsXG4gICAgICAgICAgICBhZ2VudFJlcXVlc3RJbnZlbnRvcnkubG9nZ2VyTWVzc2FnZSxcbiAgICAgICAgICAgICdkZWJ1ZydcbiAgICAgICAgICApO1xuXG4gICAgICAgICAgY29uc3QgaW52ZW50b3J5UmVzcG9uc2UgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNDdXJyZW50VXNlci5yZXF1ZXN0KFxuICAgICAgICAgICAgJ0dFVCcsXG4gICAgICAgICAgICBhZ2VudFJlcXVlc3RJbnZlbnRvcnkuZW5kcG9pbnQsXG4gICAgICAgICAgICB7fSxcbiAgICAgICAgICAgIHsgYXBpSG9zdElEOiBhcGlJZCB9XG4gICAgICAgICAgKTtcblxuICAgICAgICAgIGNvbnN0IGludmVudG9yeSA9XG4gICAgICAgICAgICBpbnZlbnRvcnlSZXNwb25zZSAmJlxuICAgICAgICAgICAgaW52ZW50b3J5UmVzcG9uc2UuZGF0YSAmJlxuICAgICAgICAgICAgaW52ZW50b3J5UmVzcG9uc2UuZGF0YS5kYXRhICYmXG4gICAgICAgICAgICBpbnZlbnRvcnlSZXNwb25zZS5kYXRhLmRhdGEuYWZmZWN0ZWRfaXRlbXM7XG4gICAgICAgICAgaWYgKGludmVudG9yeSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgLi4uYWdlbnRSZXF1ZXN0SW52ZW50b3J5LnRhYmxlLFxuICAgICAgICAgICAgICBpdGVtczogYWdlbnRSZXF1ZXN0SW52ZW50b3J5Lm1hcFJlc3BvbnNlSXRlbXNcbiAgICAgICAgICAgICAgICA/IGludmVudG9yeS5tYXAoYWdlbnRSZXF1ZXN0SW52ZW50b3J5Lm1hcFJlc3BvbnNlSXRlbXMpXG4gICAgICAgICAgICAgICAgOiBpbnZlbnRvcnksXG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBsb2coJ3JlcG9ydGluZzpjcmVhdGVSZXBvcnRzQWdlbnRzSW52ZW50b3J5JywgZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgJ2RlYnVnJyk7XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIGlmICh0aW1lKSB7XG4gICAgICAgIC8vIEFkZCBWdWxuZXJhYmlsaXR5IERldGVjdG9yIGZpbHRlciB0byB0aGUgU2VydmVyIFNpZGUgUXVlcnlcbiAgICAgICAgc2VydmVyU2lkZVF1ZXJ5Py5ib29sPy5tdXN0Py5wdXNoPy4oe1xuICAgICAgICAgIG1hdGNoX3BocmFzZToge1xuICAgICAgICAgICAgXCJydWxlLmdyb3Vwc1wiOiB7XG4gICAgICAgICAgICAgIHF1ZXJ5OiBcInZ1bG5lcmFiaWxpdHktZGV0ZWN0b3JcIlxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgYXdhaXQgZXh0ZW5kZWRJbmZvcm1hdGlvbihcbiAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgIHByaW50ZXIsXG4gICAgICAgICAgJ2FnZW50cycsXG4gICAgICAgICAgJ3N5c2NvbGxlY3RvcicsXG4gICAgICAgICAgYXBpSWQsXG4gICAgICAgICAgZnJvbSxcbiAgICAgICAgICB0byxcbiAgICAgICAgICBzZXJ2ZXJTaWRlUXVlcnksXG4gICAgICAgICAgYWdlbnRzRmlsdGVyLFxuICAgICAgICAgIGluZGV4UGF0dGVyblRpdGxlLFxuICAgICAgICAgIGFnZW50SURcbiAgICAgICAgKTtcbiAgICAgIH1cblxuICAgICAgLy8gQWRkIGludmVudG9yeSB0YWJsZXNcbiAgICAgIChhd2FpdCBQcm9taXNlLmFsbChhZ2VudFJlcXVlc3RzSW52ZW50b3J5Lm1hcChyZXF1ZXN0SW52ZW50b3J5KSkpXG4gICAgICAgIC5maWx0ZXIoKHRhYmxlKSA9PiB0YWJsZSlcbiAgICAgICAgLmZvckVhY2goKHRhYmxlKSA9PiBwcmludGVyLmFkZFNpbXBsZVRhYmxlKHRhYmxlKSk7XG5cbiAgICAgIC8vIFByaW50IHRoZSBkb2N1bWVudFxuICAgICAgYXdhaXQgcHJpbnRlci5wcmludChjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMucGF0aEZpbGVuYW1lKTtcblxuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgbWVzc2FnZTogYFJlcG9ydCAke2NvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5maWxlbmFtZX0gd2FzIGNyZWF0ZWRgLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygncmVwb3J0aW5nOmNyZWF0ZVJlcG9ydHNBZ2VudHMnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDUwMjksIDUwMCwgcmVzcG9uc2UpO1xuICAgIH1cbiAgfSwgKHtwYXJhbXM6IHsgYWdlbnRJRCB9fSkgPT4gYHdhenVoLWFnZW50LWludmVudG9yeS0ke2FnZW50SUR9LSR7dGhpcy5nZW5lcmF0ZVJlcG9ydFRpbWVzdGFtcCgpfS5wZGZgKVxuXG4gIC8qKlxuICAgKiBGZXRjaCB0aGUgcmVwb3J0cyBsaXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSBjb250ZXh0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXF1ZXN0XG4gICAqIEBwYXJhbSB7T2JqZWN0fSByZXNwb25zZVxuICAgKiBAcmV0dXJucyB7QXJyYXk8T2JqZWN0Pn0gcmVwb3J0cyBsaXN0IG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIGdldFJlcG9ydHMoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3QsXG4gICAgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeVxuICApIHtcbiAgICB0cnkge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Z2V0UmVwb3J0cycsIGBGZXRjaGluZyBjcmVhdGVkIHJlcG9ydHNgLCAnaW5mbycpO1xuICAgICAgY29uc3QgeyBoYXNoVXNlcm5hbWUgfSA9IGF3YWl0IGNvbnRleHQud2F6dWguc2VjdXJpdHkuZ2V0Q3VycmVudFVzZXIocmVxdWVzdCwgY29udGV4dCk7XG4gICAgICBjcmVhdGVEYXRhRGlyZWN0b3J5SWZOb3RFeGlzdHMoKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKFdBWlVIX0RBVEFfRE9XTkxPQURTX0RJUkVDVE9SWV9QQVRIKTtcbiAgICAgIGNyZWF0ZURpcmVjdG9yeUlmTm90RXhpc3RzKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgpO1xuICAgICAgY29uc3QgdXNlclJlcG9ydHNEaXJlY3RvcnlQYXRoID0gcGF0aC5qb2luKFdBWlVIX0RBVEFfRE9XTkxPQURTX1JFUE9SVFNfRElSRUNUT1JZX1BBVEgsIGhhc2hVc2VybmFtZSk7XG4gICAgICBjcmVhdGVEaXJlY3RvcnlJZk5vdEV4aXN0cyh1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGgpO1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Z2V0UmVwb3J0cycsIGBEaXJlY3Rvcnk6ICR7dXNlclJlcG9ydHNEaXJlY3RvcnlQYXRofWAsICdkZWJ1ZycpO1xuXG4gICAgICBjb25zdCBzb3J0UmVwb3J0c0J5RGF0ZSA9IChhLCBiKSA9PiAoYS5kYXRlIDwgYi5kYXRlID8gMSA6IGEuZGF0ZSA+IGIuZGF0ZSA/IC0xIDogMCk7XG5cbiAgICAgIGNvbnN0IHJlcG9ydHMgPSBmcy5yZWFkZGlyU3luYyh1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGgpLm1hcCgoZmlsZSkgPT4ge1xuICAgICAgICBjb25zdCBzdGF0cyA9IGZzLnN0YXRTeW5jKHVzZXJSZXBvcnRzRGlyZWN0b3J5UGF0aCArICcvJyArIGZpbGUpO1xuICAgICAgICAvLyBHZXQgdGhlIGZpbGUgY3JlYXRpb24gdGltZSAoYml0aHRpbWUpLiBJdCByZXR1cm5zIHRoZSBmaXJzdCB2YWx1ZSB0aGF0IGlzIGEgdHJ1dGh5IHZhbHVlIG9mIG5leHQgZmlsZSBzdGF0czogYmlydGh0aW1lLCBtdGltZSwgY3RpbWUgYW5kIGF0aW1lLlxuICAgICAgICAvLyBUaGlzIHNvbHZlcyBzb21lIE9TcyBjYW4gaGF2ZSB0aGUgYml0aHRpbWVNcyBlcXVhbCB0byAwIGFuZCByZXR1cm5zIHRoZSBkYXRlIGxpa2UgMTk3MC0wMS0wMVxuICAgICAgICBjb25zdCBiaXJ0aFRpbWVGaWVsZCA9IFsnYmlydGh0aW1lJywgJ210aW1lJywgJ2N0aW1lJywgJ2F0aW1lJ10uZmluZChcbiAgICAgICAgICAodGltZSkgPT4gc3RhdHNbYCR7dGltZX1Nc2BdXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgbmFtZTogZmlsZSxcbiAgICAgICAgICBzaXplOiBzdGF0cy5zaXplLFxuICAgICAgICAgIGRhdGU6IHN0YXRzW2JpcnRoVGltZUZpZWxkXSxcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Z2V0UmVwb3J0cycsIGBVc2luZyBUaW1Tb3J0IGZvciBzb3J0aW5nICR7cmVwb3J0cy5sZW5ndGh9IGl0ZW1zYCwgJ2RlYnVnJyk7XG4gICAgICBUaW1Tb3J0LnNvcnQocmVwb3J0cywgc29ydFJlcG9ydHNCeURhdGUpO1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Z2V0UmVwb3J0cycsIGBUb3RhbCByZXBvcnRzOiAke3JlcG9ydHMubGVuZ3RofWAsICdkZWJ1ZycpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keTogeyByZXBvcnRzIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Z2V0UmVwb3J0cycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAzMSwgNTAwLCByZXNwb25zZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEZldGNoIHNwZWNpZmljIHJlcG9ydFxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gcmVwb3J0IG9yIEVycm9yUmVzcG9uc2VcbiAgICovXG4gIGdldFJlcG9ydEJ5TmFtZSA9IHRoaXMuY2hlY2tSZXBvcnRzVXNlckRpcmVjdG9yeUlzVmFsaWRSb3V0ZURlY29yYXRvcihhc3luYyAoXG4gICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgIHJlcXVlc3Q6IEtpYmFuYVJlcXVlc3QsXG4gICAgcmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeVxuICApID0+IHtcbiAgICB0cnkge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6Z2V0UmVwb3J0QnlOYW1lJywgYEdldHRpbmcgJHtjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMucGF0aEZpbGVuYW1lfSByZXBvcnRgLCAnZGVidWcnKTtcbiAgICAgIGNvbnN0IHJlcG9ydEZpbGVCdWZmZXIgPSBmcy5yZWFkRmlsZVN5bmMoY29udGV4dC53YXp1aEVuZHBvaW50UGFyYW1zLnBhdGhGaWxlbmFtZSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vcGRmJyB9LFxuICAgICAgICBib2R5OiByZXBvcnRGaWxlQnVmZmVyLFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGxvZygncmVwb3J0aW5nOmdldFJlcG9ydEJ5TmFtZScsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgcmV0dXJuIEVycm9yUmVzcG9uc2UoZXJyb3IubWVzc2FnZSB8fCBlcnJvciwgNTAzMCwgNTAwLCByZXNwb25zZSk7XG4gICAgfVxuICB9LCAocmVxdWVzdCkgPT4gcmVxdWVzdC5wYXJhbXMubmFtZSlcblxuICAvKipcbiAgICogRGVsZXRlIHNwZWNpZmljIHJlcG9ydFxuICAgKiBAcGFyYW0ge09iamVjdH0gY29udGV4dFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVxdWVzdFxuICAgKiBAcGFyYW0ge09iamVjdH0gcmVzcG9uc2VcbiAgICogQHJldHVybnMge09iamVjdH0gc3RhdHVzIG9iaiBvciBFcnJvclJlc3BvbnNlXG4gICAqL1xuICBkZWxldGVSZXBvcnRCeU5hbWUgPSB0aGlzLmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3IoYXN5bmMgKFxuICAgIGNvbnRleHQ6IFJlcXVlc3RIYW5kbGVyQ29udGV4dCxcbiAgICByZXF1ZXN0OiBLaWJhbmFSZXF1ZXN0LFxuICAgIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnlcbiAgKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGxvZygncmVwb3J0aW5nOmRlbGV0ZVJlcG9ydEJ5TmFtZScsIGBEZWxldGluZyAke2NvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWV9IHJlcG9ydGAsICdkZWJ1ZycpO1xuICAgICAgZnMudW5saW5rU3luYyhjb250ZXh0LndhenVoRW5kcG9pbnRQYXJhbXMucGF0aEZpbGVuYW1lKTtcbiAgICAgIGxvZygncmVwb3J0aW5nOmRlbGV0ZVJlcG9ydEJ5TmFtZScsIGAke2NvbnRleHQud2F6dWhFbmRwb2ludFBhcmFtcy5wYXRoRmlsZW5hbWV9IHJlcG9ydCB3YXMgZGVsZXRlZGAsICdpbmZvJyk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICBib2R5OiB7IGVycm9yOiAwIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgbG9nKCdyZXBvcnRpbmc6ZGVsZXRlUmVwb3J0QnlOYW1lJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICByZXR1cm4gRXJyb3JSZXNwb25zZShlcnJvci5tZXNzYWdlIHx8IGVycm9yLCA1MDMyLCA1MDAsIHJlc3BvbnNlKTtcbiAgICB9XG4gIH0sKHJlcXVlc3QpID0+IHJlcXVlc3QucGFyYW1zLm5hbWUpXG5cbiAgY2hlY2tSZXBvcnRzVXNlckRpcmVjdG9yeUlzVmFsaWRSb3V0ZURlY29yYXRvcihyb3V0ZUhhbmRsZXIsIHJlcG9ydEZpbGVOYW1lQWNjZXNzb3Ipe1xuICAgIHJldHVybiAoYXN5bmMgKFxuICAgICAgY29udGV4dDogUmVxdWVzdEhhbmRsZXJDb250ZXh0LFxuICAgICAgcmVxdWVzdDogS2liYW5hUmVxdWVzdCxcbiAgICAgIHJlc3BvbnNlOiBLaWJhbmFSZXNwb25zZUZhY3RvcnlcbiAgICApID0+IHtcbiAgICAgIHRyeXtcbiAgICAgICAgY29uc3QgeyB1c2VybmFtZSwgaGFzaFVzZXJuYW1lIH0gPSBhd2FpdCBjb250ZXh0LndhenVoLnNlY3VyaXR5LmdldEN1cnJlbnRVc2VyKHJlcXVlc3QsIGNvbnRleHQpO1xuICAgICAgICBjb25zdCB1c2VyUmVwb3J0c0RpcmVjdG9yeVBhdGggPSBwYXRoLmpvaW4oV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCwgaGFzaFVzZXJuYW1lKTtcbiAgICAgICAgY29uc3QgZmlsZW5hbWUgPSByZXBvcnRGaWxlTmFtZUFjY2Vzc29yKHJlcXVlc3QpO1xuICAgICAgICBjb25zdCBwYXRoRmlsZW5hbWUgPSBwYXRoLmpvaW4odXNlclJlcG9ydHNEaXJlY3RvcnlQYXRoLCBmaWxlbmFtZSk7XG4gICAgICAgIGxvZygncmVwb3J0aW5nOmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3InLCBgQ2hlY2tpbmcgdGhlIHVzZXIgJHt1c2VybmFtZX0oJHtoYXNoVXNlcm5hbWV9KSBjYW4gZG8gYWN0aW9ucyBpbiB0aGUgcmVwb3J0cyBmaWxlOiAke3BhdGhGaWxlbmFtZX1gLCAnZGVidWcnKTtcbiAgICAgICAgaWYoIXBhdGhGaWxlbmFtZS5zdGFydHNXaXRoKHVzZXJSZXBvcnRzRGlyZWN0b3J5UGF0aCkgfHwgcGF0aEZpbGVuYW1lLmluY2x1ZGVzKCcuLi8nKSl7XG4gICAgICAgICAgbG9nKCdzZWN1cml0eTpyZXBvcnRpbmc6Y2hlY2tSZXBvcnRzVXNlckRpcmVjdG9yeUlzVmFsaWRSb3V0ZURlY29yYXRvcicsIGBVc2VyICR7dXNlcm5hbWV9KCR7aGFzaFVzZXJuYW1lfSkgdHJpZWQgdG8gYWNjZXNzIHRvIGEgbm9uIHVzZXIgcmVwb3J0IGZpbGU6ICR7cGF0aEZpbGVuYW1lfWAsICd3YXJuJyk7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJhZFJlcXVlc3Qoe1xuICAgICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgICBtZXNzYWdlOiAnNTA0MCAtIFlvdSBzaGFsbCBub3QgcGFzcyEnXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgIH07XG4gICAgICAgIGxvZygncmVwb3J0aW5nOmNoZWNrUmVwb3J0c1VzZXJEaXJlY3RvcnlJc1ZhbGlkUm91dGVEZWNvcmF0b3InLCAnQ2hlY2tpbmcgdGhlIHVzZXIgY2FuIGRvIGFjdGlvbnMgaW4gdGhlIHJlcG9ydHMgZmlsZScsICdkZWJ1ZycpO1xuICAgICAgICByZXR1cm4gYXdhaXQgcm91dGVIYW5kbGVyLmJpbmQodGhpcykoey4uLmNvbnRleHQsIHdhenVoRW5kcG9pbnRQYXJhbXM6IHsgaGFzaFVzZXJuYW1lLCBmaWxlbmFtZSwgcGF0aEZpbGVuYW1lIH19LCByZXF1ZXN0LCByZXNwb25zZSk7XG4gICAgICB9Y2F0Y2goZXJyb3Ipe1xuICAgICAgICBsb2coJ3JlcG9ydGluZzpjaGVja1JlcG9ydHNVc2VyRGlyZWN0b3J5SXNWYWxpZFJvdXRlRGVjb3JhdG9yJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICAgIHJldHVybiBFcnJvclJlc3BvbnNlKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IsIDUwNDAsIDUwMCwgcmVzcG9uc2UpO1xuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICBwcml2YXRlIGdlbmVyYXRlUmVwb3J0VGltZXN0YW1wKCl7XG4gICAgcmV0dXJuIGAkeyhEYXRlLm5vdygpIC8gMTAwMCkgfCAwfWA7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFXQSxJQUFBQSxLQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBQyxHQUFBLEdBQUFGLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBRSxhQUFBLEdBQUFGLE9BQUE7QUFDQSxJQUFBRyxPQUFBLEdBQUFDLHVCQUFBLENBQUFKLE9BQUE7QUFDQSxJQUFBSyxjQUFBLEdBQUFMLE9BQUE7QUFDQSxJQUFBTSx3QkFBQSxHQUFBUCxzQkFBQSxDQUFBQyxPQUFBO0FBQ0EsSUFBQU8sa0JBQUEsR0FBQVAsT0FBQTtBQUNBLElBQUFRLG1CQUFBLEdBQUFSLE9BQUE7QUFDQSxJQUFBUyxvQkFBQSxHQUFBVCxPQUFBO0FBQ0EsSUFBQVUsUUFBQSxHQUFBVixPQUFBO0FBQ0EsSUFBQVcsT0FBQSxHQUFBWCxPQUFBO0FBRUEsSUFBQVksVUFBQSxHQUFBWixPQUFBO0FBTUEsSUFBQWEsV0FBQSxHQUFBYixPQUFBO0FBQ0EsSUFBQWMsZ0JBQUEsR0FBQWQsT0FBQTtBQUFzRixTQUFBZSx5QkFBQUMsV0FBQSxlQUFBQyxPQUFBLGtDQUFBQyxpQkFBQSxPQUFBRCxPQUFBLFFBQUFFLGdCQUFBLE9BQUFGLE9BQUEsWUFBQUYsd0JBQUEsWUFBQUEsQ0FBQUMsV0FBQSxXQUFBQSxXQUFBLEdBQUFHLGdCQUFBLEdBQUFELGlCQUFBLEtBQUFGLFdBQUE7QUFBQSxTQUFBWix3QkFBQWdCLEdBQUEsRUFBQUosV0FBQSxTQUFBQSxXQUFBLElBQUFJLEdBQUEsSUFBQUEsR0FBQSxDQUFBQyxVQUFBLFdBQUFELEdBQUEsUUFBQUEsR0FBQSxvQkFBQUEsR0FBQSx3QkFBQUEsR0FBQSw0QkFBQUUsT0FBQSxFQUFBRixHQUFBLFVBQUFHLEtBQUEsR0FBQVIsd0JBQUEsQ0FBQUMsV0FBQSxPQUFBTyxLQUFBLElBQUFBLEtBQUEsQ0FBQUMsR0FBQSxDQUFBSixHQUFBLFlBQUFHLEtBQUEsQ0FBQUUsR0FBQSxDQUFBTCxHQUFBLFNBQUFNLE1BQUEsV0FBQUMscUJBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsR0FBQSxJQUFBWCxHQUFBLFFBQUFXLEdBQUEsa0JBQUFILE1BQUEsQ0FBQUksU0FBQSxDQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWQsR0FBQSxFQUFBVyxHQUFBLFNBQUFJLElBQUEsR0FBQVIscUJBQUEsR0FBQUMsTUFBQSxDQUFBRSx3QkFBQSxDQUFBVixHQUFBLEVBQUFXLEdBQUEsY0FBQUksSUFBQSxLQUFBQSxJQUFBLENBQUFWLEdBQUEsSUFBQVUsSUFBQSxDQUFBQyxHQUFBLEtBQUFSLE1BQUEsQ0FBQUMsY0FBQSxDQUFBSCxNQUFBLEVBQUFLLEdBQUEsRUFBQUksSUFBQSxZQUFBVCxNQUFBLENBQUFLLEdBQUEsSUFBQVgsR0FBQSxDQUFBVyxHQUFBLFNBQUFMLE1BQUEsQ0FBQUosT0FBQSxHQUFBRixHQUFBLE1BQUFHLEtBQUEsSUFBQUEsS0FBQSxDQUFBYSxHQUFBLENBQUFoQixHQUFBLEVBQUFNLE1BQUEsWUFBQUEsTUFBQTtBQTlCdEY7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUEyQk8sTUFBTVcsa0JBQWtCLENBQUM7RUFDOUJDLFdBQVdBLENBQUEsRUFBRztJQTJPZDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQU5FLElBQUFDLGdCQUFBLENBQUFqQixPQUFBLGdDQU91QixJQUFJLENBQUNrQiw4Q0FBOEMsQ0FBQyxPQUN6RUMsT0FBOEIsRUFDOUJDLE9BQXNCLEVBQ3RCQyxRQUErQixLQUM1QjtNQUNILElBQUk7UUFDRixJQUFBQyxXQUFHLEVBQUMsZ0NBQWdDLEVBQUcsZ0JBQWUsRUFBRSxNQUFNLENBQUM7UUFDL0QsTUFBTTtVQUNKQyxLQUFLO1VBQ0xDLE1BQU07VUFDTkMsZUFBZTtVQUNmQyxTQUFTO1VBQ1RDLE9BQU87VUFDUEMsZUFBZTtVQUNmQyxJQUFJO1VBQ0pDLE1BQU07VUFDTkMsT0FBTztVQUNQQyxpQkFBaUI7VUFDakJDO1FBQ0YsQ0FBQyxHQUFHYixPQUFPLENBQUNjLElBQUk7UUFDaEIsTUFBTTtVQUFFQztRQUFTLENBQUMsR0FBR2YsT0FBTyxDQUFDZ0IsTUFBTTtRQUNuQyxNQUFNO1VBQUVDLElBQUk7VUFBRUM7UUFBRyxDQUFDLEdBQUdULElBQUksSUFBSSxDQUFDLENBQUM7UUFDL0IsSUFBSVUsZ0JBQWdCLEdBQUcsRUFBRTtRQUN6QjtRQUNBLE1BQU1DLE9BQU8sR0FBRyxJQUFJQyxzQkFBYSxFQUFFO1FBRW5DLElBQUFDLDBDQUE4QixHQUFFO1FBQ2hDLElBQUFDLHNDQUEwQixFQUFDQyw4Q0FBbUMsQ0FBQztRQUMvRCxJQUFBRCxzQ0FBMEIsRUFBQ0Usc0RBQTJDLENBQUM7UUFDdkUsSUFBQUYsc0NBQTBCLEVBQUNHLGFBQUksQ0FBQ0MsSUFBSSxDQUFDRixzREFBMkMsRUFBRTFCLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDQyxZQUFZLENBQUMsQ0FBQztRQUU1SCxNQUFNLElBQUksQ0FBQ0MsWUFBWSxDQUFDL0IsT0FBTyxFQUFFcUIsT0FBTyxFQUFFVCxPQUFPLEVBQUVJLFFBQVEsRUFBRVgsTUFBTSxFQUFFUyxLQUFLLENBQUM7UUFFM0UsTUFBTSxDQUFDa0IsZ0JBQWdCLEVBQUVDLFlBQVksQ0FBQyxHQUFHekIsT0FBTyxHQUM1QyxJQUFJLENBQUMwQixxQkFBcUIsQ0FBQzFCLE9BQU8sRUFBRUQsU0FBUyxDQUFDLEdBQzlDLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztRQUVqQixJQUFJRyxJQUFJLElBQUlzQixnQkFBZ0IsRUFBRTtVQUM1QlgsT0FBTyxDQUFDYyxzQkFBc0IsQ0FBQ2pCLElBQUksRUFBRUMsRUFBRSxFQUFFYSxnQkFBZ0IsRUFBRTFCLGVBQWUsQ0FBQztRQUM3RTtRQUVBLElBQUlJLElBQUksRUFBRTtVQUNSVSxnQkFBZ0IsR0FBRyxNQUFNLElBQUFnQix3Q0FBbUIsRUFDMUNwQyxPQUFPLEVBQ1BxQixPQUFPLEVBQ1BULE9BQU8sRUFDUEksUUFBUSxFQUNSRixLQUFLLEVBQ0wsSUFBSXVCLElBQUksQ0FBQ25CLElBQUksQ0FBQyxDQUFDb0IsT0FBTyxFQUFFLEVBQ3hCLElBQUlELElBQUksQ0FBQ2xCLEVBQUUsQ0FBQyxDQUFDbUIsT0FBTyxFQUFFLEVBQ3RCN0IsZUFBZSxFQUNmd0IsWUFBWSxFQUNacEIsaUJBQWlCLEVBQ2pCUixNQUFNLENBQ1A7UUFDSDtRQUVBZ0IsT0FBTyxDQUFDa0IsaUJBQWlCLENBQUNuQyxLQUFLLEVBQUVDLE1BQU0sRUFBRVcsUUFBUSxDQUFDO1FBRWxELElBQUlMLE1BQU0sRUFBRTtVQUNWVSxPQUFPLENBQUNtQixTQUFTLENBQUMsQ0FBQyxHQUFHN0IsTUFBTSxFQUFFLElBQUlTLGdCQUFnQixJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDN0Q7O1FBRUE7UUFDQSxJQUFJYSxZQUFZLGFBQVpBLFlBQVksZUFBWkEsWUFBWSxDQUFFUSxVQUFVLEVBQUU7VUFDNUJwQixPQUFPLENBQUNxQixnQkFBZ0IsQ0FBQ1QsWUFBWSxDQUFDUSxVQUFVLENBQUM7UUFDbkQ7UUFFQSxNQUFNcEIsT0FBTyxDQUFDc0IsS0FBSyxDQUFDM0MsT0FBTyxDQUFDNkIsbUJBQW1CLENBQUNlLFlBQVksQ0FBQztRQUU3RCxPQUFPMUMsUUFBUSxDQUFDMkMsRUFBRSxDQUFDO1VBQ2pCOUIsSUFBSSxFQUFFO1lBQ0orQixPQUFPLEVBQUUsSUFBSTtZQUNiQyxPQUFPLEVBQUcsVUFBUy9DLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDbUIsUUFBUztVQUMxRDtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsQ0FBQyxPQUFPQyxLQUFLLEVBQUU7UUFDZCxPQUFPLElBQUFDLDRCQUFhLEVBQUNELEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRS9DLFFBQVEsQ0FBQztNQUNuRTtJQUNGLENBQUMsRUFBQyxDQUFDO01BQUNhLElBQUksRUFBQztRQUFFVjtNQUFPLENBQUM7TUFBRVksTUFBTSxFQUFFO1FBQUVEO01BQVM7SUFBQyxDQUFDLEtBQU0sZ0JBQWVYLE1BQU0sR0FBSSxVQUFTQSxNQUFPLEVBQUMsR0FBRyxVQUFXLElBQUdXLFFBQVMsSUFBRyxJQUFJLENBQUNtQyx1QkFBdUIsRUFBRyxNQUFLLENBQUM7SUFFNUo7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFORSxJQUFBckQsZ0JBQUEsQ0FBQWpCLE9BQUEsK0JBT3NCLElBQUksQ0FBQ2tCLDhDQUE4QyxDQUFDLE9BQ3hFQyxPQUE4QixFQUM5QkMsT0FBc0IsRUFDdEJDLFFBQStCLEtBQzVCO01BQ0gsSUFBSTtRQUNGLElBQUFDLFdBQUcsRUFBQywrQkFBK0IsRUFBRyxnQkFBZSxFQUFFLE1BQU0sQ0FBQztRQUM5RCxNQUFNO1VBQUVpRCxVQUFVO1VBQUV0QztRQUFNLENBQUMsR0FBR2IsT0FBTyxDQUFDYyxJQUFJO1FBQzFDLE1BQU07VUFBRXNDO1FBQVEsQ0FBQyxHQUFHcEQsT0FBTyxDQUFDZ0IsTUFBTTtRQUNsQztRQUNBLE1BQU1JLE9BQU8sR0FBRyxJQUFJQyxzQkFBYSxFQUFFO1FBRW5DLElBQUFDLDBDQUE4QixHQUFFO1FBQ2hDLElBQUFDLHNDQUEwQixFQUFDQyw4Q0FBbUMsQ0FBQztRQUMvRCxJQUFBRCxzQ0FBMEIsRUFBQ0Usc0RBQTJDLENBQUM7UUFDdkUsSUFBQUYsc0NBQTBCLEVBQUNHLGFBQUksQ0FBQ0MsSUFBSSxDQUFDRixzREFBMkMsRUFBRTFCLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDQyxZQUFZLENBQUMsQ0FBQztRQUU1SCxJQUFJbkIsTUFBTSxHQUFHLEVBQUU7UUFDZixNQUFNMkMsWUFBWSxHQUFHO1VBQ25CQyxTQUFTLEVBQUUsYUFBYTtVQUN4QkMsT0FBTyxFQUFFLFNBQVM7VUFDbEJDLE9BQU8sRUFBRSxTQUFTO1VBQ2xCQyxRQUFRLEVBQUUsVUFBVTtVQUNwQixXQUFXLEVBQUUsVUFBVTtVQUN2QixTQUFTLEVBQUUsU0FBUztVQUNwQkMsWUFBWSxFQUFFLGNBQWM7VUFDNUJDLFNBQVMsRUFBRSxXQUFXO1VBQ3RCQyxNQUFNLEVBQUUsUUFBUTtVQUNoQkMsR0FBRyxFQUFFO1FBQ1AsQ0FBQztRQUNEekMsT0FBTyxDQUFDMEMsVUFBVSxDQUFDO1VBQ2pCQyxJQUFJLEVBQUcsU0FBUVgsT0FBUSxnQkFBZTtVQUN0Q1ksS0FBSyxFQUFFO1FBQ1QsQ0FBQyxDQUFDOztRQUVGO1FBQ0EsSUFBSWIsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFO1VBRW5CLE1BQU07WUFBRWMsSUFBSSxFQUFFO2NBQUVBLElBQUksRUFBRUM7WUFBYztVQUFFLENBQUMsR0FBRyxNQUFNbkUsT0FBTyxDQUFDb0UsS0FBSyxDQUFDQyxHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDdEUsT0FBTyxDQUM1RixLQUFLLEVBQ0osV0FBVW9ELE9BQVEsZ0JBQWUsRUFDbEMsQ0FBQyxDQUFDLEVBQ0Y7WUFBRW1CLFNBQVMsRUFBRTFEO1VBQU0sQ0FBQyxDQUNyQjtVQUVELElBQ0VxRCxhQUFhLENBQUNNLGNBQWMsQ0FBQ0MsTUFBTSxHQUFHLENBQUMsSUFDdkN2RixNQUFNLENBQUN3RixJQUFJLENBQUNSLGFBQWEsQ0FBQ00sY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDRyxNQUFNLENBQUMsQ0FBQ0YsTUFBTSxFQUMxRDtZQUNBckQsT0FBTyxDQUFDMEMsVUFBVSxDQUFDO2NBQ2pCQyxJQUFJLEVBQUUsZ0JBQWdCO2NBQ3RCQyxLQUFLLEVBQUU7Z0JBQUVZLFFBQVEsRUFBRSxFQUFFO2dCQUFFQyxLQUFLLEVBQUU7Y0FBTyxDQUFDO2NBQ3RDQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3ZCLENBQUMsQ0FBQztZQUNGLE1BQU1uRSxPQUFPLEdBQUc7Y0FDZGlELE1BQU0sRUFBRSxFQUFFO2NBQ1ZtQixhQUFhLEVBQUU7WUFDakIsQ0FBQztZQUNELEtBQUssSUFBSUosTUFBTSxJQUFJVCxhQUFhLENBQUNNLGNBQWMsRUFBRTtjQUMvQyxJQUFJUSxXQUFXLEdBQUcsRUFBRTtjQUNwQixJQUFJQyxLQUFLLEdBQUcsQ0FBQztjQUNiLEtBQUssSUFBSUMsTUFBTSxJQUFJaEcsTUFBTSxDQUFDd0YsSUFBSSxDQUFDQyxNQUFNLENBQUNwRSxPQUFPLENBQUMsRUFBRTtnQkFDOUN5RSxXQUFXLEdBQUdBLFdBQVcsQ0FBQ0csTUFBTSxDQUFFLEdBQUVELE1BQU8sS0FBSVAsTUFBTSxDQUFDcEUsT0FBTyxDQUFDMkUsTUFBTSxDQUFFLEVBQUMsQ0FBQztnQkFDeEUsSUFBSUQsS0FBSyxHQUFHL0YsTUFBTSxDQUFDd0YsSUFBSSxDQUFDQyxNQUFNLENBQUNwRSxPQUFPLENBQUMsQ0FBQ2tFLE1BQU0sR0FBRyxDQUFDLEVBQUU7a0JBQ2xETyxXQUFXLEdBQUdBLFdBQVcsQ0FBQ0csTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDekM7Z0JBQ0FGLEtBQUssRUFBRTtjQUNUO2NBQ0E3RCxPQUFPLENBQUMwQyxVQUFVLENBQUM7Z0JBQ2pCQyxJQUFJLEVBQUVpQixXQUFXO2dCQUNqQmhCLEtBQUssRUFBRSxJQUFJO2dCQUNYYyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO2NBQ3RCLENBQUMsQ0FBQztjQUNGLElBQUlNLEdBQUcsR0FBRyxDQUFDO2NBQ1h6RSxPQUFPLENBQUMwRSxJQUFJLEdBQUcsRUFBRTtjQUNqQixLQUFLLElBQUlDLEVBQUUsSUFBSXBHLE1BQU0sQ0FBQ3dGLElBQUksQ0FBQ0MsTUFBTSxDQUFDQSxNQUFNLENBQUMsRUFBRTtnQkFDekMsS0FBSyxJQUFJWSxDQUFDLElBQUlDLHNDQUFrQixDQUFDQyxjQUFjLEVBQUU7a0JBQy9DLEtBQUssSUFBSUMsQ0FBQyxJQUFJSCxDQUFDLENBQUNJLFFBQVEsRUFBRTtvQkFDeEJoRixPQUFPLENBQUNpRixJQUFJLEdBQUdGLENBQUMsQ0FBQ0UsSUFBSSxJQUFJLENBQUMsQ0FBQztvQkFDM0IsS0FBSyxJQUFJQyxFQUFFLElBQUlILENBQUMsQ0FBQ2YsTUFBTSxJQUFJLEVBQUUsRUFBRTtzQkFDN0IsSUFBSWtCLEVBQUUsQ0FBQzNCLGFBQWEsS0FBS29CLEVBQUUsRUFBRTt3QkFDM0IzRSxPQUFPLENBQUNpRCxNQUFNLEdBQUc4QixDQUFDLENBQUM5QixNQUFNLElBQUksQ0FBQyxFQUFFLENBQUM7c0JBQ25DO29CQUNGO29CQUNBLEtBQUssSUFBSWtDLEVBQUUsSUFBSUosQ0FBQyxDQUFDSyxLQUFLLElBQUksRUFBRSxFQUFFO3NCQUM1QixJQUFJRCxFQUFFLENBQUNFLElBQUksS0FBS1YsRUFBRSxFQUFFO3dCQUNsQjNFLE9BQU8sQ0FBQ2lELE1BQU0sR0FBRzhCLENBQUMsQ0FBQzlCLE1BQU0sSUFBSSxDQUFDLEVBQUUsQ0FBQztzQkFDbkM7b0JBQ0Y7a0JBQ0Y7Z0JBQ0Y7Z0JBQ0FqRCxPQUFPLENBQUNpRCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsT0FBTztnQkFDbkNqRCxPQUFPLENBQUNpRCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsYUFBYTtnQkFDNUNqRCxPQUFPLENBQUNpRCxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsOEJBQThCO2dCQUN2RGpELE9BQU8sQ0FBQzBFLElBQUksQ0FBQ1ksSUFBSSxDQUFDNUMsWUFBWSxDQUFDaUMsRUFBRSxDQUFDLENBQUM7Z0JBRW5DLElBQUlZLEtBQUssQ0FBQ0MsT0FBTyxDQUFDeEIsTUFBTSxDQUFDQSxNQUFNLENBQUNXLEVBQUUsQ0FBQyxDQUFDLEVBQUU7a0JBQ3BDO2tCQUNBLElBQUlBLEVBQUUsS0FBSyxXQUFXLEVBQUU7b0JBQ3RCLElBQUljLE1BQU0sR0FBRyxFQUFFO29CQUNmekIsTUFBTSxDQUFDQSxNQUFNLENBQUNXLEVBQUUsQ0FBQyxDQUFDZSxPQUFPLENBQUUzSCxHQUFHLElBQUs7c0JBQ2pDLElBQUksQ0FBQzBILE1BQU0sQ0FBQzFILEdBQUcsQ0FBQzRILFNBQVMsQ0FBQyxFQUFFO3dCQUMxQkYsTUFBTSxDQUFDMUgsR0FBRyxDQUFDNEgsU0FBUyxDQUFDLEdBQUcsRUFBRTtzQkFDNUI7c0JBQ0FGLE1BQU0sQ0FBQzFILEdBQUcsQ0FBQzRILFNBQVMsQ0FBQyxDQUFDTCxJQUFJLENBQUN2SCxHQUFHLENBQUM7b0JBQ2pDLENBQUMsQ0FBQztvQkFDRlEsTUFBTSxDQUFDd0YsSUFBSSxDQUFDMEIsTUFBTSxDQUFDLENBQUNDLE9BQU8sQ0FBRUUsS0FBSyxJQUFLO3NCQUNyQyxJQUFJQyxPQUFPLEdBQUcsQ0FBQztzQkFDZkosTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQ0YsT0FBTyxDQUFDLENBQUNJLENBQUMsRUFBRUMsQ0FBQyxLQUFLO3dCQUM5QixJQUFJeEgsTUFBTSxDQUFDd0YsSUFBSSxDQUFDK0IsQ0FBQyxDQUFDLENBQUNoQyxNQUFNLEdBQUd2RixNQUFNLENBQUN3RixJQUFJLENBQUMwQixNQUFNLENBQUNHLEtBQUssQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDL0IsTUFBTSxFQUFFOzBCQUN0RStCLE9BQU8sR0FBR0UsQ0FBQzt3QkFDYjtzQkFDRixDQUFDLENBQUM7c0JBQ0YsTUFBTUMsT0FBTyxHQUFHekgsTUFBTSxDQUFDd0YsSUFBSSxDQUFDMEIsTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7c0JBQ25ELE1BQU1JLElBQUksR0FBR1IsTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQ00sR0FBRyxDQUFFSixDQUFDLElBQUs7d0JBQ3BDLElBQUlLLEdBQUcsR0FBRyxFQUFFO3dCQUNaSCxPQUFPLENBQUNOLE9BQU8sQ0FBRWhILEdBQUcsSUFBSzswQkFDdkJ5SCxHQUFHLENBQUNiLElBQUksQ0FDTixPQUFPUSxDQUFDLENBQUNwSCxHQUFHLENBQUMsS0FBSyxRQUFRLEdBQ3RCb0gsQ0FBQyxDQUFDcEgsR0FBRyxDQUFDLEdBQ042RyxLQUFLLENBQUNDLE9BQU8sQ0FBQ00sQ0FBQyxDQUFDcEgsR0FBRyxDQUFDLENBQUMsR0FDckJvSCxDQUFDLENBQUNwSCxHQUFHLENBQUMsQ0FBQ3dILEdBQUcsQ0FBRUosQ0FBQyxJQUFLOzRCQUNoQixPQUFPQSxDQUFDLEdBQUcsSUFBSTswQkFDakIsQ0FBQyxDQUFDLEdBQ0ZNLElBQUksQ0FBQ0MsU0FBUyxDQUFDUCxDQUFDLENBQUNwSCxHQUFHLENBQUMsQ0FBQyxDQUMzQjt3QkFDSCxDQUFDLENBQUM7d0JBQ0YsT0FBT3lILEdBQUc7c0JBQ1osQ0FBQyxDQUFDO3NCQUNGSCxPQUFPLENBQUNOLE9BQU8sQ0FBQyxDQUFDWSxHQUFHLEVBQUVQLENBQUMsS0FBSzt3QkFDMUJDLE9BQU8sQ0FBQ0QsQ0FBQyxDQUFDLEdBQUdPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxFQUFFLEdBQUdELEdBQUcsQ0FBQ0UsS0FBSyxDQUFDLENBQUMsQ0FBQztzQkFDbEQsQ0FBQyxDQUFDO3NCQUNGekcsTUFBTSxDQUFDdUYsSUFBSSxDQUFDO3dCQUNWbUIsS0FBSyxFQUFFLGFBQWE7d0JBQ3BCQyxJQUFJLEVBQUUsT0FBTzt3QkFDYlYsT0FBTzt3QkFDUEM7c0JBQ0YsQ0FBQyxDQUFDO29CQUNKLENBQUMsQ0FBQztrQkFDSixDQUFDLE1BQU0sSUFBSXRCLEVBQUUsS0FBSyxRQUFRLEVBQUU7b0JBQzFCLE1BQU01RyxHQUFHLEdBQUdpRyxNQUFNLENBQUNBLE1BQU0sQ0FBQ1csRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUNnQyxLQUFLO29CQUN0QyxNQUFNWCxPQUFPLEdBQUd6SCxNQUFNLENBQUN3RixJQUFJLENBQUNoRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ25DLElBQUksQ0FBQ2lJLE9BQU8sQ0FBQ1ksUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO3NCQUMvQlosT0FBTyxDQUFDVixJQUFJLENBQUMsUUFBUSxDQUFDO29CQUN4QjtvQkFDQSxNQUFNVyxJQUFJLEdBQUdsSSxHQUFHLENBQUNtSSxHQUFHLENBQUVKLENBQUMsSUFBSztzQkFDMUIsSUFBSUssR0FBRyxHQUFHLEVBQUU7c0JBQ1pILE9BQU8sQ0FBQ04sT0FBTyxDQUFFaEgsR0FBRyxJQUFLO3dCQUN2QnlILEdBQUcsQ0FBQ2IsSUFBSSxDQUFDUSxDQUFDLENBQUNwSCxHQUFHLENBQUMsQ0FBQztzQkFDbEIsQ0FBQyxDQUFDO3NCQUNGLE9BQU95SCxHQUFHO29CQUNaLENBQUMsQ0FBQztvQkFDRkgsT0FBTyxDQUFDTixPQUFPLENBQUMsQ0FBQ1ksR0FBRyxFQUFFUCxDQUFDLEtBQUs7c0JBQzFCQyxPQUFPLENBQUNELENBQUMsQ0FBQyxHQUFHTyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUNDLFdBQVcsRUFBRSxHQUFHRCxHQUFHLENBQUNFLEtBQUssQ0FBQyxDQUFDLENBQUM7b0JBQ2xELENBQUMsQ0FBQztvQkFDRnpHLE1BQU0sQ0FBQ3VGLElBQUksQ0FBQztzQkFDVm1CLEtBQUssRUFBRSxRQUFRO3NCQUNmQyxJQUFJLEVBQUUsT0FBTztzQkFDYlYsT0FBTztzQkFDUEM7b0JBQ0YsQ0FBQyxDQUFDO2tCQUNKLENBQUMsTUFBTTtvQkFDTCxLQUFLLElBQUlZLEdBQUcsSUFBSTdDLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDVyxFQUFFLENBQUMsRUFBRTtzQkFDakM1RSxNQUFNLENBQUN1RixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUN3QixlQUFlLENBQUNELEdBQUcsRUFBRTdHLE9BQU8sRUFBRXlFLEdBQUcsQ0FBQyxDQUFDO29CQUN6RDtrQkFDRjtnQkFDRixDQUFDLE1BQU07a0JBQ0w7a0JBQ0EsSUFBSVQsTUFBTSxDQUFDQSxNQUFNLENBQUNXLEVBQUUsQ0FBQyxDQUFDb0MsV0FBVyxFQUFFO29CQUNqQyxNQUFNQSxXQUFXLEdBQUcvQyxNQUFNLENBQUNBLE1BQU0sQ0FBQ1csRUFBRSxDQUFDLENBQUNvQyxXQUFXO29CQUNqRCxPQUFPL0MsTUFBTSxDQUFDQSxNQUFNLENBQUNXLEVBQUUsQ0FBQyxDQUFDb0MsV0FBVztvQkFDcENoSCxNQUFNLENBQUN1RixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUN3QixlQUFlLENBQUM5QyxNQUFNLENBQUNBLE1BQU0sQ0FBQ1csRUFBRSxDQUFDLEVBQUUzRSxPQUFPLEVBQUV5RSxHQUFHLENBQUMsQ0FBQztvQkFDckUsSUFBSXVDLFFBQVEsR0FBRyxFQUFFO29CQUNqQnpJLE1BQU0sQ0FBQ3dGLElBQUksQ0FBQy9ELE9BQU8sQ0FBQ2lGLElBQUksQ0FBQyxDQUFDUyxPQUFPLENBQUVJLENBQUMsSUFBSztzQkFDdkNrQixRQUFRLENBQUMxQixJQUFJLENBQUNRLENBQUMsQ0FBQztvQkFDbEIsQ0FBQyxDQUFDO29CQUNGLE1BQU1FLE9BQU8sR0FBRyxDQUNkLEVBQUUsRUFDRixHQUFHZ0IsUUFBUSxDQUFDekMsTUFBTSxDQUFFdUIsQ0FBQyxJQUFLQSxDQUFDLEtBQUssV0FBVyxJQUFJQSxDQUFDLEtBQUssV0FBVyxDQUFDLENBQ2xFO29CQUNELElBQUlHLElBQUksR0FBRyxFQUFFO29CQUNiYyxXQUFXLENBQUNyQixPQUFPLENBQUVJLENBQUMsSUFBSztzQkFDekIsSUFBSUssR0FBRyxHQUFHLEVBQUU7c0JBQ1pBLEdBQUcsQ0FBQ2IsSUFBSSxDQUFDUSxDQUFDLENBQUMvRSxJQUFJLENBQUM7c0JBQ2hCaUYsT0FBTyxDQUFDTixPQUFPLENBQUV1QixDQUFDLElBQUs7d0JBQ3JCLElBQUlBLENBQUMsS0FBSyxFQUFFLEVBQUU7MEJBQ1pBLENBQUMsR0FBR0EsQ0FBQyxLQUFLLGVBQWUsR0FBR0EsQ0FBQyxHQUFHLFNBQVM7MEJBQ3pDZCxHQUFHLENBQUNiLElBQUksQ0FBQ1EsQ0FBQyxDQUFDbUIsQ0FBQyxDQUFDLEdBQUduQixDQUFDLENBQUNtQixDQUFDLENBQUMsR0FBRyxJQUFJLENBQUM7d0JBQzlCO3NCQUNGLENBQUMsQ0FBQztzQkFDRmQsR0FBRyxDQUFDYixJQUFJLENBQUNRLENBQUMsQ0FBQ29CLGVBQWUsQ0FBQztzQkFDM0JqQixJQUFJLENBQUNYLElBQUksQ0FBQ2EsR0FBRyxDQUFDO29CQUNoQixDQUFDLENBQUM7b0JBQ0ZILE9BQU8sQ0FBQ04sT0FBTyxDQUFDLENBQUNJLENBQUMsRUFBRXJCLEdBQUcsS0FBSztzQkFDMUJ1QixPQUFPLENBQUN2QixHQUFHLENBQUMsR0FBR3pFLE9BQU8sQ0FBQ2lGLElBQUksQ0FBQ2EsQ0FBQyxDQUFDO29CQUNoQyxDQUFDLENBQUM7b0JBQ0ZFLE9BQU8sQ0FBQ1YsSUFBSSxDQUFDLElBQUksQ0FBQztvQkFDbEJ2RixNQUFNLENBQUN1RixJQUFJLENBQUM7c0JBQ1ZtQixLQUFLLEVBQUUsdUJBQXVCO3NCQUM5QkMsSUFBSSxFQUFFLE9BQU87c0JBQ2JWLE9BQU87c0JBQ1BDO29CQUNGLENBQUMsQ0FBQztrQkFDSixDQUFDLE1BQU07b0JBQ0xsRyxNQUFNLENBQUN1RixJQUFJLENBQUMsR0FBRyxJQUFJLENBQUN3QixlQUFlLENBQUM5QyxNQUFNLENBQUNBLE1BQU0sQ0FBQ1csRUFBRSxDQUFDLEVBQUUzRSxPQUFPLEVBQUV5RSxHQUFHLENBQUMsQ0FBQztrQkFDdkU7Z0JBQ0Y7Z0JBQ0EsS0FBSyxNQUFNMEMsS0FBSyxJQUFJcEgsTUFBTSxFQUFFO2tCQUMxQlUsT0FBTyxDQUFDMkcsZUFBZSxDQUFDLENBQUNELEtBQUssQ0FBQyxDQUFDO2dCQUNsQztnQkFDQTFDLEdBQUcsRUFBRTtnQkFDTDFFLE1BQU0sR0FBRyxFQUFFO2NBQ2I7Y0FDQUEsTUFBTSxHQUFHLEVBQUU7WUFDYjtVQUNGLENBQUMsTUFBTTtZQUNMVSxPQUFPLENBQUMwQyxVQUFVLENBQUM7Y0FDakJDLElBQUksRUFBRSx5REFBeUQ7Y0FDL0RDLEtBQUssRUFBRTtnQkFBRVksUUFBUSxFQUFFLEVBQUU7Z0JBQUVDLEtBQUssRUFBRTtjQUFPLENBQUM7Y0FDdENDLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDdkIsQ0FBQyxDQUFDO1VBQ0o7UUFDRjs7UUFFQTtRQUNBLElBQUkzQixVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUU7VUFDbkIsTUFBTSxJQUFJLENBQUNyQixZQUFZLENBQ3JCL0IsT0FBTyxFQUNQcUIsT0FBTyxFQUNQLGFBQWEsRUFDYmdDLE9BQU8sRUFDUCxFQUFFLEVBQ0Z2QyxLQUFLLENBQ047UUFDSDtRQUVBLE1BQU1PLE9BQU8sQ0FBQ3NCLEtBQUssQ0FBQzNDLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDZSxZQUFZLENBQUM7UUFFN0QsT0FBTzFDLFFBQVEsQ0FBQzJDLEVBQUUsQ0FBQztVQUNqQjlCLElBQUksRUFBRTtZQUNKK0IsT0FBTyxFQUFFLElBQUk7WUFDYkMsT0FBTyxFQUFHLFVBQVMvQyxPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ21CLFFBQVM7VUFDMUQ7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT0MsS0FBSyxFQUFFO1FBQ2QsSUFBQTlDLFdBQUcsRUFBQywrQkFBK0IsRUFBRThDLEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLENBQUM7UUFDNUQsT0FBTyxJQUFBQyw0QkFBYSxFQUFDRCxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUvQyxRQUFRLENBQUM7TUFDbkU7SUFDRixDQUFDLEVBQUUsQ0FBQztNQUFDZSxNQUFNLEVBQUU7UUFBRW9DO01BQVE7SUFBQyxDQUFDLEtBQU0sNkJBQTRCQSxPQUFRLElBQUcsSUFBSSxDQUFDRix1QkFBdUIsRUFBRyxNQUFLLENBQUM7SUFFM0c7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFORSxJQUFBckQsZ0JBQUEsQ0FBQWpCLE9BQUEsNENBT21DLElBQUksQ0FBQ2tCLDhDQUE4QyxDQUFFLE9BQ3RGQyxPQUE4QixFQUM5QkMsT0FBc0IsRUFDdEJDLFFBQStCLEtBQzVCO01BQ0gsSUFBSTtRQUNGLElBQUFDLFdBQUcsRUFBQyw0Q0FBNEMsRUFBRyxnQkFBZSxFQUFFLE1BQU0sQ0FBQztRQUMzRSxNQUFNO1VBQUVpRCxVQUFVO1VBQUV0QztRQUFNLENBQUMsR0FBR2IsT0FBTyxDQUFDYyxJQUFJO1FBQzFDLE1BQU07VUFBRWtIO1FBQVEsQ0FBQyxHQUFHaEksT0FBTyxDQUFDZ0IsTUFBTTtRQUVsQyxNQUFNSSxPQUFPLEdBQUcsSUFBSUMsc0JBQWEsRUFBRTtRQUNuQyxJQUFBQywwQ0FBOEIsR0FBRTtRQUNoQyxJQUFBQyxzQ0FBMEIsRUFBQ0MsOENBQW1DLENBQUM7UUFDL0QsSUFBQUQsc0NBQTBCLEVBQUNFLHNEQUEyQyxDQUFDO1FBQ3ZFLElBQUFGLHNDQUEwQixFQUFDRyxhQUFJLENBQUNDLElBQUksQ0FBQ0Ysc0RBQTJDLEVBQUUxQixPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ0MsWUFBWSxDQUFDLENBQUM7UUFFNUgsSUFBSW9HLGdCQUFnQixHQUFHLENBQUMsQ0FBQztRQUN6QixJQUFJdkgsTUFBTSxHQUFHLEVBQUU7UUFDZixJQUFJO1VBQ0Z1SCxnQkFBZ0IsR0FBRyxNQUFNbEksT0FBTyxDQUFDb0UsS0FBSyxDQUFDQyxHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDdEUsT0FBTyxDQUNyRSxLQUFLLEVBQ0osV0FBVWdJLE9BQVEsMkJBQTBCLEVBQzdDLENBQUMsQ0FBQyxFQUNGO1lBQUV6RCxTQUFTLEVBQUUxRDtVQUFNLENBQUMsQ0FDckI7UUFDSCxDQUFDLENBQUMsT0FBT21DLEtBQUssRUFBRTtVQUNkLElBQUE5QyxXQUFHLEVBQUMsa0JBQWtCLEVBQUU4QyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxFQUFFLE9BQU8sQ0FBQztRQUMxRDtRQUVBLE1BQU0sSUFBSSxDQUFDbEIsWUFBWSxDQUFDL0IsT0FBTyxFQUFFcUIsT0FBTyxFQUFFLGFBQWEsRUFBRSxhQUFhLEVBQUU0RyxPQUFPLEVBQUVuSCxLQUFLLENBQUM7UUFFdkYsSUFBSXFILFlBQVksR0FBRyxDQUFDO1FBQ3BCLEtBQUssSUFBSXZELE1BQU0sSUFBSWEsc0NBQWtCLENBQUNDLGNBQWMsRUFBRTtVQUNwRCxJQUFJMEMsY0FBYyxHQUFHLEtBQUs7VUFDMUIsSUFBQWpJLFdBQUcsRUFDRCw0Q0FBNEMsRUFDM0MsZ0JBQWV5RSxNQUFNLENBQUNnQixRQUFRLENBQUNsQixNQUFPLHlCQUF3QixFQUMvRCxPQUFPLENBQ1I7VUFDRCxLQUFLLElBQUk5RCxPQUFPLElBQUlnRSxNQUFNLENBQUNnQixRQUFRLEVBQUU7WUFDbkMsSUFBSXlDLGlCQUFpQixHQUFHLEtBQUs7WUFDN0IsSUFDRWpGLFVBQVUsQ0FBQytFLFlBQVksQ0FBQyxLQUN2QnZILE9BQU8sQ0FBQ2dFLE1BQU0sSUFBSWhFLE9BQU8sQ0FBQ29GLEtBQUssQ0FBQyxFQUNqQztjQUNBLElBQUlYLEdBQUcsR0FBRyxDQUFDO2NBQ1gsTUFBTWlELE9BQU8sR0FBRyxDQUFDMUgsT0FBTyxDQUFDZ0UsTUFBTSxJQUFJLEVBQUUsRUFBRVEsTUFBTSxDQUFDeEUsT0FBTyxDQUFDb0YsS0FBSyxJQUFJLEVBQUUsQ0FBQztjQUNsRSxJQUFBN0YsV0FBRyxFQUNELDRDQUE0QyxFQUMzQyxnQkFBZW1JLE9BQU8sQ0FBQzVELE1BQU8sdUJBQXNCLEVBQ3JELE9BQU8sQ0FDUjtjQUNELEtBQUssSUFBSTZELElBQUksSUFBSUQsT0FBTyxFQUFFO2dCQUN4QixJQUFJRSxtQkFBbUIsR0FBRyxDQUFDLENBQUM7Z0JBQzVCLElBQUk7a0JBQ0YsSUFBSSxDQUFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUU7b0JBQ2pCQyxtQkFBbUIsR0FBRyxNQUFNeEksT0FBTyxDQUFDb0UsS0FBSyxDQUFDQyxHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDdEUsT0FBTyxDQUN4RSxLQUFLLEVBQ0osV0FBVWdJLE9BQVEsV0FBVU0sSUFBSSxDQUFDRSxTQUFVLElBQUdGLElBQUksQ0FBQ3BFLGFBQWMsRUFBQyxFQUNuRSxDQUFDLENBQUMsRUFDRjtzQkFBRUssU0FBUyxFQUFFMUQ7b0JBQU0sQ0FBQyxDQUNyQjtrQkFDSCxDQUFDLE1BQU07b0JBQ0wsS0FBSyxJQUFJa0YsS0FBSyxJQUFJa0MsZ0JBQWdCLENBQUNoRSxJQUFJLENBQUNBLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRTtzQkFDeEQsSUFBSS9FLE1BQU0sQ0FBQ3dGLElBQUksQ0FBQ3FCLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLdUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO3dCQUMxQ0MsbUJBQW1CLENBQUN0RSxJQUFJLEdBQUc7MEJBQ3pCQSxJQUFJLEVBQUU4Qjt3QkFDUixDQUFDO3NCQUNIO29CQUNGO2tCQUNGO2tCQUVBLE1BQU0wQyxXQUFXLEdBQ2ZGLG1CQUFtQixJQUFJQSxtQkFBbUIsQ0FBQ3RFLElBQUksSUFBSXNFLG1CQUFtQixDQUFDdEUsSUFBSSxDQUFDQSxJQUFJO2tCQUNsRixJQUFJLENBQUNrRSxjQUFjLEVBQUU7b0JBQ25CL0csT0FBTyxDQUFDMEMsVUFBVSxDQUFDO3NCQUNqQkMsSUFBSSxFQUFFWSxNQUFNLENBQUN5QyxLQUFLO3NCQUNsQnBELEtBQUssRUFBRSxJQUFJO3NCQUNYYyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO29CQUN0QixDQUFDLENBQUM7b0JBQ0ZxRCxjQUFjLEdBQUcsSUFBSTtrQkFDdkI7a0JBQ0EsSUFBSSxDQUFDQyxpQkFBaUIsRUFBRTtvQkFDdEJoSCxPQUFPLENBQUMwQyxVQUFVLENBQUM7c0JBQ2pCQyxJQUFJLEVBQUVwRCxPQUFPLENBQUMrSCxRQUFRO3NCQUN0QjFFLEtBQUssRUFBRTtvQkFDVCxDQUFDLENBQUM7b0JBQ0Y1QyxPQUFPLENBQUMwQyxVQUFVLENBQUM7c0JBQ2pCQyxJQUFJLEVBQUVwRCxPQUFPLENBQUNsQixJQUFJO3NCQUNsQnVFLEtBQUssRUFBRTt3QkFBRVksUUFBUSxFQUFFLEVBQUU7d0JBQUVDLEtBQUssRUFBRTtzQkFBTyxDQUFDO3NCQUN0Q0MsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDdEIsQ0FBQyxDQUFDO29CQUNGc0QsaUJBQWlCLEdBQUcsSUFBSTtrQkFDMUI7a0JBQ0EsSUFBSUssV0FBVyxFQUFFO29CQUNmLEtBQUssSUFBSUUsY0FBYyxJQUFJekosTUFBTSxDQUFDd0YsSUFBSSxDQUFDK0QsV0FBVyxDQUFDLEVBQUU7c0JBQ25ELElBQUl2QyxLQUFLLENBQUNDLE9BQU8sQ0FBQ3NDLFdBQVcsQ0FBQ0UsY0FBYyxDQUFDLENBQUMsRUFBRTt3QkFDOUM7d0JBQ0EsSUFBSUwsSUFBSSxDQUFDTSxRQUFRLEVBQUU7MEJBQ2pCLElBQUl4QyxNQUFNLEdBQUcsRUFBRTswQkFDZnFDLFdBQVcsQ0FBQ0UsY0FBYyxDQUFDLENBQUN0QyxPQUFPLENBQUUzSCxHQUFHLElBQUs7NEJBQzNDLElBQUksQ0FBQzBILE1BQU0sQ0FBQzFILEdBQUcsQ0FBQzRILFNBQVMsQ0FBQyxFQUFFOzhCQUMxQkYsTUFBTSxDQUFDMUgsR0FBRyxDQUFDNEgsU0FBUyxDQUFDLEdBQUcsRUFBRTs0QkFDNUI7NEJBQ0FGLE1BQU0sQ0FBQzFILEdBQUcsQ0FBQzRILFNBQVMsQ0FBQyxDQUFDTCxJQUFJLENBQUN2SCxHQUFHLENBQUM7MEJBQ2pDLENBQUMsQ0FBQzswQkFDRlEsTUFBTSxDQUFDd0YsSUFBSSxDQUFDMEIsTUFBTSxDQUFDLENBQUNDLE9BQU8sQ0FBRUUsS0FBSyxJQUFLOzRCQUNyQyxJQUFJQyxPQUFPLEdBQUcsQ0FBQzs0QkFDZkosTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQ0YsT0FBTyxDQUFDLENBQUNJLENBQUMsRUFBRUMsQ0FBQyxLQUFLOzhCQUM5QixJQUNFeEgsTUFBTSxDQUFDd0YsSUFBSSxDQUFDK0IsQ0FBQyxDQUFDLENBQUNoQyxNQUFNLEdBQUd2RixNQUFNLENBQUN3RixJQUFJLENBQUMwQixNQUFNLENBQUNHLEtBQUssQ0FBQyxDQUFDQyxPQUFPLENBQUMsQ0FBQyxDQUFDL0IsTUFBTSxFQUNsRTtnQ0FDQStCLE9BQU8sR0FBR0UsQ0FBQzs4QkFDYjs0QkFDRixDQUFDLENBQUM7NEJBQ0YsTUFBTUMsT0FBTyxHQUFHekgsTUFBTSxDQUFDd0YsSUFBSSxDQUFDMEIsTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLENBQUM7NEJBQ25ELE1BQU1JLElBQUksR0FBR1IsTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQ00sR0FBRyxDQUFFSixDQUFDLElBQUs7OEJBQ3BDLElBQUlLLEdBQUcsR0FBRyxFQUFFOzhCQUNaSCxPQUFPLENBQUNOLE9BQU8sQ0FBRWhILEdBQUcsSUFBSztnQ0FDdkJ5SCxHQUFHLENBQUNiLElBQUksQ0FDTixPQUFPUSxDQUFDLENBQUNwSCxHQUFHLENBQUMsS0FBSyxRQUFRLEdBQ3RCb0gsQ0FBQyxDQUFDcEgsR0FBRyxDQUFDLEdBQ042RyxLQUFLLENBQUNDLE9BQU8sQ0FBQ00sQ0FBQyxDQUFDcEgsR0FBRyxDQUFDLENBQUMsR0FDckJvSCxDQUFDLENBQUNwSCxHQUFHLENBQUMsQ0FBQ3dILEdBQUcsQ0FBRUosQ0FBQyxJQUFLO2tDQUNoQixPQUFPQSxDQUFDLEdBQUcsSUFBSTtnQ0FDakIsQ0FBQyxDQUFDLEdBQ0ZNLElBQUksQ0FBQ0MsU0FBUyxDQUFDUCxDQUFDLENBQUNwSCxHQUFHLENBQUMsQ0FBQyxDQUMzQjs4QkFDSCxDQUFDLENBQUM7OEJBQ0YsT0FBT3lILEdBQUc7NEJBQ1osQ0FBQyxDQUFDOzRCQUNGSCxPQUFPLENBQUNOLE9BQU8sQ0FBQyxDQUFDWSxHQUFHLEVBQUVQLENBQUMsS0FBSzs4QkFDMUJDLE9BQU8sQ0FBQ0QsQ0FBQyxDQUFDLEdBQUdPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxFQUFFLEdBQUdELEdBQUcsQ0FBQ0UsS0FBSyxDQUFDLENBQUMsQ0FBQzs0QkFDbEQsQ0FBQyxDQUFDOzRCQUNGekcsTUFBTSxDQUFDdUYsSUFBSSxDQUFDOzhCQUNWbUIsS0FBSyxFQUFFekcsT0FBTyxDQUFDaUQsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDMkMsS0FBSyxDQUFDOzhCQUMvQmMsSUFBSSxFQUFFLE9BQU87OEJBQ2JWLE9BQU87OEJBQ1BDOzRCQUNGLENBQUMsQ0FBQzswQkFDSixDQUFDLENBQUM7d0JBQ0osQ0FBQyxNQUFNLElBQUkrQixjQUFjLENBQUN6RSxhQUFhLEtBQUssUUFBUSxFQUFFOzBCQUNwRHhELE1BQU0sQ0FBQ3VGLElBQUksQ0FDVCxHQUFHLElBQUksQ0FBQ3dCLGVBQWUsQ0FBQ2dCLFdBQVcsQ0FBQ0UsY0FBYyxDQUFDLEVBQUVoSSxPQUFPLEVBQUV5RSxHQUFHLENBQUMsQ0FDbkU7d0JBQ0gsQ0FBQyxNQUFNOzBCQUNMLEtBQUssSUFBSW9DLEdBQUcsSUFBSWlCLFdBQVcsQ0FBQ0UsY0FBYyxDQUFDLEVBQUU7NEJBQzNDakksTUFBTSxDQUFDdUYsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDd0IsZUFBZSxDQUFDRCxHQUFHLEVBQUU3RyxPQUFPLEVBQUV5RSxHQUFHLENBQUMsQ0FBQzswQkFDekQ7d0JBQ0Y7c0JBQ0YsQ0FBQyxNQUFNO3dCQUNMO3dCQUNBLElBQUlrRCxJQUFJLENBQUNPLE1BQU0sRUFBRTswQkFDZixNQUFNOzRCQUFDbkIsV0FBVzs0QkFBQ29CLElBQUk7NEJBQUNDLGVBQWU7NEJBQUNDLFVBQVU7NEJBQUMsR0FBR0M7MEJBQUksQ0FBQyxHQUFHUixXQUFXLENBQUNFLGNBQWMsQ0FBQzswQkFDekZqSSxNQUFNLENBQUN1RixJQUFJLENBQ1QsR0FBRyxJQUFJLENBQUN3QixlQUFlLENBQUN3QixJQUFJLEVBQUV0SSxPQUFPLEVBQUV5RSxHQUFHLENBQUMsRUFDM0MsSUFBSTBELElBQUksSUFBSUEsSUFBSSxDQUFDSSxVQUFVLEdBQUcsSUFBSSxDQUFDekIsZUFBZSxDQUFDcUIsSUFBSSxDQUFDSSxVQUFVLEVBQUU7NEJBQUM3RCxJQUFJLEVBQUMsQ0FBQyxZQUFZOzBCQUFDLENBQUMsRUFBRSxDQUFDLENBQUUsR0FBRSxFQUFFLENBQUMsRUFDbkcsSUFBSXlELElBQUksSUFBSUEsSUFBSSxDQUFDSyxTQUFTLEdBQUcsSUFBSSxDQUFDMUIsZUFBZSxDQUFDcUIsSUFBSSxDQUFDSyxTQUFTLEVBQUU7NEJBQUM5RCxJQUFJLEVBQUMsQ0FBQyxXQUFXOzBCQUFDLENBQUMsRUFBRSxDQUFDLENBQUUsR0FBRSxFQUFFLENBQUMsRUFDaEcsSUFBSTBELGVBQWUsR0FBRyxJQUFJLENBQUN0QixlQUFlLENBQUNzQixlQUFlLEVBQUU7NEJBQUMxRCxJQUFJLEVBQUMsQ0FBQyxpQkFBaUI7MEJBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBRSxHQUFFLEVBQUUsQ0FBQyxFQUNoRyxJQUFJMkQsVUFBVSxHQUFHLElBQUksQ0FBQ3ZCLGVBQWUsQ0FBQ3VCLFVBQVUsRUFBRTs0QkFBQzNELElBQUksRUFBQyxDQUFDLFlBQVk7MEJBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBRSxHQUFFLEVBQUUsQ0FBQyxDQUNsRjswQkFDRCxJQUFJc0MsUUFBUSxHQUFHLEVBQUU7MEJBQ2pCekksTUFBTSxDQUFDd0YsSUFBSSxDQUFDL0QsT0FBTyxDQUFDaUYsSUFBSSxDQUFDLENBQUNTLE9BQU8sQ0FBRUksQ0FBQyxJQUFLOzRCQUN2Q2tCLFFBQVEsQ0FBQzFCLElBQUksQ0FBQ1EsQ0FBQyxDQUFDOzBCQUNsQixDQUFDLENBQUM7MEJBQ0YsTUFBTUUsT0FBTyxHQUFHLENBQ2QsRUFBRSxFQUNGLEdBQUdnQixRQUFRLENBQUN6QyxNQUFNLENBQUV1QixDQUFDLElBQUtBLENBQUMsS0FBSyxXQUFXLElBQUlBLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FDbEU7MEJBQ0QsSUFBSUcsSUFBSSxHQUFHLEVBQUU7MEJBQ2JjLFdBQVcsQ0FBQ3JCLE9BQU8sQ0FBRUksQ0FBQyxJQUFLOzRCQUN6QixJQUFJSyxHQUFHLEdBQUcsRUFBRTs0QkFDWkEsR0FBRyxDQUFDYixJQUFJLENBQUNRLENBQUMsQ0FBQzJDLEdBQUcsQ0FBQzs0QkFDZnpDLE9BQU8sQ0FBQ04sT0FBTyxDQUFFdUIsQ0FBQyxJQUFLOzhCQUNyQixJQUFJQSxDQUFDLEtBQUssRUFBRSxFQUFFO2dDQUNaZCxHQUFHLENBQUNiLElBQUksQ0FBQ1EsQ0FBQyxDQUFDYixJQUFJLENBQUN5RCxPQUFPLENBQUN6QixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUcsSUFBSSxDQUFDOzhCQUNqRDs0QkFDRixDQUFDLENBQUM7NEJBQ0ZkLEdBQUcsQ0FBQ2IsSUFBSSxDQUFDUSxDQUFDLENBQUNvQixlQUFlLENBQUM7NEJBQzNCakIsSUFBSSxDQUFDWCxJQUFJLENBQUNhLEdBQUcsQ0FBQzswQkFDaEIsQ0FBQyxDQUFDOzBCQUNGSCxPQUFPLENBQUNOLE9BQU8sQ0FBQyxDQUFDSSxDQUFDLEVBQUVyQixHQUFHLEtBQUs7NEJBQzFCdUIsT0FBTyxDQUFDdkIsR0FBRyxDQUFDLEdBQUd6RSxPQUFPLENBQUNpRixJQUFJLENBQUNhLENBQUMsQ0FBQzswQkFDaEMsQ0FBQyxDQUFDOzBCQUNGRSxPQUFPLENBQUNWLElBQUksQ0FBQyxJQUFJLENBQUM7MEJBQ2xCdkYsTUFBTSxDQUFDdUYsSUFBSSxDQUFDOzRCQUNWbUIsS0FBSyxFQUFFLHVCQUF1Qjs0QkFDOUJDLElBQUksRUFBRSxPQUFPOzRCQUNiVixPQUFPOzRCQUNQQzswQkFDRixDQUFDLENBQUM7d0JBQ0osQ0FBQyxNQUFNOzBCQUNMbEcsTUFBTSxDQUFDdUYsSUFBSSxDQUNULEdBQUcsSUFBSSxDQUFDd0IsZUFBZSxDQUFDZ0IsV0FBVyxDQUFDRSxjQUFjLENBQUMsRUFBRWhJLE9BQU8sRUFBRXlFLEdBQUcsQ0FBQyxDQUNuRTt3QkFDSDtzQkFDRjtvQkFDRjtrQkFDRixDQUFDLE1BQU07b0JBQ0w7b0JBQ0FoRSxPQUFPLENBQUMwQyxVQUFVLENBQUM7c0JBQ2pCQyxJQUFJLEVBQUUsQ0FDSiw4RUFBOEUsRUFDOUU7d0JBQ0VBLElBQUksRUFBRyxHQUFFcEQsT0FBTyxDQUFDK0gsUUFBUSxDQUFDWSxXQUFXLEVBQUcsaUJBQWdCO3dCQUN4REMsSUFBSSxFQUFFNUksT0FBTyxDQUFDNkksUUFBUTt3QkFDdEJ4RixLQUFLLEVBQUU7MEJBQUVZLFFBQVEsRUFBRSxFQUFFOzBCQUFFQyxLQUFLLEVBQUU7d0JBQVU7c0JBQzFDLENBQUMsQ0FDRjtzQkFDREMsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtvQkFDdEIsQ0FBQyxDQUFDO2tCQUNKO2dCQUNGLENBQUMsQ0FBQyxPQUFPOUIsS0FBSyxFQUFFO2tCQUNkLElBQUE5QyxXQUFHLEVBQUMsa0JBQWtCLEVBQUU4QyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxFQUFFLE9BQU8sQ0FBQztnQkFDMUQ7Z0JBQ0FvQyxHQUFHLEVBQUU7Y0FDUDtjQUNBLEtBQUssTUFBTTBDLEtBQUssSUFBSXBILE1BQU0sRUFBRTtnQkFDMUJVLE9BQU8sQ0FBQzJHLGVBQWUsQ0FBQyxDQUFDRCxLQUFLLENBQUMsQ0FBQztjQUNsQztZQUNGO1lBQ0FJLFlBQVksRUFBRTtZQUNkeEgsTUFBTSxHQUFHLEVBQUU7VUFDYjtRQUNGO1FBRUEsTUFBTVUsT0FBTyxDQUFDc0IsS0FBSyxDQUFDM0MsT0FBTyxDQUFDNkIsbUJBQW1CLENBQUNlLFlBQVksQ0FBQztRQUU3RCxPQUFPMUMsUUFBUSxDQUFDMkMsRUFBRSxDQUFDO1VBQ2pCOUIsSUFBSSxFQUFFO1lBQ0orQixPQUFPLEVBQUUsSUFBSTtZQUNiQyxPQUFPLEVBQUcsVUFBUy9DLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDbUIsUUFBUztVQUMxRDtRQUNGLENBQUMsQ0FBQztNQUNKLENBQUMsQ0FBQyxPQUFPQyxLQUFLLEVBQUU7UUFDZCxJQUFBOUMsV0FBRyxFQUFDLDRDQUE0QyxFQUFFOEMsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssQ0FBQztRQUN6RSxPQUFPLElBQUFDLDRCQUFhLEVBQUNELEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEdBQUcsRUFBRS9DLFFBQVEsQ0FBQztNQUNuRTtJQUNGLENBQUMsRUFBRSxDQUFDO01BQUVlLE1BQU0sRUFBRTtRQUFFZ0g7TUFBUTtJQUFDLENBQUMsS0FBTSw2QkFBNEJBLE9BQVEsSUFBRyxJQUFJLENBQUM5RSx1QkFBdUIsRUFBRyxNQUFLLENBQUM7SUFFNUc7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFORSxJQUFBckQsZ0JBQUEsQ0FBQWpCLE9BQUEsd0NBTytCLElBQUksQ0FBQ2tCLDhDQUE4QyxDQUFFLE9BQ2xGQyxPQUE4QixFQUM5QkMsT0FBc0IsRUFDdEJDLFFBQStCLEtBQzVCO01BQ0gsSUFBSTtRQUNGLElBQUFDLFdBQUcsRUFBQyx3Q0FBd0MsRUFBRyxnQkFBZSxFQUFFLE1BQU0sQ0FBQztRQUN2RSxNQUFNO1VBQUVJLFNBQVM7VUFBRUMsT0FBTztVQUFFRSxJQUFJO1VBQUVHLGlCQUFpQjtVQUFFQyxLQUFLO1VBQUVMO1FBQWdCLENBQUMsR0FBR1IsT0FBTyxDQUFDYyxJQUFJO1FBQzVGLE1BQU07VUFBRWtIO1FBQVEsQ0FBQyxHQUFHaEksT0FBTyxDQUFDZ0IsTUFBTTtRQUNsQyxNQUFNO1VBQUVDLElBQUk7VUFBRUM7UUFBRyxDQUFDLEdBQUdULElBQUksSUFBSSxDQUFDLENBQUM7UUFDL0I7UUFDQSxNQUFNVyxPQUFPLEdBQUcsSUFBSUMsc0JBQWEsRUFBRTtRQUVuQyxNQUFNO1VBQUVRO1FBQWEsQ0FBQyxHQUFHLE1BQU05QixPQUFPLENBQUNvRSxLQUFLLENBQUNzRixRQUFRLENBQUNDLGNBQWMsQ0FBQzFKLE9BQU8sRUFBRUQsT0FBTyxDQUFDO1FBQ3RGLElBQUF1QiwwQ0FBOEIsR0FBRTtRQUNoQyxJQUFBQyxzQ0FBMEIsRUFBQ0MsOENBQW1DLENBQUM7UUFDL0QsSUFBQUQsc0NBQTBCLEVBQUNFLHNEQUEyQyxDQUFDO1FBQ3ZFLElBQUFGLHNDQUEwQixFQUFDRyxhQUFJLENBQUNDLElBQUksQ0FBQ0Ysc0RBQTJDLEVBQUVJLFlBQVksQ0FBQyxDQUFDO1FBRWhHLElBQUEzQixXQUFHLEVBQUMsd0NBQXdDLEVBQUcscUJBQW9CLEVBQUUsT0FBTyxDQUFDO1FBQzdFLE1BQU0sQ0FBQzZCLGdCQUFnQixFQUFFQyxZQUFZLENBQUMsR0FBR3pCLE9BQU8sR0FBRyxJQUFJLENBQUMwQixxQkFBcUIsQ0FBQzFCLE9BQU8sRUFBRUQsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDOztRQUVqSDtRQUNBLElBQUlxSixPQUFPLEdBQUcsRUFBRTtRQUNoQixJQUFJO1VBQ0YsTUFBTUMsYUFBYSxHQUFHLE1BQU03SixPQUFPLENBQUNvRSxLQUFLLENBQUNDLEdBQUcsQ0FBQ0MsTUFBTSxDQUFDQyxhQUFhLENBQUN0RSxPQUFPLENBQ3hFLEtBQUssRUFDTCxTQUFTLEVBQ1Q7WUFBRWdCLE1BQU0sRUFBRTtjQUFFNkksQ0FBQyxFQUFHLE1BQUs3QixPQUFRO1lBQUU7VUFBRSxDQUFDLEVBQ2xDO1lBQUV6RCxTQUFTLEVBQUUxRDtVQUFNLENBQUMsQ0FDckI7VUFDRDhJLE9BQU8sR0FBR0MsYUFBYSxDQUFDM0YsSUFBSSxDQUFDQSxJQUFJLENBQUNPLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQ3NGLEVBQUUsQ0FBQ0MsUUFBUTtRQUNqRSxDQUFDLENBQUMsT0FBTy9HLEtBQUssRUFBRTtVQUNkLElBQUE5QyxXQUFHLEVBQUMsd0NBQXdDLEVBQUU4QyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxFQUFFLE9BQU8sQ0FBQztRQUNoRjs7UUFFQTtRQUNBNUIsT0FBTyxDQUFDNEkscUJBQXFCLENBQUM7VUFDNUJqRyxJQUFJLEVBQUUsdUJBQXVCO1VBQzdCQyxLQUFLLEVBQUU7UUFDVCxDQUFDLENBQUM7O1FBRUY7UUFDQSxNQUFNLElBQUFpRyxxQ0FBZ0IsRUFBQ2xLLE9BQU8sRUFBRXFCLE9BQU8sRUFBRSxDQUFDNEcsT0FBTyxDQUFDLEVBQUVuSCxLQUFLLENBQUM7O1FBRTFEO1FBQ0EsTUFBTXFKLHNCQUFzQixHQUFHLENBQzdCO1VBQ0VDLFFBQVEsRUFBRyxpQkFBZ0JuQyxPQUFRLFdBQVU7VUFDN0NvQyxhQUFhLEVBQUcsK0JBQThCcEMsT0FBUSxFQUFDO1VBQ3ZERixLQUFLLEVBQUU7WUFDTFYsS0FBSyxFQUFFLFVBQVU7WUFDakJULE9BQU8sRUFDTGdELE9BQU8sS0FBSyxTQUFTLEdBQ2pCLENBQ0U7Y0FBRVUsRUFBRSxFQUFFLE1BQU07Y0FBRS9DLEtBQUssRUFBRTtZQUFPLENBQUMsRUFDN0I7Y0FBRStDLEVBQUUsRUFBRSxjQUFjO2NBQUUvQyxLQUFLLEVBQUU7WUFBZSxDQUFDLEVBQzdDO2NBQUUrQyxFQUFFLEVBQUUsU0FBUztjQUFFL0MsS0FBSyxFQUFFO1lBQVUsQ0FBQyxFQUNuQztjQUFFK0MsRUFBRSxFQUFFLFFBQVE7Y0FBRS9DLEtBQUssRUFBRTtZQUFTLENBQUMsQ0FDbEMsR0FDRCxDQUNFO2NBQUUrQyxFQUFFLEVBQUUsTUFBTTtjQUFFL0MsS0FBSyxFQUFFO1lBQU8sQ0FBQyxFQUM3QjtjQUFFK0MsRUFBRSxFQUFFLGNBQWM7Y0FBRS9DLEtBQUssRUFBRTtZQUFlLENBQUMsRUFDN0M7Y0FBRStDLEVBQUUsRUFBRSxTQUFTO2NBQUUvQyxLQUFLLEVBQUU7WUFBVSxDQUFDLEVBQ25DO2NBQUUrQyxFQUFFLEVBQUUsUUFBUTtjQUFFL0MsS0FBSyxFQUFFO1lBQVMsQ0FBQyxFQUNqQztjQUFFK0MsRUFBRSxFQUFFLGFBQWE7Y0FBRS9DLEtBQUssRUFBRTtZQUFjLENBQUM7VUFFckQ7UUFDRixDQUFDLEVBQ0Q7VUFDRTZDLFFBQVEsRUFBRyxpQkFBZ0JuQyxPQUFRLFlBQVc7VUFDOUNvQyxhQUFhLEVBQUcsZ0NBQStCcEMsT0FBUSxFQUFDO1VBQ3hERixLQUFLLEVBQUU7WUFDTFYsS0FBSyxFQUFFLFdBQVc7WUFDbEJULE9BQU8sRUFDTGdELE9BQU8sS0FBSyxTQUFTLEdBQ2pCLENBQ0U7Y0FBRVUsRUFBRSxFQUFFLE1BQU07Y0FBRS9DLEtBQUssRUFBRTtZQUFPLENBQUMsRUFDN0I7Y0FBRStDLEVBQUUsRUFBRSxLQUFLO2NBQUUvQyxLQUFLLEVBQUU7WUFBTSxDQUFDLEVBQzNCO2NBQUUrQyxFQUFFLEVBQUUsVUFBVTtjQUFFL0MsS0FBSyxFQUFFO1lBQVcsQ0FBQyxFQUNyQztjQUFFK0MsRUFBRSxFQUFFLE1BQU07Y0FBRS9DLEtBQUssRUFBRTtZQUFPLENBQUMsQ0FDOUIsR0FDRCxDQUNFO2NBQUUrQyxFQUFFLEVBQUUsTUFBTTtjQUFFL0MsS0FBSyxFQUFFO1lBQU8sQ0FBQyxFQUM3QjtjQUFFK0MsRUFBRSxFQUFFLE9BQU87Y0FBRS9DLEtBQUssRUFBRTtZQUFpQixDQUFDLEVBQ3hDO2NBQUUrQyxFQUFFLEVBQUUsTUFBTTtjQUFFL0MsS0FBSyxFQUFFO1lBQVcsQ0FBQyxFQUNqQztjQUFFK0MsRUFBRSxFQUFFLE9BQU87Y0FBRS9DLEtBQUssRUFBRTtZQUFRLENBQUM7VUFFekMsQ0FBQztVQUNEZ0QsZ0JBQWdCLEVBQUdDLElBQUksSUFDckJaLE9BQU8sS0FBSyxTQUFTLEdBQUdZLElBQUksR0FBRztZQUFFLEdBQUdBLElBQUk7WUFBRUMsS0FBSyxFQUFFQyxnQ0FBa0IsQ0FBQ0YsSUFBSSxDQUFDQyxLQUFLO1VBQUU7UUFDcEYsQ0FBQyxFQUNEO1VBQ0VMLFFBQVEsRUFBRyxpQkFBZ0JuQyxPQUFRLFFBQU87VUFDMUNvQyxhQUFhLEVBQUcsNEJBQTJCcEMsT0FBUSxFQUFDO1VBQ3BERixLQUFLLEVBQUU7WUFDTFYsS0FBSyxFQUFFLGVBQWU7WUFDdEJULE9BQU8sRUFDTGdELE9BQU8sS0FBSyxTQUFTLEdBQ2pCLENBQ0U7Y0FBRVUsRUFBRSxFQUFFLFVBQVU7Y0FBRS9DLEtBQUssRUFBRTtZQUFtQixDQUFDLEVBQzdDO2NBQUUrQyxFQUFFLEVBQUUsWUFBWTtjQUFFL0MsS0FBSyxFQUFFO1lBQWEsQ0FBQyxFQUN6QztjQUFFK0MsRUFBRSxFQUFFLFNBQVM7Y0FBRS9DLEtBQUssRUFBRTtZQUFVLENBQUMsRUFDbkM7Y0FBRStDLEVBQUUsRUFBRSxPQUFPO2NBQUUvQyxLQUFLLEVBQUU7WUFBUSxDQUFDLEVBQy9CO2NBQUUrQyxFQUFFLEVBQUUsVUFBVTtjQUFFL0MsS0FBSyxFQUFFO1lBQVcsQ0FBQyxDQUN0QyxHQUNELENBQ0U7Y0FBRStDLEVBQUUsRUFBRSxVQUFVO2NBQUUvQyxLQUFLLEVBQUU7WUFBbUIsQ0FBQyxFQUM3QztjQUFFK0MsRUFBRSxFQUFFLFlBQVk7Y0FBRS9DLEtBQUssRUFBRTtZQUFhLENBQUMsRUFDekM7Y0FBRStDLEVBQUUsRUFBRSxPQUFPO2NBQUUvQyxLQUFLLEVBQUU7WUFBUSxDQUFDLEVBQy9CO2NBQUUrQyxFQUFFLEVBQUUsVUFBVTtjQUFFL0MsS0FBSyxFQUFFO1lBQVcsQ0FBQztVQUUvQyxDQUFDO1VBQ0RnRCxnQkFBZ0IsRUFBR0MsSUFBSSxLQUFNO1lBQzNCLEdBQUdBLElBQUk7WUFDUEcsUUFBUSxFQUFFSCxJQUFJLENBQUNJLEtBQUssQ0FBQ0MsRUFBRTtZQUN2QkMsVUFBVSxFQUFFTixJQUFJLENBQUNJLEtBQUssQ0FBQ0c7VUFDekIsQ0FBQztRQUNILENBQUMsRUFDRDtVQUNFWCxRQUFRLEVBQUcsaUJBQWdCbkMsT0FBUSxXQUFVO1VBQzdDb0MsYUFBYSxFQUFHLCtCQUE4QnBDLE9BQVEsRUFBQztVQUN2REYsS0FBSyxFQUFFO1lBQ0xWLEtBQUssRUFBRSxvQkFBb0I7WUFDM0JULE9BQU8sRUFBRSxDQUNQO2NBQUUwRCxFQUFFLEVBQUUsTUFBTTtjQUFFL0MsS0FBSyxFQUFFO1lBQU8sQ0FBQyxFQUM3QjtjQUFFK0MsRUFBRSxFQUFFLEtBQUs7Y0FBRS9DLEtBQUssRUFBRTtZQUFNLENBQUMsRUFDM0I7Y0FBRStDLEVBQUUsRUFBRSxPQUFPO2NBQUUvQyxLQUFLLEVBQUU7WUFBUSxDQUFDLEVBQy9CO2NBQUUrQyxFQUFFLEVBQUUsS0FBSztjQUFFL0MsS0FBSyxFQUFFO1lBQU0sQ0FBQyxFQUMzQjtjQUFFK0MsRUFBRSxFQUFFLE1BQU07Y0FBRS9DLEtBQUssRUFBRTtZQUFPLENBQUM7VUFFakM7UUFDRixDQUFDLEVBQ0Q7VUFDRTZDLFFBQVEsRUFBRyxpQkFBZ0JuQyxPQUFRLFVBQVM7VUFDNUNvQyxhQUFhLEVBQUcsOEJBQTZCcEMsT0FBUSxFQUFDO1VBQ3RERixLQUFLLEVBQUU7WUFDTFYsS0FBSyxFQUFFLGtCQUFrQjtZQUN6QlQsT0FBTyxFQUFFLENBQ1A7Y0FBRTBELEVBQUUsRUFBRSxPQUFPO2NBQUUvQyxLQUFLLEVBQUU7WUFBWSxDQUFDLEVBQ25DO2NBQUUrQyxFQUFFLEVBQUUsU0FBUztjQUFFL0MsS0FBSyxFQUFFO1lBQVUsQ0FBQyxFQUNuQztjQUFFK0MsRUFBRSxFQUFFLFNBQVM7Y0FBRS9DLEtBQUssRUFBRTtZQUFVLENBQUMsRUFDbkM7Y0FBRStDLEVBQUUsRUFBRSxPQUFPO2NBQUUvQyxLQUFLLEVBQUU7WUFBVyxDQUFDLEVBQ2xDO2NBQUUrQyxFQUFFLEVBQUUsV0FBVztjQUFFL0MsS0FBSyxFQUFFO1lBQVksQ0FBQztVQUUzQztRQUNGLENBQUMsQ0FDRjtRQUVEcUMsT0FBTyxLQUFLLFNBQVMsSUFDbkJPLHNCQUFzQixDQUFDakUsSUFBSSxDQUFDO1VBQzFCa0UsUUFBUSxFQUFHLGlCQUFnQm5DLE9BQVEsV0FBVTtVQUM3Q29DLGFBQWEsRUFBRywrQkFBOEJwQyxPQUFRLEVBQUM7VUFDdkRGLEtBQUssRUFBRTtZQUNMVixLQUFLLEVBQUUsaUJBQWlCO1lBQ3hCVCxPQUFPLEVBQUUsQ0FBQztjQUFFMEQsRUFBRSxFQUFFLFFBQVE7Y0FBRS9DLEtBQUssRUFBRTtZQUFjLENBQUM7VUFDbEQ7UUFDRixDQUFDLENBQUM7UUFFSixNQUFNeUQsZ0JBQWdCLEdBQUcsTUFBT0MscUJBQXFCLElBQUs7VUFDeEQsSUFBSTtZQUNGLElBQUE5SyxXQUFHLEVBQ0Qsd0NBQXdDLEVBQ3hDOEsscUJBQXFCLENBQUNaLGFBQWEsRUFDbkMsT0FBTyxDQUNSO1lBRUQsTUFBTWEsaUJBQWlCLEdBQUcsTUFBTWxMLE9BQU8sQ0FBQ29FLEtBQUssQ0FBQ0MsR0FBRyxDQUFDQyxNQUFNLENBQUNDLGFBQWEsQ0FBQ3RFLE9BQU8sQ0FDNUUsS0FBSyxFQUNMZ0wscUJBQXFCLENBQUNiLFFBQVEsRUFDOUIsQ0FBQyxDQUFDLEVBQ0Y7Y0FBRTVGLFNBQVMsRUFBRTFEO1lBQU0sQ0FBQyxDQUNyQjtZQUVELE1BQU1xSyxTQUFTLEdBQ2JELGlCQUFpQixJQUNqQkEsaUJBQWlCLENBQUNoSCxJQUFJLElBQ3RCZ0gsaUJBQWlCLENBQUNoSCxJQUFJLENBQUNBLElBQUksSUFDM0JnSCxpQkFBaUIsQ0FBQ2hILElBQUksQ0FBQ0EsSUFBSSxDQUFDTyxjQUFjO1lBQzVDLElBQUkwRyxTQUFTLEVBQUU7Y0FDYixPQUFPO2dCQUNMLEdBQUdGLHFCQUFxQixDQUFDbEQsS0FBSztnQkFDOUJxRCxLQUFLLEVBQUVILHFCQUFxQixDQUFDVixnQkFBZ0IsR0FDekNZLFNBQVMsQ0FBQ3JFLEdBQUcsQ0FBQ21FLHFCQUFxQixDQUFDVixnQkFBZ0IsQ0FBQyxHQUNyRFk7Y0FDTixDQUFDO1lBQ0g7VUFDRixDQUFDLENBQUMsT0FBT2xJLEtBQUssRUFBRTtZQUNkLElBQUE5QyxXQUFHLEVBQUMsd0NBQXdDLEVBQUU4QyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxFQUFFLE9BQU8sQ0FBQztVQUNoRjtRQUNGLENBQUM7UUFFRCxJQUFJdkMsSUFBSSxFQUFFO1VBQUEsSUFBQTJLLHFCQUFBLEVBQUFDLHNCQUFBLEVBQUFDLHNCQUFBO1VBQ1I7VUFDQTlLLGVBQWUsYUFBZkEsZUFBZSx3QkFBQTRLLHFCQUFBLEdBQWY1SyxlQUFlLENBQUUrSyxJQUFJLGNBQUFILHFCQUFBLHdCQUFBQyxzQkFBQSxHQUFyQkQscUJBQUEsQ0FBdUJJLElBQUksY0FBQUgsc0JBQUEsd0JBQUFDLHNCQUFBLEdBQTNCRCxzQkFBQSxDQUE2QnBGLElBQUksY0FBQXFGLHNCQUFBLHVCQUFqQ0Esc0JBQUEsQ0FBQTlMLElBQUEsQ0FBQTZMLHNCQUFBLEVBQW9DO1lBQ2xDSSxZQUFZLEVBQUU7Y0FDWixhQUFhLEVBQUU7Z0JBQ2JDLEtBQUssRUFBRTtjQUNUO1lBQ0Y7VUFDRixDQUFDLENBQUM7VUFFRixNQUFNLElBQUF2Six3Q0FBbUIsRUFDdkJwQyxPQUFPLEVBQ1BxQixPQUFPLEVBQ1AsUUFBUSxFQUNSLGNBQWMsRUFDZFAsS0FBSyxFQUNMSSxJQUFJLEVBQ0pDLEVBQUUsRUFDRlYsZUFBZSxFQUNmd0IsWUFBWSxFQUNacEIsaUJBQWlCLEVBQ2pCb0gsT0FBTyxDQUNSO1FBQ0g7O1FBRUE7UUFDQSxDQUFDLE1BQU0yRCxPQUFPLENBQUNDLEdBQUcsQ0FBQzFCLHNCQUFzQixDQUFDckQsR0FBRyxDQUFDa0UsZ0JBQWdCLENBQUMsQ0FBQyxFQUM3RDdGLE1BQU0sQ0FBRTRDLEtBQUssSUFBS0EsS0FBSyxDQUFDLENBQ3hCekIsT0FBTyxDQUFFeUIsS0FBSyxJQUFLMUcsT0FBTyxDQUFDeUssY0FBYyxDQUFDL0QsS0FBSyxDQUFDLENBQUM7O1FBRXBEO1FBQ0EsTUFBTTFHLE9BQU8sQ0FBQ3NCLEtBQUssQ0FBQzNDLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDZSxZQUFZLENBQUM7UUFFN0QsT0FBTzFDLFFBQVEsQ0FBQzJDLEVBQUUsQ0FBQztVQUNqQjlCLElBQUksRUFBRTtZQUNKK0IsT0FBTyxFQUFFLElBQUk7WUFDYkMsT0FBTyxFQUFHLFVBQVMvQyxPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ21CLFFBQVM7VUFDMUQ7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT0MsS0FBSyxFQUFFO1FBQ2QsSUFBQTlDLFdBQUcsRUFBQywrQkFBK0IsRUFBRThDLEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLENBQUM7UUFDNUQsT0FBTyxJQUFBQyw0QkFBYSxFQUFDRCxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUvQyxRQUFRLENBQUM7TUFDbkU7SUFDRixDQUFDLEVBQUUsQ0FBQztNQUFDZSxNQUFNLEVBQUU7UUFBRWdIO01BQVE7SUFBQyxDQUFDLEtBQU0seUJBQXdCQSxPQUFRLElBQUcsSUFBSSxDQUFDOUUsdUJBQXVCLEVBQUcsTUFBSyxDQUFDO0lBbUR2RztBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQU5FLElBQUFyRCxnQkFBQSxDQUFBakIsT0FBQSwyQkFPa0IsSUFBSSxDQUFDa0IsOENBQThDLENBQUMsT0FDcEVDLE9BQThCLEVBQzlCQyxPQUFzQixFQUN0QkMsUUFBK0IsS0FDNUI7TUFDSCxJQUFJO1FBQ0YsSUFBQUMsV0FBRyxFQUFDLDJCQUEyQixFQUFHLFdBQVVILE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDZSxZQUFhLFNBQVEsRUFBRSxPQUFPLENBQUM7UUFDdkcsTUFBTW1KLGdCQUFnQixHQUFHQyxXQUFFLENBQUNDLFlBQVksQ0FBQ2pNLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDZSxZQUFZLENBQUM7UUFDbEYsT0FBTzFDLFFBQVEsQ0FBQzJDLEVBQUUsQ0FBQztVQUNqQnFKLE9BQU8sRUFBRTtZQUFFLGNBQWMsRUFBRTtVQUFrQixDQUFDO1VBQzlDbkwsSUFBSSxFQUFFZ0w7UUFDUixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBTzlJLEtBQUssRUFBRTtRQUNkLElBQUE5QyxXQUFHLEVBQUMsMkJBQTJCLEVBQUU4QyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxDQUFDO1FBQ3hELE9BQU8sSUFBQUMsNEJBQWEsRUFBQ0QsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFL0MsUUFBUSxDQUFDO01BQ25FO0lBQ0YsQ0FBQyxFQUFHRCxPQUFPLElBQUtBLE9BQU8sQ0FBQ2dCLE1BQU0sQ0FBQ2dGLElBQUksQ0FBQztJQUVwQztBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQU5FLElBQUFuRyxnQkFBQSxDQUFBakIsT0FBQSw4QkFPcUIsSUFBSSxDQUFDa0IsOENBQThDLENBQUMsT0FDdkVDLE9BQThCLEVBQzlCQyxPQUFzQixFQUN0QkMsUUFBK0IsS0FDNUI7TUFDSCxJQUFJO1FBQ0YsSUFBQUMsV0FBRyxFQUFDLDhCQUE4QixFQUFHLFlBQVdILE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDZSxZQUFhLFNBQVEsRUFBRSxPQUFPLENBQUM7UUFDM0dvSixXQUFFLENBQUNHLFVBQVUsQ0FBQ25NLE9BQU8sQ0FBQzZCLG1CQUFtQixDQUFDZSxZQUFZLENBQUM7UUFDdkQsSUFBQXpDLFdBQUcsRUFBQyw4QkFBOEIsRUFBRyxHQUFFSCxPQUFPLENBQUM2QixtQkFBbUIsQ0FBQ2UsWUFBYSxxQkFBb0IsRUFBRSxNQUFNLENBQUM7UUFDN0csT0FBTzFDLFFBQVEsQ0FBQzJDLEVBQUUsQ0FBQztVQUNqQjlCLElBQUksRUFBRTtZQUFFa0MsS0FBSyxFQUFFO1VBQUU7UUFDbkIsQ0FBQyxDQUFDO01BQ0osQ0FBQyxDQUFDLE9BQU9BLEtBQUssRUFBRTtRQUNkLElBQUE5QyxXQUFHLEVBQUMsOEJBQThCLEVBQUU4QyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxDQUFDO1FBQzNELE9BQU8sSUFBQUMsNEJBQWEsRUFBQ0QsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFL0MsUUFBUSxDQUFDO01BQ25FO0lBQ0YsQ0FBQyxFQUFFRCxPQUFPLElBQUtBLE9BQU8sQ0FBQ2dCLE1BQU0sQ0FBQ2dGLElBQUksQ0FBQztFQWhwQ3BCO0VBQ2Y7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNVL0QscUJBQXFCQSxDQUFDMUIsT0FBWSxFQUFFRCxTQUFrQixFQUEwQjtJQUN0RixJQUFBSixXQUFHLEVBQUMsaUNBQWlDLEVBQUcsNkJBQTRCLEVBQUUsTUFBTSxDQUFDO0lBQzdFLElBQUFBLFdBQUcsRUFDRCxpQ0FBaUMsRUFDaEMsWUFBV0ssT0FBTyxDQUFDa0UsTUFBTyxnQkFBZW5FLFNBQVUsRUFBQyxFQUNyRCxPQUFPLENBQ1I7SUFDRCxJQUFJNkwsR0FBRyxHQUFHLEVBQUU7SUFFWixNQUFNbkssWUFBMEIsR0FBRztNQUFFMEosS0FBSyxFQUFFLENBQUMsQ0FBQztNQUFFbEosVUFBVSxFQUFFO0lBQUcsQ0FBQztJQUNoRSxNQUFNNEosVUFBb0IsR0FBRyxFQUFFOztJQUUvQjtJQUNBN0wsT0FBTyxHQUFHQSxPQUFPLENBQUMyRSxNQUFNLENBQUVBLE1BQU0sSUFBSztNQUNuQyxJQUFJQSxNQUFNLENBQUNtSCxJQUFJLENBQUNDLFlBQVksS0FBS0MsNEJBQWlCLEVBQUU7UUFDbER2SyxZQUFZLENBQUMwSixLQUFLLEdBQUd4RyxNQUFNLENBQUN3RyxLQUFLO1FBQ2pDVSxVQUFVLENBQUNuRyxJQUFJLENBQUNmLE1BQU0sQ0FBQztRQUN2QixPQUFPLEtBQUs7TUFDZDtNQUNBLE9BQU9BLE1BQU07SUFDZixDQUFDLENBQUM7SUFFRixNQUFNc0gsR0FBRyxHQUFHak0sT0FBTyxDQUFDa0UsTUFBTTtJQUUxQixLQUFLLElBQUlpQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUc4RixHQUFHLEVBQUU5RixDQUFDLEVBQUUsRUFBRTtNQUM1QixNQUFNO1FBQUUrRixNQUFNO1FBQUVwTixHQUFHO1FBQUVxTixLQUFLO1FBQUUxTCxNQUFNO1FBQUVxRztNQUFLLENBQUMsR0FBRzlHLE9BQU8sQ0FBQ21HLENBQUMsQ0FBQyxDQUFDMkYsSUFBSTtNQUM1REYsR0FBRyxJQUFLLEdBQUVNLE1BQU0sR0FBRyxNQUFNLEdBQUcsRUFBRyxFQUFDO01BQ2hDTixHQUFHLElBQUssR0FBRTlNLEdBQUksSUFBRztNQUNqQjhNLEdBQUcsSUFBSyxHQUNOOUUsSUFBSSxLQUFLLE9BQU8sR0FDWCxHQUFFckcsTUFBTSxDQUFDMkwsR0FBSSxJQUFHM0wsTUFBTSxDQUFDNEwsRUFBRyxFQUFDLEdBQzVCdkYsSUFBSSxLQUFLLFNBQVMsR0FDaEIsR0FBRyxHQUFHckcsTUFBTSxDQUFDVyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxHQUMvQjBGLElBQUksS0FBSyxRQUFRLEdBQ2YsR0FBRyxHQUNILENBQUMsQ0FBQ3FGLEtBQUssR0FDWEEsS0FBSyxHQUNMLENBQUMxTCxNQUFNLElBQUksQ0FBQyxDQUFDLEVBQUUwSyxLQUNwQixFQUFDO01BQ0ZTLEdBQUcsSUFBSyxHQUFFekYsQ0FBQyxLQUFLOEYsR0FBRyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsT0FBUSxFQUFDO0lBQzFDO0lBRUEsSUFBSWxNLFNBQVMsRUFBRTtNQUNiNkwsR0FBRyxJQUFLLFNBQVM3TCxTQUFVLEdBQUU7SUFDL0I7SUFFQTBCLFlBQVksQ0FBQ1EsVUFBVSxHQUFHNEosVUFBVSxDQUFDdkYsR0FBRyxDQUFFM0IsTUFBTSxJQUFLQSxNQUFNLENBQUNtSCxJQUFJLENBQUNLLEtBQUssQ0FBQyxDQUFDL0ssSUFBSSxDQUFDLEdBQUcsQ0FBQztJQUVqRixJQUFBekIsV0FBRyxFQUNELGlDQUFpQyxFQUNoQyxRQUFPaU0sR0FBSSxzQkFBcUJuSyxZQUFZLENBQUNRLFVBQVcsRUFBQyxFQUMxRCxPQUFPLENBQ1I7SUFFRCxPQUFPLENBQUMySixHQUFHLEVBQUVuSyxZQUFZLENBQUM7RUFDNUI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE1BQWNGLFlBQVlBLENBQUMvQixPQUFPLEVBQUVxQixPQUFPLEVBQUVULE9BQU8sRUFBRWtNLEdBQUcsRUFBRUMsUUFBUSxFQUFFak0sS0FBSyxFQUFFO0lBQzFFLElBQUk7TUFDRixJQUFBWCxXQUFHLEVBQ0Qsd0JBQXdCLEVBQ3ZCLFlBQVdTLE9BQVEsVUFBU2tNLEdBQUksZUFBY0MsUUFBUyxZQUFXak0sS0FBTSxFQUFDLEVBQzFFLE9BQU8sQ0FDUjtNQUNELElBQUlGLE9BQU8sSUFBSSxPQUFPQSxPQUFPLEtBQUssUUFBUSxFQUFFO1FBQzFDLElBQUksQ0FBQyxDQUFDLGFBQWEsRUFBRSxhQUFhLENBQUMsQ0FBQzRHLFFBQVEsQ0FBQzVHLE9BQU8sQ0FBQyxFQUFFO1VBQ3JEUyxPQUFPLENBQUMwQyxVQUFVLENBQUM7WUFDakJDLElBQUksRUFBRWdKLDJCQUFhLENBQUNGLEdBQUcsQ0FBQyxDQUFDekYsS0FBSyxHQUFHLFNBQVM7WUFDMUNwRCxLQUFLLEVBQUU7VUFDVCxDQUFDLENBQUM7UUFDSixDQUFDLE1BQU0sSUFBSXJELE9BQU8sS0FBSyxhQUFhLEVBQUU7VUFDcENTLE9BQU8sQ0FBQzBDLFVBQVUsQ0FBQztZQUNqQkMsSUFBSSxFQUFHLFNBQVErSSxRQUFTLGdCQUFlO1lBQ3ZDOUksS0FBSyxFQUFFO1VBQ1QsQ0FBQyxDQUFDO1FBQ0osQ0FBQyxNQUFNLElBQUlyRCxPQUFPLEtBQUssYUFBYSxFQUFFO1VBQ3BDUyxPQUFPLENBQUMwQyxVQUFVLENBQUM7WUFDakJDLElBQUksRUFBRSxpQkFBaUI7WUFDdkJDLEtBQUssRUFBRTtVQUNULENBQUMsQ0FBQztRQUNKO1FBQ0E1QyxPQUFPLENBQUM0TCxVQUFVLEVBQUU7TUFDdEI7TUFFQSxJQUFJRixRQUFRLElBQUksT0FBT0EsUUFBUSxLQUFLLFFBQVEsRUFBRTtRQUM1QyxNQUFNLElBQUE3QyxxQ0FBZ0IsRUFDcEJsSyxPQUFPLEVBQ1BxQixPQUFPLEVBQ1AwTCxRQUFRLEVBQ1JqTSxLQUFLLEVBQ0xGLE9BQU8sS0FBSyxhQUFhLEdBQUdrTSxHQUFHLEdBQUcsRUFBRSxDQUNyQztNQUNIO01BRUEsSUFBSUMsUUFBUSxJQUFJLE9BQU9BLFFBQVEsS0FBSyxRQUFRLEVBQUU7UUFDNUMsTUFBTWxELGFBQWEsR0FBRyxNQUFNN0osT0FBTyxDQUFDb0UsS0FBSyxDQUFDQyxHQUFHLENBQUNDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDdEUsT0FBTyxDQUN4RSxLQUFLLEVBQ0osU0FBUSxFQUNUO1VBQUVnQixNQUFNLEVBQUU7WUFBRWlNLFdBQVcsRUFBRUg7VUFBUztRQUFFLENBQUMsRUFDckM7VUFBRXZJLFNBQVMsRUFBRTFEO1FBQU0sQ0FBQyxDQUNyQjtRQUNELE1BQU1xTSxTQUFTLEdBQUd0RCxhQUFhLENBQUMzRixJQUFJLENBQUNBLElBQUksQ0FBQ08sY0FBYyxDQUFDLENBQUMsQ0FBQztRQUMzRCxJQUFJMEksU0FBUyxJQUFJQSxTQUFTLENBQUNDLE1BQU0sS0FBS0MsZ0NBQXFCLENBQUNDLE1BQU0sRUFBRTtVQUNsRWpNLE9BQU8sQ0FBQzRJLHFCQUFxQixDQUFDO1lBQzVCakcsSUFBSSxFQUFHLHFCQUFvQixJQUFBdUosOENBQTZCLEVBQUNKLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUM3RCxXQUFXLEVBQUcsRUFBQztZQUMxRnRGLEtBQUssRUFBRTtVQUNULENBQUMsQ0FBQztRQUNKO1FBQ0EsTUFBTSxJQUFBaUcscUNBQWdCLEVBQUNsSyxPQUFPLEVBQUVxQixPQUFPLEVBQUUsQ0FBQzBMLFFBQVEsQ0FBQyxFQUFFak0sS0FBSyxDQUFDO1FBRTNELElBQUlxTSxTQUFTLElBQUlBLFNBQVMsQ0FBQzNHLEtBQUssRUFBRTtVQUNoQyxNQUFNZ0gsV0FBVyxHQUFHTCxTQUFTLENBQUMzRyxLQUFLLENBQUM1RSxJQUFJLENBQUMsSUFBSSxDQUFDO1VBQzlDUCxPQUFPLENBQUM0SSxxQkFBcUIsQ0FBQztZQUM1QmpHLElBQUksRUFBRyxRQUFPbUosU0FBUyxDQUFDM0csS0FBSyxDQUFDOUIsTUFBTSxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsRUFBRyxLQUFJOEksV0FBWSxFQUFDO1lBQ3JFdkosS0FBSyxFQUFFO1VBQ1QsQ0FBQyxDQUFDO1FBQ0o7TUFDRjtNQUNBLElBQUkrSSwyQkFBYSxDQUFDRixHQUFHLENBQUMsSUFBSUUsMkJBQWEsQ0FBQ0YsR0FBRyxDQUFDLENBQUNXLFdBQVcsRUFBRTtRQUN4RHBNLE9BQU8sQ0FBQzRJLHFCQUFxQixDQUFDO1VBQzVCakcsSUFBSSxFQUFFZ0osMkJBQWEsQ0FBQ0YsR0FBRyxDQUFDLENBQUNXLFdBQVc7VUFDcEN4SixLQUFLLEVBQUU7UUFDVCxDQUFDLENBQUM7TUFDSjtJQUNGLENBQUMsQ0FBQyxPQUFPaEIsS0FBSyxFQUFFO01BQ2QsSUFBQTlDLFdBQUcsRUFBQyx3QkFBd0IsRUFBRThDLEtBQUssQ0FBQ0YsT0FBTyxJQUFJRSxLQUFLLENBQUM7TUFDckQsT0FBTzJJLE9BQU8sQ0FBQzhCLE1BQU0sQ0FBQ3pLLEtBQUssQ0FBQztJQUM5QjtFQUNGO0VBRVEwSyxhQUFhQSxDQUFDekosSUFBSSxFQUFFTCxNQUFNLEVBQUU7SUFDbEMsSUFBQTFELFdBQUcsRUFBQyx5QkFBeUIsRUFBRyw2QkFBNEIsRUFBRSxNQUFNLENBQUM7SUFDckUsTUFBTXlOLE1BQU0sR0FBRyxFQUFFO0lBQ2pCLEtBQUssSUFBSUMsSUFBSSxJQUFJM0osSUFBSSxJQUFJLEVBQUUsRUFBRTtNQUMzQixJQUFJaUMsS0FBSyxDQUFDQyxPQUFPLENBQUNsQyxJQUFJLENBQUMySixJQUFJLENBQUMsQ0FBQyxFQUFFO1FBQzdCM0osSUFBSSxDQUFDMkosSUFBSSxDQUFDLENBQUN2SCxPQUFPLENBQUMsQ0FBQ0ksQ0FBQyxFQUFFckIsR0FBRyxLQUFLO1VBQzdCLElBQUksT0FBT3FCLENBQUMsS0FBSyxRQUFRLEVBQUV4QyxJQUFJLENBQUMySixJQUFJLENBQUMsQ0FBQ3hJLEdBQUcsQ0FBQyxHQUFHMkIsSUFBSSxDQUFDQyxTQUFTLENBQUNQLENBQUMsQ0FBQztRQUNoRSxDQUFDLENBQUM7TUFDSjtNQUNBa0gsTUFBTSxDQUFDMUgsSUFBSSxDQUFDLENBQUMsQ0FBQ3JDLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBRWdLLElBQUksQ0FBQyxJQUFJQyxpQ0FBYyxDQUFDRCxJQUFJLENBQUMsSUFBSUEsSUFBSSxFQUFFM0osSUFBSSxDQUFDMkosSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLENBQUM7SUFDeEY7SUFDQSxPQUFPRCxNQUFNO0VBQ2Y7RUFFUWxHLGVBQWVBLENBQUN4RCxJQUFJLEVBQUV0RCxPQUFPLEVBQUVrTSxHQUFHLEVBQUUxTSxLQUFLLEdBQUcsRUFBRSxFQUFFO0lBQ3RELElBQUFELFdBQUcsRUFBQywyQkFBMkIsRUFBRywrQkFBOEIsRUFBRSxNQUFNLENBQUM7SUFDekUsSUFBSTROLFNBQVMsR0FBRyxDQUFDLENBQUM7SUFDbEIsTUFBTUMsVUFBVSxHQUFHLEVBQUU7SUFDckIsTUFBTUMsU0FBUyxHQUFHLEVBQUU7SUFFcEIsSUFBSS9KLElBQUksQ0FBQ1EsTUFBTSxLQUFLLENBQUMsSUFBSXlCLEtBQUssQ0FBQ0MsT0FBTyxDQUFDbEMsSUFBSSxDQUFDLEVBQUU7TUFDNUMrSixTQUFTLENBQUNyTixPQUFPLENBQUNnRSxNQUFNLENBQUNrSSxHQUFHLENBQUMsQ0FBQzNJLGFBQWEsQ0FBQyxHQUFHRCxJQUFJO0lBQ3JELENBQUMsTUFBTTtNQUNMLEtBQUssSUFBSTVFLEdBQUcsSUFBSTRFLElBQUksRUFBRTtRQUNwQixJQUNHLE9BQU9BLElBQUksQ0FBQzVFLEdBQUcsQ0FBQyxLQUFLLFFBQVEsSUFBSSxDQUFDNkcsS0FBSyxDQUFDQyxPQUFPLENBQUNsQyxJQUFJLENBQUM1RSxHQUFHLENBQUMsQ0FBQyxJQUMxRDZHLEtBQUssQ0FBQ0MsT0FBTyxDQUFDbEMsSUFBSSxDQUFDNUUsR0FBRyxDQUFDLENBQUMsSUFBSSxPQUFPNEUsSUFBSSxDQUFDNUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUyxFQUM5RDtVQUNBeU8sU0FBUyxDQUFDek8sR0FBRyxDQUFDLEdBQ1o2RyxLQUFLLENBQUNDLE9BQU8sQ0FBQ2xDLElBQUksQ0FBQzVFLEdBQUcsQ0FBQyxDQUFDLElBQUksT0FBTzRFLElBQUksQ0FBQzVFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsR0FDeEQ0RSxJQUFJLENBQUM1RSxHQUFHLENBQUMsQ0FBQ3dILEdBQUcsQ0FBRUosQ0FBQyxJQUFLO1lBQ25CLE9BQU8sT0FBT0EsQ0FBQyxLQUFLLFFBQVEsR0FBR00sSUFBSSxDQUFDQyxTQUFTLENBQUNQLENBQUMsQ0FBQyxHQUFHQSxDQUFDLEdBQUcsSUFBSTtVQUM3RCxDQUFDLENBQUMsR0FDRnhDLElBQUksQ0FBQzVFLEdBQUcsQ0FBQztRQUNqQixDQUFDLE1BQU0sSUFBSTZHLEtBQUssQ0FBQ0MsT0FBTyxDQUFDbEMsSUFBSSxDQUFDNUUsR0FBRyxDQUFDLENBQUMsSUFBSSxPQUFPNEUsSUFBSSxDQUFDNUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO1VBQ3ZFMk8sU0FBUyxDQUFDM08sR0FBRyxDQUFDLEdBQUc0RSxJQUFJLENBQUM1RSxHQUFHLENBQUM7UUFDNUIsQ0FBQyxNQUFNO1VBQ0wsSUFBSXNCLE9BQU8sQ0FBQ29FLGFBQWEsSUFBSSxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQ3dDLFFBQVEsQ0FBQ2xJLEdBQUcsQ0FBQyxFQUFFO1lBQzlEMk8sU0FBUyxDQUFDM08sR0FBRyxDQUFDLEdBQUcsQ0FBQzRFLElBQUksQ0FBQzVFLEdBQUcsQ0FBQyxDQUFDO1VBQzlCLENBQUMsTUFBTTtZQUNMME8sVUFBVSxDQUFDOUgsSUFBSSxDQUFDaEMsSUFBSSxDQUFDNUUsR0FBRyxDQUFDLENBQUM7VUFDNUI7UUFDRjtNQUNGO0lBQ0Y7SUFDQWMsS0FBSyxDQUFDOEYsSUFBSSxDQUFDO01BQ1RtQixLQUFLLEVBQUUsQ0FBQ3pHLE9BQU8sQ0FBQ3NOLE9BQU8sSUFBSSxDQUFDLENBQUMsRUFBRUMsVUFBVSxHQUNyQyxFQUFFLEdBQ0YsQ0FBQ3ZOLE9BQU8sQ0FBQzBFLElBQUksSUFBSSxFQUFFLEVBQUV3SCxHQUFHLENBQUMsS0FDeEJsTSxPQUFPLENBQUNvRSxhQUFhLEdBQUcsQ0FBQyxDQUFDcEUsT0FBTyxDQUFDaUQsTUFBTSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUVpSixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUM7TUFDekVsRyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDO01BQ2pCVSxJQUFJLEVBQUUsUUFBUTtNQUNkVCxJQUFJLEVBQUUsSUFBSSxDQUFDOEcsYUFBYSxDQUFDSSxTQUFTLEVBQUUsQ0FBQ25OLE9BQU8sQ0FBQ2lELE1BQU0sSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQy9ELENBQUMsQ0FBQztJQUNGLEtBQUssSUFBSXZFLEdBQUcsSUFBSTJPLFNBQVMsRUFBRTtNQUN6QixNQUFNckgsT0FBTyxHQUFHekgsTUFBTSxDQUFDd0YsSUFBSSxDQUFDc0osU0FBUyxDQUFDM08sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDOUNzSCxPQUFPLENBQUNOLE9BQU8sQ0FBQyxDQUFDWSxHQUFHLEVBQUVQLENBQUMsS0FBSztRQUMxQkMsT0FBTyxDQUFDRCxDQUFDLENBQUMsR0FBR08sR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDQyxXQUFXLEVBQUUsR0FBR0QsR0FBRyxDQUFDRSxLQUFLLENBQUMsQ0FBQyxDQUFDO01BQ2xELENBQUMsQ0FBQztNQUVGLE1BQU1QLElBQUksR0FBR29ILFNBQVMsQ0FBQzNPLEdBQUcsQ0FBQyxDQUFDd0gsR0FBRyxDQUFFSixDQUFDLElBQUs7UUFDckMsSUFBSUssR0FBRyxHQUFHLEVBQUU7UUFDWixLQUFLLElBQUl6SCxHQUFHLElBQUlvSCxDQUFDLEVBQUU7VUFDakJLLEdBQUcsQ0FBQ2IsSUFBSSxDQUNOLE9BQU9RLENBQUMsQ0FBQ3BILEdBQUcsQ0FBQyxLQUFLLFFBQVEsR0FDdEJvSCxDQUFDLENBQUNwSCxHQUFHLENBQUMsR0FDTjZHLEtBQUssQ0FBQ0MsT0FBTyxDQUFDTSxDQUFDLENBQUNwSCxHQUFHLENBQUMsQ0FBQyxHQUNyQm9ILENBQUMsQ0FBQ3BILEdBQUcsQ0FBQyxDQUFDd0gsR0FBRyxDQUFFSixDQUFDLElBQUs7WUFDaEIsT0FBT0EsQ0FBQyxHQUFHLElBQUk7VUFDakIsQ0FBQyxDQUFDLEdBQ0ZNLElBQUksQ0FBQ0MsU0FBUyxDQUFDUCxDQUFDLENBQUNwSCxHQUFHLENBQUMsQ0FBQyxDQUMzQjtRQUNIO1FBQ0EsT0FBT3lILEdBQUcsQ0FBQ3JDLE1BQU0sR0FBR2tDLE9BQU8sQ0FBQ2xDLE1BQU0sRUFBRTtVQUNsQ3FDLEdBQUcsQ0FBQ2IsSUFBSSxDQUFDLEdBQUcsQ0FBQztRQUNmO1FBQ0EsT0FBT2EsR0FBRztNQUNaLENBQUMsQ0FBQztNQUNGM0csS0FBSyxDQUFDOEYsSUFBSSxDQUFDO1FBQ1RtQixLQUFLLEVBQUUsQ0FBQyxDQUFDekcsT0FBTyxDQUFDaUQsTUFBTSxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUV2RSxHQUFHLENBQUMsSUFBSSxFQUFFO1FBQ25EZ0ksSUFBSSxFQUFFLE9BQU87UUFDYlYsT0FBTztRQUNQQztNQUNGLENBQUMsQ0FBQztJQUNKO0lBQ0FtSCxVQUFVLENBQUMxSCxPQUFPLENBQUM4SCxJQUFJLElBQUk7TUFDekIsSUFBSSxDQUFDMUcsZUFBZSxDQUFDMEcsSUFBSSxFQUFFeE4sT0FBTyxFQUFFa00sR0FBRyxHQUFHLENBQUMsRUFBRTFNLEtBQUssQ0FBQztJQUNyRCxDQUFDLENBQUM7SUFDRixPQUFPQSxLQUFLO0VBQ2Q7RUFzMEJBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsTUFBTWlPLFVBQVVBLENBQ2RyTyxPQUE4QixFQUM5QkMsT0FBc0IsRUFDdEJDLFFBQStCLEVBQy9CO0lBQ0EsSUFBSTtNQUNGLElBQUFDLFdBQUcsRUFBQyxzQkFBc0IsRUFBRywwQkFBeUIsRUFBRSxNQUFNLENBQUM7TUFDL0QsTUFBTTtRQUFFMkI7TUFBYSxDQUFDLEdBQUcsTUFBTTlCLE9BQU8sQ0FBQ29FLEtBQUssQ0FBQ3NGLFFBQVEsQ0FBQ0MsY0FBYyxDQUFDMUosT0FBTyxFQUFFRCxPQUFPLENBQUM7TUFDdEYsSUFBQXVCLDBDQUE4QixHQUFFO01BQ2hDLElBQUFDLHNDQUEwQixFQUFDQyw4Q0FBbUMsQ0FBQztNQUMvRCxJQUFBRCxzQ0FBMEIsRUFBQ0Usc0RBQTJDLENBQUM7TUFDdkUsTUFBTTRNLHdCQUF3QixHQUFHM00sYUFBSSxDQUFDQyxJQUFJLENBQUNGLHNEQUEyQyxFQUFFSSxZQUFZLENBQUM7TUFDckcsSUFBQU4sc0NBQTBCLEVBQUM4TSx3QkFBd0IsQ0FBQztNQUNwRCxJQUFBbk8sV0FBRyxFQUFDLHNCQUFzQixFQUFHLGNBQWFtTyx3QkFBeUIsRUFBQyxFQUFFLE9BQU8sQ0FBQztNQUU5RSxNQUFNQyxpQkFBaUIsR0FBR0EsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQU1ELENBQUMsQ0FBQ0UsSUFBSSxHQUFHRCxDQUFDLENBQUNDLElBQUksR0FBRyxDQUFDLEdBQUdGLENBQUMsQ0FBQ0UsSUFBSSxHQUFHRCxDQUFDLENBQUNDLElBQUksR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFFO01BRXBGLE1BQU1DLE9BQU8sR0FBRzNDLFdBQUUsQ0FBQzRDLFdBQVcsQ0FBQ04sd0JBQXdCLENBQUMsQ0FBQ3hILEdBQUcsQ0FBRStILElBQUksSUFBSztRQUNyRSxNQUFNQyxLQUFLLEdBQUc5QyxXQUFFLENBQUMrQyxRQUFRLENBQUNULHdCQUF3QixHQUFHLEdBQUcsR0FBR08sSUFBSSxDQUFDO1FBQ2hFO1FBQ0E7UUFDQSxNQUFNRyxjQUFjLEdBQUcsQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQ0MsSUFBSSxDQUNqRXZPLElBQUksSUFBS29PLEtBQUssQ0FBRSxHQUFFcE8sSUFBSyxJQUFHLENBQUMsQ0FDN0I7UUFDRCxPQUFPO1VBQ0x1RixJQUFJLEVBQUU0SSxJQUFJO1VBQ1ZLLElBQUksRUFBRUosS0FBSyxDQUFDSSxJQUFJO1VBQ2hCUixJQUFJLEVBQUVJLEtBQUssQ0FBQ0UsY0FBYztRQUM1QixDQUFDO01BQ0gsQ0FBQyxDQUFDO01BQ0YsSUFBQTdPLFdBQUcsRUFBQyxzQkFBc0IsRUFBRyw2QkFBNEJ3TyxPQUFPLENBQUNqSyxNQUFPLFFBQU8sRUFBRSxPQUFPLENBQUM7TUFDekZoSCxPQUFPLENBQUN5UixJQUFJLENBQUNSLE9BQU8sRUFBRUosaUJBQWlCLENBQUM7TUFDeEMsSUFBQXBPLFdBQUcsRUFBQyxzQkFBc0IsRUFBRyxrQkFBaUJ3TyxPQUFPLENBQUNqSyxNQUFPLEVBQUMsRUFBRSxPQUFPLENBQUM7TUFDeEUsT0FBT3hFLFFBQVEsQ0FBQzJDLEVBQUUsQ0FBQztRQUNqQjlCLElBQUksRUFBRTtVQUFFNE47UUFBUTtNQUNsQixDQUFDLENBQUM7SUFDSixDQUFDLENBQUMsT0FBTzFMLEtBQUssRUFBRTtNQUNkLElBQUE5QyxXQUFHLEVBQUMsc0JBQXNCLEVBQUU4QyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxDQUFDO01BQ25ELE9BQU8sSUFBQUMsNEJBQWEsRUFBQ0QsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFL0MsUUFBUSxDQUFDO0lBQ25FO0VBQ0Y7RUFvREFILDhDQUE4Q0EsQ0FBQ3FQLFlBQVksRUFBRUMsc0JBQXNCLEVBQUM7SUFDbEYsT0FBUSxPQUNOclAsT0FBOEIsRUFDOUJDLE9BQXNCLEVBQ3RCQyxRQUErQixLQUM1QjtNQUNILElBQUc7UUFDRCxNQUFNO1VBQUVvUCxRQUFRO1VBQUV4TjtRQUFhLENBQUMsR0FBRyxNQUFNOUIsT0FBTyxDQUFDb0UsS0FBSyxDQUFDc0YsUUFBUSxDQUFDQyxjQUFjLENBQUMxSixPQUFPLEVBQUVELE9BQU8sQ0FBQztRQUNoRyxNQUFNc08sd0JBQXdCLEdBQUczTSxhQUFJLENBQUNDLElBQUksQ0FBQ0Ysc0RBQTJDLEVBQUVJLFlBQVksQ0FBQztRQUNyRyxNQUFNa0IsUUFBUSxHQUFHcU0sc0JBQXNCLENBQUNwUCxPQUFPLENBQUM7UUFDaEQsTUFBTTJDLFlBQVksR0FBR2pCLGFBQUksQ0FBQ0MsSUFBSSxDQUFDME0sd0JBQXdCLEVBQUV0TCxRQUFRLENBQUM7UUFDbEUsSUFBQTdDLFdBQUcsRUFBQywwREFBMEQsRUFBRyxxQkFBb0JtUCxRQUFTLElBQUd4TixZQUFhLHlDQUF3Q2MsWUFBYSxFQUFDLEVBQUUsT0FBTyxDQUFDO1FBQzlLLElBQUcsQ0FBQ0EsWUFBWSxDQUFDMk0sVUFBVSxDQUFDakIsd0JBQXdCLENBQUMsSUFBSTFMLFlBQVksQ0FBQzRFLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBQztVQUNwRixJQUFBckgsV0FBRyxFQUFDLG1FQUFtRSxFQUFHLFFBQU9tUCxRQUFTLElBQUd4TixZQUFhLGdEQUErQ2MsWUFBYSxFQUFDLEVBQUUsTUFBTSxDQUFDO1VBQ2hMLE9BQU8xQyxRQUFRLENBQUNzUCxVQUFVLENBQUM7WUFDekJ6TyxJQUFJLEVBQUU7Y0FDSmdDLE9BQU8sRUFBRTtZQUNYO1VBQ0YsQ0FBQyxDQUFDO1FBQ0o7UUFBQztRQUNELElBQUE1QyxXQUFHLEVBQUMsMERBQTBELEVBQUUsc0RBQXNELEVBQUUsT0FBTyxDQUFDO1FBQ2hJLE9BQU8sTUFBTWlQLFlBQVksQ0FBQ0ssSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1VBQUMsR0FBR3pQLE9BQU87VUFBRTZCLG1CQUFtQixFQUFFO1lBQUVDLFlBQVk7WUFBRWtCLFFBQVE7WUFBRUo7VUFBYTtRQUFDLENBQUMsRUFBRTNDLE9BQU8sRUFBRUMsUUFBUSxDQUFDO01BQ3RJLENBQUMsUUFBTStDLEtBQUssRUFBQztRQUNYLElBQUE5QyxXQUFHLEVBQUMsMERBQTBELEVBQUU4QyxLQUFLLENBQUNGLE9BQU8sSUFBSUUsS0FBSyxDQUFDO1FBQ3ZGLE9BQU8sSUFBQUMsNEJBQWEsRUFBQ0QsS0FBSyxDQUFDRixPQUFPLElBQUlFLEtBQUssRUFBRSxJQUFJLEVBQUUsR0FBRyxFQUFFL0MsUUFBUSxDQUFDO01BQ25FO0lBQ0YsQ0FBQztFQUNIO0VBRVFpRCx1QkFBdUJBLENBQUEsRUFBRTtJQUMvQixPQUFRLEdBQUdkLElBQUksQ0FBQ3FOLEdBQUcsRUFBRSxHQUFHLElBQUksR0FBSSxDQUFFLEVBQUM7RUFDckM7QUFDRjtBQUFDQyxPQUFBLENBQUEvUCxrQkFBQSxHQUFBQSxrQkFBQSJ9