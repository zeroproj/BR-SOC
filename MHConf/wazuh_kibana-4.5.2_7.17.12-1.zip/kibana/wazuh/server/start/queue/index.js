"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.addJobToQueue = addJobToQueue;
exports.jobQueueRun = jobQueueRun;
exports.queue = void 0;
var _nodeCron = _interopRequireDefault(require("node-cron"));
var _logger = require("../../lib/logger");
var _constants = require("../../../common/constants");
/*
 * Wazuh app - Add delayed jobs to a queue.
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */

let queue = [];
exports.queue = queue;
;

/**
 * Add a job to the queue.
 * @param job Job to add to queue
 */
function addJobToQueue(job) {
  (0, _logger.log)('queue:addJob', `New job added`, 'debug');
  queue.push(job);
}
;
async function executePendingJobs() {
  try {
    if (!queue || !queue.length) return;
    const now = new Date();
    const pendingJobs = queue.filter(item => item.startAt <= now);
    (0, _logger.log)('queue:executePendingJobs', `Pending jobs: ${pendingJobs.length}`, 'debug');
    if (!pendingJobs || !pendingJobs.length) {
      return;
    }
    ;
    exports.queue = queue = queue.filter(item => item.startAt > now);
    for (const job of pendingJobs) {
      try {
        await job.run();
      } catch (error) {
        continue;
      }
      ;
    }
  } catch (error) {
    exports.queue = queue = [];
    (0, _logger.log)('queue:executePendingJobs', error.message || error);
    return Promise.reject(error);
  }
}

/**
 * Run the job queue it plugin start.
 * @param context 
 */
function jobQueueRun(context) {
  _nodeCron.default.schedule(_constants.WAZUH_QUEUE_CRON_FREQ, async () => {
    try {
      await executePendingJobs();
    } catch (error) {
      (0, _logger.log)('queue:launchCronJob', error.message || error);
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZUNyb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwicmVxdWlyZSIsIl9sb2dnZXIiLCJfY29uc3RhbnRzIiwicXVldWUiLCJleHBvcnRzIiwiYWRkSm9iVG9RdWV1ZSIsImpvYiIsImxvZyIsInB1c2giLCJleGVjdXRlUGVuZGluZ0pvYnMiLCJsZW5ndGgiLCJub3ciLCJEYXRlIiwicGVuZGluZ0pvYnMiLCJmaWx0ZXIiLCJpdGVtIiwic3RhcnRBdCIsInJ1biIsImVycm9yIiwibWVzc2FnZSIsIlByb21pc2UiLCJyZWplY3QiLCJqb2JRdWV1ZVJ1biIsImNvbnRleHQiLCJjcm9uIiwic2NoZWR1bGUiLCJXQVpVSF9RVUVVRV9DUk9OX0ZSRVEiXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gQWRkIGRlbGF5ZWQgam9icyB0byBhIHF1ZXVlLlxuICogQ29weXJpZ2h0IChDKSAyMDE1LTIwMjIgV2F6dWgsIEluYy5cbiAqXG4gKiBUaGlzIHByb2dyYW0gaXMgZnJlZSBzb2Z0d2FyZTsgeW91IGNhbiByZWRpc3RyaWJ1dGUgaXQgYW5kL29yIG1vZGlmeVxuICogaXQgdW5kZXIgdGhlIHRlcm1zIG9mIHRoZSBHTlUgR2VuZXJhbCBQdWJsaWMgTGljZW5zZSBhcyBwdWJsaXNoZWQgYnlcbiAqIHRoZSBGcmVlIFNvZnR3YXJlIEZvdW5kYXRpb247IGVpdGhlciB2ZXJzaW9uIDIgb2YgdGhlIExpY2Vuc2UsIG9yXG4gKiAoYXQgeW91ciBvcHRpb24pIGFueSBsYXRlciB2ZXJzaW9uLlxuICpcbiAqIEZpbmQgbW9yZSBpbmZvcm1hdGlvbiBhYm91dCB0aGlzIG9uIHRoZSBMSUNFTlNFIGZpbGUuXG4gKi9cbmltcG9ydCBjcm9uIGZyb20gJ25vZGUtY3Jvbic7XG5pbXBvcnQgeyBsb2cgfSBmcm9tICcuLi8uLi9saWIvbG9nZ2VyJztcbmltcG9ydCB7IFdBWlVIX1FVRVVFX0NST05fRlJFUSB9IGZyb20gJy4uLy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xuXG5leHBvcnQgbGV0IHF1ZXVlID0gW107XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVF1ZXVlSm9ie1xuICAvKiogRGF0ZSBvYmplY3QgdG8gc3RhcnQgdGhlIGpvYiAqL1xuICBzdGFydEF0OiBEYXRlXG4gIC8qKiBGdW5jdGlvbiB0byBleGVjdXRlICovXG4gIHJ1bjogKCkgPT4gdm9pZFxufTtcblxuLyoqXG4gKiBBZGQgYSBqb2IgdG8gdGhlIHF1ZXVlLlxuICogQHBhcmFtIGpvYiBKb2IgdG8gYWRkIHRvIHF1ZXVlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGRKb2JUb1F1ZXVlKGpvYjogSVF1ZXVlSm9iKSB7XG4gIGxvZygncXVldWU6YWRkSm9iJywgYE5ldyBqb2IgYWRkZWRgLCAnZGVidWcnKTtcbiAgcXVldWUucHVzaChqb2IpO1xufTtcblxuYXN5bmMgZnVuY3Rpb24gZXhlY3V0ZVBlbmRpbmdKb2JzKCkge1xuICB0cnkge1xuICAgIGlmICghcXVldWUgfHwgIXF1ZXVlLmxlbmd0aCkgcmV0dXJuO1xuICAgIGNvbnN0IG5vdzogRGF0ZSA9IG5ldyBEYXRlKCk7XG4gICAgY29uc3QgcGVuZGluZ0pvYnM6IElRdWV1ZUpvYltdID0gcXVldWUuZmlsdGVyKGl0ZW0gPT4gaXRlbS5zdGFydEF0IDw9IG5vdyk7XG4gICAgbG9nKFxuICAgICAgJ3F1ZXVlOmV4ZWN1dGVQZW5kaW5nSm9icycsXG4gICAgICBgUGVuZGluZyBqb2JzOiAke3BlbmRpbmdKb2JzLmxlbmd0aH1gLFxuICAgICAgJ2RlYnVnJ1xuICAgICk7XG4gICAgaWYgKCFwZW5kaW5nSm9icyB8fCAhcGVuZGluZ0pvYnMubGVuZ3RoKXtcbiAgICAgIHJldHVybjtcbiAgICB9O1xuICAgIHF1ZXVlID0gcXVldWUuZmlsdGVyKChpdGVtOiBJUXVldWVKb2IpID0+IGl0ZW0uc3RhcnRBdCA+IG5vdyk7XG5cbiAgICBmb3IgKGNvbnN0IGpvYiBvZiBwZW5kaW5nSm9icykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgam9iLnJ1bigpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9O1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBxdWV1ZSA9IFtdO1xuICAgIGxvZygncXVldWU6ZXhlY3V0ZVBlbmRpbmdKb2JzJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgfVxufVxuXG4vKipcbiAqIFJ1biB0aGUgam9iIHF1ZXVlIGl0IHBsdWdpbiBzdGFydC5cbiAqIEBwYXJhbSBjb250ZXh0IFxuICovXG5leHBvcnQgZnVuY3Rpb24gam9iUXVldWVSdW4oY29udGV4dCkge1xuICBjcm9uLnNjaGVkdWxlKFxuICAgIFdBWlVIX1FVRVVFX0NST05fRlJFUSxcbiAgICBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBleGVjdXRlUGVuZGluZ0pvYnMoKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGxvZygncXVldWU6bGF1bmNoQ3JvbkpvYicsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBV0EsSUFBQUEsU0FBQSxHQUFBQyxzQkFBQSxDQUFBQyxPQUFBO0FBQ0EsSUFBQUMsT0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsVUFBQSxHQUFBRixPQUFBO0FBYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFLTyxJQUFJRyxLQUFLLEdBQUcsRUFBRTtBQUFDQyxPQUFBLENBQUFELEtBQUEsR0FBQUEsS0FBQTtBQU9yQjs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNFLGFBQWFBLENBQUNDLEdBQWMsRUFBRTtFQUM1QyxJQUFBQyxXQUFHLEVBQUMsY0FBYyxFQUFHLGVBQWMsRUFBRSxPQUFPLENBQUM7RUFDN0NKLEtBQUssQ0FBQ0ssSUFBSSxDQUFDRixHQUFHLENBQUM7QUFDakI7QUFBQztBQUVELGVBQWVHLGtCQUFrQkEsQ0FBQSxFQUFHO0VBQ2xDLElBQUk7SUFDRixJQUFJLENBQUNOLEtBQUssSUFBSSxDQUFDQSxLQUFLLENBQUNPLE1BQU0sRUFBRTtJQUM3QixNQUFNQyxHQUFTLEdBQUcsSUFBSUMsSUFBSSxFQUFFO0lBQzVCLE1BQU1DLFdBQXdCLEdBQUdWLEtBQUssQ0FBQ1csTUFBTSxDQUFDQyxJQUFJLElBQUlBLElBQUksQ0FBQ0MsT0FBTyxJQUFJTCxHQUFHLENBQUM7SUFDMUUsSUFBQUosV0FBRyxFQUNELDBCQUEwQixFQUN6QixpQkFBZ0JNLFdBQVcsQ0FBQ0gsTUFBTyxFQUFDLEVBQ3JDLE9BQU8sQ0FDUjtJQUNELElBQUksQ0FBQ0csV0FBVyxJQUFJLENBQUNBLFdBQVcsQ0FBQ0gsTUFBTSxFQUFDO01BQ3RDO0lBQ0Y7SUFBQztJQUNETixPQUFBLENBQUFELEtBQUEsR0FBQUEsS0FBSyxHQUFHQSxLQUFLLENBQUNXLE1BQU0sQ0FBRUMsSUFBZSxJQUFLQSxJQUFJLENBQUNDLE9BQU8sR0FBR0wsR0FBRyxDQUFDO0lBRTdELEtBQUssTUFBTUwsR0FBRyxJQUFJTyxXQUFXLEVBQUU7TUFDN0IsSUFBSTtRQUNGLE1BQU1QLEdBQUcsQ0FBQ1csR0FBRyxFQUFFO01BQ2pCLENBQUMsQ0FBQyxPQUFPQyxLQUFLLEVBQUU7UUFDZDtNQUNGO01BQUM7SUFDSDtFQUNGLENBQUMsQ0FBQyxPQUFPQSxLQUFLLEVBQUU7SUFDZGQsT0FBQSxDQUFBRCxLQUFBLEdBQUFBLEtBQUssR0FBRyxFQUFFO0lBQ1YsSUFBQUksV0FBRyxFQUFDLDBCQUEwQixFQUFFVyxLQUFLLENBQUNDLE9BQU8sSUFBSUQsS0FBSyxDQUFDO0lBQ3ZELE9BQU9FLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDSCxLQUFLLENBQUM7RUFDOUI7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNJLFdBQVdBLENBQUNDLE9BQU8sRUFBRTtFQUNuQ0MsaUJBQUksQ0FBQ0MsUUFBUSxDQUNYQyxnQ0FBcUIsRUFDckIsWUFBWTtJQUNWLElBQUk7TUFDRixNQUFNakIsa0JBQWtCLEVBQUU7SUFDNUIsQ0FBQyxDQUFDLE9BQU9TLEtBQUssRUFBRTtNQUNkLElBQUFYLFdBQUcsRUFBQyxxQkFBcUIsRUFBRVcsS0FBSyxDQUFDQyxPQUFPLElBQUlELEtBQUssQ0FBQztJQUNwRDtFQUNGLENBQUMsQ0FDRjtBQUNIIn0=