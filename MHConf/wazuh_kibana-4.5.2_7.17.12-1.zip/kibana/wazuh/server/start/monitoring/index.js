"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.jobMonitoringRun = jobMonitoringRun;
var _nodeCron = _interopRequireDefault(require("node-cron"));
var _logger = require("../../lib/logger");
var _monitoringTemplate = require("../../integration-files/monitoring-template");
var _getConfiguration = require("../../lib/get-configuration");
var _parseCron = require("../../lib/parse-cron");
var _indexDate = require("../../lib/index-date");
var _buildIndexSettings = require("../../lib/build-index-settings");
var _wazuhHosts = require("../../controllers/wazuh-hosts");
var _constants = require("../../../common/constants");
var _tryCatchForIndexPermissionError = require("../tryCatchForIndexPermissionError");
var _utils = require("../../../common/utils");
var _settings = require("../../../common/services/settings");
/*
 * Wazuh app - Module for agent info fetching functions
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */

const blueWazuh = '\u001b[34mwazuh\u001b[39m';
const monitoringErrorLogColors = [blueWazuh, 'monitoring', 'error'];
const wazuhHostController = new _wazuhHosts.WazuhHostsCtrl();
let MONITORING_ENABLED, MONITORING_FREQUENCY, MONITORING_CRON_FREQ, MONITORING_CREATION, MONITORING_INDEX_PATTERN, MONITORING_INDEX_PREFIX;

// Utils functions
/**
 * Get the setting value from the configuration
 * @param setting
 * @param configuration
 * @param defaultValue
 */
function getAppConfigurationSetting(setting, configuration, defaultValue) {
  return typeof configuration[setting] !== 'undefined' ? configuration[setting] : defaultValue;
}
;

/**
 * Set the monitoring variables
 * @param context
 */
function initMonitoringConfiguration(context) {
  try {
    const appConfig = (0, _getConfiguration.getConfiguration)();
    MONITORING_ENABLED = appConfig && typeof appConfig['wazuh.monitoring.enabled'] !== 'undefined' ? appConfig['wazuh.monitoring.enabled'] && appConfig['wazuh.monitoring.enabled'] !== 'worker' : (0, _settings.getSettingDefaultValue)('wazuh.monitoring.enabled');
    MONITORING_FREQUENCY = getAppConfigurationSetting('wazuh.monitoring.frequency', appConfig, (0, _settings.getSettingDefaultValue)('wazuh.monitoring.frequency'));
    MONITORING_CRON_FREQ = (0, _parseCron.parseCron)(MONITORING_FREQUENCY);
    MONITORING_CREATION = getAppConfigurationSetting('wazuh.monitoring.creation', appConfig, (0, _settings.getSettingDefaultValue)('wazuh.monitoring.creation'));
    MONITORING_INDEX_PATTERN = getAppConfigurationSetting('wazuh.monitoring.pattern', appConfig, (0, _settings.getSettingDefaultValue)('wazuh.monitoring.pattern'));
    const lastCharIndexPattern = MONITORING_INDEX_PATTERN[MONITORING_INDEX_PATTERN.length - 1];
    if (lastCharIndexPattern !== '*') {
      MONITORING_INDEX_PATTERN += '*';
    }
    ;
    MONITORING_INDEX_PREFIX = MONITORING_INDEX_PATTERN.slice(0, MONITORING_INDEX_PATTERN.length - 1);
    (0, _logger.log)('monitoring:initMonitoringConfiguration', `wazuh.monitoring.enabled: ${MONITORING_ENABLED}`, 'debug');
    (0, _logger.log)('monitoring:initMonitoringConfiguration', `wazuh.monitoring.frequency: ${MONITORING_FREQUENCY} (${MONITORING_CRON_FREQ})`, 'debug');
    (0, _logger.log)('monitoring:initMonitoringConfiguration', `wazuh.monitoring.pattern: ${MONITORING_INDEX_PATTERN} (index prefix: ${MONITORING_INDEX_PREFIX})`, 'debug');
  } catch (error) {
    const errorMessage = error.message || error;
    (0, _logger.log)('monitoring:initMonitoringConfiguration', errorMessage);
    context.wazuh.logger.error(errorMessage);
  }
}
;

/**
 * Main. First execution when installing / loading App.
 * @param context
 */
async function init(context) {
  try {
    if (MONITORING_ENABLED) {
      await checkTemplate(context);
    }
    ;
  } catch (error) {
    const errorMessage = error.message || error;
    (0, _logger.log)('monitoring:init', error.message || error);
    context.wazuh.logger.error(errorMessage);
  }
}

/**
 * Verify wazuh-agent template
 */
async function checkTemplate(context) {
  try {
    (0, _logger.log)('monitoring:checkTemplate', 'Updating the monitoring template', 'debug');
    try {
      // Check if the template already exists
      const currentTemplate = await context.core.elasticsearch.client.asInternalUser.indices.getTemplate({
        name: _constants.WAZUH_MONITORING_TEMPLATE_NAME
      });
      // Copy already created index patterns
      _monitoringTemplate.monitoringTemplate.index_patterns = currentTemplate.body[_constants.WAZUH_MONITORING_TEMPLATE_NAME].index_patterns;
    } catch (error) {
      // Init with the default index pattern
      _monitoringTemplate.monitoringTemplate.index_patterns = [(0, _settings.getSettingDefaultValue)('wazuh.monitoring.pattern')];
    }

    // Check if the user is using a custom pattern and add it to the template if it does
    if (!_monitoringTemplate.monitoringTemplate.index_patterns.includes(MONITORING_INDEX_PATTERN)) {
      _monitoringTemplate.monitoringTemplate.index_patterns.push(MONITORING_INDEX_PATTERN);
    }
    ;

    // Update the monitoring template
    await context.core.elasticsearch.client.asInternalUser.indices.putTemplate({
      name: _constants.WAZUH_MONITORING_TEMPLATE_NAME,
      body: _monitoringTemplate.monitoringTemplate
    });
    (0, _logger.log)('monitoring:checkTemplate', 'Updated the monitoring template', 'debug');
  } catch (error) {
    const errorMessage = `Something went wrong updating the monitoring template ${error.message || error}`;
    (0, _logger.log)('monitoring:checkTemplate', errorMessage);
    context.wazuh.logger.error(monitoringErrorLogColors, errorMessage);
    throw error;
  }
}

/**
 * Save agent status into elasticsearch, create index and/or insert document
 * @param {*} context
 * @param {*} data
 */
async function insertMonitoringDataElasticsearch(context, data) {
  const monitoringIndexName = MONITORING_INDEX_PREFIX + (0, _indexDate.indexDate)(MONITORING_CREATION);
  if (!MONITORING_ENABLED) {
    return;
  }
  ;
  try {
    await (0, _tryCatchForIndexPermissionError.tryCatchForIndexPermissionError)(monitoringIndexName)(async () => {
      const exists = await context.core.elasticsearch.client.asInternalUser.indices.exists({
        index: monitoringIndexName
      });
      if (!exists.body) {
        await createIndex(context, monitoringIndexName);
      }
      ;

      // Update the index configuration
      const appConfig = (0, _getConfiguration.getConfiguration)();
      const indexConfiguration = (0, _buildIndexSettings.buildIndexSettings)(appConfig, 'wazuh.monitoring', (0, _settings.getSettingDefaultValue)('wazuh.monitoring.shards'));

      // To update the index settings with this client is required close the index, update the settings and open it
      // Number of shards is not dynamic so delete that setting if it's given
      delete indexConfiguration.settings.index.number_of_shards;
      await context.core.elasticsearch.client.asInternalUser.indices.putSettings({
        index: monitoringIndexName,
        body: indexConfiguration
      });

      // Insert data to the monitoring index
      await insertDataToIndex(context, monitoringIndexName, data);
    })();
  } catch (error) {
    (0, _logger.log)('monitoring:insertMonitoringDataElasticsearch', error.message || error);
    context.wazuh.logger.error(error.message);
  }
}

/**
 * Inserting one document per agent into Elastic. Bulk.
 * @param {*} context Endpoint
 * @param {String} indexName The name for the index (e.g. daily: wazuh-monitoring-YYYY.MM.DD)
 * @param {*} data
 */
async function insertDataToIndex(context, indexName, data) {
  const {
    agents,
    apiHost
  } = data;
  try {
    if (agents.length > 0) {
      (0, _logger.log)('monitoring:insertDataToIndex', `Bulk data to index ${indexName} for ${agents.length} agents`, 'debug');
      const bodyBulk = agents.map(agent => {
        const agentInfo = {
          ...agent
        };
        agentInfo['timestamp'] = new Date(Date.now()).toISOString();
        agentInfo.host = agent.manager;
        agentInfo.cluster = {
          name: apiHost.clusterName ? apiHost.clusterName : 'disabled'
        };
        return `{ "index":  { "_index": "${indexName}" } }\n${JSON.stringify(agentInfo)}\n`;
      }).join('');
      await context.core.elasticsearch.client.asInternalUser.bulk({
        index: indexName,
        body: bodyBulk
      });
      (0, _logger.log)('monitoring:insertDataToIndex', `Bulk data to index ${indexName} for ${agents.length} agents completed`, 'debug');
    }
  } catch (error) {
    (0, _logger.log)('monitoring:insertDataToIndex', `Error inserting agent data into elasticsearch. Bulk request failed due to ${error.message || error}`);
  }
}

/**
 * Create the wazuh-monitoring index
 * @param {*} context context
 * @param {String} indexName The name for the index (e.g. daily: wazuh-monitoring-YYYY.MM.DD)
 */
async function createIndex(context, indexName) {
  try {
    if (!MONITORING_ENABLED) return;
    const appConfig = (0, _getConfiguration.getConfiguration)();
    const IndexConfiguration = {
      settings: {
        index: {
          number_of_shards: getAppConfigurationSetting('wazuh.monitoring.shards', appConfig, (0, _settings.getSettingDefaultValue)('wazuh.monitoring.shards')),
          number_of_replicas: getAppConfigurationSetting('wazuh.monitoring.replicas', appConfig, (0, _settings.getSettingDefaultValue)('wazuh.monitoring.replicas'))
        }
      }
    };
    await context.core.elasticsearch.client.asInternalUser.indices.create({
      index: indexName,
      body: IndexConfiguration
    });
    (0, _logger.log)('monitoring:createIndex', `Successfully created new index: ${indexName}`, 'debug');
  } catch (error) {
    const errorMessage = `Could not create ${indexName} index on elasticsearch due to ${error.message || error}`;
    (0, _logger.log)('monitoring:createIndex', errorMessage);
    context.wazuh.logger.error(errorMessage);
  }
}

/**
* Wait until Kibana server is ready
*/
async function checkPluginPlatformStatus(context) {
  try {
    (0, _logger.log)('monitoring:checkPluginPlatformStatus', 'Waiting for Kibana and Elasticsearch servers to be ready...', 'debug');
    await checkElasticsearchServer(context);
    await init(context);
    return;
  } catch (error) {
    (0, _logger.log)('monitoring:checkPluginPlatformStatus', error.mesage || error);
    try {
      await (0, _utils.delayAsPromise)(3000);
      await checkPluginPlatformStatus(context);
    } catch (error) {}
    ;
  }
}

/**
 * Check Elasticsearch Server status and Kibana index presence
 */
async function checkElasticsearchServer(context) {
  try {
    const data = await context.core.elasticsearch.client.asInternalUser.indices.exists({
      index: context.server.config.kibana.index
    });
    return data.body;
    // TODO: check if Elasticsearch can receive requests
    // if (data) {
    //   const pluginsData = await this.server.plugins.elasticsearch.waitUntilReady();
    //   return pluginsData;
    // }
    return Promise.reject(data);
  } catch (error) {
    (0, _logger.log)('monitoring:checkElasticsearchServer', error.message || error);
    return Promise.reject(error);
  }
}
const fakeResponseEndpoint = {
  ok: body => body,
  custom: body => body
};
/**
 * Get API configuration from elastic and callback to loadCredentials
 */
async function getHostsConfiguration() {
  try {
    const hosts = await wazuhHostController.getHostsEntries(false, false, fakeResponseEndpoint);
    if (hosts.body.length) {
      return hosts.body;
    }
    ;
    (0, _logger.log)('monitoring:getConfig', 'There are no Wazuh API entries yet', 'debug');
    return Promise.reject({
      error: 'no credentials',
      error_code: 1
    });
  } catch (error) {
    (0, _logger.log)('monitoring:getHostsConfiguration', error.message || error);
    return Promise.reject({
      error: 'no wazuh hosts',
      error_code: 2
    });
  }
}

/**
   * Task used by the cron job.
   */
async function cronTask(context) {
  try {
    const templateMonitoring = await context.core.elasticsearch.client.asInternalUser.indices.getTemplate({
      name: _constants.WAZUH_MONITORING_TEMPLATE_NAME
    });
    const apiHosts = await getHostsConfiguration();
    const apiHostsUnique = (apiHosts || []).filter((apiHost, index, self) => index === self.findIndex(t => t.user === apiHost.user && t.password === apiHost.password && t.url === apiHost.url && t.port === apiHost.port));
    for (let apiHost of apiHostsUnique) {
      try {
        const {
          agents,
          apiHost: host
        } = await getApiInfo(context, apiHost);
        await insertMonitoringDataElasticsearch(context, {
          agents,
          apiHost: host
        });
      } catch (error) {}
      ;
    }
  } catch (error) {
    // Retry to call itself again if Kibana index is not ready yet
    // try {
    //   if (
    //     this.wzWrapper.buildingKibanaIndex ||
    //     ((error || {}).status === 404 &&
    //       (error || {}).displayName === 'NotFound')
    //   ) {
    //     await delayAsPromise(1000);
    //     return cronTask(context);
    //   }
    // } catch (error) {} //eslint-disable-line

    (0, _logger.log)('monitoring:cronTask', error.message || error);
    context.wazuh.logger.error(error.message || error);
  }
}

/**
 * Get API and agents info
 * @param context
 * @param apiHost
 */
async function getApiInfo(context, apiHost) {
  try {
    (0, _logger.log)('monitoring:getApiInfo', `Getting API info for ${apiHost.id}`, 'debug');
    const responseIsCluster = await context.wazuh.api.client.asInternalUser.request('GET', '/cluster/status', {}, {
      apiHostID: apiHost.id
    });
    const isCluster = (((responseIsCluster || {}).data || {}).data || {}).enabled === 'yes';
    if (isCluster) {
      const responseClusterInfo = await context.wazuh.api.client.asInternalUser.request('GET', `/cluster/local/info`, {}, {
        apiHostID: apiHost.id
      });
      apiHost.clusterName = responseClusterInfo.data.data.affected_items[0].cluster;
    }
    ;
    const agents = await fetchAllAgentsFromApiHost(context, apiHost);
    return {
      agents,
      apiHost
    };
  } catch (error) {
    (0, _logger.log)('monitoring:getApiInfo', error.message || error);
    throw error;
  }
}
;

/**
 * Fetch all agents for the API provided
 * @param context
 * @param apiHost
 */
async function fetchAllAgentsFromApiHost(context, apiHost) {
  let agents = [];
  try {
    (0, _logger.log)('monitoring:fetchAllAgentsFromApiHost', `Getting all agents from ApiID: ${apiHost.id}`, 'debug');
    const responseAgentsCount = await context.wazuh.api.client.asInternalUser.request('GET', '/agents', {
      params: {
        offset: 0,
        limit: 1,
        q: 'id!=000'
      }
    }, {
      apiHostID: apiHost.id
    });
    const agentsCount = responseAgentsCount.data.data.total_affected_items;
    (0, _logger.log)('monitoring:fetchAllAgentsFromApiHost', `ApiID: ${apiHost.id}, Agent count: ${agentsCount}`, 'debug');
    let payload = {
      offset: 0,
      limit: 500,
      q: 'id!=000'
    };
    while (agents.length < agentsCount && payload.offset < agentsCount) {
      try {
        /* 
        TODO: Improve the performance of request with:
          - Reduce the number of requests to the Wazuh API
          - Reduce (if possible) the quantity of data to index by document
         Requirements:
          - Research about the neccesary data to index.
         How to do:
          - Wazuh API request:
            - select the required data to retrieve depending on is required to index (using the `select` query param)
            - increase the limit of results to retrieve (currently, the requests use the recommended value: 500).
              See the allowed values. This depends on the selected data because the response could fail if contains a lot of data
        */
        const responseAgents = await context.wazuh.api.client.asInternalUser.request('GET', `/agents`, {
          params: payload
        }, {
          apiHostID: apiHost.id
        });
        agents = [...agents, ...responseAgents.data.data.affected_items];
        payload.offset += payload.limit;
      } catch (error) {
        (0, _logger.log)('monitoring:fetchAllAgentsFromApiHost', `ApiID: ${apiHost.id}, Error request with offset/limit ${payload.offset}/${payload.limit}: ${error.message || error}`);
      }
    }
    return agents;
  } catch (error) {
    (0, _logger.log)('monitoring:fetchAllAgentsFromApiHost', `ApiID: ${apiHost.id}. Error: ${error.message || error}`);
    throw error;
  }
}
;

/**
 * Start the cron job
 */
async function jobMonitoringRun(context) {
  // Init the monitoring variables
  initMonitoringConfiguration(context);
  // Check Kibana index and if it is prepared, start the initialization of Wazuh App.
  await checkPluginPlatformStatus(context);
  // // Run the cron job only it it's enabled
  if (MONITORING_ENABLED) {
    cronTask(context);
    _nodeCron.default.schedule(MONITORING_CRON_FREQ, () => cronTask(context));
  }
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbm9kZUNyb24iLCJfaW50ZXJvcFJlcXVpcmVEZWZhdWx0IiwicmVxdWlyZSIsIl9sb2dnZXIiLCJfbW9uaXRvcmluZ1RlbXBsYXRlIiwiX2dldENvbmZpZ3VyYXRpb24iLCJfcGFyc2VDcm9uIiwiX2luZGV4RGF0ZSIsIl9idWlsZEluZGV4U2V0dGluZ3MiLCJfd2F6dWhIb3N0cyIsIl9jb25zdGFudHMiLCJfdHJ5Q2F0Y2hGb3JJbmRleFBlcm1pc3Npb25FcnJvciIsIl91dGlscyIsIl9zZXR0aW5ncyIsImJsdWVXYXp1aCIsIm1vbml0b3JpbmdFcnJvckxvZ0NvbG9ycyIsIndhenVoSG9zdENvbnRyb2xsZXIiLCJXYXp1aEhvc3RzQ3RybCIsIk1PTklUT1JJTkdfRU5BQkxFRCIsIk1PTklUT1JJTkdfRlJFUVVFTkNZIiwiTU9OSVRPUklOR19DUk9OX0ZSRVEiLCJNT05JVE9SSU5HX0NSRUFUSU9OIiwiTU9OSVRPUklOR19JTkRFWF9QQVRURVJOIiwiTU9OSVRPUklOR19JTkRFWF9QUkVGSVgiLCJnZXRBcHBDb25maWd1cmF0aW9uU2V0dGluZyIsInNldHRpbmciLCJjb25maWd1cmF0aW9uIiwiZGVmYXVsdFZhbHVlIiwiaW5pdE1vbml0b3JpbmdDb25maWd1cmF0aW9uIiwiY29udGV4dCIsImFwcENvbmZpZyIsImdldENvbmZpZ3VyYXRpb24iLCJnZXRTZXR0aW5nRGVmYXVsdFZhbHVlIiwicGFyc2VDcm9uIiwibGFzdENoYXJJbmRleFBhdHRlcm4iLCJsZW5ndGgiLCJzbGljZSIsImxvZyIsImVycm9yIiwiZXJyb3JNZXNzYWdlIiwibWVzc2FnZSIsIndhenVoIiwibG9nZ2VyIiwiaW5pdCIsImNoZWNrVGVtcGxhdGUiLCJjdXJyZW50VGVtcGxhdGUiLCJjb3JlIiwiZWxhc3RpY3NlYXJjaCIsImNsaWVudCIsImFzSW50ZXJuYWxVc2VyIiwiaW5kaWNlcyIsImdldFRlbXBsYXRlIiwibmFtZSIsIldBWlVIX01PTklUT1JJTkdfVEVNUExBVEVfTkFNRSIsIm1vbml0b3JpbmdUZW1wbGF0ZSIsImluZGV4X3BhdHRlcm5zIiwiYm9keSIsImluY2x1ZGVzIiwicHVzaCIsInB1dFRlbXBsYXRlIiwiaW5zZXJ0TW9uaXRvcmluZ0RhdGFFbGFzdGljc2VhcmNoIiwiZGF0YSIsIm1vbml0b3JpbmdJbmRleE5hbWUiLCJpbmRleERhdGUiLCJ0cnlDYXRjaEZvckluZGV4UGVybWlzc2lvbkVycm9yIiwiZXhpc3RzIiwiaW5kZXgiLCJjcmVhdGVJbmRleCIsImluZGV4Q29uZmlndXJhdGlvbiIsImJ1aWxkSW5kZXhTZXR0aW5ncyIsInNldHRpbmdzIiwibnVtYmVyX29mX3NoYXJkcyIsInB1dFNldHRpbmdzIiwiaW5zZXJ0RGF0YVRvSW5kZXgiLCJpbmRleE5hbWUiLCJhZ2VudHMiLCJhcGlIb3N0IiwiYm9keUJ1bGsiLCJtYXAiLCJhZ2VudCIsImFnZW50SW5mbyIsIkRhdGUiLCJub3ciLCJ0b0lTT1N0cmluZyIsImhvc3QiLCJtYW5hZ2VyIiwiY2x1c3RlciIsImNsdXN0ZXJOYW1lIiwiSlNPTiIsInN0cmluZ2lmeSIsImpvaW4iLCJidWxrIiwiSW5kZXhDb25maWd1cmF0aW9uIiwibnVtYmVyX29mX3JlcGxpY2FzIiwiY3JlYXRlIiwiY2hlY2tQbHVnaW5QbGF0Zm9ybVN0YXR1cyIsImNoZWNrRWxhc3RpY3NlYXJjaFNlcnZlciIsIm1lc2FnZSIsImRlbGF5QXNQcm9taXNlIiwic2VydmVyIiwiY29uZmlnIiwia2liYW5hIiwiUHJvbWlzZSIsInJlamVjdCIsImZha2VSZXNwb25zZUVuZHBvaW50Iiwib2siLCJjdXN0b20iLCJnZXRIb3N0c0NvbmZpZ3VyYXRpb24iLCJob3N0cyIsImdldEhvc3RzRW50cmllcyIsImVycm9yX2NvZGUiLCJjcm9uVGFzayIsInRlbXBsYXRlTW9uaXRvcmluZyIsImFwaUhvc3RzIiwiYXBpSG9zdHNVbmlxdWUiLCJmaWx0ZXIiLCJzZWxmIiwiZmluZEluZGV4IiwidCIsInVzZXIiLCJwYXNzd29yZCIsInVybCIsInBvcnQiLCJnZXRBcGlJbmZvIiwiaWQiLCJyZXNwb25zZUlzQ2x1c3RlciIsImFwaSIsInJlcXVlc3QiLCJhcGlIb3N0SUQiLCJpc0NsdXN0ZXIiLCJlbmFibGVkIiwicmVzcG9uc2VDbHVzdGVySW5mbyIsImFmZmVjdGVkX2l0ZW1zIiwiZmV0Y2hBbGxBZ2VudHNGcm9tQXBpSG9zdCIsInJlc3BvbnNlQWdlbnRzQ291bnQiLCJwYXJhbXMiLCJvZmZzZXQiLCJsaW1pdCIsInEiLCJhZ2VudHNDb3VudCIsInRvdGFsX2FmZmVjdGVkX2l0ZW1zIiwicGF5bG9hZCIsInJlc3BvbnNlQWdlbnRzIiwiam9iTW9uaXRvcmluZ1J1biIsImNyb24iLCJzY2hlZHVsZSJdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBhcHAgLSBNb2R1bGUgZm9yIGFnZW50IGluZm8gZmV0Y2hpbmcgZnVuY3Rpb25zXG4gKiBDb3B5cmlnaHQgKEMpIDIwMTUtMjAyMiBXYXp1aCwgSW5jLlxuICpcbiAqIFRoaXMgcHJvZ3JhbSBpcyBmcmVlIHNvZnR3YXJlOyB5b3UgY2FuIHJlZGlzdHJpYnV0ZSBpdCBhbmQvb3IgbW9kaWZ5XG4gKiBpdCB1bmRlciB0aGUgdGVybXMgb2YgdGhlIEdOVSBHZW5lcmFsIFB1YmxpYyBMaWNlbnNlIGFzIHB1Ymxpc2hlZCBieVxuICogdGhlIEZyZWUgU29mdHdhcmUgRm91bmRhdGlvbjsgZWl0aGVyIHZlcnNpb24gMiBvZiB0aGUgTGljZW5zZSwgb3JcbiAqIChhdCB5b3VyIG9wdGlvbikgYW55IGxhdGVyIHZlcnNpb24uXG4gKlxuICogRmluZCBtb3JlIGluZm9ybWF0aW9uIGFib3V0IHRoaXMgb24gdGhlIExJQ0VOU0UgZmlsZS5cbiAqL1xuaW1wb3J0IGNyb24gZnJvbSAnbm9kZS1jcm9uJztcbmltcG9ydCB7IGxvZyB9IGZyb20gJy4uLy4uL2xpYi9sb2dnZXInO1xuaW1wb3J0IHsgbW9uaXRvcmluZ1RlbXBsYXRlIH0gZnJvbSAnLi4vLi4vaW50ZWdyYXRpb24tZmlsZXMvbW9uaXRvcmluZy10ZW1wbGF0ZSc7XG5pbXBvcnQgeyBnZXRDb25maWd1cmF0aW9uIH0gZnJvbSAnLi4vLi4vbGliL2dldC1jb25maWd1cmF0aW9uJztcbmltcG9ydCB7IHBhcnNlQ3JvbiB9IGZyb20gJy4uLy4uL2xpYi9wYXJzZS1jcm9uJztcbmltcG9ydCB7IGluZGV4RGF0ZSB9IGZyb20gJy4uLy4uL2xpYi9pbmRleC1kYXRlJztcbmltcG9ydCB7IGJ1aWxkSW5kZXhTZXR0aW5ncyB9IGZyb20gJy4uLy4uL2xpYi9idWlsZC1pbmRleC1zZXR0aW5ncyc7XG5pbXBvcnQgeyBXYXp1aEhvc3RzQ3RybCB9IGZyb20gJy4uLy4uL2NvbnRyb2xsZXJzL3dhenVoLWhvc3RzJztcbmltcG9ydCB7IFxuICBXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUUsXG59IGZyb20gJy4uLy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xuaW1wb3J0IHsgdHJ5Q2F0Y2hGb3JJbmRleFBlcm1pc3Npb25FcnJvciB9IGZyb20gJy4uL3RyeUNhdGNoRm9ySW5kZXhQZXJtaXNzaW9uRXJyb3InO1xuaW1wb3J0IHsgZGVsYXlBc1Byb21pc2UgfSBmcm9tICcuLi8uLi8uLi9jb21tb24vdXRpbHMnO1xuaW1wb3J0IHsgZ2V0U2V0dGluZ0RlZmF1bHRWYWx1ZSB9IGZyb20gJy4uLy4uLy4uL2NvbW1vbi9zZXJ2aWNlcy9zZXR0aW5ncyc7XG5cbmNvbnN0IGJsdWVXYXp1aCA9ICdcXHUwMDFiWzM0bXdhenVoXFx1MDAxYlszOW0nO1xuY29uc3QgbW9uaXRvcmluZ0Vycm9yTG9nQ29sb3JzID0gW2JsdWVXYXp1aCwgJ21vbml0b3JpbmcnLCAnZXJyb3InXTtcbmNvbnN0IHdhenVoSG9zdENvbnRyb2xsZXIgPSBuZXcgV2F6dWhIb3N0c0N0cmwoKTtcblxubGV0IE1PTklUT1JJTkdfRU5BQkxFRCwgTU9OSVRPUklOR19GUkVRVUVOQ1ksIE1PTklUT1JJTkdfQ1JPTl9GUkVRLCBNT05JVE9SSU5HX0NSRUFUSU9OLCBNT05JVE9SSU5HX0lOREVYX1BBVFRFUk4sIE1PTklUT1JJTkdfSU5ERVhfUFJFRklYO1xuXG4vLyBVdGlscyBmdW5jdGlvbnNcbi8qKlxuICogR2V0IHRoZSBzZXR0aW5nIHZhbHVlIGZyb20gdGhlIGNvbmZpZ3VyYXRpb25cbiAqIEBwYXJhbSBzZXR0aW5nXG4gKiBAcGFyYW0gY29uZmlndXJhdGlvblxuICogQHBhcmFtIGRlZmF1bHRWYWx1ZVxuICovXG5mdW5jdGlvbiBnZXRBcHBDb25maWd1cmF0aW9uU2V0dGluZyhzZXR0aW5nOiBzdHJpbmcsIGNvbmZpZ3VyYXRpb246IGFueSwgZGVmYXVsdFZhbHVlOiBhbnkpe1xuICByZXR1cm4gdHlwZW9mIGNvbmZpZ3VyYXRpb25bc2V0dGluZ10gIT09ICd1bmRlZmluZWQnID8gY29uZmlndXJhdGlvbltzZXR0aW5nXSA6IGRlZmF1bHRWYWx1ZTtcbn07XG5cbi8qKlxuICogU2V0IHRoZSBtb25pdG9yaW5nIHZhcmlhYmxlc1xuICogQHBhcmFtIGNvbnRleHRcbiAqL1xuZnVuY3Rpb24gaW5pdE1vbml0b3JpbmdDb25maWd1cmF0aW9uKGNvbnRleHQpe1xuICB0cnl7XG4gICAgY29uc3QgYXBwQ29uZmlnID0gZ2V0Q29uZmlndXJhdGlvbigpO1xuICAgIE1PTklUT1JJTkdfRU5BQkxFRCA9IGFwcENvbmZpZyAmJiB0eXBlb2YgYXBwQ29uZmlnWyd3YXp1aC5tb25pdG9yaW5nLmVuYWJsZWQnXSAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgID8gYXBwQ29uZmlnWyd3YXp1aC5tb25pdG9yaW5nLmVuYWJsZWQnXSAmJlxuICAgICAgICBhcHBDb25maWdbJ3dhenVoLm1vbml0b3JpbmcuZW5hYmxlZCddICE9PSAnd29ya2VyJ1xuICAgICAgOiBnZXRTZXR0aW5nRGVmYXVsdFZhbHVlKCd3YXp1aC5tb25pdG9yaW5nLmVuYWJsZWQnKTtcbiAgICBNT05JVE9SSU5HX0ZSRVFVRU5DWSA9IGdldEFwcENvbmZpZ3VyYXRpb25TZXR0aW5nKCd3YXp1aC5tb25pdG9yaW5nLmZyZXF1ZW5jeScsIGFwcENvbmZpZywgZ2V0U2V0dGluZ0RlZmF1bHRWYWx1ZSgnd2F6dWgubW9uaXRvcmluZy5mcmVxdWVuY3knKSk7XG4gICAgTU9OSVRPUklOR19DUk9OX0ZSRVEgPSBwYXJzZUNyb24oTU9OSVRPUklOR19GUkVRVUVOQ1kpO1xuICAgIE1PTklUT1JJTkdfQ1JFQVRJT04gPSBnZXRBcHBDb25maWd1cmF0aW9uU2V0dGluZygnd2F6dWgubW9uaXRvcmluZy5jcmVhdGlvbicsIGFwcENvbmZpZywgZ2V0U2V0dGluZ0RlZmF1bHRWYWx1ZSgnd2F6dWgubW9uaXRvcmluZy5jcmVhdGlvbicpKTtcblxuICAgIE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTiA9IGdldEFwcENvbmZpZ3VyYXRpb25TZXR0aW5nKCd3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm4nLCBhcHBDb25maWcsIGdldFNldHRpbmdEZWZhdWx0VmFsdWUoJ3dhenVoLm1vbml0b3JpbmcucGF0dGVybicpKTtcbiAgICBjb25zdCBsYXN0Q2hhckluZGV4UGF0dGVybiA9IE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTltNT05JVE9SSU5HX0lOREVYX1BBVFRFUk4ubGVuZ3RoIC0gMV07XG4gICAgaWYgKGxhc3RDaGFySW5kZXhQYXR0ZXJuICE9PSAnKicpIHtcbiAgICAgIE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTiArPSAnKic7XG4gICAgfTtcbiAgICBNT05JVE9SSU5HX0lOREVYX1BSRUZJWCA9IE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTi5zbGljZSgwLE1PTklUT1JJTkdfSU5ERVhfUEFUVEVSTi5sZW5ndGggLSAxKTtcblxuICAgIGxvZyhcbiAgICAgICdtb25pdG9yaW5nOmluaXRNb25pdG9yaW5nQ29uZmlndXJhdGlvbicsXG4gICAgICBgd2F6dWgubW9uaXRvcmluZy5lbmFibGVkOiAke01PTklUT1JJTkdfRU5BQkxFRH1gLFxuICAgICAgJ2RlYnVnJ1xuICAgICk7XG5cbiAgICBsb2coXG4gICAgICAnbW9uaXRvcmluZzppbml0TW9uaXRvcmluZ0NvbmZpZ3VyYXRpb24nLFxuICAgICAgYHdhenVoLm1vbml0b3JpbmcuZnJlcXVlbmN5OiAke01PTklUT1JJTkdfRlJFUVVFTkNZfSAoJHtNT05JVE9SSU5HX0NST05fRlJFUX0pYCxcbiAgICAgICdkZWJ1ZydcbiAgICApO1xuXG4gICAgbG9nKFxuICAgICAgJ21vbml0b3Jpbmc6aW5pdE1vbml0b3JpbmdDb25maWd1cmF0aW9uJyxcbiAgICAgIGB3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm46ICR7TU9OSVRPUklOR19JTkRFWF9QQVRURVJOfSAoaW5kZXggcHJlZml4OiAke01PTklUT1JJTkdfSU5ERVhfUFJFRklYfSlgLFxuICAgICAgJ2RlYnVnJ1xuICAgICk7XG4gIH1jYXRjaChlcnJvcil7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gZXJyb3IubWVzc2FnZSB8fCBlcnJvcjtcbiAgICBsb2coXG4gICAgICAnbW9uaXRvcmluZzppbml0TW9uaXRvcmluZ0NvbmZpZ3VyYXRpb24nLFxuICAgICAgZXJyb3JNZXNzYWdlXG4gICAgKTtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvck1lc3NhZ2UpXG4gIH1cbn07XG5cbi8qKlxuICogTWFpbi4gRmlyc3QgZXhlY3V0aW9uIHdoZW4gaW5zdGFsbGluZyAvIGxvYWRpbmcgQXBwLlxuICogQHBhcmFtIGNvbnRleHRcbiAqL1xuYXN5bmMgZnVuY3Rpb24gaW5pdChjb250ZXh0KSB7XG4gIHRyeSB7XG4gICAgaWYgKE1PTklUT1JJTkdfRU5BQkxFRCkge1xuICAgICAgYXdhaXQgY2hlY2tUZW1wbGF0ZShjb250ZXh0KTtcbiAgICB9O1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UgfHwgZXJyb3I7XG4gICAgbG9nKCdtb25pdG9yaW5nOmluaXQnLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvck1lc3NhZ2UpO1xuICB9XG59XG5cbi8qKlxuICogVmVyaWZ5IHdhenVoLWFnZW50IHRlbXBsYXRlXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNoZWNrVGVtcGxhdGUoY29udGV4dCkge1xuICB0cnkge1xuICAgIGxvZyhcbiAgICAgICdtb25pdG9yaW5nOmNoZWNrVGVtcGxhdGUnLFxuICAgICAgJ1VwZGF0aW5nIHRoZSBtb25pdG9yaW5nIHRlbXBsYXRlJyxcbiAgICAgICdkZWJ1ZydcbiAgICApO1xuXG4gICAgdHJ5IHtcbiAgICAgIC8vIENoZWNrIGlmIHRoZSB0ZW1wbGF0ZSBhbHJlYWR5IGV4aXN0c1xuICAgICAgY29uc3QgY3VycmVudFRlbXBsYXRlID0gYXdhaXQgY29udGV4dC5jb3JlLmVsYXN0aWNzZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmluZGljZXMuZ2V0VGVtcGxhdGUoe1xuICAgICAgICBuYW1lOiBXQVpVSF9NT05JVE9SSU5HX1RFTVBMQVRFX05BTUVcbiAgICAgIH0pO1xuICAgICAgLy8gQ29weSBhbHJlYWR5IGNyZWF0ZWQgaW5kZXggcGF0dGVybnNcbiAgICAgIG1vbml0b3JpbmdUZW1wbGF0ZS5pbmRleF9wYXR0ZXJucyA9IGN1cnJlbnRUZW1wbGF0ZS5ib2R5W1dBWlVIX01PTklUT1JJTkdfVEVNUExBVEVfTkFNRV0uaW5kZXhfcGF0dGVybnM7XG4gICAgfWNhdGNoIChlcnJvcikge1xuICAgICAgLy8gSW5pdCB3aXRoIHRoZSBkZWZhdWx0IGluZGV4IHBhdHRlcm5cbiAgICAgIG1vbml0b3JpbmdUZW1wbGF0ZS5pbmRleF9wYXR0ZXJucyA9IFtnZXRTZXR0aW5nRGVmYXVsdFZhbHVlKCd3YXp1aC5tb25pdG9yaW5nLnBhdHRlcm4nKV07XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgaWYgdGhlIHVzZXIgaXMgdXNpbmcgYSBjdXN0b20gcGF0dGVybiBhbmQgYWRkIGl0IHRvIHRoZSB0ZW1wbGF0ZSBpZiBpdCBkb2VzXG4gICAgaWYgKCFtb25pdG9yaW5nVGVtcGxhdGUuaW5kZXhfcGF0dGVybnMuaW5jbHVkZXMoTU9OSVRPUklOR19JTkRFWF9QQVRURVJOKSkge1xuICAgICAgbW9uaXRvcmluZ1RlbXBsYXRlLmluZGV4X3BhdHRlcm5zLnB1c2goTU9OSVRPUklOR19JTkRFWF9QQVRURVJOKTtcbiAgICB9O1xuXG4gICAgLy8gVXBkYXRlIHRoZSBtb25pdG9yaW5nIHRlbXBsYXRlXG4gICAgYXdhaXQgY29udGV4dC5jb3JlLmVsYXN0aWNzZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmluZGljZXMucHV0VGVtcGxhdGUoe1xuICAgICAgbmFtZTogV0FaVUhfTU9OSVRPUklOR19URU1QTEFURV9OQU1FLFxuICAgICAgYm9keTogbW9uaXRvcmluZ1RlbXBsYXRlXG4gICAgfSk7XG4gICAgbG9nKFxuICAgICAgJ21vbml0b3Jpbmc6Y2hlY2tUZW1wbGF0ZScsXG4gICAgICAnVXBkYXRlZCB0aGUgbW9uaXRvcmluZyB0ZW1wbGF0ZScsXG4gICAgICAnZGVidWcnXG4gICAgKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBgU29tZXRoaW5nIHdlbnQgd3JvbmcgdXBkYXRpbmcgdGhlIG1vbml0b3JpbmcgdGVtcGxhdGUgJHtlcnJvci5tZXNzYWdlIHx8IGVycm9yfWA7XG4gICAgbG9nKFxuICAgICAgJ21vbml0b3Jpbmc6Y2hlY2tUZW1wbGF0ZScsXG4gICAgICBlcnJvck1lc3NhZ2VcbiAgICApO1xuICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKG1vbml0b3JpbmdFcnJvckxvZ0NvbG9ycywgZXJyb3JNZXNzYWdlKTtcbiAgICB0aHJvdyBlcnJvcjtcbiAgfVxufVxuXG4vKipcbiAqIFNhdmUgYWdlbnQgc3RhdHVzIGludG8gZWxhc3RpY3NlYXJjaCwgY3JlYXRlIGluZGV4IGFuZC9vciBpbnNlcnQgZG9jdW1lbnRcbiAqIEBwYXJhbSB7Kn0gY29udGV4dFxuICogQHBhcmFtIHsqfSBkYXRhXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGluc2VydE1vbml0b3JpbmdEYXRhRWxhc3RpY3NlYXJjaChjb250ZXh0LCBkYXRhKSB7XG4gIGNvbnN0IG1vbml0b3JpbmdJbmRleE5hbWUgPSBNT05JVE9SSU5HX0lOREVYX1BSRUZJWCArIGluZGV4RGF0ZShNT05JVE9SSU5HX0NSRUFUSU9OKTtcbiAgICBpZiAoIU1PTklUT1JJTkdfRU5BQkxFRCl7XG4gICAgICByZXR1cm47XG4gICAgfTtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdHJ5Q2F0Y2hGb3JJbmRleFBlcm1pc3Npb25FcnJvcihtb25pdG9yaW5nSW5kZXhOYW1lKSAoYXN5bmMoKSA9PiB7XG4gICAgICAgIGNvbnN0IGV4aXN0cyA9IGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5pbmRpY2VzLmV4aXN0cyh7aW5kZXg6IG1vbml0b3JpbmdJbmRleE5hbWV9KTtcbiAgICAgICAgaWYoIWV4aXN0cy5ib2R5KXtcbiAgICAgICAgICBhd2FpdCBjcmVhdGVJbmRleChjb250ZXh0LCBtb25pdG9yaW5nSW5kZXhOYW1lKTtcbiAgICAgICAgfTtcblxuICAgICAgICAvLyBVcGRhdGUgdGhlIGluZGV4IGNvbmZpZ3VyYXRpb25cbiAgICAgICAgY29uc3QgYXBwQ29uZmlnID0gZ2V0Q29uZmlndXJhdGlvbigpO1xuICAgICAgICBjb25zdCBpbmRleENvbmZpZ3VyYXRpb24gPSBidWlsZEluZGV4U2V0dGluZ3MoXG4gICAgICAgICAgYXBwQ29uZmlnLFxuICAgICAgICAgICd3YXp1aC5tb25pdG9yaW5nJyxcbiAgICAgICAgICBnZXRTZXR0aW5nRGVmYXVsdFZhbHVlKCd3YXp1aC5tb25pdG9yaW5nLnNoYXJkcycpXG4gICAgICAgICk7XG5cbiAgICAgICAgLy8gVG8gdXBkYXRlIHRoZSBpbmRleCBzZXR0aW5ncyB3aXRoIHRoaXMgY2xpZW50IGlzIHJlcXVpcmVkIGNsb3NlIHRoZSBpbmRleCwgdXBkYXRlIHRoZSBzZXR0aW5ncyBhbmQgb3BlbiBpdFxuICAgICAgICAvLyBOdW1iZXIgb2Ygc2hhcmRzIGlzIG5vdCBkeW5hbWljIHNvIGRlbGV0ZSB0aGF0IHNldHRpbmcgaWYgaXQncyBnaXZlblxuICAgICAgICBkZWxldGUgaW5kZXhDb25maWd1cmF0aW9uLnNldHRpbmdzLmluZGV4Lm51bWJlcl9vZl9zaGFyZHM7XG4gICAgICAgIGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5pbmRpY2VzLnB1dFNldHRpbmdzKHtcbiAgICAgICAgICBpbmRleDogbW9uaXRvcmluZ0luZGV4TmFtZSxcbiAgICAgICAgICBib2R5OiBpbmRleENvbmZpZ3VyYXRpb25cbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gSW5zZXJ0IGRhdGEgdG8gdGhlIG1vbml0b3JpbmcgaW5kZXhcbiAgICAgICAgYXdhaXQgaW5zZXJ0RGF0YVRvSW5kZXgoY29udGV4dCwgbW9uaXRvcmluZ0luZGV4TmFtZSwgZGF0YSk7XG4gICAgICB9KSgpO1xuICAgIH1jYXRjaChlcnJvcil7XG4gICAgICBsb2coJ21vbml0b3Jpbmc6aW5zZXJ0TW9uaXRvcmluZ0RhdGFFbGFzdGljc2VhcmNoJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgICBjb250ZXh0LndhenVoLmxvZ2dlci5lcnJvcihlcnJvci5tZXNzYWdlKTtcbiAgICB9XG59XG5cbi8qKlxuICogSW5zZXJ0aW5nIG9uZSBkb2N1bWVudCBwZXIgYWdlbnQgaW50byBFbGFzdGljLiBCdWxrLlxuICogQHBhcmFtIHsqfSBjb250ZXh0IEVuZHBvaW50XG4gKiBAcGFyYW0ge1N0cmluZ30gaW5kZXhOYW1lIFRoZSBuYW1lIGZvciB0aGUgaW5kZXggKGUuZy4gZGFpbHk6IHdhenVoLW1vbml0b3JpbmctWVlZWS5NTS5ERClcbiAqIEBwYXJhbSB7Kn0gZGF0YVxuICovXG5hc3luYyBmdW5jdGlvbiBpbnNlcnREYXRhVG9JbmRleChjb250ZXh0LCBpbmRleE5hbWU6IHN0cmluZywgZGF0YToge2FnZW50czogYW55W10sIGFwaUhvc3R9KSB7XG4gIGNvbnN0IHsgYWdlbnRzLCBhcGlIb3N0IH0gPSBkYXRhO1xuICB0cnkge1xuICAgIGlmIChhZ2VudHMubGVuZ3RoID4gMCkge1xuICAgICAgbG9nKFxuICAgICAgICAnbW9uaXRvcmluZzppbnNlcnREYXRhVG9JbmRleCcsXG4gICAgICAgIGBCdWxrIGRhdGEgdG8gaW5kZXggJHtpbmRleE5hbWV9IGZvciAke2FnZW50cy5sZW5ndGh9IGFnZW50c2AsXG4gICAgICAgICdkZWJ1ZydcbiAgICAgICk7XG5cbiAgICAgIGNvbnN0IGJvZHlCdWxrID0gYWdlbnRzLm1hcChhZ2VudCA9PiB7XG4gICAgICAgIGNvbnN0IGFnZW50SW5mbyA9IHsuLi5hZ2VudH07XG4gICAgICAgIGFnZW50SW5mb1sndGltZXN0YW1wJ10gPSBuZXcgRGF0ZShEYXRlLm5vdygpKS50b0lTT1N0cmluZygpO1xuICAgICAgICBhZ2VudEluZm8uaG9zdCA9IGFnZW50Lm1hbmFnZXI7XG4gICAgICAgIGFnZW50SW5mby5jbHVzdGVyID0geyBuYW1lOiBhcGlIb3N0LmNsdXN0ZXJOYW1lID8gYXBpSG9zdC5jbHVzdGVyTmFtZSA6ICdkaXNhYmxlZCcgfTtcbiAgICAgICAgcmV0dXJuIGB7IFwiaW5kZXhcIjogIHsgXCJfaW5kZXhcIjogXCIke2luZGV4TmFtZX1cIiB9IH1cXG4ke0pTT04uc3RyaW5naWZ5KGFnZW50SW5mbyl9XFxuYDtcbiAgICAgIH0pLmpvaW4oJycpO1xuXG4gICAgICBhd2FpdCBjb250ZXh0LmNvcmUuZWxhc3RpY3NlYXJjaC5jbGllbnQuYXNJbnRlcm5hbFVzZXIuYnVsayh7XG4gICAgICAgIGluZGV4OiBpbmRleE5hbWUsXG4gICAgICAgIGJvZHk6IGJvZHlCdWxrXG4gICAgICB9KTtcbiAgICAgIGxvZyhcbiAgICAgICAgJ21vbml0b3Jpbmc6aW5zZXJ0RGF0YVRvSW5kZXgnLFxuICAgICAgICBgQnVsayBkYXRhIHRvIGluZGV4ICR7aW5kZXhOYW1lfSBmb3IgJHthZ2VudHMubGVuZ3RofSBhZ2VudHMgY29tcGxldGVkYCxcbiAgICAgICAgJ2RlYnVnJ1xuICAgICAgKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgbG9nKFxuICAgICAgJ21vbml0b3Jpbmc6aW5zZXJ0RGF0YVRvSW5kZXgnLFxuICAgICAgYEVycm9yIGluc2VydGluZyBhZ2VudCBkYXRhIGludG8gZWxhc3RpY3NlYXJjaC4gQnVsayByZXF1ZXN0IGZhaWxlZCBkdWUgdG8gJHtlcnJvci5tZXNzYWdlIHx8XG4gICAgICAgIGVycm9yfWBcbiAgICApO1xuICB9XG59XG5cbi8qKlxuICogQ3JlYXRlIHRoZSB3YXp1aC1tb25pdG9yaW5nIGluZGV4XG4gKiBAcGFyYW0geyp9IGNvbnRleHQgY29udGV4dFxuICogQHBhcmFtIHtTdHJpbmd9IGluZGV4TmFtZSBUaGUgbmFtZSBmb3IgdGhlIGluZGV4IChlLmcuIGRhaWx5OiB3YXp1aC1tb25pdG9yaW5nLVlZWVkuTU0uREQpXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZUluZGV4KGNvbnRleHQsIGluZGV4TmFtZTogc3RyaW5nKSB7XG4gIHRyeSB7XG4gICAgaWYgKCFNT05JVE9SSU5HX0VOQUJMRUQpIHJldHVybjtcbiAgICBjb25zdCBhcHBDb25maWcgPSBnZXRDb25maWd1cmF0aW9uKCk7XG5cbiAgICBjb25zdCBJbmRleENvbmZpZ3VyYXRpb24gPSB7XG4gICAgICBzZXR0aW5nczoge1xuICAgICAgICBpbmRleDoge1xuICAgICAgICAgIG51bWJlcl9vZl9zaGFyZHM6IGdldEFwcENvbmZpZ3VyYXRpb25TZXR0aW5nKCd3YXp1aC5tb25pdG9yaW5nLnNoYXJkcycsIGFwcENvbmZpZywgZ2V0U2V0dGluZ0RlZmF1bHRWYWx1ZSgnd2F6dWgubW9uaXRvcmluZy5zaGFyZHMnKSksXG4gICAgICAgICAgbnVtYmVyX29mX3JlcGxpY2FzOiBnZXRBcHBDb25maWd1cmF0aW9uU2V0dGluZygnd2F6dWgubW9uaXRvcmluZy5yZXBsaWNhcycsIGFwcENvbmZpZywgZ2V0U2V0dGluZ0RlZmF1bHRWYWx1ZSgnd2F6dWgubW9uaXRvcmluZy5yZXBsaWNhcycpKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcblxuICAgIGF3YWl0IGNvbnRleHQuY29yZS5lbGFzdGljc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlci5pbmRpY2VzLmNyZWF0ZSh7XG4gICAgICBpbmRleDogaW5kZXhOYW1lLFxuICAgICAgYm9keTogSW5kZXhDb25maWd1cmF0aW9uXG4gICAgfSk7XG5cbiAgICBsb2coXG4gICAgICAnbW9uaXRvcmluZzpjcmVhdGVJbmRleCcsXG4gICAgICBgU3VjY2Vzc2Z1bGx5IGNyZWF0ZWQgbmV3IGluZGV4OiAke2luZGV4TmFtZX1gLFxuICAgICAgJ2RlYnVnJ1xuICAgICk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID0gYENvdWxkIG5vdCBjcmVhdGUgJHtpbmRleE5hbWV9IGluZGV4IG9uIGVsYXN0aWNzZWFyY2ggZHVlIHRvICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gO1xuICAgIGxvZyhcbiAgICAgICdtb25pdG9yaW5nOmNyZWF0ZUluZGV4JyxcbiAgICAgIGVycm9yTWVzc2FnZVxuICAgICk7XG4gICAgY29udGV4dC53YXp1aC5sb2dnZXIuZXJyb3IoZXJyb3JNZXNzYWdlKTtcbiAgfVxufVxuXG4vKipcbiogV2FpdCB1bnRpbCBLaWJhbmEgc2VydmVyIGlzIHJlYWR5XG4qL1xuYXN5bmMgZnVuY3Rpb24gY2hlY2tQbHVnaW5QbGF0Zm9ybVN0YXR1cyhjb250ZXh0KSB7XG4gdHJ5IHtcbiAgICBsb2coXG4gICAgICAnbW9uaXRvcmluZzpjaGVja1BsdWdpblBsYXRmb3JtU3RhdHVzJyxcbiAgICAgICdXYWl0aW5nIGZvciBLaWJhbmEgYW5kIEVsYXN0aWNzZWFyY2ggc2VydmVycyB0byBiZSByZWFkeS4uLicsXG4gICAgICAnZGVidWcnXG4gICAgKTtcblxuICAgYXdhaXQgY2hlY2tFbGFzdGljc2VhcmNoU2VydmVyKGNvbnRleHQpO1xuICAgYXdhaXQgaW5pdChjb250ZXh0KTtcbiAgIHJldHVybjtcbiB9IGNhdGNoIChlcnJvcikge1xuICAgIGxvZyhcbiAgICAgICdtb25pdG9yaW5nOmNoZWNrUGx1Z2luUGxhdGZvcm1TdGF0dXMnLFxuICAgICAgZXJyb3IubWVzYWdlIHx8ZXJyb3JcbiAgICApO1xuICAgIHRyeXtcbiAgICAgIGF3YWl0IGRlbGF5QXNQcm9taXNlKDMwMDApO1xuICAgICAgYXdhaXQgY2hlY2tQbHVnaW5QbGF0Zm9ybVN0YXR1cyhjb250ZXh0KTtcbiAgICB9Y2F0Y2goZXJyb3Ipe307XG4gfVxufVxuXG5cbi8qKlxuICogQ2hlY2sgRWxhc3RpY3NlYXJjaCBTZXJ2ZXIgc3RhdHVzIGFuZCBLaWJhbmEgaW5kZXggcHJlc2VuY2VcbiAqL1xuYXN5bmMgZnVuY3Rpb24gY2hlY2tFbGFzdGljc2VhcmNoU2VydmVyKGNvbnRleHQpIHtcbiAgdHJ5IHtcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgY29udGV4dC5jb3JlLmVsYXN0aWNzZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyLmluZGljZXMuZXhpc3RzKHtcbiAgICAgIGluZGV4OiBjb250ZXh0LnNlcnZlci5jb25maWcua2liYW5hLmluZGV4XG4gICAgfSk7XG5cbiAgICByZXR1cm4gZGF0YS5ib2R5O1xuICAgIC8vIFRPRE86IGNoZWNrIGlmIEVsYXN0aWNzZWFyY2ggY2FuIHJlY2VpdmUgcmVxdWVzdHNcbiAgICAvLyBpZiAoZGF0YSkge1xuICAgIC8vICAgY29uc3QgcGx1Z2luc0RhdGEgPSBhd2FpdCB0aGlzLnNlcnZlci5wbHVnaW5zLmVsYXN0aWNzZWFyY2gud2FpdFVudGlsUmVhZHkoKTtcbiAgICAvLyAgIHJldHVybiBwbHVnaW5zRGF0YTtcbiAgICAvLyB9XG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGRhdGEpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGxvZygnbW9uaXRvcmluZzpjaGVja0VsYXN0aWNzZWFyY2hTZXJ2ZXInLCBlcnJvci5tZXNzYWdlIHx8IGVycm9yKTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICB9XG59XG5cbmNvbnN0IGZha2VSZXNwb25zZUVuZHBvaW50ID0ge1xuICBvazogKGJvZHk6IGFueSkgPT4gYm9keSxcbiAgY3VzdG9tOiAoYm9keTogYW55KSA9PiBib2R5LFxufVxuLyoqXG4gKiBHZXQgQVBJIGNvbmZpZ3VyYXRpb24gZnJvbSBlbGFzdGljIGFuZCBjYWxsYmFjayB0byBsb2FkQ3JlZGVudGlhbHNcbiAqL1xuYXN5bmMgZnVuY3Rpb24gZ2V0SG9zdHNDb25maWd1cmF0aW9uKCkge1xuICB0cnkge1xuICAgIGNvbnN0IGhvc3RzID0gYXdhaXQgd2F6dWhIb3N0Q29udHJvbGxlci5nZXRIb3N0c0VudHJpZXMoZmFsc2UsIGZhbHNlLCBmYWtlUmVzcG9uc2VFbmRwb2ludCk7XG4gICAgaWYgKGhvc3RzLmJvZHkubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gaG9zdHMuYm9keTtcbiAgICB9O1xuXG4gICAgbG9nKFxuICAgICAgJ21vbml0b3Jpbmc6Z2V0Q29uZmlnJyxcbiAgICAgICdUaGVyZSBhcmUgbm8gV2F6dWggQVBJIGVudHJpZXMgeWV0JyxcbiAgICAgICdkZWJ1ZydcbiAgICApO1xuICAgIHJldHVybiBQcm9taXNlLnJlamVjdCh7XG4gICAgICBlcnJvcjogJ25vIGNyZWRlbnRpYWxzJyxcbiAgICAgIGVycm9yX2NvZGU6IDFcbiAgICB9KTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBsb2coJ21vbml0b3Jpbmc6Z2V0SG9zdHNDb25maWd1cmF0aW9uJywgZXJyb3IubWVzc2FnZSB8fCBlcnJvcik7XG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KHtcbiAgICAgIGVycm9yOiAnbm8gd2F6dWggaG9zdHMnLFxuICAgICAgZXJyb3JfY29kZTogMlxuICAgIH0pO1xuICB9XG59XG5cbi8qKlxuICAgKiBUYXNrIHVzZWQgYnkgdGhlIGNyb24gam9iLlxuICAgKi9cbmFzeW5jIGZ1bmN0aW9uIGNyb25UYXNrKGNvbnRleHQpIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB0ZW1wbGF0ZU1vbml0b3JpbmcgPSBhd2FpdCBjb250ZXh0LmNvcmUuZWxhc3RpY3NlYXJjaC5jbGllbnQuYXNJbnRlcm5hbFVzZXIuaW5kaWNlcy5nZXRUZW1wbGF0ZSh7bmFtZTogV0FaVUhfTU9OSVRPUklOR19URU1QTEFURV9OQU1FfSk7XG5cbiAgICBjb25zdCBhcGlIb3N0cyA9IGF3YWl0IGdldEhvc3RzQ29uZmlndXJhdGlvbigpO1xuICAgIGNvbnN0IGFwaUhvc3RzVW5pcXVlID0gKGFwaUhvc3RzIHx8IFtdKS5maWx0ZXIoXG4gICAgICAoYXBpSG9zdCwgaW5kZXgsIHNlbGYpID0+XG4gICAgICAgIGluZGV4ID09PVxuICAgICAgICBzZWxmLmZpbmRJbmRleChcbiAgICAgICAgICB0ID0+XG4gICAgICAgICAgICB0LnVzZXIgPT09IGFwaUhvc3QudXNlciAmJlxuICAgICAgICAgICAgdC5wYXNzd29yZCA9PT0gYXBpSG9zdC5wYXNzd29yZCAmJlxuICAgICAgICAgICAgdC51cmwgPT09IGFwaUhvc3QudXJsICYmXG4gICAgICAgICAgICB0LnBvcnQgPT09IGFwaUhvc3QucG9ydFxuICAgICAgICApXG4gICAgKTtcbiAgICBmb3IobGV0IGFwaUhvc3Qgb2YgYXBpSG9zdHNVbmlxdWUpe1xuICAgICAgdHJ5e1xuICAgICAgICBjb25zdCB7IGFnZW50cywgYXBpSG9zdDogaG9zdH0gPSBhd2FpdCBnZXRBcGlJbmZvKGNvbnRleHQsIGFwaUhvc3QpO1xuICAgICAgICBhd2FpdCBpbnNlcnRNb25pdG9yaW5nRGF0YUVsYXN0aWNzZWFyY2goY29udGV4dCwge2FnZW50cywgYXBpSG9zdDogaG9zdH0pO1xuICAgICAgfWNhdGNoKGVycm9yKXtcblxuICAgICAgfTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgLy8gUmV0cnkgdG8gY2FsbCBpdHNlbGYgYWdhaW4gaWYgS2liYW5hIGluZGV4IGlzIG5vdCByZWFkeSB5ZXRcbiAgICAvLyB0cnkge1xuICAgIC8vICAgaWYgKFxuICAgIC8vICAgICB0aGlzLnd6V3JhcHBlci5idWlsZGluZ0tpYmFuYUluZGV4IHx8XG4gICAgLy8gICAgICgoZXJyb3IgfHwge30pLnN0YXR1cyA9PT0gNDA0ICYmXG4gICAgLy8gICAgICAgKGVycm9yIHx8IHt9KS5kaXNwbGF5TmFtZSA9PT0gJ05vdEZvdW5kJylcbiAgICAvLyAgICkge1xuICAgIC8vICAgICBhd2FpdCBkZWxheUFzUHJvbWlzZSgxMDAwKTtcbiAgICAvLyAgICAgcmV0dXJuIGNyb25UYXNrKGNvbnRleHQpO1xuICAgIC8vICAgfVxuICAgIC8vIH0gY2F0Y2ggKGVycm9yKSB7fSAvL2VzbGludC1kaXNhYmxlLWxpbmVcblxuICAgIGxvZygnbW9uaXRvcmluZzpjcm9uVGFzaycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgIGNvbnRleHQud2F6dWgubG9nZ2VyLmVycm9yKGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICB9XG59XG5cbi8qKlxuICogR2V0IEFQSSBhbmQgYWdlbnRzIGluZm9cbiAqIEBwYXJhbSBjb250ZXh0XG4gKiBAcGFyYW0gYXBpSG9zdFxuICovXG5hc3luYyBmdW5jdGlvbiBnZXRBcGlJbmZvKGNvbnRleHQsIGFwaUhvc3Qpe1xuICB0cnl7XG4gICAgbG9nKCdtb25pdG9yaW5nOmdldEFwaUluZm8nLCBgR2V0dGluZyBBUEkgaW5mbyBmb3IgJHthcGlIb3N0LmlkfWAsICdkZWJ1ZycpO1xuICAgIGNvbnN0IHJlc3BvbnNlSXNDbHVzdGVyID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoJ0dFVCcsICcvY2x1c3Rlci9zdGF0dXMnLCB7fSwgeyBhcGlIb3N0SUQ6IGFwaUhvc3QuaWQgfSk7XG4gICAgY29uc3QgaXNDbHVzdGVyID0gKCgocmVzcG9uc2VJc0NsdXN0ZXIgfHwge30pLmRhdGEgfHwge30pLmRhdGEgfHwge30pLmVuYWJsZWQgPT09ICd5ZXMnO1xuICAgIGlmKGlzQ2x1c3Rlcil7XG4gICAgICBjb25zdCByZXNwb25zZUNsdXN0ZXJJbmZvID0gYXdhaXQgY29udGV4dC53YXp1aC5hcGkuY2xpZW50LmFzSW50ZXJuYWxVc2VyLnJlcXVlc3QoJ0dFVCcsIGAvY2x1c3Rlci9sb2NhbC9pbmZvYCwge30sICB7IGFwaUhvc3RJRDogYXBpSG9zdC5pZCB9KTtcbiAgICAgIGFwaUhvc3QuY2x1c3Rlck5hbWUgPSByZXNwb25zZUNsdXN0ZXJJbmZvLmRhdGEuZGF0YS5hZmZlY3RlZF9pdGVtc1swXS5jbHVzdGVyO1xuICAgIH07XG4gICAgY29uc3QgYWdlbnRzID0gYXdhaXQgZmV0Y2hBbGxBZ2VudHNGcm9tQXBpSG9zdChjb250ZXh0LCBhcGlIb3N0KTtcbiAgICByZXR1cm4geyBhZ2VudHMsIGFwaUhvc3QgfTtcbiAgfWNhdGNoKGVycm9yKXtcbiAgICBsb2coJ21vbml0b3Jpbmc6Z2V0QXBpSW5mbycsIGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IpO1xuICAgIHRocm93IGVycm9yO1xuICB9XG59O1xuXG4vKipcbiAqIEZldGNoIGFsbCBhZ2VudHMgZm9yIHRoZSBBUEkgcHJvdmlkZWRcbiAqIEBwYXJhbSBjb250ZXh0XG4gKiBAcGFyYW0gYXBpSG9zdFxuICovXG5hc3luYyBmdW5jdGlvbiBmZXRjaEFsbEFnZW50c0Zyb21BcGlIb3N0KGNvbnRleHQsIGFwaUhvc3Qpe1xuICBsZXQgYWdlbnRzID0gW107XG4gIHRyeXtcbiAgICBsb2coJ21vbml0b3Jpbmc6ZmV0Y2hBbGxBZ2VudHNGcm9tQXBpSG9zdCcsIGBHZXR0aW5nIGFsbCBhZ2VudHMgZnJvbSBBcGlJRDogJHthcGlIb3N0LmlkfWAsICdkZWJ1ZycpO1xuICAgIGNvbnN0IHJlc3BvbnNlQWdlbnRzQ291bnQgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcbiAgICAgICdHRVQnLFxuICAgICAgJy9hZ2VudHMnLFxuICAgICAge1xuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBvZmZzZXQ6IDAsXG4gICAgICAgICAgbGltaXQ6IDEsXG4gICAgICAgICAgcTogJ2lkIT0wMDAnXG4gICAgICAgIH1cbiAgICAgIH0sIHthcGlIb3N0SUQ6IGFwaUhvc3QuaWR9KTtcblxuICAgIGNvbnN0IGFnZW50c0NvdW50ID0gcmVzcG9uc2VBZ2VudHNDb3VudC5kYXRhLmRhdGEudG90YWxfYWZmZWN0ZWRfaXRlbXM7XG4gICAgbG9nKCdtb25pdG9yaW5nOmZldGNoQWxsQWdlbnRzRnJvbUFwaUhvc3QnLCBgQXBpSUQ6ICR7YXBpSG9zdC5pZH0sIEFnZW50IGNvdW50OiAke2FnZW50c0NvdW50fWAsICdkZWJ1ZycpO1xuXG4gICAgbGV0IHBheWxvYWQgPSB7XG4gICAgICBvZmZzZXQ6IDAsXG4gICAgICBsaW1pdDogNTAwLFxuICAgICAgcTogJ2lkIT0wMDAnXG4gICAgfTtcblxuICAgIHdoaWxlIChhZ2VudHMubGVuZ3RoIDwgYWdlbnRzQ291bnQgJiYgcGF5bG9hZC5vZmZzZXQgPCBhZ2VudHNDb3VudCkge1xuICAgICAgdHJ5e1xuICAgICAgICAvKiBcbiAgICAgICAgVE9ETzogSW1wcm92ZSB0aGUgcGVyZm9ybWFuY2Ugb2YgcmVxdWVzdCB3aXRoOlxuICAgICAgICAgIC0gUmVkdWNlIHRoZSBudW1iZXIgb2YgcmVxdWVzdHMgdG8gdGhlIFdhenVoIEFQSVxuICAgICAgICAgIC0gUmVkdWNlIChpZiBwb3NzaWJsZSkgdGhlIHF1YW50aXR5IG9mIGRhdGEgdG8gaW5kZXggYnkgZG9jdW1lbnRcblxuICAgICAgICBSZXF1aXJlbWVudHM6XG4gICAgICAgICAgLSBSZXNlYXJjaCBhYm91dCB0aGUgbmVjY2VzYXJ5IGRhdGEgdG8gaW5kZXguXG5cbiAgICAgICAgSG93IHRvIGRvOlxuICAgICAgICAgIC0gV2F6dWggQVBJIHJlcXVlc3Q6XG4gICAgICAgICAgICAtIHNlbGVjdCB0aGUgcmVxdWlyZWQgZGF0YSB0byByZXRyaWV2ZSBkZXBlbmRpbmcgb24gaXMgcmVxdWlyZWQgdG8gaW5kZXggKHVzaW5nIHRoZSBgc2VsZWN0YCBxdWVyeSBwYXJhbSlcbiAgICAgICAgICAgIC0gaW5jcmVhc2UgdGhlIGxpbWl0IG9mIHJlc3VsdHMgdG8gcmV0cmlldmUgKGN1cnJlbnRseSwgdGhlIHJlcXVlc3RzIHVzZSB0aGUgcmVjb21tZW5kZWQgdmFsdWU6IDUwMCkuXG4gICAgICAgICAgICAgIFNlZSB0aGUgYWxsb3dlZCB2YWx1ZXMuIFRoaXMgZGVwZW5kcyBvbiB0aGUgc2VsZWN0ZWQgZGF0YSBiZWNhdXNlIHRoZSByZXNwb25zZSBjb3VsZCBmYWlsIGlmIGNvbnRhaW5zIGEgbG90IG9mIGRhdGFcbiAgICAgICAgKi9cbiAgICAgICAgY29uc3QgcmVzcG9uc2VBZ2VudHMgPSBhd2FpdCBjb250ZXh0LndhenVoLmFwaS5jbGllbnQuYXNJbnRlcm5hbFVzZXIucmVxdWVzdChcbiAgICAgICAgICAnR0VUJyxcbiAgICAgICAgICBgL2FnZW50c2AsXG4gICAgICAgICAge3BhcmFtczogcGF5bG9hZH0sXG4gICAgICAgICAge2FwaUhvc3RJRDogYXBpSG9zdC5pZH1cbiAgICAgICAgKTtcbiAgICAgICAgYWdlbnRzID0gWy4uLmFnZW50cywgLi4ucmVzcG9uc2VBZ2VudHMuZGF0YS5kYXRhLmFmZmVjdGVkX2l0ZW1zXTtcbiAgICAgICAgcGF5bG9hZC5vZmZzZXQgKz0gcGF5bG9hZC5saW1pdDtcbiAgICAgIH1jYXRjaChlcnJvcil7XG4gICAgICAgIGxvZygnbW9uaXRvcmluZzpmZXRjaEFsbEFnZW50c0Zyb21BcGlIb3N0JywgYEFwaUlEOiAke2FwaUhvc3QuaWR9LCBFcnJvciByZXF1ZXN0IHdpdGggb2Zmc2V0L2xpbWl0ICR7cGF5bG9hZC5vZmZzZXR9LyR7cGF5bG9hZC5saW1pdH06ICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGFnZW50cztcbiAgfWNhdGNoKGVycm9yKXtcbiAgICBsb2coJ21vbml0b3Jpbmc6ZmV0Y2hBbGxBZ2VudHNGcm9tQXBpSG9zdCcsIGBBcGlJRDogJHthcGlIb3N0LmlkfS4gRXJyb3I6ICR7ZXJyb3IubWVzc2FnZSB8fCBlcnJvcn1gKTtcbiAgICB0aHJvdyBlcnJvcjtcbiAgfVxufTtcblxuLyoqXG4gKiBTdGFydCB0aGUgY3JvbiBqb2JcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGpvYk1vbml0b3JpbmdSdW4oY29udGV4dCkge1xuICAvLyBJbml0IHRoZSBtb25pdG9yaW5nIHZhcmlhYmxlc1xuICBpbml0TW9uaXRvcmluZ0NvbmZpZ3VyYXRpb24oY29udGV4dCk7XG4gIC8vIENoZWNrIEtpYmFuYSBpbmRleCBhbmQgaWYgaXQgaXMgcHJlcGFyZWQsIHN0YXJ0IHRoZSBpbml0aWFsaXphdGlvbiBvZiBXYXp1aCBBcHAuXG4gIGF3YWl0IGNoZWNrUGx1Z2luUGxhdGZvcm1TdGF0dXMoY29udGV4dCk7XG4gIC8vIC8vIFJ1biB0aGUgY3JvbiBqb2Igb25seSBpdCBpdCdzIGVuYWJsZWRcbiAgaWYgKE1PTklUT1JJTkdfRU5BQkxFRCkge1xuICAgIGNyb25UYXNrKGNvbnRleHQpO1xuICAgIGNyb24uc2NoZWR1bGUoTU9OSVRPUklOR19DUk9OX0ZSRVEsICgpID0+IGNyb25UYXNrKGNvbnRleHQpKTtcbiAgfVxufVxuXG4iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFXQSxJQUFBQSxTQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBQyxPQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxtQkFBQSxHQUFBRixPQUFBO0FBQ0EsSUFBQUcsaUJBQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLFVBQUEsR0FBQUosT0FBQTtBQUNBLElBQUFLLFVBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLG1CQUFBLEdBQUFOLE9BQUE7QUFDQSxJQUFBTyxXQUFBLEdBQUFQLE9BQUE7QUFDQSxJQUFBUSxVQUFBLEdBQUFSLE9BQUE7QUFHQSxJQUFBUyxnQ0FBQSxHQUFBVCxPQUFBO0FBQ0EsSUFBQVUsTUFBQSxHQUFBVixPQUFBO0FBQ0EsSUFBQVcsU0FBQSxHQUFBWCxPQUFBO0FBeEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBZ0JBLE1BQU1ZLFNBQVMsR0FBRywyQkFBMkI7QUFDN0MsTUFBTUMsd0JBQXdCLEdBQUcsQ0FBQ0QsU0FBUyxFQUFFLFlBQVksRUFBRSxPQUFPLENBQUM7QUFDbkUsTUFBTUUsbUJBQW1CLEdBQUcsSUFBSUMsMEJBQWMsRUFBRTtBQUVoRCxJQUFJQyxrQkFBa0IsRUFBRUMsb0JBQW9CLEVBQUVDLG9CQUFvQixFQUFFQyxtQkFBbUIsRUFBRUMsd0JBQXdCLEVBQUVDLHVCQUF1Qjs7QUFFMUk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQywwQkFBMEJBLENBQUNDLE9BQWUsRUFBRUMsYUFBa0IsRUFBRUMsWUFBaUIsRUFBQztFQUN6RixPQUFPLE9BQU9ELGFBQWEsQ0FBQ0QsT0FBTyxDQUFDLEtBQUssV0FBVyxHQUFHQyxhQUFhLENBQUNELE9BQU8sQ0FBQyxHQUFHRSxZQUFZO0FBQzlGO0FBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQywyQkFBMkJBLENBQUNDLE9BQU8sRUFBQztFQUMzQyxJQUFHO0lBQ0QsTUFBTUMsU0FBUyxHQUFHLElBQUFDLGtDQUFnQixHQUFFO0lBQ3BDYixrQkFBa0IsR0FBR1ksU0FBUyxJQUFJLE9BQU9BLFNBQVMsQ0FBQywwQkFBMEIsQ0FBQyxLQUFLLFdBQVcsR0FDMUZBLFNBQVMsQ0FBQywwQkFBMEIsQ0FBQyxJQUNyQ0EsU0FBUyxDQUFDLDBCQUEwQixDQUFDLEtBQUssUUFBUSxHQUNsRCxJQUFBRSxnQ0FBc0IsRUFBQywwQkFBMEIsQ0FBQztJQUN0RGIsb0JBQW9CLEdBQUdLLDBCQUEwQixDQUFDLDRCQUE0QixFQUFFTSxTQUFTLEVBQUUsSUFBQUUsZ0NBQXNCLEVBQUMsNEJBQTRCLENBQUMsQ0FBQztJQUNoSlosb0JBQW9CLEdBQUcsSUFBQWEsb0JBQVMsRUFBQ2Qsb0JBQW9CLENBQUM7SUFDdERFLG1CQUFtQixHQUFHRywwQkFBMEIsQ0FBQywyQkFBMkIsRUFBRU0sU0FBUyxFQUFFLElBQUFFLGdDQUFzQixFQUFDLDJCQUEyQixDQUFDLENBQUM7SUFFN0lWLHdCQUF3QixHQUFHRSwwQkFBMEIsQ0FBQywwQkFBMEIsRUFBRU0sU0FBUyxFQUFFLElBQUFFLGdDQUFzQixFQUFDLDBCQUEwQixDQUFDLENBQUM7SUFDaEosTUFBTUUsb0JBQW9CLEdBQUdaLHdCQUF3QixDQUFDQSx3QkFBd0IsQ0FBQ2EsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUMxRixJQUFJRCxvQkFBb0IsS0FBSyxHQUFHLEVBQUU7TUFDaENaLHdCQUF3QixJQUFJLEdBQUc7SUFDakM7SUFBQztJQUNEQyx1QkFBdUIsR0FBR0Qsd0JBQXdCLENBQUNjLEtBQUssQ0FBQyxDQUFDLEVBQUNkLHdCQUF3QixDQUFDYSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBRS9GLElBQUFFLFdBQUcsRUFDRCx3Q0FBd0MsRUFDdkMsNkJBQTRCbkIsa0JBQW1CLEVBQUMsRUFDakQsT0FBTyxDQUNSO0lBRUQsSUFBQW1CLFdBQUcsRUFDRCx3Q0FBd0MsRUFDdkMsK0JBQThCbEIsb0JBQXFCLEtBQUlDLG9CQUFxQixHQUFFLEVBQy9FLE9BQU8sQ0FDUjtJQUVELElBQUFpQixXQUFHLEVBQ0Qsd0NBQXdDLEVBQ3ZDLDZCQUE0QmYsd0JBQXlCLG1CQUFrQkMsdUJBQXdCLEdBQUUsRUFDbEcsT0FBTyxDQUNSO0VBQ0gsQ0FBQyxRQUFNZSxLQUFLLEVBQUM7SUFDWCxNQUFNQyxZQUFZLEdBQUdELEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFLO0lBQzNDLElBQUFELFdBQUcsRUFDRCx3Q0FBd0MsRUFDeENFLFlBQVksQ0FDYjtJQUNEVixPQUFPLENBQUNZLEtBQUssQ0FBQ0MsTUFBTSxDQUFDSixLQUFLLENBQUNDLFlBQVksQ0FBQztFQUMxQztBQUNGO0FBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlSSxJQUFJQSxDQUFDZCxPQUFPLEVBQUU7RUFDM0IsSUFBSTtJQUNGLElBQUlYLGtCQUFrQixFQUFFO01BQ3RCLE1BQU0wQixhQUFhLENBQUNmLE9BQU8sQ0FBQztJQUM5QjtJQUFDO0VBQ0gsQ0FBQyxDQUFDLE9BQU9TLEtBQUssRUFBRTtJQUNkLE1BQU1DLFlBQVksR0FBR0QsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUs7SUFDM0MsSUFBQUQsV0FBRyxFQUFDLGlCQUFpQixFQUFFQyxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO0lBQzlDVCxPQUFPLENBQUNZLEtBQUssQ0FBQ0MsTUFBTSxDQUFDSixLQUFLLENBQUNDLFlBQVksQ0FBQztFQUMxQztBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGVBQWVLLGFBQWFBLENBQUNmLE9BQU8sRUFBRTtFQUNwQyxJQUFJO0lBQ0YsSUFBQVEsV0FBRyxFQUNELDBCQUEwQixFQUMxQixrQ0FBa0MsRUFDbEMsT0FBTyxDQUNSO0lBRUQsSUFBSTtNQUNGO01BQ0EsTUFBTVEsZUFBZSxHQUFHLE1BQU1oQixPQUFPLENBQUNpQixJQUFJLENBQUNDLGFBQWEsQ0FBQ0MsTUFBTSxDQUFDQyxjQUFjLENBQUNDLE9BQU8sQ0FBQ0MsV0FBVyxDQUFDO1FBQ2pHQyxJQUFJLEVBQUVDO01BQ1IsQ0FBQyxDQUFDO01BQ0Y7TUFDQUMsc0NBQWtCLENBQUNDLGNBQWMsR0FBR1YsZUFBZSxDQUFDVyxJQUFJLENBQUNILHlDQUE4QixDQUFDLENBQUNFLGNBQWM7SUFDekcsQ0FBQyxRQUFPakIsS0FBSyxFQUFFO01BQ2I7TUFDQWdCLHNDQUFrQixDQUFDQyxjQUFjLEdBQUcsQ0FBQyxJQUFBdkIsZ0NBQXNCLEVBQUMsMEJBQTBCLENBQUMsQ0FBQztJQUMxRjs7SUFFQTtJQUNBLElBQUksQ0FBQ3NCLHNDQUFrQixDQUFDQyxjQUFjLENBQUNFLFFBQVEsQ0FBQ25DLHdCQUF3QixDQUFDLEVBQUU7TUFDekVnQyxzQ0FBa0IsQ0FBQ0MsY0FBYyxDQUFDRyxJQUFJLENBQUNwQyx3QkFBd0IsQ0FBQztJQUNsRTtJQUFDOztJQUVEO0lBQ0EsTUFBTU8sT0FBTyxDQUFDaUIsSUFBSSxDQUFDQyxhQUFhLENBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDQyxPQUFPLENBQUNTLFdBQVcsQ0FBQztNQUN6RVAsSUFBSSxFQUFFQyx5Q0FBOEI7TUFDcENHLElBQUksRUFBRUY7SUFDUixDQUFDLENBQUM7SUFDRixJQUFBakIsV0FBRyxFQUNELDBCQUEwQixFQUMxQixpQ0FBaUMsRUFDakMsT0FBTyxDQUNSO0VBQ0gsQ0FBQyxDQUFDLE9BQU9DLEtBQUssRUFBRTtJQUNkLE1BQU1DLFlBQVksR0FBSSx5REFBd0RELEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFNLEVBQUM7SUFDdEcsSUFBQUQsV0FBRyxFQUNELDBCQUEwQixFQUMxQkUsWUFBWSxDQUNiO0lBQ0RWLE9BQU8sQ0FBQ1ksS0FBSyxDQUFDQyxNQUFNLENBQUNKLEtBQUssQ0FBQ3ZCLHdCQUF3QixFQUFFd0IsWUFBWSxDQUFDO0lBQ2xFLE1BQU1ELEtBQUs7RUFDYjtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlc0IsaUNBQWlDQSxDQUFDL0IsT0FBTyxFQUFFZ0MsSUFBSSxFQUFFO0VBQzlELE1BQU1DLG1CQUFtQixHQUFHdkMsdUJBQXVCLEdBQUcsSUFBQXdDLG9CQUFTLEVBQUMxQyxtQkFBbUIsQ0FBQztFQUNsRixJQUFJLENBQUNILGtCQUFrQixFQUFDO0lBQ3RCO0VBQ0Y7RUFBQztFQUNELElBQUk7SUFDRixNQUFNLElBQUE4QyxnRUFBK0IsRUFBQ0YsbUJBQW1CLENBQUMsQ0FBRSxZQUFXO01BQ3JFLE1BQU1HLE1BQU0sR0FBRyxNQUFNcEMsT0FBTyxDQUFDaUIsSUFBSSxDQUFDQyxhQUFhLENBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDQyxPQUFPLENBQUNlLE1BQU0sQ0FBQztRQUFDQyxLQUFLLEVBQUVKO01BQW1CLENBQUMsQ0FBQztNQUNsSCxJQUFHLENBQUNHLE1BQU0sQ0FBQ1QsSUFBSSxFQUFDO1FBQ2QsTUFBTVcsV0FBVyxDQUFDdEMsT0FBTyxFQUFFaUMsbUJBQW1CLENBQUM7TUFDakQ7TUFBQzs7TUFFRDtNQUNBLE1BQU1oQyxTQUFTLEdBQUcsSUFBQUMsa0NBQWdCLEdBQUU7TUFDcEMsTUFBTXFDLGtCQUFrQixHQUFHLElBQUFDLHNDQUFrQixFQUMzQ3ZDLFNBQVMsRUFDVCxrQkFBa0IsRUFDbEIsSUFBQUUsZ0NBQXNCLEVBQUMseUJBQXlCLENBQUMsQ0FDbEQ7O01BRUQ7TUFDQTtNQUNBLE9BQU9vQyxrQkFBa0IsQ0FBQ0UsUUFBUSxDQUFDSixLQUFLLENBQUNLLGdCQUFnQjtNQUN6RCxNQUFNMUMsT0FBTyxDQUFDaUIsSUFBSSxDQUFDQyxhQUFhLENBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDQyxPQUFPLENBQUNzQixXQUFXLENBQUM7UUFDekVOLEtBQUssRUFBRUosbUJBQW1CO1FBQzFCTixJQUFJLEVBQUVZO01BQ1IsQ0FBQyxDQUFDOztNQUVGO01BQ0EsTUFBTUssaUJBQWlCLENBQUM1QyxPQUFPLEVBQUVpQyxtQkFBbUIsRUFBRUQsSUFBSSxDQUFDO0lBQzdELENBQUMsQ0FBQyxFQUFFO0VBQ04sQ0FBQyxRQUFNdkIsS0FBSyxFQUFDO0lBQ1gsSUFBQUQsV0FBRyxFQUFDLDhDQUE4QyxFQUFFQyxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO0lBQzNFVCxPQUFPLENBQUNZLEtBQUssQ0FBQ0MsTUFBTSxDQUFDSixLQUFLLENBQUNBLEtBQUssQ0FBQ0UsT0FBTyxDQUFDO0VBQzNDO0FBQ0o7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZWlDLGlCQUFpQkEsQ0FBQzVDLE9BQU8sRUFBRTZDLFNBQWlCLEVBQUViLElBQThCLEVBQUU7RUFDM0YsTUFBTTtJQUFFYyxNQUFNO0lBQUVDO0VBQVEsQ0FBQyxHQUFHZixJQUFJO0VBQ2hDLElBQUk7SUFDRixJQUFJYyxNQUFNLENBQUN4QyxNQUFNLEdBQUcsQ0FBQyxFQUFFO01BQ3JCLElBQUFFLFdBQUcsRUFDRCw4QkFBOEIsRUFDN0Isc0JBQXFCcUMsU0FBVSxRQUFPQyxNQUFNLENBQUN4QyxNQUFPLFNBQVEsRUFDN0QsT0FBTyxDQUNSO01BRUQsTUFBTTBDLFFBQVEsR0FBR0YsTUFBTSxDQUFDRyxHQUFHLENBQUNDLEtBQUssSUFBSTtRQUNuQyxNQUFNQyxTQUFTLEdBQUc7VUFBQyxHQUFHRDtRQUFLLENBQUM7UUFDNUJDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxJQUFJQyxJQUFJLENBQUNBLElBQUksQ0FBQ0MsR0FBRyxFQUFFLENBQUMsQ0FBQ0MsV0FBVyxFQUFFO1FBQzNESCxTQUFTLENBQUNJLElBQUksR0FBR0wsS0FBSyxDQUFDTSxPQUFPO1FBQzlCTCxTQUFTLENBQUNNLE9BQU8sR0FBRztVQUFFbEMsSUFBSSxFQUFFd0IsT0FBTyxDQUFDVyxXQUFXLEdBQUdYLE9BQU8sQ0FBQ1csV0FBVyxHQUFHO1FBQVcsQ0FBQztRQUNwRixPQUFRLDRCQUEyQmIsU0FBVSxVQUFTYyxJQUFJLENBQUNDLFNBQVMsQ0FBQ1QsU0FBUyxDQUFFLElBQUc7TUFDckYsQ0FBQyxDQUFDLENBQUNVLElBQUksQ0FBQyxFQUFFLENBQUM7TUFFWCxNQUFNN0QsT0FBTyxDQUFDaUIsSUFBSSxDQUFDQyxhQUFhLENBQUNDLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDMEMsSUFBSSxDQUFDO1FBQzFEekIsS0FBSyxFQUFFUSxTQUFTO1FBQ2hCbEIsSUFBSSxFQUFFcUI7TUFDUixDQUFDLENBQUM7TUFDRixJQUFBeEMsV0FBRyxFQUNELDhCQUE4QixFQUM3QixzQkFBcUJxQyxTQUFVLFFBQU9DLE1BQU0sQ0FBQ3hDLE1BQU8sbUJBQWtCLEVBQ3ZFLE9BQU8sQ0FDUjtJQUNIO0VBQ0YsQ0FBQyxDQUFDLE9BQU9HLEtBQUssRUFBRTtJQUNkLElBQUFELFdBQUcsRUFDRCw4QkFBOEIsRUFDN0IsNkVBQTRFQyxLQUFLLENBQUNFLE9BQU8sSUFDeEZGLEtBQU0sRUFBQyxDQUNWO0VBQ0g7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZUFBZTZCLFdBQVdBLENBQUN0QyxPQUFPLEVBQUU2QyxTQUFpQixFQUFFO0VBQ3JELElBQUk7SUFDRixJQUFJLENBQUN4RCxrQkFBa0IsRUFBRTtJQUN6QixNQUFNWSxTQUFTLEdBQUcsSUFBQUMsa0NBQWdCLEdBQUU7SUFFcEMsTUFBTTZELGtCQUFrQixHQUFHO01BQ3pCdEIsUUFBUSxFQUFFO1FBQ1JKLEtBQUssRUFBRTtVQUNMSyxnQkFBZ0IsRUFBRS9DLDBCQUEwQixDQUFDLHlCQUF5QixFQUFFTSxTQUFTLEVBQUUsSUFBQUUsZ0NBQXNCLEVBQUMseUJBQXlCLENBQUMsQ0FBQztVQUNySTZELGtCQUFrQixFQUFFckUsMEJBQTBCLENBQUMsMkJBQTJCLEVBQUVNLFNBQVMsRUFBRSxJQUFBRSxnQ0FBc0IsRUFBQywyQkFBMkIsQ0FBQztRQUM1STtNQUNGO0lBQ0YsQ0FBQztJQUVELE1BQU1ILE9BQU8sQ0FBQ2lCLElBQUksQ0FBQ0MsYUFBYSxDQUFDQyxNQUFNLENBQUNDLGNBQWMsQ0FBQ0MsT0FBTyxDQUFDNEMsTUFBTSxDQUFDO01BQ3BFNUIsS0FBSyxFQUFFUSxTQUFTO01BQ2hCbEIsSUFBSSxFQUFFb0M7SUFDUixDQUFDLENBQUM7SUFFRixJQUFBdkQsV0FBRyxFQUNELHdCQUF3QixFQUN2QixtQ0FBa0NxQyxTQUFVLEVBQUMsRUFDOUMsT0FBTyxDQUNSO0VBQ0gsQ0FBQyxDQUFDLE9BQU9wQyxLQUFLLEVBQUU7SUFDZCxNQUFNQyxZQUFZLEdBQUksb0JBQW1CbUMsU0FBVSxrQ0FBaUNwQyxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBTSxFQUFDO0lBQzVHLElBQUFELFdBQUcsRUFDRCx3QkFBd0IsRUFDeEJFLFlBQVksQ0FDYjtJQUNEVixPQUFPLENBQUNZLEtBQUssQ0FBQ0MsTUFBTSxDQUFDSixLQUFLLENBQUNDLFlBQVksQ0FBQztFQUMxQztBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBLGVBQWV3RCx5QkFBeUJBLENBQUNsRSxPQUFPLEVBQUU7RUFDakQsSUFBSTtJQUNELElBQUFRLFdBQUcsRUFDRCxzQ0FBc0MsRUFDdEMsNkRBQTZELEVBQzdELE9BQU8sQ0FDUjtJQUVGLE1BQU0yRCx3QkFBd0IsQ0FBQ25FLE9BQU8sQ0FBQztJQUN2QyxNQUFNYyxJQUFJLENBQUNkLE9BQU8sQ0FBQztJQUNuQjtFQUNGLENBQUMsQ0FBQyxPQUFPUyxLQUFLLEVBQUU7SUFDYixJQUFBRCxXQUFHLEVBQ0Qsc0NBQXNDLEVBQ3RDQyxLQUFLLENBQUMyRCxNQUFNLElBQUczRCxLQUFLLENBQ3JCO0lBQ0QsSUFBRztNQUNELE1BQU0sSUFBQTRELHFCQUFjLEVBQUMsSUFBSSxDQUFDO01BQzFCLE1BQU1ILHlCQUF5QixDQUFDbEUsT0FBTyxDQUFDO0lBQzFDLENBQUMsUUFBTVMsS0FBSyxFQUFDLENBQUM7SUFBQztFQUNsQjtBQUNEOztBQUdBO0FBQ0E7QUFDQTtBQUNBLGVBQWUwRCx3QkFBd0JBLENBQUNuRSxPQUFPLEVBQUU7RUFDL0MsSUFBSTtJQUNGLE1BQU1nQyxJQUFJLEdBQUcsTUFBTWhDLE9BQU8sQ0FBQ2lCLElBQUksQ0FBQ0MsYUFBYSxDQUFDQyxNQUFNLENBQUNDLGNBQWMsQ0FBQ0MsT0FBTyxDQUFDZSxNQUFNLENBQUM7TUFDakZDLEtBQUssRUFBRXJDLE9BQU8sQ0FBQ3NFLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDQyxNQUFNLENBQUNuQztJQUN0QyxDQUFDLENBQUM7SUFFRixPQUFPTCxJQUFJLENBQUNMLElBQUk7SUFDaEI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLE9BQU84QyxPQUFPLENBQUNDLE1BQU0sQ0FBQzFDLElBQUksQ0FBQztFQUM3QixDQUFDLENBQUMsT0FBT3ZCLEtBQUssRUFBRTtJQUNkLElBQUFELFdBQUcsRUFBQyxxQ0FBcUMsRUFBRUMsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztJQUNsRSxPQUFPZ0UsT0FBTyxDQUFDQyxNQUFNLENBQUNqRSxLQUFLLENBQUM7RUFDOUI7QUFDRjtBQUVBLE1BQU1rRSxvQkFBb0IsR0FBRztFQUMzQkMsRUFBRSxFQUFHakQsSUFBUyxJQUFLQSxJQUFJO0VBQ3ZCa0QsTUFBTSxFQUFHbEQsSUFBUyxJQUFLQTtBQUN6QixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsZUFBZW1ELHFCQUFxQkEsQ0FBQSxFQUFHO0VBQ3JDLElBQUk7SUFDRixNQUFNQyxLQUFLLEdBQUcsTUFBTTVGLG1CQUFtQixDQUFDNkYsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUVMLG9CQUFvQixDQUFDO0lBQzNGLElBQUlJLEtBQUssQ0FBQ3BELElBQUksQ0FBQ3JCLE1BQU0sRUFBRTtNQUNyQixPQUFPeUUsS0FBSyxDQUFDcEQsSUFBSTtJQUNuQjtJQUFDO0lBRUQsSUFBQW5CLFdBQUcsRUFDRCxzQkFBc0IsRUFDdEIsb0NBQW9DLEVBQ3BDLE9BQU8sQ0FDUjtJQUNELE9BQU9pRSxPQUFPLENBQUNDLE1BQU0sQ0FBQztNQUNwQmpFLEtBQUssRUFBRSxnQkFBZ0I7TUFDdkJ3RSxVQUFVLEVBQUU7SUFDZCxDQUFDLENBQUM7RUFDSixDQUFDLENBQUMsT0FBT3hFLEtBQUssRUFBRTtJQUNkLElBQUFELFdBQUcsRUFBQyxrQ0FBa0MsRUFBRUMsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztJQUMvRCxPQUFPZ0UsT0FBTyxDQUFDQyxNQUFNLENBQUM7TUFDcEJqRSxLQUFLLEVBQUUsZ0JBQWdCO01BQ3ZCd0UsVUFBVSxFQUFFO0lBQ2QsQ0FBQyxDQUFDO0VBQ0o7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxlQUFlQyxRQUFRQSxDQUFDbEYsT0FBTyxFQUFFO0VBQy9CLElBQUk7SUFDRixNQUFNbUYsa0JBQWtCLEdBQUcsTUFBTW5GLE9BQU8sQ0FBQ2lCLElBQUksQ0FBQ0MsYUFBYSxDQUFDQyxNQUFNLENBQUNDLGNBQWMsQ0FBQ0MsT0FBTyxDQUFDQyxXQUFXLENBQUM7TUFBQ0MsSUFBSSxFQUFFQztJQUE4QixDQUFDLENBQUM7SUFFN0ksTUFBTTRELFFBQVEsR0FBRyxNQUFNTixxQkFBcUIsRUFBRTtJQUM5QyxNQUFNTyxjQUFjLEdBQUcsQ0FBQ0QsUUFBUSxJQUFJLEVBQUUsRUFBRUUsTUFBTSxDQUM1QyxDQUFDdkMsT0FBTyxFQUFFVixLQUFLLEVBQUVrRCxJQUFJLEtBQ25CbEQsS0FBSyxLQUNMa0QsSUFBSSxDQUFDQyxTQUFTLENBQ1pDLENBQUMsSUFDQ0EsQ0FBQyxDQUFDQyxJQUFJLEtBQUszQyxPQUFPLENBQUMyQyxJQUFJLElBQ3ZCRCxDQUFDLENBQUNFLFFBQVEsS0FBSzVDLE9BQU8sQ0FBQzRDLFFBQVEsSUFDL0JGLENBQUMsQ0FBQ0csR0FBRyxLQUFLN0MsT0FBTyxDQUFDNkMsR0FBRyxJQUNyQkgsQ0FBQyxDQUFDSSxJQUFJLEtBQUs5QyxPQUFPLENBQUM4QyxJQUFJLENBQzFCLENBQ0o7SUFDRCxLQUFJLElBQUk5QyxPQUFPLElBQUlzQyxjQUFjLEVBQUM7TUFDaEMsSUFBRztRQUNELE1BQU07VUFBRXZDLE1BQU07VUFBRUMsT0FBTyxFQUFFUTtRQUFJLENBQUMsR0FBRyxNQUFNdUMsVUFBVSxDQUFDOUYsT0FBTyxFQUFFK0MsT0FBTyxDQUFDO1FBQ25FLE1BQU1oQixpQ0FBaUMsQ0FBQy9CLE9BQU8sRUFBRTtVQUFDOEMsTUFBTTtVQUFFQyxPQUFPLEVBQUVRO1FBQUksQ0FBQyxDQUFDO01BQzNFLENBQUMsUUFBTTlDLEtBQUssRUFBQyxDQUViO01BQUM7SUFDSDtFQUNGLENBQUMsQ0FBQyxPQUFPQSxLQUFLLEVBQUU7SUFDZDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBOztJQUVBLElBQUFELFdBQUcsRUFBQyxxQkFBcUIsRUFBRUMsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztJQUNsRFQsT0FBTyxDQUFDWSxLQUFLLENBQUNDLE1BQU0sQ0FBQ0osS0FBSyxDQUFDQSxLQUFLLENBQUNFLE9BQU8sSUFBSUYsS0FBSyxDQUFDO0VBQ3BEO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGVBQWVxRixVQUFVQSxDQUFDOUYsT0FBTyxFQUFFK0MsT0FBTyxFQUFDO0VBQ3pDLElBQUc7SUFDRCxJQUFBdkMsV0FBRyxFQUFDLHVCQUF1QixFQUFHLHdCQUF1QnVDLE9BQU8sQ0FBQ2dELEVBQUcsRUFBQyxFQUFFLE9BQU8sQ0FBQztJQUMzRSxNQUFNQyxpQkFBaUIsR0FBRyxNQUFNaEcsT0FBTyxDQUFDWSxLQUFLLENBQUNxRixHQUFHLENBQUM5RSxNQUFNLENBQUNDLGNBQWMsQ0FBQzhFLE9BQU8sQ0FBQyxLQUFLLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDLEVBQUU7TUFBRUMsU0FBUyxFQUFFcEQsT0FBTyxDQUFDZ0Q7SUFBRyxDQUFDLENBQUM7SUFDeEksTUFBTUssU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDSixpQkFBaUIsSUFBSSxDQUFDLENBQUMsRUFBRWhFLElBQUksSUFBSSxDQUFDLENBQUMsRUFBRUEsSUFBSSxJQUFJLENBQUMsQ0FBQyxFQUFFcUUsT0FBTyxLQUFLLEtBQUs7SUFDdkYsSUFBR0QsU0FBUyxFQUFDO01BQ1gsTUFBTUUsbUJBQW1CLEdBQUcsTUFBTXRHLE9BQU8sQ0FBQ1ksS0FBSyxDQUFDcUYsR0FBRyxDQUFDOUUsTUFBTSxDQUFDQyxjQUFjLENBQUM4RSxPQUFPLENBQUMsS0FBSyxFQUFHLHFCQUFvQixFQUFFLENBQUMsQ0FBQyxFQUFHO1FBQUVDLFNBQVMsRUFBRXBELE9BQU8sQ0FBQ2dEO01BQUcsQ0FBQyxDQUFDO01BQy9JaEQsT0FBTyxDQUFDVyxXQUFXLEdBQUc0QyxtQkFBbUIsQ0FBQ3RFLElBQUksQ0FBQ0EsSUFBSSxDQUFDdUUsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDOUMsT0FBTztJQUMvRTtJQUFDO0lBQ0QsTUFBTVgsTUFBTSxHQUFHLE1BQU0wRCx5QkFBeUIsQ0FBQ3hHLE9BQU8sRUFBRStDLE9BQU8sQ0FBQztJQUNoRSxPQUFPO01BQUVELE1BQU07TUFBRUM7SUFBUSxDQUFDO0VBQzVCLENBQUMsUUFBTXRDLEtBQUssRUFBQztJQUNYLElBQUFELFdBQUcsRUFBQyx1QkFBdUIsRUFBRUMsS0FBSyxDQUFDRSxPQUFPLElBQUlGLEtBQUssQ0FBQztJQUNwRCxNQUFNQSxLQUFLO0VBQ2I7QUFDRjtBQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlK0YseUJBQXlCQSxDQUFDeEcsT0FBTyxFQUFFK0MsT0FBTyxFQUFDO0VBQ3hELElBQUlELE1BQU0sR0FBRyxFQUFFO0VBQ2YsSUFBRztJQUNELElBQUF0QyxXQUFHLEVBQUMsc0NBQXNDLEVBQUcsa0NBQWlDdUMsT0FBTyxDQUFDZ0QsRUFBRyxFQUFDLEVBQUUsT0FBTyxDQUFDO0lBQ3BHLE1BQU1VLG1CQUFtQixHQUFHLE1BQU16RyxPQUFPLENBQUNZLEtBQUssQ0FBQ3FGLEdBQUcsQ0FBQzlFLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDOEUsT0FBTyxDQUMvRSxLQUFLLEVBQ0wsU0FBUyxFQUNUO01BQ0VRLE1BQU0sRUFBRTtRQUNOQyxNQUFNLEVBQUUsQ0FBQztRQUNUQyxLQUFLLEVBQUUsQ0FBQztRQUNSQyxDQUFDLEVBQUU7TUFDTDtJQUNGLENBQUMsRUFBRTtNQUFDVixTQUFTLEVBQUVwRCxPQUFPLENBQUNnRDtJQUFFLENBQUMsQ0FBQztJQUU3QixNQUFNZSxXQUFXLEdBQUdMLG1CQUFtQixDQUFDekUsSUFBSSxDQUFDQSxJQUFJLENBQUMrRSxvQkFBb0I7SUFDdEUsSUFBQXZHLFdBQUcsRUFBQyxzQ0FBc0MsRUFBRyxVQUFTdUMsT0FBTyxDQUFDZ0QsRUFBRyxrQkFBaUJlLFdBQVksRUFBQyxFQUFFLE9BQU8sQ0FBQztJQUV6RyxJQUFJRSxPQUFPLEdBQUc7TUFDWkwsTUFBTSxFQUFFLENBQUM7TUFDVEMsS0FBSyxFQUFFLEdBQUc7TUFDVkMsQ0FBQyxFQUFFO0lBQ0wsQ0FBQztJQUVELE9BQU8vRCxNQUFNLENBQUN4QyxNQUFNLEdBQUd3RyxXQUFXLElBQUlFLE9BQU8sQ0FBQ0wsTUFBTSxHQUFHRyxXQUFXLEVBQUU7TUFDbEUsSUFBRztRQUNEO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtRQUdRLE1BQU1HLGNBQWMsR0FBRyxNQUFNakgsT0FBTyxDQUFDWSxLQUFLLENBQUNxRixHQUFHLENBQUM5RSxNQUFNLENBQUNDLGNBQWMsQ0FBQzhFLE9BQU8sQ0FDMUUsS0FBSyxFQUNKLFNBQVEsRUFDVDtVQUFDUSxNQUFNLEVBQUVNO1FBQU8sQ0FBQyxFQUNqQjtVQUFDYixTQUFTLEVBQUVwRCxPQUFPLENBQUNnRDtRQUFFLENBQUMsQ0FDeEI7UUFDRGpELE1BQU0sR0FBRyxDQUFDLEdBQUdBLE1BQU0sRUFBRSxHQUFHbUUsY0FBYyxDQUFDakYsSUFBSSxDQUFDQSxJQUFJLENBQUN1RSxjQUFjLENBQUM7UUFDaEVTLE9BQU8sQ0FBQ0wsTUFBTSxJQUFJSyxPQUFPLENBQUNKLEtBQUs7TUFDakMsQ0FBQyxRQUFNbkcsS0FBSyxFQUFDO1FBQ1gsSUFBQUQsV0FBRyxFQUFDLHNDQUFzQyxFQUFHLFVBQVN1QyxPQUFPLENBQUNnRCxFQUFHLHFDQUFvQ2lCLE9BQU8sQ0FBQ0wsTUFBTyxJQUFHSyxPQUFPLENBQUNKLEtBQU0sS0FBSW5HLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFNLEVBQUMsQ0FBQztNQUNwSztJQUNGO0lBQ0EsT0FBT3FDLE1BQU07RUFDZixDQUFDLFFBQU1yQyxLQUFLLEVBQUM7SUFDWCxJQUFBRCxXQUFHLEVBQUMsc0NBQXNDLEVBQUcsVUFBU3VDLE9BQU8sQ0FBQ2dELEVBQUcsWUFBV3RGLEtBQUssQ0FBQ0UsT0FBTyxJQUFJRixLQUFNLEVBQUMsQ0FBQztJQUNyRyxNQUFNQSxLQUFLO0VBQ2I7QUFDRjtBQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNPLGVBQWV5RyxnQkFBZ0JBLENBQUNsSCxPQUFPLEVBQUU7RUFDOUM7RUFDQUQsMkJBQTJCLENBQUNDLE9BQU8sQ0FBQztFQUNwQztFQUNBLE1BQU1rRSx5QkFBeUIsQ0FBQ2xFLE9BQU8sQ0FBQztFQUN4QztFQUNBLElBQUlYLGtCQUFrQixFQUFFO0lBQ3RCNkYsUUFBUSxDQUFDbEYsT0FBTyxDQUFDO0lBQ2pCbUgsaUJBQUksQ0FBQ0MsUUFBUSxDQUFDN0gsb0JBQW9CLEVBQUUsTUFBTTJGLFFBQVEsQ0FBQ2xGLE9BQU8sQ0FBQyxDQUFDO0VBQzlEO0FBQ0YifQ==