"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ApiRequest = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var ApiInterceptor = _interopRequireWildcard(require("../../lib/api-interceptor.js"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
class ApiRequest {
  constructor(request, api, params = {}) {
    (0, _defineProperty2.default)(this, "api", void 0);
    (0, _defineProperty2.default)(this, "request", void 0);
    (0, _defineProperty2.default)(this, "params", void 0);
    this.request = request;
    this.api = api;
    this.params = params;
  }
  async makeRequest() {
    const {
      id,
      url,
      port
    } = this.api;
    const response = await ApiInterceptor.requestAsInternalUser('GET', '/${this.request}', this.params, {
      apiHostID: id
    });
    return response;
  }
  async getData() {
    try {
      const response = await this.makeRequest();
      if (response.status !== 200) throw response;
      return response.data;
    } catch (error) {
      if (error.status === 404) {
        throw {
          error: 404,
          message: error.data.detail
        };
      }
      if (error.response && error.response.status === 401) {
        throw {
          error: 401,
          message: 'Wrong Wazuh API credentials used'
        };
      }
      if (error && error.data && error.data.detail && error.data.detail === 'ECONNRESET') {
        throw {
          error: 3005,
          message: 'Wrong protocol being used to connect to the Wazuh API'
        };
      }
      if (error && error.data && error.data.detail && ['ENOTFOUND', 'EHOSTUNREACH', 'EINVAL', 'EAI_AGAIN', 'ECONNREFUSED'].includes(error.data.detail)) {
        throw {
          error: 3005,
          message: 'Wazuh API is not reachable. Please check your url and port.'
        };
      }
      throw error;
    }
  }
}
exports.ApiRequest = ApiRequest;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJBcGlJbnRlcmNlcHRvciIsIl9pbnRlcm9wUmVxdWlyZVdpbGRjYXJkIiwicmVxdWlyZSIsIl9nZXRSZXF1aXJlV2lsZGNhcmRDYWNoZSIsIm5vZGVJbnRlcm9wIiwiV2Vha01hcCIsImNhY2hlQmFiZWxJbnRlcm9wIiwiY2FjaGVOb2RlSW50ZXJvcCIsIm9iaiIsIl9fZXNNb2R1bGUiLCJkZWZhdWx0IiwiY2FjaGUiLCJoYXMiLCJnZXQiLCJuZXdPYmoiLCJoYXNQcm9wZXJ0eURlc2NyaXB0b3IiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsImtleSIsInByb3RvdHlwZSIsImhhc093blByb3BlcnR5IiwiY2FsbCIsImRlc2MiLCJzZXQiLCJBcGlSZXF1ZXN0IiwiY29uc3RydWN0b3IiLCJyZXF1ZXN0IiwiYXBpIiwicGFyYW1zIiwiX2RlZmluZVByb3BlcnR5MiIsIm1ha2VSZXF1ZXN0IiwiaWQiLCJ1cmwiLCJwb3J0IiwicmVzcG9uc2UiLCJyZXF1ZXN0QXNJbnRlcm5hbFVzZXIiLCJhcGlIb3N0SUQiLCJnZXREYXRhIiwic3RhdHVzIiwiZGF0YSIsImVycm9yIiwibWVzc2FnZSIsImRldGFpbCIsImluY2x1ZGVzIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbImFwaVJlcXVlc3QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXhpb3NSZXNwb25zZSB9ZnJvbSAnYXhpb3MnO1xuaW1wb3J0ICogYXMgQXBpSW50ZXJjZXB0b3IgIGZyb20gJy4uLy4uL2xpYi9hcGktaW50ZXJjZXB0b3IuanMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIElBcGkge1xuICBpZDogc3RyaW5nXG4gIHVzZXI6IHN0cmluZ1xuICBwYXNzd29yZDogc3RyaW5nXG4gIHVybDogc3RyaW5nXG4gIHBvcnQ6IG51bWJlclxuICBjbHVzdGVyX2luZm86IHtcbiAgICBtYW5hZ2VyOiBzdHJpbmdcbiAgICBjbHVzdGVyOiAnRGlzYWJsZWQnIHwgJ0VuYWJsZWQnXG4gICAgc3RhdHVzOiAnZGlzYWJsZWQnIHwgJ2VuYWJsZWQnXG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEFwaVJlcXVlc3Qge1xuICBwcml2YXRlIGFwaTogSUFwaTtcbiAgcHJpdmF0ZSByZXF1ZXN0OiBzdHJpbmc7XG4gIHByaXZhdGUgcGFyYW1zOiB7fTtcblxuICBjb25zdHJ1Y3RvcihyZXF1ZXN0OnN0cmluZywgYXBpOklBcGksIHBhcmFtczp7fT17fSwgKSB7XG4gICAgdGhpcy5yZXF1ZXN0ID0gcmVxdWVzdDtcbiAgICB0aGlzLmFwaSA9IGFwaTtcbiAgICB0aGlzLnBhcmFtcyA9IHBhcmFtcztcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbWFrZVJlcXVlc3QoKTpQcm9taXNlPEF4aW9zUmVzcG9uc2U+IHtcbiAgICBjb25zdCB7aWQsIHVybCwgcG9ydH0gPSB0aGlzLmFwaTtcbiAgICBcbiAgICBjb25zdCByZXNwb25zZTogQXhpb3NSZXNwb25zZSA9IGF3YWl0IEFwaUludGVyY2VwdG9yLnJlcXVlc3RBc0ludGVybmFsVXNlcihcbiAgICAgICdHRVQnLFxuICAgICAgJy8ke3RoaXMucmVxdWVzdH0nLFxuICAgICAgdGhpcy5wYXJhbXMsXG4gICAgICB7YXBpSG9zdElEOiBpZCB9XG4gICAgKVxuICAgIHJldHVybiByZXNwb25zZTtcbiAgfVxuXG4gIHB1YmxpYyBhc3luYyBnZXREYXRhKCk6UHJvbWlzZTxvYmplY3Q+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLm1ha2VSZXF1ZXN0KCk7XG4gICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzICE9PSAyMDApIHRocm93IHJlc3BvbnNlO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvci5zdGF0dXMgPT09IDQwNCkge1xuICAgICAgICB0aHJvdyB7ZXJyb3I6IDQwNCwgbWVzc2FnZTogZXJyb3IuZGF0YS5kZXRhaWx9O1xuICAgICAgfVxuICAgICAgaWYgKGVycm9yLnJlc3BvbnNlICYmIGVycm9yLnJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxKXtcbiAgICAgICAgdGhyb3cge2Vycm9yOiA0MDEsIG1lc3NhZ2U6ICdXcm9uZyBXYXp1aCBBUEkgY3JlZGVudGlhbHMgdXNlZCd9O1xuICAgICAgfVxuICAgICAgaWYgKGVycm9yICYmIGVycm9yLmRhdGEgJiYgZXJyb3IuZGF0YS5kZXRhaWwgJiYgZXJyb3IuZGF0YS5kZXRhaWwgPT09ICdFQ09OTlJFU0VUJykge1xuICAgICAgICB0aHJvdyB7ZXJyb3I6IDMwMDUsIG1lc3NhZ2U6ICdXcm9uZyBwcm90b2NvbCBiZWluZyB1c2VkIHRvIGNvbm5lY3QgdG8gdGhlIFdhenVoIEFQSSd9O1xuICAgICAgfVxuICAgICAgaWYgKGVycm9yICYmIGVycm9yLmRhdGEgJiYgZXJyb3IuZGF0YS5kZXRhaWwgJiYgWydFTk9URk9VTkQnLCdFSE9TVFVOUkVBQ0gnLCdFSU5WQUwnLCdFQUlfQUdBSU4nLCdFQ09OTlJFRlVTRUQnXS5pbmNsdWRlcyhlcnJvci5kYXRhLmRldGFpbCkpIHtcbiAgICAgICAgdGhyb3cge2Vycm9yOiAzMDA1LCBtZXNzYWdlOiAnV2F6dWggQVBJIGlzIG5vdCByZWFjaGFibGUuIFBsZWFzZSBjaGVjayB5b3VyIHVybCBhbmQgcG9ydC4nfTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxufSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFDQSxJQUFBQSxjQUFBLEdBQUFDLHVCQUFBLENBQUFDLE9BQUE7QUFBZ0UsU0FBQUMseUJBQUFDLFdBQUEsZUFBQUMsT0FBQSxrQ0FBQUMsaUJBQUEsT0FBQUQsT0FBQSxRQUFBRSxnQkFBQSxPQUFBRixPQUFBLFlBQUFGLHdCQUFBLFlBQUFBLENBQUFDLFdBQUEsV0FBQUEsV0FBQSxHQUFBRyxnQkFBQSxHQUFBRCxpQkFBQSxLQUFBRixXQUFBO0FBQUEsU0FBQUgsd0JBQUFPLEdBQUEsRUFBQUosV0FBQSxTQUFBQSxXQUFBLElBQUFJLEdBQUEsSUFBQUEsR0FBQSxDQUFBQyxVQUFBLFdBQUFELEdBQUEsUUFBQUEsR0FBQSxvQkFBQUEsR0FBQSx3QkFBQUEsR0FBQSw0QkFBQUUsT0FBQSxFQUFBRixHQUFBLFVBQUFHLEtBQUEsR0FBQVIsd0JBQUEsQ0FBQUMsV0FBQSxPQUFBTyxLQUFBLElBQUFBLEtBQUEsQ0FBQUMsR0FBQSxDQUFBSixHQUFBLFlBQUFHLEtBQUEsQ0FBQUUsR0FBQSxDQUFBTCxHQUFBLFNBQUFNLE1BQUEsV0FBQUMscUJBQUEsR0FBQUMsTUFBQSxDQUFBQyxjQUFBLElBQUFELE1BQUEsQ0FBQUUsd0JBQUEsV0FBQUMsR0FBQSxJQUFBWCxHQUFBLFFBQUFXLEdBQUEsa0JBQUFILE1BQUEsQ0FBQUksU0FBQSxDQUFBQyxjQUFBLENBQUFDLElBQUEsQ0FBQWQsR0FBQSxFQUFBVyxHQUFBLFNBQUFJLElBQUEsR0FBQVIscUJBQUEsR0FBQUMsTUFBQSxDQUFBRSx3QkFBQSxDQUFBVixHQUFBLEVBQUFXLEdBQUEsY0FBQUksSUFBQSxLQUFBQSxJQUFBLENBQUFWLEdBQUEsSUFBQVUsSUFBQSxDQUFBQyxHQUFBLEtBQUFSLE1BQUEsQ0FBQUMsY0FBQSxDQUFBSCxNQUFBLEVBQUFLLEdBQUEsRUFBQUksSUFBQSxZQUFBVCxNQUFBLENBQUFLLEdBQUEsSUFBQVgsR0FBQSxDQUFBVyxHQUFBLFNBQUFMLE1BQUEsQ0FBQUosT0FBQSxHQUFBRixHQUFBLE1BQUFHLEtBQUEsSUFBQUEsS0FBQSxDQUFBYSxHQUFBLENBQUFoQixHQUFBLEVBQUFNLE1BQUEsWUFBQUEsTUFBQTtBQWV6RCxNQUFNVyxVQUFVLENBQUM7RUFLdEJDLFdBQVdBLENBQUNDLE9BQWMsRUFBRUMsR0FBUSxFQUFFQyxNQUFTLEdBQUMsQ0FBQyxDQUFDLEVBQUk7SUFBQSxJQUFBQyxnQkFBQSxDQUFBcEIsT0FBQTtJQUFBLElBQUFvQixnQkFBQSxDQUFBcEIsT0FBQTtJQUFBLElBQUFvQixnQkFBQSxDQUFBcEIsT0FBQTtJQUNwRCxJQUFJLENBQUNpQixPQUFPLEdBQUdBLE9BQU87SUFDdEIsSUFBSSxDQUFDQyxHQUFHLEdBQUdBLEdBQUc7SUFDZCxJQUFJLENBQUNDLE1BQU0sR0FBR0EsTUFBTTtFQUN0QjtFQUVBLE1BQWNFLFdBQVdBLENBQUEsRUFBMEI7SUFDakQsTUFBTTtNQUFDQyxFQUFFO01BQUVDLEdBQUc7TUFBRUM7SUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDTixHQUFHO0lBRWhDLE1BQU1PLFFBQXVCLEdBQUcsTUFBTW5DLGNBQWMsQ0FBQ29DLHFCQUFxQixDQUN4RSxLQUFLLEVBQ0wsa0JBQWtCLEVBQ2xCLElBQUksQ0FBQ1AsTUFBTSxFQUNYO01BQUNRLFNBQVMsRUFBRUw7SUFBRyxDQUFDLENBQ2pCO0lBQ0QsT0FBT0csUUFBUTtFQUNqQjtFQUVBLE1BQWFHLE9BQU9BLENBQUEsRUFBbUI7SUFDckMsSUFBSTtNQUNGLE1BQU1ILFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQ0osV0FBVyxFQUFFO01BQ3pDLElBQUlJLFFBQVEsQ0FBQ0ksTUFBTSxLQUFLLEdBQUcsRUFBRSxNQUFNSixRQUFRO01BQzNDLE9BQU9BLFFBQVEsQ0FBQ0ssSUFBSTtJQUN0QixDQUFDLENBQUMsT0FBT0MsS0FBSyxFQUFFO01BQ2QsSUFBSUEsS0FBSyxDQUFDRixNQUFNLEtBQUssR0FBRyxFQUFFO1FBQ3hCLE1BQU07VUFBQ0UsS0FBSyxFQUFFLEdBQUc7VUFBRUMsT0FBTyxFQUFFRCxLQUFLLENBQUNELElBQUksQ0FBQ0c7UUFBTSxDQUFDO01BQ2hEO01BQ0EsSUFBSUYsS0FBSyxDQUFDTixRQUFRLElBQUlNLEtBQUssQ0FBQ04sUUFBUSxDQUFDSSxNQUFNLEtBQUssR0FBRyxFQUFDO1FBQ2xELE1BQU07VUFBQ0UsS0FBSyxFQUFFLEdBQUc7VUFBRUMsT0FBTyxFQUFFO1FBQWtDLENBQUM7TUFDakU7TUFDQSxJQUFJRCxLQUFLLElBQUlBLEtBQUssQ0FBQ0QsSUFBSSxJQUFJQyxLQUFLLENBQUNELElBQUksQ0FBQ0csTUFBTSxJQUFJRixLQUFLLENBQUNELElBQUksQ0FBQ0csTUFBTSxLQUFLLFlBQVksRUFBRTtRQUNsRixNQUFNO1VBQUNGLEtBQUssRUFBRSxJQUFJO1VBQUVDLE9BQU8sRUFBRTtRQUF1RCxDQUFDO01BQ3ZGO01BQ0EsSUFBSUQsS0FBSyxJQUFJQSxLQUFLLENBQUNELElBQUksSUFBSUMsS0FBSyxDQUFDRCxJQUFJLENBQUNHLE1BQU0sSUFBSSxDQUFDLFdBQVcsRUFBQyxjQUFjLEVBQUMsUUFBUSxFQUFDLFdBQVcsRUFBQyxjQUFjLENBQUMsQ0FBQ0MsUUFBUSxDQUFDSCxLQUFLLENBQUNELElBQUksQ0FBQ0csTUFBTSxDQUFDLEVBQUU7UUFDNUksTUFBTTtVQUFDRixLQUFLLEVBQUUsSUFBSTtVQUFFQyxPQUFPLEVBQUU7UUFBNkQsQ0FBQztNQUM3RjtNQUNBLE1BQU1ELEtBQUs7SUFDYjtFQUNGO0FBQ0Y7QUFBQ0ksT0FBQSxDQUFBcEIsVUFBQSxHQUFBQSxVQUFBIn0=