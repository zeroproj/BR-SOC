"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.jobs = void 0;
const jobs = {
  'manager-stats-remoted': {
    status: true,
    method: "GET",
    request: '/manager/stats/remoted?pretty',
    params: {},
    interval: '0 */5 * * * *',
    index: {
      name: 'statistics',
      creation: 'w',
      mapping: '{"remoted": ${data.affected_items[0]}, "apiName": ${apiName}, "cluster": "false"}'
    }
  },
  'manager-stats-analysisd': {
    status: true,
    method: "GET",
    request: '/manager/stats/analysisd?pretty',
    params: {},
    interval: '0 */5 * * * *',
    index: {
      name: 'statistics',
      creation: 'w',
      mapping: '{"analysisd": ${data.affected_items[0]}, "apiName": ${apiName}, "cluster": "false"}'
    }
  },
  'cluster-stats-remoted': {
    status: true,
    method: "GET",
    request: {
      request: '/cluster/{nodeName}/stats/remoted?pretty',
      params: {
        nodeName: {
          request: '/cluster/nodes?select=name'
        }
      }
    },
    params: {},
    interval: '0 */5 * * * *',
    index: {
      name: 'statistics',
      creation: 'w',
      mapping: '{"remoted": ${data.affected_items[0]}, "apiName": ${apiName}, "nodeName": ${nodeName}, "cluster": "true"}'
    }
  },
  'cluster-stats-analysisd': {
    status: true,
    method: "GET",
    request: {
      request: '/cluster/{nodeName}/stats/analysisd?pretty',
      params: {
        nodeName: {
          request: '/cluster/nodes?select=name'
        }
      }
    },
    params: {},
    interval: '0 */5 * * * *',
    index: {
      name: 'statistics',
      creation: 'w',
      mapping: '{"analysisd": ${data.affected_items[0]}, "apiName": ${apiName}, "nodeName": ${nodeName}, "cluster": "true"}'
    }
  }
};
exports.jobs = jobs;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJqb2JzIiwic3RhdHVzIiwibWV0aG9kIiwicmVxdWVzdCIsInBhcmFtcyIsImludGVydmFsIiwiaW5kZXgiLCJuYW1lIiwiY3JlYXRpb24iLCJtYXBwaW5nIiwibm9kZU5hbWUiLCJleHBvcnRzIl0sInNvdXJjZXMiOlsicHJlZGVmaW5lZC1qb2JzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IElJbmRleENvbmZpZ3VyYXRpb24gfSBmcm9tICcuL2luZGV4JztcblxuZXhwb3J0IGludGVyZmFjZSBJSm9iIHtcbiAgc3RhdHVzOiBib29sZWFuXG4gIG1ldGhvZDogJ0dFVCcgfCAnUE9TVCcgfCAnUFVUJyB8ICdERUxFVEUnXG4gIHJlcXVlc3Q6IHN0cmluZyB8IElSZXF1ZXN0XG4gIHBhcmFtczoge31cbiAgaW50ZXJ2YWw6IHN0cmluZ1xuICBpbmRleDogSUluZGV4Q29uZmlndXJhdGlvblxuICBhcGlzPzogc3RyaW5nW11cbn1cblxuZXhwb3J0IGludGVyZmFjZSBJUmVxdWVzdCB7XG4gIHJlcXVlc3Q6IHN0cmluZ1xuICBwYXJhbXM6IHtcbiAgICBba2V5OnN0cmluZ106IHtcbiAgICAgIHJlcXVlc3Q/OiBzdHJpbmdcbiAgICAgIGxpc3Q/OiBzdHJpbmdbXVxuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgY29uc3Qgam9iczoge1trZXk6c3RyaW5nXTogSUpvYn0gPSB7XG4gICdtYW5hZ2VyLXN0YXRzLXJlbW90ZWQnOiB7XG4gICAgc3RhdHVzOiB0cnVlLFxuICAgIG1ldGhvZDogXCJHRVRcIixcbiAgICByZXF1ZXN0OiAnL21hbmFnZXIvc3RhdHMvcmVtb3RlZD9wcmV0dHknLFxuICAgIHBhcmFtczoge30sXG4gICAgaW50ZXJ2YWw6ICcwICovNSAqICogKiAqJyxcbiAgICBpbmRleDoge1xuICAgICAgbmFtZTogJ3N0YXRpc3RpY3MnLFxuICAgICAgY3JlYXRpb246ICd3JyxcbiAgICAgIG1hcHBpbmc6ICd7XCJyZW1vdGVkXCI6ICR7ZGF0YS5hZmZlY3RlZF9pdGVtc1swXX0sIFwiYXBpTmFtZVwiOiAke2FwaU5hbWV9LCBcImNsdXN0ZXJcIjogXCJmYWxzZVwifScsXG4gICAgfVxuICB9LFxuICAnbWFuYWdlci1zdGF0cy1hbmFseXNpc2QnOiB7XG4gICAgc3RhdHVzOiB0cnVlLFxuICAgIG1ldGhvZDogXCJHRVRcIixcbiAgICByZXF1ZXN0OiAnL21hbmFnZXIvc3RhdHMvYW5hbHlzaXNkP3ByZXR0eScsXG4gICAgcGFyYW1zOiB7fSxcbiAgICBpbnRlcnZhbDogJzAgKi81ICogKiAqIConLFxuICAgIGluZGV4OiB7XG4gICAgICBuYW1lOiAnc3RhdGlzdGljcycsXG4gICAgICBjcmVhdGlvbjogJ3cnLFxuICAgICAgbWFwcGluZzogJ3tcImFuYWx5c2lzZFwiOiAke2RhdGEuYWZmZWN0ZWRfaXRlbXNbMF19LCBcImFwaU5hbWVcIjogJHthcGlOYW1lfSwgXCJjbHVzdGVyXCI6IFwiZmFsc2VcIn0nLFxuICAgIH1cbiAgfSxcbiAgJ2NsdXN0ZXItc3RhdHMtcmVtb3RlZCc6IHtcbiAgICBzdGF0dXM6IHRydWUsXG4gICAgbWV0aG9kOiBcIkdFVFwiLFxuICAgIHJlcXVlc3Q6IHtcbiAgICAgIHJlcXVlc3Q6ICcvY2x1c3Rlci97bm9kZU5hbWV9L3N0YXRzL3JlbW90ZWQ/cHJldHR5JyxcbiAgICAgIHBhcmFtczoge1xuICAgICAgICBub2RlTmFtZToge1xuICAgICAgICAgIHJlcXVlc3Q6ICcvY2x1c3Rlci9ub2Rlcz9zZWxlY3Q9bmFtZSdcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgcGFyYW1zOiB7fSxcbiAgICBpbnRlcnZhbDogJzAgKi81ICogKiAqIConLFxuICAgIGluZGV4OiB7XG4gICAgICBuYW1lOidzdGF0aXN0aWNzJyxcbiAgICAgIGNyZWF0aW9uOiAndycsXG4gICAgICBtYXBwaW5nOiAne1wicmVtb3RlZFwiOiAke2RhdGEuYWZmZWN0ZWRfaXRlbXNbMF19LCBcImFwaU5hbWVcIjogJHthcGlOYW1lfSwgXCJub2RlTmFtZVwiOiAke25vZGVOYW1lfSwgXCJjbHVzdGVyXCI6IFwidHJ1ZVwifScsXG4gICAgfVxuICB9LFxuICAnY2x1c3Rlci1zdGF0cy1hbmFseXNpc2QnOiB7XG4gICAgc3RhdHVzOiB0cnVlLFxuICAgIG1ldGhvZDogXCJHRVRcIixcbiAgICByZXF1ZXN0OiB7XG4gICAgICByZXF1ZXN0OiAnL2NsdXN0ZXIve25vZGVOYW1lfS9zdGF0cy9hbmFseXNpc2Q/cHJldHR5JyxcbiAgICAgIHBhcmFtczoge1xuICAgICAgICBub2RlTmFtZToge1xuICAgICAgICAgIHJlcXVlc3Q6ICcvY2x1c3Rlci9ub2Rlcz9zZWxlY3Q9bmFtZSdcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgcGFyYW1zOiB7fSxcbiAgICBpbnRlcnZhbDogJzAgKi81ICogKiAqIConLFxuICAgIGluZGV4OiB7XG4gICAgICBuYW1lOiAnc3RhdGlzdGljcycsXG4gICAgICBjcmVhdGlvbjogJ3cnLFxuICAgICAgbWFwcGluZzogJ3tcImFuYWx5c2lzZFwiOiAke2RhdGEuYWZmZWN0ZWRfaXRlbXNbMF19LCBcImFwaU5hbWVcIjogJHthcGlOYW1lfSwgXCJub2RlTmFtZVwiOiAke25vZGVOYW1lfSwgXCJjbHVzdGVyXCI6IFwidHJ1ZVwifScsXG4gICAgfVxuICB9LFxufSJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBc0JPLE1BQU1BLElBQTBCLEdBQUc7RUFDeEMsdUJBQXVCLEVBQUU7SUFDdkJDLE1BQU0sRUFBRSxJQUFJO0lBQ1pDLE1BQU0sRUFBRSxLQUFLO0lBQ2JDLE9BQU8sRUFBRSwrQkFBK0I7SUFDeENDLE1BQU0sRUFBRSxDQUFDLENBQUM7SUFDVkMsUUFBUSxFQUFFLGVBQWU7SUFDekJDLEtBQUssRUFBRTtNQUNMQyxJQUFJLEVBQUUsWUFBWTtNQUNsQkMsUUFBUSxFQUFFLEdBQUc7TUFDYkMsT0FBTyxFQUFFO0lBQ1g7RUFDRixDQUFDO0VBQ0QseUJBQXlCLEVBQUU7SUFDekJSLE1BQU0sRUFBRSxJQUFJO0lBQ1pDLE1BQU0sRUFBRSxLQUFLO0lBQ2JDLE9BQU8sRUFBRSxpQ0FBaUM7SUFDMUNDLE1BQU0sRUFBRSxDQUFDLENBQUM7SUFDVkMsUUFBUSxFQUFFLGVBQWU7SUFDekJDLEtBQUssRUFBRTtNQUNMQyxJQUFJLEVBQUUsWUFBWTtNQUNsQkMsUUFBUSxFQUFFLEdBQUc7TUFDYkMsT0FBTyxFQUFFO0lBQ1g7RUFDRixDQUFDO0VBQ0QsdUJBQXVCLEVBQUU7SUFDdkJSLE1BQU0sRUFBRSxJQUFJO0lBQ1pDLE1BQU0sRUFBRSxLQUFLO0lBQ2JDLE9BQU8sRUFBRTtNQUNQQSxPQUFPLEVBQUUsMENBQTBDO01BQ25EQyxNQUFNLEVBQUU7UUFDTk0sUUFBUSxFQUFFO1VBQ1JQLE9BQU8sRUFBRTtRQUNYO01BQ0Y7SUFDRixDQUFDO0lBQ0RDLE1BQU0sRUFBRSxDQUFDLENBQUM7SUFDVkMsUUFBUSxFQUFFLGVBQWU7SUFDekJDLEtBQUssRUFBRTtNQUNMQyxJQUFJLEVBQUMsWUFBWTtNQUNqQkMsUUFBUSxFQUFFLEdBQUc7TUFDYkMsT0FBTyxFQUFFO0lBQ1g7RUFDRixDQUFDO0VBQ0QseUJBQXlCLEVBQUU7SUFDekJSLE1BQU0sRUFBRSxJQUFJO0lBQ1pDLE1BQU0sRUFBRSxLQUFLO0lBQ2JDLE9BQU8sRUFBRTtNQUNQQSxPQUFPLEVBQUUsNENBQTRDO01BQ3JEQyxNQUFNLEVBQUU7UUFDTk0sUUFBUSxFQUFFO1VBQ1JQLE9BQU8sRUFBRTtRQUNYO01BQ0Y7SUFDRixDQUFDO0lBQ0RDLE1BQU0sRUFBRSxDQUFDLENBQUM7SUFDVkMsUUFBUSxFQUFFLGVBQWU7SUFDekJDLEtBQUssRUFBRTtNQUNMQyxJQUFJLEVBQUUsWUFBWTtNQUNsQkMsUUFBUSxFQUFFLEdBQUc7TUFDYkMsT0FBTyxFQUFFO0lBQ1g7RUFDRjtBQUNGLENBQUM7QUFBQUUsT0FBQSxDQUFBWCxJQUFBLEdBQUFBLElBQUEifQ==