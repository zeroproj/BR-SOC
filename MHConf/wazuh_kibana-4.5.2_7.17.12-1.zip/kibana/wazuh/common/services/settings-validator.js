"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SettingsValidator = void 0;
var _defineProperty2 = _interopRequireDefault(require("@babel/runtime/helpers/defineProperty"));
var _path = _interopRequireDefault(require("path"));
var _fileSize = require("./file-size");
class SettingsValidator {
  /**
   * Create a function that is a composition of the input validations
   * @param functions SettingsValidator functions to compose
   * @returns composed validation
   */
  static compose(...functions) {
    return function composedValidation(value) {
      for (const fn of functions) {
        const result = fn(value);
        if (typeof result === 'string' && result.length > 0) {
          return result;
        }
        ;
      }
      ;
    };
  }
  /**
   * Check the value is a string
   * @param value
   * @returns
   */
  static isString(value) {
    return typeof value === 'string' ? undefined : "Value is not a string.";
  }
  /**
   * Check the string has no spaces
   * @param value
   * @returns
   */
  static hasNoSpaces(value) {
    return /^\S*$/.test(value) ? undefined : "No whitespaces allowed.";
  }
  /**
   * Check the string has no empty
   * @param value
   * @returns
   */
  static isNotEmptyString(value) {
    if (typeof value === 'string') {
      if (value.length === 0) {
        return "Value can not be empty.";
      } else {
        return undefined;
      }
    }
    ;
  }
  /**
   * Check the number of string lines is limited
   * @param options
   * @returns
   */
  static multipleLinesString(options = {}) {
    return function (value) {
      const lines = value.split(/\r\n|\r|\n/).length;
      if (typeof options.maxLength !== 'undefined' && value.split('\n').some(line => line.length > options.maxLength)) {
        return `The maximum length of a line is ${options.maxLength} characters.`;
      }
      ;
      if (typeof options.minRows !== 'undefined' && lines < options.minRows) {
        return `The string should have more or ${options.minRows} line/s.`;
      }
      ;
      if (typeof options.maxRows !== 'undefined' && lines > options.maxRows) {
        return `The string should have less or equal to ${options.maxRows} line/s.`;
      }
      ;
    };
  }
  /**
   * Creates a function that checks the string does not contain some characters
   * @param invalidCharacters
   * @returns
   */
  static hasNotInvalidCharacters(...invalidCharacters) {
    return function (value) {
      return invalidCharacters.some(invalidCharacter => value.includes(invalidCharacter)) ? `It can't contain invalid characters: ${invalidCharacters.join(', ')}.` : undefined;
    };
  }
  /**
   * Creates a function that checks the string does not start with a substring
   * @param invalidStartingCharacters
   * @returns
   */
  static noStartsWithString(...invalidStartingCharacters) {
    return function (value) {
      return invalidStartingCharacters.some(invalidStartingCharacter => value.startsWith(invalidStartingCharacter)) ? `It can't start with: ${invalidStartingCharacters.join(', ')}.` : undefined;
    };
  }
  /**
   * Creates a function that checks the string is not equals to some values
   * @param invalidLiterals
   * @returns
   */
  static noLiteralString(...invalidLiterals) {
    return function (value) {
      return invalidLiterals.some(invalidLiteral => value === invalidLiteral) ? `It can't be: ${invalidLiterals.join(', ')}.` : undefined;
    };
  }
  /**
   * Check the value is a boolean
   * @param value
   * @returns
   */
  static isBoolean(value) {
    return typeof value === 'boolean' ? undefined : "It should be a boolean. Allowed values: true or false.";
  }
  /**
   * Check the value is a number between some optional limits
   * @param options
   * @returns
   */
  static number(options = {}) {
    return function (value) {
      if (options.integer && ((typeof value === 'string' ? ['.', ','].some(character => value.includes(character)) : false) || !Number.isInteger(Number(value)))) {
        return 'Number should be an integer.';
      }
      ;
      const valueNumber = typeof value === 'string' ? Number(value) : value;
      if (typeof options.min !== 'undefined' && valueNumber < options.min) {
        return `Value should be greater or equal than ${options.min}.`;
      }
      ;
      if (typeof options.max !== 'undefined' && valueNumber > options.max) {
        return `Value should be lower or equal than ${options.max}.`;
      }
      ;
    };
  }
  /**
   * Creates a function that checks if the value is a json
   * @param validateParsed Optional parameter to validate the parsed object
   * @returns
   */
  static json(validateParsed) {
    return function (value) {
      let jsonObject;
      // Try to parse the string as JSON
      try {
        jsonObject = JSON.parse(value);
      } catch (error) {
        return "Value can't be parsed. There is some error.";
      }
      ;
      return validateParsed ? validateParsed(jsonObject) : undefined;
    };
  }
  /**
   * Creates a function that checks is the value is an array and optionally validates each element
   * @param validationElement Optional function to validate each element of the array
   * @returns
   */
  static array(validationElement) {
    return function (value) {
      // Check the JSON is an array
      if (!Array.isArray(value)) {
        return 'Value is not a valid list.';
      }
      ;
      return validationElement ? value.reduce((accum, elementValue) => {
        if (accum) {
          return accum;
        }
        ;
        const resultValidationElement = validationElement(elementValue);
        if (resultValidationElement) {
          return resultValidationElement;
        }
        ;
        return accum;
      }, undefined) : undefined;
    };
  }
  /**
   * Creates a function that checks if the value is equal to list of values
   * @param literals Array of values to compare
   * @returns
   */
  static literal(literals) {
    return function (value) {
      return literals.includes(value) ? undefined : `Invalid value. Allowed values: ${literals.map(String).join(', ')}.`;
    };
  }
}
exports.SettingsValidator = SettingsValidator;
// FilePicker
(0, _defineProperty2.default)(SettingsValidator, "filePickerSupportedExtensions", extensions => options => {
  if (typeof options === 'undefined' || typeof options.name === 'undefined') {
    return;
  }
  if (!extensions.includes(_path.default.extname(options.name))) {
    return `File extension is invalid. Allowed file extensions: ${extensions.join(', ')}.`;
  }
  ;
});
/**
 * filePickerFileSize
 * @param options
 */
(0, _defineProperty2.default)(SettingsValidator, "filePickerFileSize", options => value => {
  if (typeof value === 'undefined' || typeof value.size === 'undefined') {
    return;
  }
  ;
  if (typeof options.minBytes !== 'undefined' && value.size <= options.minBytes) {
    return `File size should be greater or equal than ${options.meaningfulUnit ? (0, _fileSize.formatBytes)(options.minBytes) : `${options.minBytes} bytes`}.`;
  }
  ;
  if (typeof options.maxBytes !== 'undefined' && value.size >= options.maxBytes) {
    return `File size should be lower or equal than ${options.meaningfulUnit ? (0, _fileSize.formatBytes)(options.maxBytes) : `${options.maxBytes} bytes`}.`;
  }
  ;
});
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGF0aCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX2ZpbGVTaXplIiwiU2V0dGluZ3NWYWxpZGF0b3IiLCJjb21wb3NlIiwiZnVuY3Rpb25zIiwiY29tcG9zZWRWYWxpZGF0aW9uIiwidmFsdWUiLCJmbiIsInJlc3VsdCIsImxlbmd0aCIsImlzU3RyaW5nIiwidW5kZWZpbmVkIiwiaGFzTm9TcGFjZXMiLCJ0ZXN0IiwiaXNOb3RFbXB0eVN0cmluZyIsIm11bHRpcGxlTGluZXNTdHJpbmciLCJvcHRpb25zIiwibGluZXMiLCJzcGxpdCIsIm1heExlbmd0aCIsInNvbWUiLCJsaW5lIiwibWluUm93cyIsIm1heFJvd3MiLCJoYXNOb3RJbnZhbGlkQ2hhcmFjdGVycyIsImludmFsaWRDaGFyYWN0ZXJzIiwiaW52YWxpZENoYXJhY3RlciIsImluY2x1ZGVzIiwiam9pbiIsIm5vU3RhcnRzV2l0aFN0cmluZyIsImludmFsaWRTdGFydGluZ0NoYXJhY3RlcnMiLCJpbnZhbGlkU3RhcnRpbmdDaGFyYWN0ZXIiLCJzdGFydHNXaXRoIiwibm9MaXRlcmFsU3RyaW5nIiwiaW52YWxpZExpdGVyYWxzIiwiaW52YWxpZExpdGVyYWwiLCJpc0Jvb2xlYW4iLCJudW1iZXIiLCJpbnRlZ2VyIiwiY2hhcmFjdGVyIiwiTnVtYmVyIiwiaXNJbnRlZ2VyIiwidmFsdWVOdW1iZXIiLCJtaW4iLCJtYXgiLCJqc29uIiwidmFsaWRhdGVQYXJzZWQiLCJqc29uT2JqZWN0IiwiSlNPTiIsInBhcnNlIiwiZXJyb3IiLCJhcnJheSIsInZhbGlkYXRpb25FbGVtZW50IiwiQXJyYXkiLCJpc0FycmF5IiwicmVkdWNlIiwiYWNjdW0iLCJlbGVtZW50VmFsdWUiLCJyZXN1bHRWYWxpZGF0aW9uRWxlbWVudCIsImxpdGVyYWwiLCJsaXRlcmFscyIsIm1hcCIsIlN0cmluZyIsImV4cG9ydHMiLCJfZGVmaW5lUHJvcGVydHkyIiwiZGVmYXVsdCIsImV4dGVuc2lvbnMiLCJuYW1lIiwicGF0aCIsImV4dG5hbWUiLCJzaXplIiwibWluQnl0ZXMiLCJtZWFuaW5nZnVsVW5pdCIsImZvcm1hdEJ5dGVzIiwibWF4Qnl0ZXMiXSwic291cmNlcyI6WyJzZXR0aW5ncy12YWxpZGF0b3IudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHBhdGggZnJvbSAncGF0aCc7XG5pbXBvcnQgeyBmb3JtYXRCeXRlcyB9IGZyb20gJy4vZmlsZS1zaXplJztcblxuZXhwb3J0IGNsYXNzIFNldHRpbmdzVmFsaWRhdG9yIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIGZ1bmN0aW9uIHRoYXQgaXMgYSBjb21wb3NpdGlvbiBvZiB0aGUgaW5wdXQgdmFsaWRhdGlvbnNcbiAgICogQHBhcmFtIGZ1bmN0aW9ucyBTZXR0aW5nc1ZhbGlkYXRvciBmdW5jdGlvbnMgdG8gY29tcG9zZVxuICAgKiBAcmV0dXJucyBjb21wb3NlZCB2YWxpZGF0aW9uXG4gICAqL1xuICBzdGF0aWMgY29tcG9zZSguLi5mdW5jdGlvbnMpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gY29tcG9zZWRWYWxpZGF0aW9uKHZhbHVlKSB7XG4gICAgICBmb3IgKGNvbnN0IGZuIG9mIGZ1bmN0aW9ucykge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBmbih2YWx1ZSk7XG4gICAgICAgIGlmICh0eXBlb2YgcmVzdWx0ID09PSAnc3RyaW5nJyAmJiByZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH07XG4gICAgICB9O1xuICAgIH07XG4gIH07XG5cbiAgLyoqXG4gICAqIENoZWNrIHRoZSB2YWx1ZSBpcyBhIHN0cmluZ1xuICAgKiBAcGFyYW0gdmFsdWVcbiAgICogQHJldHVybnNcbiAgICovXG4gIHN0YXRpYyBpc1N0cmluZyh2YWx1ZTogdW5rbm93bik6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgPyB1bmRlZmluZWQgOiBcIlZhbHVlIGlzIG5vdCBhIHN0cmluZy5cIjtcbiAgfTtcblxuICAvKipcbiAgICogQ2hlY2sgdGhlIHN0cmluZyBoYXMgbm8gc3BhY2VzXG4gICAqIEBwYXJhbSB2YWx1ZVxuICAgKiBAcmV0dXJuc1xuICAgKi9cbiAgc3RhdGljIGhhc05vU3BhY2VzKHZhbHVlOiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiAvXlxcUyokLy50ZXN0KHZhbHVlKSA/IHVuZGVmaW5lZCA6IFwiTm8gd2hpdGVzcGFjZXMgYWxsb3dlZC5cIjtcbiAgfTtcblxuICAvKipcbiAgICogQ2hlY2sgdGhlIHN0cmluZyBoYXMgbm8gZW1wdHlcbiAgICogQHBhcmFtIHZhbHVlXG4gICAqIEByZXR1cm5zXG4gICAqL1xuICBzdGF0aWMgaXNOb3RFbXB0eVN0cmluZyh2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgICAgaWYgKHZhbHVlLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gXCJWYWx1ZSBjYW4gbm90IGJlIGVtcHR5LlwiXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgfVxuICAgIH07XG4gIH07XG5cbiAgLyoqXG4gICAqIENoZWNrIHRoZSBudW1iZXIgb2Ygc3RyaW5nIGxpbmVzIGlzIGxpbWl0ZWRcbiAgICogQHBhcmFtIG9wdGlvbnNcbiAgICogQHJldHVybnNcbiAgICovXG4gIHN0YXRpYyBtdWx0aXBsZUxpbmVzU3RyaW5nKG9wdGlvbnM6IHsgbWluUm93cz86IG51bWJlciwgbWF4Um93cz86IG51bWJlciwgbWF4TGVuZ3RoPzogbnVtYmVyIH0gPSB7fSkge1xuICAgIHJldHVybiBmdW5jdGlvbiAodmFsdWU6IG51bWJlcikge1xuICAgICAgY29uc3QgbGluZXMgPSB2YWx1ZS5zcGxpdCgvXFxyXFxufFxccnxcXG4vKS5sZW5ndGg7XG4gICAgICBpZiAodHlwZW9mIG9wdGlvbnMubWF4TGVuZ3RoICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZS5zcGxpdCgnXFxuJykuc29tZShsaW5lID0+IGxpbmUubGVuZ3RoID4gb3B0aW9ucy5tYXhMZW5ndGgpKSB7XG4gICAgICAgIHJldHVybiBgVGhlIG1heGltdW0gbGVuZ3RoIG9mIGEgbGluZSBpcyAke29wdGlvbnMubWF4TGVuZ3RofSBjaGFyYWN0ZXJzLmA7XG4gICAgICB9O1xuICAgICAgaWYgKHR5cGVvZiBvcHRpb25zLm1pblJvd3MgIT09ICd1bmRlZmluZWQnICYmIGxpbmVzIDwgb3B0aW9ucy5taW5Sb3dzKSB7XG4gICAgICAgIHJldHVybiBgVGhlIHN0cmluZyBzaG91bGQgaGF2ZSBtb3JlIG9yICR7b3B0aW9ucy5taW5Sb3dzfSBsaW5lL3MuYDtcbiAgICAgIH07XG4gICAgICBpZiAodHlwZW9mIG9wdGlvbnMubWF4Um93cyAhPT0gJ3VuZGVmaW5lZCcgJiYgbGluZXMgPiBvcHRpb25zLm1heFJvd3MpIHtcbiAgICAgICAgcmV0dXJuIGBUaGUgc3RyaW5nIHNob3VsZCBoYXZlIGxlc3Mgb3IgZXF1YWwgdG8gJHtvcHRpb25zLm1heFJvd3N9IGxpbmUvcy5gO1xuICAgICAgfTtcbiAgICB9XG4gIH07XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBmdW5jdGlvbiB0aGF0IGNoZWNrcyB0aGUgc3RyaW5nIGRvZXMgbm90IGNvbnRhaW4gc29tZSBjaGFyYWN0ZXJzXG4gICAqIEBwYXJhbSBpbnZhbGlkQ2hhcmFjdGVyc1xuICAgKiBAcmV0dXJuc1xuICAgKi9cbiAgc3RhdGljIGhhc05vdEludmFsaWRDaGFyYWN0ZXJzKC4uLmludmFsaWRDaGFyYWN0ZXJzOiBzdHJpbmdbXSkge1xuICAgIHJldHVybiBmdW5jdGlvbiAodmFsdWU6IHN0cmluZyk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICByZXR1cm4gaW52YWxpZENoYXJhY3RlcnMuc29tZShpbnZhbGlkQ2hhcmFjdGVyID0+IHZhbHVlLmluY2x1ZGVzKGludmFsaWRDaGFyYWN0ZXIpKVxuICAgICAgICA/IGBJdCBjYW4ndCBjb250YWluIGludmFsaWQgY2hhcmFjdGVyczogJHtpbnZhbGlkQ2hhcmFjdGVycy5qb2luKCcsICcpfS5gXG4gICAgICAgIDogdW5kZWZpbmVkO1xuICAgIH07XG4gIH07XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBmdW5jdGlvbiB0aGF0IGNoZWNrcyB0aGUgc3RyaW5nIGRvZXMgbm90IHN0YXJ0IHdpdGggYSBzdWJzdHJpbmdcbiAgICogQHBhcmFtIGludmFsaWRTdGFydGluZ0NoYXJhY3RlcnNcbiAgICogQHJldHVybnNcbiAgICovXG4gIHN0YXRpYyBub1N0YXJ0c1dpdGhTdHJpbmcoLi4uaW52YWxpZFN0YXJ0aW5nQ2hhcmFjdGVyczogc3RyaW5nW10pIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gKHZhbHVlOiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgICAgcmV0dXJuIGludmFsaWRTdGFydGluZ0NoYXJhY3RlcnMuc29tZShpbnZhbGlkU3RhcnRpbmdDaGFyYWN0ZXIgPT4gdmFsdWUuc3RhcnRzV2l0aChpbnZhbGlkU3RhcnRpbmdDaGFyYWN0ZXIpKVxuICAgICAgICA/IGBJdCBjYW4ndCBzdGFydCB3aXRoOiAke2ludmFsaWRTdGFydGluZ0NoYXJhY3RlcnMuam9pbignLCAnKX0uYFxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICB9O1xuICB9O1xuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgZnVuY3Rpb24gdGhhdCBjaGVja3MgdGhlIHN0cmluZyBpcyBub3QgZXF1YWxzIHRvIHNvbWUgdmFsdWVzXG4gICAqIEBwYXJhbSBpbnZhbGlkTGl0ZXJhbHNcbiAgICogQHJldHVybnNcbiAgICovXG4gIHN0YXRpYyBub0xpdGVyYWxTdHJpbmcoLi4uaW52YWxpZExpdGVyYWxzOiBzdHJpbmdbXSkge1xuICAgIHJldHVybiBmdW5jdGlvbiAodmFsdWU6IHN0cmluZyk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgICByZXR1cm4gaW52YWxpZExpdGVyYWxzLnNvbWUoaW52YWxpZExpdGVyYWwgPT4gdmFsdWUgPT09IGludmFsaWRMaXRlcmFsKVxuICAgICAgICA/IGBJdCBjYW4ndCBiZTogJHtpbnZhbGlkTGl0ZXJhbHMuam9pbignLCAnKX0uYFxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICB9O1xuICB9O1xuXG4gIC8qKlxuICAgKiBDaGVjayB0aGUgdmFsdWUgaXMgYSBib29sZWFuXG4gICAqIEBwYXJhbSB2YWx1ZVxuICAgKiBAcmV0dXJuc1xuICAgKi9cbiAgc3RhdGljIGlzQm9vbGVhbih2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbidcbiAgICAgID8gdW5kZWZpbmVkXG4gICAgICA6IFwiSXQgc2hvdWxkIGJlIGEgYm9vbGVhbi4gQWxsb3dlZCB2YWx1ZXM6IHRydWUgb3IgZmFsc2UuXCI7XG4gIH07XG5cbiAgLyoqXG4gICAqIENoZWNrIHRoZSB2YWx1ZSBpcyBhIG51bWJlciBiZXR3ZWVuIHNvbWUgb3B0aW9uYWwgbGltaXRzXG4gICAqIEBwYXJhbSBvcHRpb25zXG4gICAqIEByZXR1cm5zXG4gICAqL1xuICBzdGF0aWMgbnVtYmVyKG9wdGlvbnM6IHsgbWluPzogbnVtYmVyLCBtYXg/OiBudW1iZXIsIGludGVnZXI/OiBib29sZWFuIH0gPSB7fSkge1xuICAgIHJldHVybiBmdW5jdGlvbiAodmFsdWU6IG51bWJlcikge1xuICAgICAgaWYgKG9wdGlvbnMuaW50ZWdlclxuICAgICAgICAmJiAoXG4gICAgICAgICAgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgPyBbJy4nLCAnLCddLnNvbWUoY2hhcmFjdGVyID0+IHZhbHVlLmluY2x1ZGVzKGNoYXJhY3RlcikpIDogZmFsc2UpXG4gICAgICAgICAgfHwgIU51bWJlci5pc0ludGVnZXIoTnVtYmVyKHZhbHVlKSlcbiAgICAgICAgKVxuICAgICAgKSB7XG4gICAgICAgIHJldHVybiAnTnVtYmVyIHNob3VsZCBiZSBhbiBpbnRlZ2VyLidcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IHZhbHVlTnVtYmVyID0gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyA/IE51bWJlcih2YWx1ZSkgOiB2YWx1ZTtcblxuICAgICAgaWYgKHR5cGVvZiBvcHRpb25zLm1pbiAhPT0gJ3VuZGVmaW5lZCcgJiYgdmFsdWVOdW1iZXIgPCBvcHRpb25zLm1pbikge1xuICAgICAgICByZXR1cm4gYFZhbHVlIHNob3VsZCBiZSBncmVhdGVyIG9yIGVxdWFsIHRoYW4gJHtvcHRpb25zLm1pbn0uYDtcbiAgICAgIH07XG4gICAgICBpZiAodHlwZW9mIG9wdGlvbnMubWF4ICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZU51bWJlciA+IG9wdGlvbnMubWF4KSB7XG4gICAgICAgIHJldHVybiBgVmFsdWUgc2hvdWxkIGJlIGxvd2VyIG9yIGVxdWFsIHRoYW4gJHtvcHRpb25zLm1heH0uYDtcbiAgICAgIH07XG4gICAgfTtcbiAgfTtcblxuICAvKipcbiAgICogQ3JlYXRlcyBhIGZ1bmN0aW9uIHRoYXQgY2hlY2tzIGlmIHRoZSB2YWx1ZSBpcyBhIGpzb25cbiAgICogQHBhcmFtIHZhbGlkYXRlUGFyc2VkIE9wdGlvbmFsIHBhcmFtZXRlciB0byB2YWxpZGF0ZSB0aGUgcGFyc2VkIG9iamVjdFxuICAgKiBAcmV0dXJuc1xuICAgKi9cbiAgc3RhdGljIGpzb24odmFsaWRhdGVQYXJzZWQ6IChvYmplY3Q6IGFueSkgPT4gc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uICh2YWx1ZTogc3RyaW5nKSB7XG4gICAgICBsZXQganNvbk9iamVjdDtcbiAgICAgIC8vIFRyeSB0byBwYXJzZSB0aGUgc3RyaW5nIGFzIEpTT05cbiAgICAgIHRyeSB7XG4gICAgICAgIGpzb25PYmplY3QgPSBKU09OLnBhcnNlKHZhbHVlKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiBcIlZhbHVlIGNhbid0IGJlIHBhcnNlZC4gVGhlcmUgaXMgc29tZSBlcnJvci5cIjtcbiAgICAgIH07XG5cbiAgICAgIHJldHVybiB2YWxpZGF0ZVBhcnNlZCA/IHZhbGlkYXRlUGFyc2VkKGpzb25PYmplY3QpIDogdW5kZWZpbmVkO1xuICAgIH07XG4gIH07XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBmdW5jdGlvbiB0aGF0IGNoZWNrcyBpcyB0aGUgdmFsdWUgaXMgYW4gYXJyYXkgYW5kIG9wdGlvbmFsbHkgdmFsaWRhdGVzIGVhY2ggZWxlbWVudFxuICAgKiBAcGFyYW0gdmFsaWRhdGlvbkVsZW1lbnQgT3B0aW9uYWwgZnVuY3Rpb24gdG8gdmFsaWRhdGUgZWFjaCBlbGVtZW50IG9mIHRoZSBhcnJheVxuICAgKiBAcmV0dXJuc1xuICAgKi9cbiAgc3RhdGljIGFycmF5KHZhbGlkYXRpb25FbGVtZW50OiAoanNvbjogYW55KSA9PiBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gKHZhbHVlOiB1bmtub3duW10pIHtcbiAgICAgIC8vIENoZWNrIHRoZSBKU09OIGlzIGFuIGFycmF5XG4gICAgICBpZiAoIUFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIHJldHVybiAnVmFsdWUgaXMgbm90IGEgdmFsaWQgbGlzdC4nO1xuICAgICAgfTtcblxuICAgICAgcmV0dXJuIHZhbGlkYXRpb25FbGVtZW50XG4gICAgICAgID8gdmFsdWUucmVkdWNlKChhY2N1bSwgZWxlbWVudFZhbHVlKSA9PiB7XG4gICAgICAgICAgaWYgKGFjY3VtKSB7XG4gICAgICAgICAgICByZXR1cm4gYWNjdW07XG4gICAgICAgICAgfTtcblxuICAgICAgICAgIGNvbnN0IHJlc3VsdFZhbGlkYXRpb25FbGVtZW50ID0gdmFsaWRhdGlvbkVsZW1lbnQoZWxlbWVudFZhbHVlKTtcbiAgICAgICAgICBpZiAocmVzdWx0VmFsaWRhdGlvbkVsZW1lbnQpIHtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHRWYWxpZGF0aW9uRWxlbWVudDtcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgcmV0dXJuIGFjY3VtO1xuICAgICAgICB9LCB1bmRlZmluZWQpXG4gICAgICAgIDogdW5kZWZpbmVkO1xuICAgIH07XG4gIH07XG5cbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBmdW5jdGlvbiB0aGF0IGNoZWNrcyBpZiB0aGUgdmFsdWUgaXMgZXF1YWwgdG8gbGlzdCBvZiB2YWx1ZXNcbiAgICogQHBhcmFtIGxpdGVyYWxzIEFycmF5IG9mIHZhbHVlcyB0byBjb21wYXJlXG4gICAqIEByZXR1cm5zXG4gICAqL1xuICBzdGF0aWMgbGl0ZXJhbChsaXRlcmFsczogdW5rbm93bltdKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uICh2YWx1ZTogYW55KTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICAgIHJldHVybiBsaXRlcmFscy5pbmNsdWRlcyh2YWx1ZSkgPyB1bmRlZmluZWQgOiBgSW52YWxpZCB2YWx1ZS4gQWxsb3dlZCB2YWx1ZXM6ICR7bGl0ZXJhbHMubWFwKFN0cmluZykuam9pbignLCAnKX0uYDtcbiAgICB9O1xuICB9O1xuXG4gIC8vIEZpbGVQaWNrZXJcbiAgc3RhdGljIGZpbGVQaWNrZXJTdXBwb3J0ZWRFeHRlbnNpb25zID0gKGV4dGVuc2lvbnM6IHN0cmluZ1tdKSA9PiAob3B0aW9uczogeyBuYW1lOiBzdHJpbmcgfSkgPT4ge1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIG9wdGlvbnMubmFtZSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFleHRlbnNpb25zLmluY2x1ZGVzKHBhdGguZXh0bmFtZShvcHRpb25zLm5hbWUpKSkge1xuICAgICAgcmV0dXJuIGBGaWxlIGV4dGVuc2lvbiBpcyBpbnZhbGlkLiBBbGxvd2VkIGZpbGUgZXh0ZW5zaW9uczogJHtleHRlbnNpb25zLmpvaW4oJywgJyl9LmA7XG4gICAgfTtcbiAgfTtcblxuICAvKipcbiAgICogZmlsZVBpY2tlckZpbGVTaXplXG4gICAqIEBwYXJhbSBvcHRpb25zXG4gICAqL1xuICBzdGF0aWMgZmlsZVBpY2tlckZpbGVTaXplID0gKG9wdGlvbnM6IHsgbWF4Qnl0ZXM/OiBudW1iZXIsIG1pbkJ5dGVzPzogbnVtYmVyLCBtZWFuaW5nZnVsVW5pdD86IGJvb2xlYW4gfSkgPT4gKHZhbHVlOiB7IHNpemU6IG51bWJlciB9KSA9PiB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3VuZGVmaW5lZCcgfHwgdHlwZW9mIHZhbHVlLnNpemUgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICByZXR1cm47XG4gICAgfTtcbiAgICBpZiAodHlwZW9mIG9wdGlvbnMubWluQnl0ZXMgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlLnNpemUgPD0gb3B0aW9ucy5taW5CeXRlcykge1xuICAgICAgcmV0dXJuIGBGaWxlIHNpemUgc2hvdWxkIGJlIGdyZWF0ZXIgb3IgZXF1YWwgdGhhbiAke29wdGlvbnMubWVhbmluZ2Z1bFVuaXQgPyBmb3JtYXRCeXRlcyhvcHRpb25zLm1pbkJ5dGVzKSA6IGAke29wdGlvbnMubWluQnl0ZXN9IGJ5dGVzYH0uYDtcbiAgICB9O1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5tYXhCeXRlcyAhPT0gJ3VuZGVmaW5lZCcgJiYgdmFsdWUuc2l6ZSA+PSBvcHRpb25zLm1heEJ5dGVzKSB7XG4gICAgICByZXR1cm4gYEZpbGUgc2l6ZSBzaG91bGQgYmUgbG93ZXIgb3IgZXF1YWwgdGhhbiAke29wdGlvbnMubWVhbmluZ2Z1bFVuaXQgPyBmb3JtYXRCeXRlcyhvcHRpb25zLm1heEJ5dGVzKSA6IGAke29wdGlvbnMubWF4Qnl0ZXN9IGJ5dGVzYH0uYDtcbiAgICB9O1xuICB9O1xufTtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFBQSxLQUFBLEdBQUFDLHNCQUFBLENBQUFDLE9BQUE7QUFDQSxJQUFBQyxTQUFBLEdBQUFELE9BQUE7QUFFTyxNQUFNRSxpQkFBaUIsQ0FBQztFQUM3QjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBT0MsT0FBT0EsQ0FBQyxHQUFHQyxTQUFTLEVBQUU7SUFDM0IsT0FBTyxTQUFTQyxrQkFBa0JBLENBQUNDLEtBQUssRUFBRTtNQUN4QyxLQUFLLE1BQU1DLEVBQUUsSUFBSUgsU0FBUyxFQUFFO1FBQzFCLE1BQU1JLE1BQU0sR0FBR0QsRUFBRSxDQUFDRCxLQUFLLENBQUM7UUFDeEIsSUFBSSxPQUFPRSxNQUFNLEtBQUssUUFBUSxJQUFJQSxNQUFNLENBQUNDLE1BQU0sR0FBRyxDQUFDLEVBQUU7VUFDbkQsT0FBT0QsTUFBTTtRQUNmO1FBQUM7TUFDSDtNQUFDO0lBQ0gsQ0FBQztFQUNIO0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU9FLFFBQVFBLENBQUNKLEtBQWMsRUFBc0I7SUFDbEQsT0FBTyxPQUFPQSxLQUFLLEtBQUssUUFBUSxHQUFHSyxTQUFTLEdBQUcsd0JBQXdCO0VBQ3pFO0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU9DLFdBQVdBLENBQUNOLEtBQWEsRUFBc0I7SUFDcEQsT0FBTyxPQUFPLENBQUNPLElBQUksQ0FBQ1AsS0FBSyxDQUFDLEdBQUdLLFNBQVMsR0FBRyx5QkFBeUI7RUFDcEU7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBT0csZ0JBQWdCQSxDQUFDUixLQUFhLEVBQXNCO0lBQ3pELElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsRUFBRTtNQUM3QixJQUFJQSxLQUFLLENBQUNHLE1BQU0sS0FBSyxDQUFDLEVBQUU7UUFDdEIsT0FBTyx5QkFBeUI7TUFDbEMsQ0FBQyxNQUFNO1FBQ0wsT0FBT0UsU0FBUztNQUNsQjtJQUNGO0lBQUM7RUFDSDtFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFDRSxPQUFPSSxtQkFBbUJBLENBQUNDLE9BQW1FLEdBQUcsQ0FBQyxDQUFDLEVBQUU7SUFDbkcsT0FBTyxVQUFVVixLQUFhLEVBQUU7TUFDOUIsTUFBTVcsS0FBSyxHQUFHWCxLQUFLLENBQUNZLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQ1QsTUFBTTtNQUM5QyxJQUFJLE9BQU9PLE9BQU8sQ0FBQ0csU0FBUyxLQUFLLFdBQVcsSUFBSWIsS0FBSyxDQUFDWSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUNFLElBQUksQ0FBQ0MsSUFBSSxJQUFJQSxJQUFJLENBQUNaLE1BQU0sR0FBR08sT0FBTyxDQUFDRyxTQUFTLENBQUMsRUFBRTtRQUMvRyxPQUFRLG1DQUFrQ0gsT0FBTyxDQUFDRyxTQUFVLGNBQWE7TUFDM0U7TUFBQztNQUNELElBQUksT0FBT0gsT0FBTyxDQUFDTSxPQUFPLEtBQUssV0FBVyxJQUFJTCxLQUFLLEdBQUdELE9BQU8sQ0FBQ00sT0FBTyxFQUFFO1FBQ3JFLE9BQVEsa0NBQWlDTixPQUFPLENBQUNNLE9BQVEsVUFBUztNQUNwRTtNQUFDO01BQ0QsSUFBSSxPQUFPTixPQUFPLENBQUNPLE9BQU8sS0FBSyxXQUFXLElBQUlOLEtBQUssR0FBR0QsT0FBTyxDQUFDTyxPQUFPLEVBQUU7UUFDckUsT0FBUSwyQ0FBMENQLE9BQU8sQ0FBQ08sT0FBUSxVQUFTO01BQzdFO01BQUM7SUFDSCxDQUFDO0VBQ0g7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBT0MsdUJBQXVCQSxDQUFDLEdBQUdDLGlCQUEyQixFQUFFO0lBQzdELE9BQU8sVUFBVW5CLEtBQWEsRUFBc0I7TUFDbEQsT0FBT21CLGlCQUFpQixDQUFDTCxJQUFJLENBQUNNLGdCQUFnQixJQUFJcEIsS0FBSyxDQUFDcUIsUUFBUSxDQUFDRCxnQkFBZ0IsQ0FBQyxDQUFDLEdBQzlFLHdDQUF1Q0QsaUJBQWlCLENBQUNHLElBQUksQ0FBQyxJQUFJLENBQUUsR0FBRSxHQUN2RWpCLFNBQVM7SUFDZixDQUFDO0VBQ0g7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBT2tCLGtCQUFrQkEsQ0FBQyxHQUFHQyx5QkFBbUMsRUFBRTtJQUNoRSxPQUFPLFVBQVV4QixLQUFhLEVBQXNCO01BQ2xELE9BQU93Qix5QkFBeUIsQ0FBQ1YsSUFBSSxDQUFDVyx3QkFBd0IsSUFBSXpCLEtBQUssQ0FBQzBCLFVBQVUsQ0FBQ0Qsd0JBQXdCLENBQUMsQ0FBQyxHQUN4Ryx3QkFBdUJELHlCQUF5QixDQUFDRixJQUFJLENBQUMsSUFBSSxDQUFFLEdBQUUsR0FDL0RqQixTQUFTO0lBQ2YsQ0FBQztFQUNIO0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU9zQixlQUFlQSxDQUFDLEdBQUdDLGVBQXlCLEVBQUU7SUFDbkQsT0FBTyxVQUFVNUIsS0FBYSxFQUFzQjtNQUNsRCxPQUFPNEIsZUFBZSxDQUFDZCxJQUFJLENBQUNlLGNBQWMsSUFBSTdCLEtBQUssS0FBSzZCLGNBQWMsQ0FBQyxHQUNsRSxnQkFBZUQsZUFBZSxDQUFDTixJQUFJLENBQUMsSUFBSSxDQUFFLEdBQUUsR0FDN0NqQixTQUFTO0lBQ2YsQ0FBQztFQUNIO0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU95QixTQUFTQSxDQUFDOUIsS0FBYSxFQUFzQjtJQUNsRCxPQUFPLE9BQU9BLEtBQUssS0FBSyxTQUFTLEdBQzdCSyxTQUFTLEdBQ1Qsd0RBQXdEO0VBQzlEO0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU8wQixNQUFNQSxDQUFDckIsT0FBMEQsR0FBRyxDQUFDLENBQUMsRUFBRTtJQUM3RSxPQUFPLFVBQVVWLEtBQWEsRUFBRTtNQUM5QixJQUFJVSxPQUFPLENBQUNzQixPQUFPLEtBRWYsQ0FBQyxPQUFPaEMsS0FBSyxLQUFLLFFBQVEsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQ2MsSUFBSSxDQUFDbUIsU0FBUyxJQUFJakMsS0FBSyxDQUFDcUIsUUFBUSxDQUFDWSxTQUFTLENBQUMsQ0FBQyxHQUFHLEtBQUssS0FDekYsQ0FBQ0MsTUFBTSxDQUFDQyxTQUFTLENBQUNELE1BQU0sQ0FBQ2xDLEtBQUssQ0FBQyxDQUFDLENBQ3BDLEVBQ0Q7UUFDQSxPQUFPLDhCQUE4QjtNQUN2QztNQUFDO01BRUQsTUFBTW9DLFdBQVcsR0FBRyxPQUFPcEMsS0FBSyxLQUFLLFFBQVEsR0FBR2tDLE1BQU0sQ0FBQ2xDLEtBQUssQ0FBQyxHQUFHQSxLQUFLO01BRXJFLElBQUksT0FBT1UsT0FBTyxDQUFDMkIsR0FBRyxLQUFLLFdBQVcsSUFBSUQsV0FBVyxHQUFHMUIsT0FBTyxDQUFDMkIsR0FBRyxFQUFFO1FBQ25FLE9BQVEseUNBQXdDM0IsT0FBTyxDQUFDMkIsR0FBSSxHQUFFO01BQ2hFO01BQUM7TUFDRCxJQUFJLE9BQU8zQixPQUFPLENBQUM0QixHQUFHLEtBQUssV0FBVyxJQUFJRixXQUFXLEdBQUcxQixPQUFPLENBQUM0QixHQUFHLEVBQUU7UUFDbkUsT0FBUSx1Q0FBc0M1QixPQUFPLENBQUM0QixHQUFJLEdBQUU7TUFDOUQ7TUFBQztJQUNILENBQUM7RUFDSDtFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFDRSxPQUFPQyxJQUFJQSxDQUFDQyxjQUFtRCxFQUFFO0lBQy9ELE9BQU8sVUFBVXhDLEtBQWEsRUFBRTtNQUM5QixJQUFJeUMsVUFBVTtNQUNkO01BQ0EsSUFBSTtRQUNGQSxVQUFVLEdBQUdDLElBQUksQ0FBQ0MsS0FBSyxDQUFDM0MsS0FBSyxDQUFDO01BQ2hDLENBQUMsQ0FBQyxPQUFPNEMsS0FBSyxFQUFFO1FBQ2QsT0FBTyw2Q0FBNkM7TUFDdEQ7TUFBQztNQUVELE9BQU9KLGNBQWMsR0FBR0EsY0FBYyxDQUFDQyxVQUFVLENBQUMsR0FBR3BDLFNBQVM7SUFDaEUsQ0FBQztFQUNIO0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU93QyxLQUFLQSxDQUFDQyxpQkFBb0QsRUFBRTtJQUNqRSxPQUFPLFVBQVU5QyxLQUFnQixFQUFFO01BQ2pDO01BQ0EsSUFBSSxDQUFDK0MsS0FBSyxDQUFDQyxPQUFPLENBQUNoRCxLQUFLLENBQUMsRUFBRTtRQUN6QixPQUFPLDRCQUE0QjtNQUNyQztNQUFDO01BRUQsT0FBTzhDLGlCQUFpQixHQUNwQjlDLEtBQUssQ0FBQ2lELE1BQU0sQ0FBQyxDQUFDQyxLQUFLLEVBQUVDLFlBQVksS0FBSztRQUN0QyxJQUFJRCxLQUFLLEVBQUU7VUFDVCxPQUFPQSxLQUFLO1FBQ2Q7UUFBQztRQUVELE1BQU1FLHVCQUF1QixHQUFHTixpQkFBaUIsQ0FBQ0ssWUFBWSxDQUFDO1FBQy9ELElBQUlDLHVCQUF1QixFQUFFO1VBQzNCLE9BQU9BLHVCQUF1QjtRQUNoQztRQUFDO1FBRUQsT0FBT0YsS0FBSztNQUNkLENBQUMsRUFBRTdDLFNBQVMsQ0FBQyxHQUNYQSxTQUFTO0lBQ2YsQ0FBQztFQUNIO0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU9nRCxPQUFPQSxDQUFDQyxRQUFtQixFQUFFO0lBQ2xDLE9BQU8sVUFBVXRELEtBQVUsRUFBc0I7TUFDL0MsT0FBT3NELFFBQVEsQ0FBQ2pDLFFBQVEsQ0FBQ3JCLEtBQUssQ0FBQyxHQUFHSyxTQUFTLEdBQUksa0NBQWlDaUQsUUFBUSxDQUFDQyxHQUFHLENBQUNDLE1BQU0sQ0FBQyxDQUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBRSxHQUFFO0lBQ3BILENBQUM7RUFDSDtBQTJCRjtBQUFDbUMsT0FBQSxDQUFBN0QsaUJBQUEsR0FBQUEsaUJBQUE7QUF6QkM7QUFBQSxJQUFBOEQsZ0JBQUEsQ0FBQUMsT0FBQSxFQTlNVy9ELGlCQUFpQixtQ0ErTVlnRSxVQUFvQixJQUFNbEQsT0FBeUIsSUFBSztFQUM5RixJQUFJLE9BQU9BLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBT0EsT0FBTyxDQUFDbUQsSUFBSSxLQUFLLFdBQVcsRUFBRTtJQUN6RTtFQUNGO0VBQ0EsSUFBSSxDQUFDRCxVQUFVLENBQUN2QyxRQUFRLENBQUN5QyxhQUFJLENBQUNDLE9BQU8sQ0FBQ3JELE9BQU8sQ0FBQ21ELElBQUksQ0FBQyxDQUFDLEVBQUU7SUFDcEQsT0FBUSx1REFBc0RELFVBQVUsQ0FBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUUsR0FBRTtFQUN4RjtFQUFDO0FBQ0gsQ0FBQztBQUVEO0FBQ0Y7QUFDQTtBQUNBO0FBSEUsSUFBQW9DLGdCQUFBLENBQUFDLE9BQUEsRUF4TlcvRCxpQkFBaUIsd0JBNE5DYyxPQUEyRSxJQUFNVixLQUF1QixJQUFLO0VBQ3hJLElBQUksT0FBT0EsS0FBSyxLQUFLLFdBQVcsSUFBSSxPQUFPQSxLQUFLLENBQUNnRSxJQUFJLEtBQUssV0FBVyxFQUFFO0lBQ3JFO0VBQ0Y7RUFBQztFQUNELElBQUksT0FBT3RELE9BQU8sQ0FBQ3VELFFBQVEsS0FBSyxXQUFXLElBQUlqRSxLQUFLLENBQUNnRSxJQUFJLElBQUl0RCxPQUFPLENBQUN1RCxRQUFRLEVBQUU7SUFDN0UsT0FBUSw2Q0FBNEN2RCxPQUFPLENBQUN3RCxjQUFjLEdBQUcsSUFBQUMscUJBQVcsRUFBQ3pELE9BQU8sQ0FBQ3VELFFBQVEsQ0FBQyxHQUFJLEdBQUV2RCxPQUFPLENBQUN1RCxRQUFTLFFBQVEsR0FBRTtFQUM3STtFQUFDO0VBQ0QsSUFBSSxPQUFPdkQsT0FBTyxDQUFDMEQsUUFBUSxLQUFLLFdBQVcsSUFBSXBFLEtBQUssQ0FBQ2dFLElBQUksSUFBSXRELE9BQU8sQ0FBQzBELFFBQVEsRUFBRTtJQUM3RSxPQUFRLDJDQUEwQzFELE9BQU8sQ0FBQ3dELGNBQWMsR0FBRyxJQUFBQyxxQkFBVyxFQUFDekQsT0FBTyxDQUFDMEQsUUFBUSxDQUFDLEdBQUksR0FBRTFELE9BQU8sQ0FBQzBELFFBQVMsUUFBUSxHQUFFO0VBQzNJO0VBQUM7QUFDSCxDQUFDO0FBQ0YifQ==