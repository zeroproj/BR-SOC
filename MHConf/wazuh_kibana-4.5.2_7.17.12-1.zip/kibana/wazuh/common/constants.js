"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WAZUH_STATISTICS_DEFAULT_CRON_FREQ = exports.WAZUH_STATISTICS_DEFAULT_CREATION = exports.WAZUH_SECURITY_PLUGIN_XPACK_SECURITY = exports.WAZUH_SECURITY_PLUGIN_OPEN_DISTRO_FOR_ELASTICSEARCH = exports.WAZUH_SECURITY_PLUGINS = exports.WAZUH_SAMPLE_ALERT_PREFIX = exports.WAZUH_SAMPLE_ALERTS_INDEX_SHARDS = exports.WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS = exports.WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS = exports.WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION = exports.WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY = exports.WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING = exports.WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS = exports.WAZUH_ROLE_ADMINISTRATOR_NAME = exports.WAZUH_ROLE_ADMINISTRATOR_ID = exports.WAZUH_QUEUE_CRON_FREQ = exports.WAZUH_PLUGIN_PLATFORM_TEMPLATE_NAME = exports.WAZUH_PLUGIN_PLATFORM_SETTING_TIME_FILTER = exports.WAZUH_PLUGIN_PLATFORM_SETTING_METAFIELDS = exports.WAZUH_PLUGIN_PLATFORM_SETTING_MAX_BUCKETS = exports.WAZUH_MONITORING_TEMPLATE_NAME = exports.WAZUH_MONITORING_PREFIX = exports.WAZUH_MONITORING_PATTERN = exports.WAZUH_MONITORING_DEFAULT_INDICES_SHARDS = exports.WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS = exports.WAZUH_MONITORING_DEFAULT_FREQUENCY = exports.WAZUH_MONITORING_DEFAULT_ENABLED = exports.WAZUH_MONITORING_DEFAULT_CRON_FREQ = exports.WAZUH_MONITORING_DEFAULT_CREATION = exports.WAZUH_MODULES_ID = exports.WAZUH_MENU_TOOLS_SECTIONS_ID = exports.WAZUH_MENU_SETTINGS_SECTIONS_ID = exports.WAZUH_MENU_SECURITY_SECTIONS_ID = exports.WAZUH_MENU_MANAGEMENT_SECTIONS_ID = exports.WAZUH_LINK_SLACK = exports.WAZUH_LINK_GOOGLE_GROUPS = exports.WAZUH_LINK_GITHUB = exports.WAZUH_INDEX_TYPE_STATISTICS = exports.WAZUH_INDEX_TYPE_MONITORING = exports.WAZUH_INDEX_TYPE_ALERTS = exports.WAZUH_ERROR_DAEMONS_NOT_READY = exports.WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH = exports.WAZUH_DATA_LOGS_RAW_PATH = exports.WAZUH_DATA_LOGS_RAW_FILENAME = exports.WAZUH_DATA_LOGS_PLAIN_PATH = exports.WAZUH_DATA_LOGS_PLAIN_FILENAME = exports.WAZUH_DATA_LOGS_DIRECTORY_PATH = exports.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH = exports.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH = exports.WAZUH_DATA_CONFIG_REGISTRY_PATH = exports.WAZUH_DATA_CONFIG_DIRECTORY_PATH = exports.WAZUH_DATA_CONFIG_APP_PATH = exports.WAZUH_DATA_ABSOLUTE_PATH = exports.WAZUH_CONFIGURATION_CACHE_TIME = exports.WAZUH_API_RESERVED_ID_LOWER_THAN = exports.WAZUH_ALERTS_PREFIX = exports.WAZUH_ALERTS_PATTERN = exports.WAZUH_AGENTS_OS_TYPE = exports.UI_TOAST_COLOR = exports.UI_ORDER_AGENT_STATUS = exports.UI_LOGGER_LEVELS = exports.UI_LABEL_NAME_AGENT_STATUS = exports.UI_COLOR_AGENT_STATUS = exports.SettingCategory = exports.REPORTS_PRIMARY_COLOR = exports.REPORTS_PAGE_HEADER_TEXT = exports.REPORTS_PAGE_FOOTER_TEXT = exports.REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH = exports.PLUGIN_VERSION_SHORT = exports.PLUGIN_VERSION = exports.PLUGIN_SETTINGS_CATEGORIES = exports.PLUGIN_SETTINGS = exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_UPGRADE_PLATFORM = exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_TROUBLESHOOTING = exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_APP_CONFIGURATION = exports.PLUGIN_PLATFORM_URL_GUIDE_TITLE = exports.PLUGIN_PLATFORM_URL_GUIDE = exports.PLUGIN_PLATFORM_SETTING_NAME_TIME_FILTER = exports.PLUGIN_PLATFORM_SETTING_NAME_METAFIELDS = exports.PLUGIN_PLATFORM_SETTING_NAME_MAX_BUCKETS = exports.PLUGIN_PLATFORM_REQUEST_HEADERS = exports.PLUGIN_PLATFORM_NAME = exports.PLUGIN_PLATFORM_INSTALLATION_USER_GROUP = exports.PLUGIN_PLATFORM_INSTALLATION_USER = exports.PLUGIN_PLATFORM_BASE_INSTALLATION_PATH = exports.PLUGIN_APP_NAME = exports.MODULE_SCA_CHECK_RESULT_LABEL = exports.MAX_MB_LOG_FILES = exports.HTTP_STATUS_CODES = exports.HEALTH_CHECK_REDIRECTION_TIME = exports.HEALTH_CHECK = exports.EpluginSettingType = exports.ELASTIC_NAME = exports.DOCUMENTATION_WEB_BASE_URL = exports.CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES = exports.AUTHORIZED_AGENTS = exports.ASSETS_PUBLIC_URL = exports.ASSETS_BASE_URL_PREFIX = exports.API_NAME_AGENT_STATUS = exports.AGENT_SYNCED_STATUS = void 0;
exports.WAZUH_UI_LOGS_RAW_PATH = exports.WAZUH_UI_LOGS_RAW_FILENAME = exports.WAZUH_UI_LOGS_PLAIN_PATH = exports.WAZUH_UI_LOGS_PLAIN_FILENAME = exports.WAZUH_STATISTICS_TEMPLATE_NAME = exports.WAZUH_STATISTICS_PATTERN = exports.WAZUH_STATISTICS_DEFAULT_STATUS = exports.WAZUH_STATISTICS_DEFAULT_PREFIX = exports.WAZUH_STATISTICS_DEFAULT_NAME = exports.WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS = exports.WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS = exports.WAZUH_STATISTICS_DEFAULT_FREQUENCY = void 0;
var _path = _interopRequireDefault(require("path"));
var _package = require("../package.json");
var _nodeCron = require("node-cron");
var _settingsValidator = require("../common/services/settings-validator");
/*
 * Wazuh app - Wazuh Constants file
 * Copyright (C) 2015-2022 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */

// Plugin
const PLUGIN_VERSION = _package.version;
exports.PLUGIN_VERSION = PLUGIN_VERSION;
const PLUGIN_VERSION_SHORT = _package.version.split('.').splice(0, 2).join('.');

// Index patterns - Wazuh alerts
exports.PLUGIN_VERSION_SHORT = PLUGIN_VERSION_SHORT;
const WAZUH_INDEX_TYPE_ALERTS = 'alerts';
exports.WAZUH_INDEX_TYPE_ALERTS = WAZUH_INDEX_TYPE_ALERTS;
const WAZUH_ALERTS_PREFIX = 'wazuh-alerts-';
exports.WAZUH_ALERTS_PREFIX = WAZUH_ALERTS_PREFIX;
const WAZUH_ALERTS_PATTERN = 'wazuh-alerts-*';

// Job - Wazuh monitoring
exports.WAZUH_ALERTS_PATTERN = WAZUH_ALERTS_PATTERN;
const WAZUH_INDEX_TYPE_MONITORING = "monitoring";
exports.WAZUH_INDEX_TYPE_MONITORING = WAZUH_INDEX_TYPE_MONITORING;
const WAZUH_MONITORING_PREFIX = "wazuh-monitoring-";
exports.WAZUH_MONITORING_PREFIX = WAZUH_MONITORING_PREFIX;
const WAZUH_MONITORING_PATTERN = "wazuh-monitoring-*";
exports.WAZUH_MONITORING_PATTERN = WAZUH_MONITORING_PATTERN;
const WAZUH_MONITORING_TEMPLATE_NAME = "wazuh-agent";
exports.WAZUH_MONITORING_TEMPLATE_NAME = WAZUH_MONITORING_TEMPLATE_NAME;
const WAZUH_MONITORING_DEFAULT_INDICES_SHARDS = 1;
exports.WAZUH_MONITORING_DEFAULT_INDICES_SHARDS = WAZUH_MONITORING_DEFAULT_INDICES_SHARDS;
const WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS = 0;
exports.WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS = WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS;
const WAZUH_MONITORING_DEFAULT_CREATION = 'w';
exports.WAZUH_MONITORING_DEFAULT_CREATION = WAZUH_MONITORING_DEFAULT_CREATION;
const WAZUH_MONITORING_DEFAULT_ENABLED = true;
exports.WAZUH_MONITORING_DEFAULT_ENABLED = WAZUH_MONITORING_DEFAULT_ENABLED;
const WAZUH_MONITORING_DEFAULT_FREQUENCY = 900;
exports.WAZUH_MONITORING_DEFAULT_FREQUENCY = WAZUH_MONITORING_DEFAULT_FREQUENCY;
const WAZUH_MONITORING_DEFAULT_CRON_FREQ = '0 * * * * *';

// Job - Wazuh statistics
exports.WAZUH_MONITORING_DEFAULT_CRON_FREQ = WAZUH_MONITORING_DEFAULT_CRON_FREQ;
const WAZUH_INDEX_TYPE_STATISTICS = "statistics";
exports.WAZUH_INDEX_TYPE_STATISTICS = WAZUH_INDEX_TYPE_STATISTICS;
const WAZUH_STATISTICS_DEFAULT_PREFIX = "wazuh";
exports.WAZUH_STATISTICS_DEFAULT_PREFIX = WAZUH_STATISTICS_DEFAULT_PREFIX;
const WAZUH_STATISTICS_DEFAULT_NAME = "statistics";
exports.WAZUH_STATISTICS_DEFAULT_NAME = WAZUH_STATISTICS_DEFAULT_NAME;
const WAZUH_STATISTICS_PATTERN = `${WAZUH_STATISTICS_DEFAULT_PREFIX}-${WAZUH_STATISTICS_DEFAULT_NAME}-*`;
exports.WAZUH_STATISTICS_PATTERN = WAZUH_STATISTICS_PATTERN;
const WAZUH_STATISTICS_TEMPLATE_NAME = `${WAZUH_STATISTICS_DEFAULT_PREFIX}-${WAZUH_STATISTICS_DEFAULT_NAME}`;
exports.WAZUH_STATISTICS_TEMPLATE_NAME = WAZUH_STATISTICS_TEMPLATE_NAME;
const WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS = 1;
exports.WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS = WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS;
const WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS = 0;
exports.WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS = WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS;
const WAZUH_STATISTICS_DEFAULT_CREATION = 'w';
exports.WAZUH_STATISTICS_DEFAULT_CREATION = WAZUH_STATISTICS_DEFAULT_CREATION;
const WAZUH_STATISTICS_DEFAULT_STATUS = true;
exports.WAZUH_STATISTICS_DEFAULT_STATUS = WAZUH_STATISTICS_DEFAULT_STATUS;
const WAZUH_STATISTICS_DEFAULT_FREQUENCY = 900;
exports.WAZUH_STATISTICS_DEFAULT_FREQUENCY = WAZUH_STATISTICS_DEFAULT_FREQUENCY;
const WAZUH_STATISTICS_DEFAULT_CRON_FREQ = '0 */5 * * * *';

// Job - Wazuh initialize
exports.WAZUH_STATISTICS_DEFAULT_CRON_FREQ = WAZUH_STATISTICS_DEFAULT_CRON_FREQ;
const WAZUH_PLUGIN_PLATFORM_TEMPLATE_NAME = 'wazuh-kibana';

// Permissions
exports.WAZUH_PLUGIN_PLATFORM_TEMPLATE_NAME = WAZUH_PLUGIN_PLATFORM_TEMPLATE_NAME;
const WAZUH_ROLE_ADMINISTRATOR_ID = 1;
exports.WAZUH_ROLE_ADMINISTRATOR_ID = WAZUH_ROLE_ADMINISTRATOR_ID;
const WAZUH_ROLE_ADMINISTRATOR_NAME = 'administrator';

// Sample data
exports.WAZUH_ROLE_ADMINISTRATOR_NAME = WAZUH_ROLE_ADMINISTRATOR_NAME;
const WAZUH_SAMPLE_ALERT_PREFIX = 'wazuh-alerts-4.x-';
exports.WAZUH_SAMPLE_ALERT_PREFIX = WAZUH_SAMPLE_ALERT_PREFIX;
const WAZUH_SAMPLE_ALERTS_INDEX_SHARDS = 1;
exports.WAZUH_SAMPLE_ALERTS_INDEX_SHARDS = WAZUH_SAMPLE_ALERTS_INDEX_SHARDS;
const WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS = 0;
exports.WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS = WAZUH_SAMPLE_ALERTS_INDEX_REPLICAS;
const WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY = 'security';
exports.WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY = WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY;
const WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING = 'auditing-policy-monitoring';
exports.WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING = WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING;
const WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION = 'threat-detection';
exports.WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION = WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION;
const WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS = 3000;
exports.WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS = WAZUH_SAMPLE_ALERTS_DEFAULT_NUMBER_ALERTS;
const WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS = {
  [WAZUH_SAMPLE_ALERTS_CATEGORY_SECURITY]: [{
    syscheck: true
  }, {
    aws: true
  }, {
    office: true
  }, {
    gcp: true
  }, {
    authentication: true
  }, {
    ssh: true
  }, {
    apache: true,
    alerts: 2000
  }, {
    web: true
  }, {
    windows: {
      service_control_manager: true
    },
    alerts: 1000
  }, {
    github: true
  }],
  [WAZUH_SAMPLE_ALERTS_CATEGORY_AUDITING_POLICY_MONITORING]: [{
    rootcheck: true
  }, {
    audit: true
  }, {
    openscap: true
  }, {
    ciscat: true
  }],
  [WAZUH_SAMPLE_ALERTS_CATEGORY_THREAT_DETECTION]: [{
    vulnerabilities: true
  }, {
    virustotal: true
  }, {
    osquery: true
  }, {
    docker: true
  }, {
    mitre: true
  }]
};

// Security
exports.WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS = WAZUH_SAMPLE_ALERTS_CATEGORIES_TYPE_ALERTS;
const WAZUH_SECURITY_PLUGIN_XPACK_SECURITY = 'X-Pack Security';
exports.WAZUH_SECURITY_PLUGIN_XPACK_SECURITY = WAZUH_SECURITY_PLUGIN_XPACK_SECURITY;
const WAZUH_SECURITY_PLUGIN_OPEN_DISTRO_FOR_ELASTICSEARCH = 'Open Distro for Elasticsearch';
exports.WAZUH_SECURITY_PLUGIN_OPEN_DISTRO_FOR_ELASTICSEARCH = WAZUH_SECURITY_PLUGIN_OPEN_DISTRO_FOR_ELASTICSEARCH;
const WAZUH_SECURITY_PLUGINS = [WAZUH_SECURITY_PLUGIN_XPACK_SECURITY, WAZUH_SECURITY_PLUGIN_OPEN_DISTRO_FOR_ELASTICSEARCH];

// App configuration
exports.WAZUH_SECURITY_PLUGINS = WAZUH_SECURITY_PLUGINS;
const WAZUH_CONFIGURATION_CACHE_TIME = 10000; // time in ms;

// Reserved ids for Users/Role mapping
exports.WAZUH_CONFIGURATION_CACHE_TIME = WAZUH_CONFIGURATION_CACHE_TIME;
const WAZUH_API_RESERVED_ID_LOWER_THAN = 100;

// Wazuh data path
exports.WAZUH_API_RESERVED_ID_LOWER_THAN = WAZUH_API_RESERVED_ID_LOWER_THAN;
const WAZUH_DATA_PLUGIN_PLATFORM_BASE_PATH = 'data';
const WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH = _path.default.join(__dirname, '../../../', WAZUH_DATA_PLUGIN_PLATFORM_BASE_PATH);
exports.WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH = WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH;
const WAZUH_DATA_ABSOLUTE_PATH = _path.default.join(WAZUH_DATA_PLUGIN_PLATFORM_BASE_ABSOLUTE_PATH, 'wazuh');

// Wazuh data path - config
exports.WAZUH_DATA_ABSOLUTE_PATH = WAZUH_DATA_ABSOLUTE_PATH;
const WAZUH_DATA_CONFIG_DIRECTORY_PATH = _path.default.join(WAZUH_DATA_ABSOLUTE_PATH, 'config');
exports.WAZUH_DATA_CONFIG_DIRECTORY_PATH = WAZUH_DATA_CONFIG_DIRECTORY_PATH;
const WAZUH_DATA_CONFIG_APP_PATH = _path.default.join(WAZUH_DATA_CONFIG_DIRECTORY_PATH, 'wazuh.yml');
exports.WAZUH_DATA_CONFIG_APP_PATH = WAZUH_DATA_CONFIG_APP_PATH;
const WAZUH_DATA_CONFIG_REGISTRY_PATH = _path.default.join(WAZUH_DATA_CONFIG_DIRECTORY_PATH, 'wazuh-registry.json');

// Wazuh data path - logs
exports.WAZUH_DATA_CONFIG_REGISTRY_PATH = WAZUH_DATA_CONFIG_REGISTRY_PATH;
const MAX_MB_LOG_FILES = 100;
exports.MAX_MB_LOG_FILES = MAX_MB_LOG_FILES;
const WAZUH_DATA_LOGS_DIRECTORY_PATH = _path.default.join(WAZUH_DATA_ABSOLUTE_PATH, 'logs');
exports.WAZUH_DATA_LOGS_DIRECTORY_PATH = WAZUH_DATA_LOGS_DIRECTORY_PATH;
const WAZUH_DATA_LOGS_PLAIN_FILENAME = 'wazuhapp-plain.log';
exports.WAZUH_DATA_LOGS_PLAIN_FILENAME = WAZUH_DATA_LOGS_PLAIN_FILENAME;
const WAZUH_DATA_LOGS_PLAIN_PATH = _path.default.join(WAZUH_DATA_LOGS_DIRECTORY_PATH, WAZUH_DATA_LOGS_PLAIN_FILENAME);
exports.WAZUH_DATA_LOGS_PLAIN_PATH = WAZUH_DATA_LOGS_PLAIN_PATH;
const WAZUH_DATA_LOGS_RAW_FILENAME = 'wazuhapp.log';
exports.WAZUH_DATA_LOGS_RAW_FILENAME = WAZUH_DATA_LOGS_RAW_FILENAME;
const WAZUH_DATA_LOGS_RAW_PATH = _path.default.join(WAZUH_DATA_LOGS_DIRECTORY_PATH, WAZUH_DATA_LOGS_RAW_FILENAME);

// Wazuh data path - UI logs
exports.WAZUH_DATA_LOGS_RAW_PATH = WAZUH_DATA_LOGS_RAW_PATH;
const WAZUH_UI_LOGS_PLAIN_FILENAME = 'wazuh-ui-plain.log';
exports.WAZUH_UI_LOGS_PLAIN_FILENAME = WAZUH_UI_LOGS_PLAIN_FILENAME;
const WAZUH_UI_LOGS_RAW_FILENAME = 'wazuh-ui.log';
exports.WAZUH_UI_LOGS_RAW_FILENAME = WAZUH_UI_LOGS_RAW_FILENAME;
const WAZUH_UI_LOGS_PLAIN_PATH = _path.default.join(WAZUH_DATA_LOGS_DIRECTORY_PATH, WAZUH_UI_LOGS_PLAIN_FILENAME);
exports.WAZUH_UI_LOGS_PLAIN_PATH = WAZUH_UI_LOGS_PLAIN_PATH;
const WAZUH_UI_LOGS_RAW_PATH = _path.default.join(WAZUH_DATA_LOGS_DIRECTORY_PATH, WAZUH_UI_LOGS_RAW_FILENAME);

// Wazuh data path - downloads
exports.WAZUH_UI_LOGS_RAW_PATH = WAZUH_UI_LOGS_RAW_PATH;
const WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH = _path.default.join(WAZUH_DATA_ABSOLUTE_PATH, 'downloads');
exports.WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH = WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH;
const WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH = _path.default.join(WAZUH_DATA_DOWNLOADS_DIRECTORY_PATH, 'reports');

// Queue
exports.WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH = WAZUH_DATA_DOWNLOADS_REPORTS_DIRECTORY_PATH;
const WAZUH_QUEUE_CRON_FREQ = '*/15 * * * * *'; // Every 15 seconds

// Wazuh errors
exports.WAZUH_QUEUE_CRON_FREQ = WAZUH_QUEUE_CRON_FREQ;
const WAZUH_ERROR_DAEMONS_NOT_READY = 'ERROR3099';

// Agents
exports.WAZUH_ERROR_DAEMONS_NOT_READY = WAZUH_ERROR_DAEMONS_NOT_READY;
let WAZUH_AGENTS_OS_TYPE;
exports.WAZUH_AGENTS_OS_TYPE = WAZUH_AGENTS_OS_TYPE;
(function (WAZUH_AGENTS_OS_TYPE) {
  WAZUH_AGENTS_OS_TYPE["WINDOWS"] = "windows";
  WAZUH_AGENTS_OS_TYPE["LINUX"] = "linux";
  WAZUH_AGENTS_OS_TYPE["SUNOS"] = "sunos";
  WAZUH_AGENTS_OS_TYPE["DARWIN"] = "darwin";
  WAZUH_AGENTS_OS_TYPE["OTHERS"] = "";
})(WAZUH_AGENTS_OS_TYPE || (exports.WAZUH_AGENTS_OS_TYPE = WAZUH_AGENTS_OS_TYPE = {}));
let WAZUH_MODULES_ID;
exports.WAZUH_MODULES_ID = WAZUH_MODULES_ID;
(function (WAZUH_MODULES_ID) {
  WAZUH_MODULES_ID["SECURITY_EVENTS"] = "general";
  WAZUH_MODULES_ID["INTEGRITY_MONITORING"] = "fim";
  WAZUH_MODULES_ID["AMAZON_WEB_SERVICES"] = "aws";
  WAZUH_MODULES_ID["OFFICE_365"] = "office";
  WAZUH_MODULES_ID["GOOGLE_CLOUD_PLATFORM"] = "gcp";
  WAZUH_MODULES_ID["POLICY_MONITORING"] = "pm";
  WAZUH_MODULES_ID["SECURITY_CONFIGURATION_ASSESSMENT"] = "sca";
  WAZUH_MODULES_ID["AUDITING"] = "audit";
  WAZUH_MODULES_ID["OPEN_SCAP"] = "oscap";
  WAZUH_MODULES_ID["VULNERABILITIES"] = "vuls";
  WAZUH_MODULES_ID["OSQUERY"] = "osquery";
  WAZUH_MODULES_ID["DOCKER"] = "docker";
  WAZUH_MODULES_ID["MITRE_ATTACK"] = "mitre";
  WAZUH_MODULES_ID["PCI_DSS"] = "pci";
  WAZUH_MODULES_ID["HIPAA"] = "hipaa";
  WAZUH_MODULES_ID["NIST_800_53"] = "nist";
  WAZUH_MODULES_ID["TSC"] = "tsc";
  WAZUH_MODULES_ID["CIS_CAT"] = "ciscat";
  WAZUH_MODULES_ID["VIRUSTOTAL"] = "virustotal";
  WAZUH_MODULES_ID["GDPR"] = "gdpr";
  WAZUH_MODULES_ID["GITHUB"] = "github";
})(WAZUH_MODULES_ID || (exports.WAZUH_MODULES_ID = WAZUH_MODULES_ID = {}));
;
let WAZUH_MENU_MANAGEMENT_SECTIONS_ID;
exports.WAZUH_MENU_MANAGEMENT_SECTIONS_ID = WAZUH_MENU_MANAGEMENT_SECTIONS_ID;
(function (WAZUH_MENU_MANAGEMENT_SECTIONS_ID) {
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["MANAGEMENT"] = "management";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["ADMINISTRATION"] = "administration";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["RULESET"] = "ruleset";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["RULES"] = "rules";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["DECODERS"] = "decoders";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["CDB_LISTS"] = "lists";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["GROUPS"] = "groups";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["CONFIGURATION"] = "configuration";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["STATUS_AND_REPORTS"] = "statusReports";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["STATUS"] = "status";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["CLUSTER"] = "monitoring";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["LOGS"] = "logs";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["REPORTING"] = "reporting";
  WAZUH_MENU_MANAGEMENT_SECTIONS_ID["STATISTICS"] = "statistics";
})(WAZUH_MENU_MANAGEMENT_SECTIONS_ID || (exports.WAZUH_MENU_MANAGEMENT_SECTIONS_ID = WAZUH_MENU_MANAGEMENT_SECTIONS_ID = {}));
;
let WAZUH_MENU_TOOLS_SECTIONS_ID;
exports.WAZUH_MENU_TOOLS_SECTIONS_ID = WAZUH_MENU_TOOLS_SECTIONS_ID;
(function (WAZUH_MENU_TOOLS_SECTIONS_ID) {
  WAZUH_MENU_TOOLS_SECTIONS_ID["API_CONSOLE"] = "devTools";
  WAZUH_MENU_TOOLS_SECTIONS_ID["RULESET_TEST"] = "logtest";
})(WAZUH_MENU_TOOLS_SECTIONS_ID || (exports.WAZUH_MENU_TOOLS_SECTIONS_ID = WAZUH_MENU_TOOLS_SECTIONS_ID = {}));
;
let WAZUH_MENU_SECURITY_SECTIONS_ID;
exports.WAZUH_MENU_SECURITY_SECTIONS_ID = WAZUH_MENU_SECURITY_SECTIONS_ID;
(function (WAZUH_MENU_SECURITY_SECTIONS_ID) {
  WAZUH_MENU_SECURITY_SECTIONS_ID["USERS"] = "users";
  WAZUH_MENU_SECURITY_SECTIONS_ID["ROLES"] = "roles";
  WAZUH_MENU_SECURITY_SECTIONS_ID["POLICIES"] = "policies";
  WAZUH_MENU_SECURITY_SECTIONS_ID["ROLES_MAPPING"] = "roleMapping";
})(WAZUH_MENU_SECURITY_SECTIONS_ID || (exports.WAZUH_MENU_SECURITY_SECTIONS_ID = WAZUH_MENU_SECURITY_SECTIONS_ID = {}));
;
let WAZUH_MENU_SETTINGS_SECTIONS_ID;
exports.WAZUH_MENU_SETTINGS_SECTIONS_ID = WAZUH_MENU_SETTINGS_SECTIONS_ID;
(function (WAZUH_MENU_SETTINGS_SECTIONS_ID) {
  WAZUH_MENU_SETTINGS_SECTIONS_ID["SETTINGS"] = "settings";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["API_CONFIGURATION"] = "api";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["MODULES"] = "modules";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["SAMPLE_DATA"] = "sample_data";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["CONFIGURATION"] = "configuration";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["LOGS"] = "logs";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["MISCELLANEOUS"] = "miscellaneous";
  WAZUH_MENU_SETTINGS_SECTIONS_ID["ABOUT"] = "about";
})(WAZUH_MENU_SETTINGS_SECTIONS_ID || (exports.WAZUH_MENU_SETTINGS_SECTIONS_ID = WAZUH_MENU_SETTINGS_SECTIONS_ID = {}));
;
const AUTHORIZED_AGENTS = 'authorized-agents';

// Wazuh links
exports.AUTHORIZED_AGENTS = AUTHORIZED_AGENTS;
const WAZUH_LINK_GITHUB = 'https://github.com/wazuh';
exports.WAZUH_LINK_GITHUB = WAZUH_LINK_GITHUB;
const WAZUH_LINK_GOOGLE_GROUPS = 'https://groups.google.com/forum/#!forum/wazuh';
exports.WAZUH_LINK_GOOGLE_GROUPS = WAZUH_LINK_GOOGLE_GROUPS;
const WAZUH_LINK_SLACK = 'https://wazuh.com/community/join-us-on-slack';
exports.WAZUH_LINK_SLACK = WAZUH_LINK_SLACK;
const HEALTH_CHECK = 'health-check';

// Health check
exports.HEALTH_CHECK = HEALTH_CHECK;
const HEALTH_CHECK_REDIRECTION_TIME = 300; //ms

// Plugin platform settings
// Default timeFilter set by the app
exports.HEALTH_CHECK_REDIRECTION_TIME = HEALTH_CHECK_REDIRECTION_TIME;
const WAZUH_PLUGIN_PLATFORM_SETTING_TIME_FILTER = {
  from: 'now-24h',
  to: 'now'
};
exports.WAZUH_PLUGIN_PLATFORM_SETTING_TIME_FILTER = WAZUH_PLUGIN_PLATFORM_SETTING_TIME_FILTER;
const PLUGIN_PLATFORM_SETTING_NAME_TIME_FILTER = 'timepicker:timeDefaults';

// Default maxBuckets set by the app
exports.PLUGIN_PLATFORM_SETTING_NAME_TIME_FILTER = PLUGIN_PLATFORM_SETTING_NAME_TIME_FILTER;
const WAZUH_PLUGIN_PLATFORM_SETTING_MAX_BUCKETS = 200000;
exports.WAZUH_PLUGIN_PLATFORM_SETTING_MAX_BUCKETS = WAZUH_PLUGIN_PLATFORM_SETTING_MAX_BUCKETS;
const PLUGIN_PLATFORM_SETTING_NAME_MAX_BUCKETS = 'timelion:max_buckets';

// Default metaFields set by the app
exports.PLUGIN_PLATFORM_SETTING_NAME_MAX_BUCKETS = PLUGIN_PLATFORM_SETTING_NAME_MAX_BUCKETS;
const WAZUH_PLUGIN_PLATFORM_SETTING_METAFIELDS = ['_source', '_index'];
exports.WAZUH_PLUGIN_PLATFORM_SETTING_METAFIELDS = WAZUH_PLUGIN_PLATFORM_SETTING_METAFIELDS;
const PLUGIN_PLATFORM_SETTING_NAME_METAFIELDS = 'metaFields';

// Logger
exports.PLUGIN_PLATFORM_SETTING_NAME_METAFIELDS = PLUGIN_PLATFORM_SETTING_NAME_METAFIELDS;
const UI_LOGGER_LEVELS = {
  WARNING: 'WARNING',
  INFO: 'INFO',
  ERROR: 'ERROR'
};
exports.UI_LOGGER_LEVELS = UI_LOGGER_LEVELS;
const UI_TOAST_COLOR = {
  SUCCESS: 'success',
  WARNING: 'warning',
  DANGER: 'danger'
};

// Assets
exports.UI_TOAST_COLOR = UI_TOAST_COLOR;
const ASSETS_BASE_URL_PREFIX = '/plugins/wazuh/assets/';
exports.ASSETS_BASE_URL_PREFIX = ASSETS_BASE_URL_PREFIX;
const ASSETS_PUBLIC_URL = '/plugins/wazuh/public/assets/';

// Reports
exports.ASSETS_PUBLIC_URL = ASSETS_PUBLIC_URL;
const REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH = 'images/logo_reports.png';
exports.REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH = REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH;
const REPORTS_PRIMARY_COLOR = '#256BD1';
exports.REPORTS_PRIMARY_COLOR = REPORTS_PRIMARY_COLOR;
const REPORTS_PAGE_FOOTER_TEXT = 'Copyright © 2023 Wazuh, Inc.';
exports.REPORTS_PAGE_FOOTER_TEXT = REPORTS_PAGE_FOOTER_TEXT;
const REPORTS_PAGE_HEADER_TEXT = 'info@wazuh.com\nhttps://wazuh.com';

// Plugin platform
exports.REPORTS_PAGE_HEADER_TEXT = REPORTS_PAGE_HEADER_TEXT;
const PLUGIN_PLATFORM_NAME = 'Kibana';
exports.PLUGIN_PLATFORM_NAME = PLUGIN_PLATFORM_NAME;
const PLUGIN_PLATFORM_BASE_INSTALLATION_PATH = '/usr/share/kibana/data/wazuh/';
exports.PLUGIN_PLATFORM_BASE_INSTALLATION_PATH = PLUGIN_PLATFORM_BASE_INSTALLATION_PATH;
const PLUGIN_PLATFORM_INSTALLATION_USER = 'kibana';
exports.PLUGIN_PLATFORM_INSTALLATION_USER = PLUGIN_PLATFORM_INSTALLATION_USER;
const PLUGIN_PLATFORM_INSTALLATION_USER_GROUP = 'kibana';
exports.PLUGIN_PLATFORM_INSTALLATION_USER_GROUP = PLUGIN_PLATFORM_INSTALLATION_USER_GROUP;
const PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_UPGRADE_PLATFORM = 'upgrade-guide';
exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_UPGRADE_PLATFORM = PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_UPGRADE_PLATFORM;
const PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_TROUBLESHOOTING = 'user-manual/elasticsearch/troubleshooting.html';
exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_TROUBLESHOOTING = PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_TROUBLESHOOTING;
const PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_APP_CONFIGURATION = 'user-manual/wazuh-dashboard/config-file.html';
exports.PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_APP_CONFIGURATION = PLUGIN_PLATFORM_WAZUH_DOCUMENTATION_URL_PATH_APP_CONFIGURATION;
const PLUGIN_PLATFORM_URL_GUIDE = 'https://www.elastic.co/guide/en/elasticsearch/reference/current/index.html';
exports.PLUGIN_PLATFORM_URL_GUIDE = PLUGIN_PLATFORM_URL_GUIDE;
const PLUGIN_PLATFORM_URL_GUIDE_TITLE = 'Elastic guide';
exports.PLUGIN_PLATFORM_URL_GUIDE_TITLE = PLUGIN_PLATFORM_URL_GUIDE_TITLE;
const PLUGIN_PLATFORM_REQUEST_HEADERS = {
  'kbn-xsrf': 'kibana'
};

// Plugin app
exports.PLUGIN_PLATFORM_REQUEST_HEADERS = PLUGIN_PLATFORM_REQUEST_HEADERS;
const PLUGIN_APP_NAME = 'Wazuh App';

// UI
exports.PLUGIN_APP_NAME = PLUGIN_APP_NAME;
const API_NAME_AGENT_STATUS = {
  ACTIVE: 'active',
  DISCONNECTED: 'disconnected',
  PENDING: 'pending',
  NEVER_CONNECTED: 'never_connected'
};
exports.API_NAME_AGENT_STATUS = API_NAME_AGENT_STATUS;
const UI_COLOR_AGENT_STATUS = {
  [API_NAME_AGENT_STATUS.ACTIVE]: '#007871',
  [API_NAME_AGENT_STATUS.DISCONNECTED]: '#BD271E',
  [API_NAME_AGENT_STATUS.PENDING]: '#FEC514',
  [API_NAME_AGENT_STATUS.NEVER_CONNECTED]: '#646A77',
  default: '#000000'
};
exports.UI_COLOR_AGENT_STATUS = UI_COLOR_AGENT_STATUS;
const UI_LABEL_NAME_AGENT_STATUS = {
  [API_NAME_AGENT_STATUS.ACTIVE]: 'Active',
  [API_NAME_AGENT_STATUS.DISCONNECTED]: 'Disconnected',
  [API_NAME_AGENT_STATUS.PENDING]: 'Pending',
  [API_NAME_AGENT_STATUS.NEVER_CONNECTED]: 'Never connected',
  default: 'Unknown'
};
exports.UI_LABEL_NAME_AGENT_STATUS = UI_LABEL_NAME_AGENT_STATUS;
const UI_ORDER_AGENT_STATUS = [API_NAME_AGENT_STATUS.ACTIVE, API_NAME_AGENT_STATUS.DISCONNECTED, API_NAME_AGENT_STATUS.PENDING, API_NAME_AGENT_STATUS.NEVER_CONNECTED];
exports.UI_ORDER_AGENT_STATUS = UI_ORDER_AGENT_STATUS;
const AGENT_SYNCED_STATUS = {
  SYNCED: 'synced',
  NOT_SYNCED: 'not synced'
};

// Documentation
exports.AGENT_SYNCED_STATUS = AGENT_SYNCED_STATUS;
const DOCUMENTATION_WEB_BASE_URL = "https://documentation.wazuh.com";

// Default Elasticsearch user name context
exports.DOCUMENTATION_WEB_BASE_URL = DOCUMENTATION_WEB_BASE_URL;
const ELASTIC_NAME = 'elastic';

// Customization
exports.ELASTIC_NAME = ELASTIC_NAME;
const CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES = 1048576;

// Plugin settings
exports.CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES = CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES;
let SettingCategory;
exports.SettingCategory = SettingCategory;
(function (SettingCategory) {
  SettingCategory[SettingCategory["GENERAL"] = 0] = "GENERAL";
  SettingCategory[SettingCategory["HEALTH_CHECK"] = 1] = "HEALTH_CHECK";
  SettingCategory[SettingCategory["EXTENSIONS"] = 2] = "EXTENSIONS";
  SettingCategory[SettingCategory["MONITORING"] = 3] = "MONITORING";
  SettingCategory[SettingCategory["STATISTICS"] = 4] = "STATISTICS";
  SettingCategory[SettingCategory["SECURITY"] = 5] = "SECURITY";
  SettingCategory[SettingCategory["CUSTOMIZATION"] = 6] = "CUSTOMIZATION";
})(SettingCategory || (exports.SettingCategory = SettingCategory = {}));
;
let EpluginSettingType;
exports.EpluginSettingType = EpluginSettingType;
(function (EpluginSettingType) {
  EpluginSettingType["text"] = "text";
  EpluginSettingType["textarea"] = "textarea";
  EpluginSettingType["switch"] = "switch";
  EpluginSettingType["number"] = "number";
  EpluginSettingType["editor"] = "editor";
  EpluginSettingType["select"] = "select";
  EpluginSettingType["filepicker"] = "filepicker";
})(EpluginSettingType || (exports.EpluginSettingType = EpluginSettingType = {}));
;
const PLUGIN_SETTINGS_CATEGORIES = {
  [SettingCategory.HEALTH_CHECK]: {
    title: 'Health check',
    description: "Checks will be executed by the app's Healthcheck.",
    renderOrder: SettingCategory.HEALTH_CHECK
  },
  [SettingCategory.GENERAL]: {
    title: 'General',
    description: "Basic app settings related to alerts index pattern, hide the manager alerts in the dashboards, logs level and more.",
    renderOrder: SettingCategory.GENERAL
  },
  [SettingCategory.EXTENSIONS]: {
    title: 'Initial display state of the modules of the new API host entries.',
    description: "Extensions."
  },
  [SettingCategory.SECURITY]: {
    title: 'Security',
    description: "Application security options such as unauthorized roles.",
    renderOrder: SettingCategory.SECURITY
  },
  [SettingCategory.MONITORING]: {
    title: 'Task:Monitoring',
    description: "Options related to the agent status monitoring job and its storage in indexes.",
    renderOrder: SettingCategory.MONITORING
  },
  [SettingCategory.STATISTICS]: {
    title: 'Task:Statistics',
    description: "Options related to the daemons manager monitoring job and their storage in indexes..",
    renderOrder: SettingCategory.STATISTICS
  },
  [SettingCategory.CUSTOMIZATION]: {
    title: 'Custom branding',
    description: "If you want to use custom branding elements such as logos, you can do so by editing the settings below.",
    documentationLink: 'user-manual/wazuh-dashboard/white-labeling.html',
    renderOrder: SettingCategory.CUSTOMIZATION
  }
};
exports.PLUGIN_SETTINGS_CATEGORIES = PLUGIN_SETTINGS_CATEGORIES;
const PLUGIN_SETTINGS = {
  "alerts.sample.prefix": {
    title: "Sample alerts prefix",
    description: "Define the index name prefix of sample alerts. It must match the template used by the index pattern to avoid unknown fields in dashboards.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_SAMPLE_ALERT_PREFIX,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#', '*')),
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  "checks.api": {
    title: "API connection",
    description: "Enable or disable the API health check when opening the app.",
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "checks.fields": {
    title: "Known fields",
    description: "Enable or disable the known fields health check when opening the app.",
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "checks.maxBuckets": {
    title: "Set max buckets to 200000",
    description: "Change the default value of the plugin platform max buckets configuration.",
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "checks.metaFields": {
    title: "Remove meta fields",
    description: "Change the default value of the plugin platform metaField configuration.",
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "checks.pattern": {
    title: "Index pattern",
    description: "Enable or disable the index pattern health check when opening the app.",
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "checks.setup": {
    title: "API version",
    description: "Enable or disable the setup health check when opening the app.",
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "checks.template": {
    title: "Index template",
    description: "Enable or disable the template health check when opening the app.",
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "checks.timeFilter": {
    title: "Set time filter to 24h",
    description: "Change the default value of the plugin platform timeFilter configuration.",
    category: SettingCategory.HEALTH_CHECK,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "cron.prefix": {
    title: "Cron prefix",
    description: "Define the index prefix of predefined jobs.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_STATISTICS_DEFAULT_PREFIX,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#', '*')),
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  "cron.statistics.apis": {
    title: "Includes APIs",
    description: "Enter the ID of the hosts you want to save data from, leave this empty to run the task on every host.",
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.editor,
    defaultValue: [],
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      editor: {
        language: 'json'
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return JSON.stringify(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      try {
        return JSON.parse(value);
      } catch (error) {
        return value;
      }
      ;
    },
    validate: _settingsValidator.SettingsValidator.json(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.array(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isString, _settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces)))),
    validateBackend: function (schema) {
      return schema.arrayOf(schema.string({
        validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces)
      }));
    }
  },
  "cron.statistics.index.creation": {
    title: "Index creation",
    description: "Define the interval in which a new index will be created.",
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.select,
    options: {
      select: [{
        text: "Hourly",
        value: "h"
      }, {
        text: "Daily",
        value: "d"
      }, {
        text: "Weekly",
        value: "w"
      }, {
        text: "Monthly",
        value: "m"
      }]
    },
    defaultValue: WAZUH_STATISTICS_DEFAULT_CREATION,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    validate: function (value) {
      return _settingsValidator.SettingsValidator.literal(this.options.select.map(({
        value
      }) => value))(value);
    },
    validateBackend: function (schema) {
      return schema.oneOf(this.options.select.map(({
        value
      }) => schema.literal(value)));
    }
  },
  "cron.statistics.index.name": {
    title: "Index name",
    description: "Define the name of the index in which the documents will be saved.",
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_STATISTICS_DEFAULT_NAME,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#', '*')),
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  "cron.statistics.index.replicas": {
    title: "Index replicas",
    description: "Define the number of replicas to use for the statistics indices.",
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_STATISTICS_DEFAULT_INDICES_REPLICAS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    options: {
      number: {
        min: 0,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  "cron.statistics.index.shards": {
    title: "Index shards",
    description: "Define the number of shards to use for the statistics indices.",
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_STATISTICS_DEFAULT_INDICES_SHARDS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    options: {
      number: {
        min: 1,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  "cron.statistics.interval": {
    title: "Interval",
    description: "Define the frequency of task execution using cron schedule expressions.",
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_STATISTICS_DEFAULT_CRON_FREQ,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRestartingPluginPlatform: true,
    validate: function (value) {
      return (0, _nodeCron.validate)(value) ? undefined : "Interval is not valid.";
    },
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  "cron.statistics.status": {
    title: "Status",
    description: "Enable or disable the statistics tasks.",
    category: SettingCategory.STATISTICS,
    type: EpluginSettingType.switch,
    defaultValue: WAZUH_STATISTICS_DEFAULT_STATUS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "customization.enabled": {
    title: "Status",
    description: "Enable or disable the customization.",
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresReloadingBrowserTab: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "customization.logo.app": {
    title: "App main logo",
    description: `This logo is used in the app main menu, at the top left corner.`,
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.filepicker,
    defaultValue: "",
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      file: {
        type: 'image',
        extensions: ['.jpeg', '.jpg', '.png', '.svg'],
        size: {
          maxBytes: CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES
        },
        recommended: {
          dimensions: {
            width: 300,
            height: 70,
            unit: 'px'
          }
        },
        store: {
          relativePathFileSystem: 'public/assets/custom/images',
          filename: 'customization.logo.app',
          resolveStaticURL: filename => `custom/images/${filename}?v=${Date.now()}`
          // ?v=${Date.now()} is used to force the browser to reload the image when a new file is uploaded
        }
      }
    },

    validate: function (value) {
      return _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.filePickerFileSize({
        ...this.options.file.size,
        meaningfulUnit: true
      }), _settingsValidator.SettingsValidator.filePickerSupportedExtensions(this.options.file.extensions))(value);
    }
  },
  "customization.logo.healthcheck": {
    title: "Healthcheck logo",
    description: `This logo is displayed during the Healthcheck routine of the app.`,
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.filepicker,
    defaultValue: "",
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      file: {
        type: 'image',
        extensions: ['.jpeg', '.jpg', '.png', '.svg'],
        size: {
          maxBytes: CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES
        },
        recommended: {
          dimensions: {
            width: 300,
            height: 70,
            unit: 'px'
          }
        },
        store: {
          relativePathFileSystem: 'public/assets/custom/images',
          filename: 'customization.logo.healthcheck',
          resolveStaticURL: filename => `custom/images/${filename}?v=${Date.now()}`
          // ?v=${Date.now()} is used to force the browser to reload the image when a new file is uploaded
        }
      }
    },

    validate: function (value) {
      return _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.filePickerFileSize({
        ...this.options.file.size,
        meaningfulUnit: true
      }), _settingsValidator.SettingsValidator.filePickerSupportedExtensions(this.options.file.extensions))(value);
    }
  },
  "customization.logo.reports": {
    title: "PDF reports logo",
    description: `This logo is used in the PDF reports generated by the app. It's placed at the top left corner of every page of the PDF.`,
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.filepicker,
    defaultValue: "",
    defaultValueIfNotSet: REPORTS_LOGO_IMAGE_ASSETS_RELATIVE_PATH,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      file: {
        type: 'image',
        extensions: ['.jpeg', '.jpg', '.png'],
        size: {
          maxBytes: CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES
        },
        recommended: {
          dimensions: {
            width: 190,
            height: 40,
            unit: 'px'
          }
        },
        store: {
          relativePathFileSystem: 'public/assets/custom/images',
          filename: 'customization.logo.reports',
          resolveStaticURL: filename => `custom/images/${filename}`
        }
      }
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.filePickerFileSize({
        ...this.options.file.size,
        meaningfulUnit: true
      }), _settingsValidator.SettingsValidator.filePickerSupportedExtensions(this.options.file.extensions))(value);
    }
  },
  "customization.logo.sidebar": {
    title: "Navigation drawer logo",
    description: `This is the logo for the app to display in the platform's navigation drawer, this is, the main sidebar collapsible menu.`,
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.filepicker,
    defaultValue: "",
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresReloadingBrowserTab: true,
    options: {
      file: {
        type: 'image',
        extensions: ['.jpeg', '.jpg', '.png', '.svg'],
        size: {
          maxBytes: CUSTOMIZATION_ENDPOINT_PAYLOAD_UPLOAD_CUSTOM_FILE_MAXIMUM_BYTES
        },
        recommended: {
          dimensions: {
            width: 80,
            height: 80,
            unit: 'px'
          }
        },
        store: {
          relativePathFileSystem: 'public/assets/custom/images',
          filename: 'customization.logo.sidebar',
          resolveStaticURL: filename => `custom/images/${filename}?v=${Date.now()}`
          // ?v=${Date.now()} is used to force the browser to reload the image when a new file is uploaded
        }
      }
    },

    validate: function (value) {
      return _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.filePickerFileSize({
        ...this.options.file.size,
        meaningfulUnit: true
      }), _settingsValidator.SettingsValidator.filePickerSupportedExtensions(this.options.file.extensions))(value);
    }
  },
  "customization.reports.footer": {
    title: "Reports footer",
    description: "Set the footer of the reports.",
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.textarea,
    defaultValue: "",
    defaultValueIfNotSet: REPORTS_PAGE_FOOTER_TEXT,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      maxRows: 2,
      maxLength: 50
    },
    validate: function (value) {
      var _this$options, _this$options2;
      return _settingsValidator.SettingsValidator.multipleLinesString({
        maxRows: (_this$options = this.options) === null || _this$options === void 0 ? void 0 : _this$options.maxRows,
        maxLength: (_this$options2 = this.options) === null || _this$options2 === void 0 ? void 0 : _this$options2.maxLength
      })(value);
    },
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate.bind(this)
      });
    }
  },
  "customization.reports.header": {
    title: "Reports header",
    description: "Set the header of the reports.",
    category: SettingCategory.CUSTOMIZATION,
    type: EpluginSettingType.textarea,
    defaultValue: "",
    defaultValueIfNotSet: REPORTS_PAGE_HEADER_TEXT,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      maxRows: 3,
      maxLength: 40
    },
    validate: function (value) {
      var _this$options3, _this$options4;
      return _settingsValidator.SettingsValidator.multipleLinesString({
        maxRows: (_this$options3 = this.options) === null || _this$options3 === void 0 ? void 0 : _this$options3.maxRows,
        maxLength: (_this$options4 = this.options) === null || _this$options4 === void 0 ? void 0 : _this$options4.maxLength
      })(value);
    },
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate.bind(this)
      });
    }
  },
  "disabled_roles": {
    title: "Disable roles",
    description: "Disabled the plugin visibility for users with the roles.",
    category: SettingCategory.SECURITY,
    type: EpluginSettingType.editor,
    defaultValue: [],
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      editor: {
        language: 'json'
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return JSON.stringify(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      try {
        return JSON.parse(value);
      } catch (error) {
        return value;
      }
      ;
    },
    validate: _settingsValidator.SettingsValidator.json(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.array(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isString, _settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces)))),
    validateBackend: function (schema) {
      return schema.arrayOf(schema.string({
        validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces)
      }));
    }
  },
  "enrollment.dns": {
    title: "Enrollment DNS",
    description: "Specifies the Wazuh registration server, used for the agent enrollment.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: "",
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    validate: _settingsValidator.SettingsValidator.hasNoSpaces,
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  "enrollment.password": {
    title: "Enrollment password",
    description: "Specifies the password used to authenticate during the agent enrollment.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: "",
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    validate: _settingsValidator.SettingsValidator.isNotEmptyString,
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  "extensions.audit": {
    title: "System auditing",
    description: "Enable or disable the Audit tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.aws": {
    title: "Amazon AWS",
    description: "Enable or disable the Amazon (AWS) tab on Overview.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.ciscat": {
    title: "CIS-CAT",
    description: "Enable or disable the CIS-CAT tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.docker": {
    title: "Docker listener",
    description: "Enable or disable the Docker listener tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.gcp": {
    title: "Google Cloud platform",
    description: "Enable or disable the Google Cloud Platform tab on Overview.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.gdpr": {
    title: "GDPR",
    description: "Enable or disable the GDPR tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.hipaa": {
    title: "Hipaa",
    description: "Enable or disable the HIPAA tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.nist": {
    title: "NIST",
    description: "Enable or disable the NIST 800-53 tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.oscap": {
    title: "OSCAP",
    description: "Enable or disable the Open SCAP tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.osquery": {
    title: "Osquery",
    description: "Enable or disable the Osquery tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.pci": {
    title: "PCI DSS",
    description: "Enable or disable the PCI DSS tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.tsc": {
    title: "TSC",
    description: "Enable or disable the TSC tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "extensions.virustotal": {
    title: "Virustotal",
    description: "Enable or disable the VirusTotal tab on Overview and Agents.",
    category: SettingCategory.EXTENSIONS,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "hideManagerAlerts": {
    title: "Hide manager alerts",
    description: "Hide the alerts of the manager in every dashboard.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.switch,
    defaultValue: false,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresReloadingBrowserTab: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "ip.ignore": {
    title: "Index pattern ignore",
    description: "Disable certain index pattern names from being available in index pattern selector.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.editor,
    defaultValue: [],
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      editor: {
        language: 'json'
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return JSON.stringify(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      try {
        return JSON.parse(value);
      } catch (error) {
        return value;
      }
      ;
    },
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.json(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.array(_settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isString, _settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noLiteralString('.', '..'), _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#'))))),
    validateBackend: function (schema) {
      return schema.arrayOf(schema.string({
        validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noLiteralString('.', '..'), _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#'))
      }));
    }
  },
  "ip.selector": {
    title: "IP selector",
    description: "Define if the user is allowed to change the selected index pattern directly from the top menu bar.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.switch,
    defaultValue: true,
    isConfigurableFromFile: true,
    isConfigurableFromUI: false,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "logs.level": {
    title: "Log level",
    description: "Logging level of the App.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.select,
    options: {
      select: [{
        text: "Info",
        value: "info"
      }, {
        text: "Debug",
        value: "debug"
      }]
    },
    defaultValue: "info",
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRestartingPluginPlatform: true,
    validate: function (value) {
      return _settingsValidator.SettingsValidator.literal(this.options.select.map(({
        value
      }) => value))(value);
    },
    validateBackend: function (schema) {
      return schema.oneOf(this.options.select.map(({
        value
      }) => schema.literal(value)));
    }
  },
  "pattern": {
    title: "Index pattern",
    description: "Default index pattern to use on the app. If there's no valid index pattern, the app will automatically create one with the name indicated in this option.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_ALERTS_PATTERN,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    // Validation: https://github.com/elastic/elasticsearch/blob/v7.10.2/docs/reference/indices/create-index.asciidoc
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noLiteralString('.', '..'), _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#')),
    validateBackend: function (schema) {
      return schema.string({
        validate: this.validate
      });
    }
  },
  "timeout": {
    title: "Request timeout",
    description: "Maximum time, in milliseconds, the app will wait for an API response when making requests to it. It will be ignored if the value is set under 1500 milliseconds.",
    category: SettingCategory.GENERAL,
    type: EpluginSettingType.number,
    defaultValue: 20000,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    options: {
      number: {
        min: 1500,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  "wazuh.monitoring.creation": {
    title: "Index creation",
    description: "Define the interval in which a new wazuh-monitoring index will be created.",
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.select,
    options: {
      select: [{
        text: "Hourly",
        value: "h"
      }, {
        text: "Daily",
        value: "d"
      }, {
        text: "Weekly",
        value: "w"
      }, {
        text: "Monthly",
        value: "m"
      }]
    },
    defaultValue: WAZUH_MONITORING_DEFAULT_CREATION,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    validate: function (value) {
      return _settingsValidator.SettingsValidator.literal(this.options.select.map(({
        value
      }) => value))(value);
    },
    validateBackend: function (schema) {
      return schema.oneOf(this.options.select.map(({
        value
      }) => schema.literal(value)));
    }
  },
  "wazuh.monitoring.enabled": {
    title: "Status",
    description: "Enable or disable the wazuh-monitoring index creation and/or visualization.",
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.switch,
    defaultValue: WAZUH_MONITORING_DEFAULT_ENABLED,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRestartingPluginPlatform: true,
    options: {
      switch: {
        values: {
          disabled: {
            label: 'false',
            value: false
          },
          enabled: {
            label: 'true',
            value: true
          }
        }
      }
    },
    uiFormTransformChangedInputValue: function (value) {
      return Boolean(value);
    },
    validate: _settingsValidator.SettingsValidator.isBoolean,
    validateBackend: function (schema) {
      return schema.boolean();
    }
  },
  "wazuh.monitoring.frequency": {
    title: "Frequency",
    description: "Frequency, in seconds, of API requests to get the state of the agents and create a new document in the wazuh-monitoring index with this data.",
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_MONITORING_DEFAULT_FREQUENCY,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRestartingPluginPlatform: true,
    options: {
      number: {
        min: 60,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  "wazuh.monitoring.pattern": {
    title: "Index pattern",
    description: "Default index pattern to use for Wazuh monitoring.",
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.text,
    defaultValue: WAZUH_MONITORING_PATTERN,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    validate: _settingsValidator.SettingsValidator.compose(_settingsValidator.SettingsValidator.isNotEmptyString, _settingsValidator.SettingsValidator.hasNoSpaces, _settingsValidator.SettingsValidator.noLiteralString('.', '..'), _settingsValidator.SettingsValidator.noStartsWithString('-', '_', '+', '.'), _settingsValidator.SettingsValidator.hasNotInvalidCharacters('\\', '/', '?', '"', '<', '>', '|', ',', '#')),
    validateBackend: function (schema) {
      return schema.string({
        minLength: 1,
        validate: this.validate
      });
    }
  },
  "wazuh.monitoring.replicas": {
    title: "Index replicas",
    description: "Define the number of replicas to use for the wazuh-monitoring-* indices.",
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_MONITORING_DEFAULT_INDICES_REPLICAS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    options: {
      number: {
        min: 0,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  },
  "wazuh.monitoring.shards": {
    title: "Index shards",
    description: "Define the number of shards to use for the wazuh-monitoring-* indices.",
    category: SettingCategory.MONITORING,
    type: EpluginSettingType.number,
    defaultValue: WAZUH_MONITORING_DEFAULT_INDICES_SHARDS,
    isConfigurableFromFile: true,
    isConfigurableFromUI: true,
    requiresRunningHealthCheck: true,
    options: {
      number: {
        min: 1,
        integer: true
      }
    },
    uiFormTransformConfigurationValueToInputValue: function (value) {
      return String(value);
    },
    uiFormTransformInputValueToConfigurationValue: function (value) {
      return Number(value);
    },
    validate: function (value) {
      return _settingsValidator.SettingsValidator.number(this.options.number)(value);
    },
    validateBackend: function (schema) {
      return schema.number({
        validate: this.validate.bind(this)
      });
    }
  }
};
exports.PLUGIN_SETTINGS = PLUGIN_SETTINGS;
let HTTP_STATUS_CODES; // Module Security configuration assessment
exports.HTTP_STATUS_CODES = HTTP_STATUS_CODES;
(function (HTTP_STATUS_CODES) {
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["CONTINUE"] = 100] = "CONTINUE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["SWITCHING_PROTOCOLS"] = 101] = "SWITCHING_PROTOCOLS";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PROCESSING"] = 102] = "PROCESSING";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["OK"] = 200] = "OK";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["CREATED"] = 201] = "CREATED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["ACCEPTED"] = 202] = "ACCEPTED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NON_AUTHORITATIVE_INFORMATION"] = 203] = "NON_AUTHORITATIVE_INFORMATION";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NO_CONTENT"] = 204] = "NO_CONTENT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["RESET_CONTENT"] = 205] = "RESET_CONTENT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PARTIAL_CONTENT"] = 206] = "PARTIAL_CONTENT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MULTI_STATUS"] = 207] = "MULTI_STATUS";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MULTIPLE_CHOICES"] = 300] = "MULTIPLE_CHOICES";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MOVED_PERMANENTLY"] = 301] = "MOVED_PERMANENTLY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MOVED_TEMPORARILY"] = 302] = "MOVED_TEMPORARILY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["SEE_OTHER"] = 303] = "SEE_OTHER";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NOT_MODIFIED"] = 304] = "NOT_MODIFIED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["USE_PROXY"] = 305] = "USE_PROXY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["TEMPORARY_REDIRECT"] = 307] = "TEMPORARY_REDIRECT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PERMANENT_REDIRECT"] = 308] = "PERMANENT_REDIRECT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["BAD_REQUEST"] = 400] = "BAD_REQUEST";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["UNAUTHORIZED"] = 401] = "UNAUTHORIZED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PAYMENT_REQUIRED"] = 402] = "PAYMENT_REQUIRED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["FORBIDDEN"] = 403] = "FORBIDDEN";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NOT_FOUND"] = 404] = "NOT_FOUND";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["METHOD_NOT_ALLOWED"] = 405] = "METHOD_NOT_ALLOWED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NOT_ACCEPTABLE"] = 406] = "NOT_ACCEPTABLE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PROXY_AUTHENTICATION_REQUIRED"] = 407] = "PROXY_AUTHENTICATION_REQUIRED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUEST_TIMEOUT"] = 408] = "REQUEST_TIMEOUT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["CONFLICT"] = 409] = "CONFLICT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["GONE"] = 410] = "GONE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["LENGTH_REQUIRED"] = 411] = "LENGTH_REQUIRED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PRECONDITION_FAILED"] = 412] = "PRECONDITION_FAILED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUEST_TOO_LONG"] = 413] = "REQUEST_TOO_LONG";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUEST_URI_TOO_LONG"] = 414] = "REQUEST_URI_TOO_LONG";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["UNSUPPORTED_MEDIA_TYPE"] = 415] = "UNSUPPORTED_MEDIA_TYPE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUESTED_RANGE_NOT_SATISFIABLE"] = 416] = "REQUESTED_RANGE_NOT_SATISFIABLE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["EXPECTATION_FAILED"] = 417] = "EXPECTATION_FAILED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["IM_A_TEAPOT"] = 418] = "IM_A_TEAPOT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["INSUFFICIENT_SPACE_ON_RESOURCE"] = 419] = "INSUFFICIENT_SPACE_ON_RESOURCE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["METHOD_FAILURE"] = 420] = "METHOD_FAILURE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["MISDIRECTED_REQUEST"] = 421] = "MISDIRECTED_REQUEST";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["UNPROCESSABLE_ENTITY"] = 422] = "UNPROCESSABLE_ENTITY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["LOCKED"] = 423] = "LOCKED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["FAILED_DEPENDENCY"] = 424] = "FAILED_DEPENDENCY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["PRECONDITION_REQUIRED"] = 428] = "PRECONDITION_REQUIRED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["TOO_MANY_REQUESTS"] = 429] = "TOO_MANY_REQUESTS";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["REQUEST_HEADER_FIELDS_TOO_LARGE"] = 431] = "REQUEST_HEADER_FIELDS_TOO_LARGE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["UNAVAILABLE_FOR_LEGAL_REASONS"] = 451] = "UNAVAILABLE_FOR_LEGAL_REASONS";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["INTERNAL_SERVER_ERROR"] = 500] = "INTERNAL_SERVER_ERROR";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NOT_IMPLEMENTED"] = 501] = "NOT_IMPLEMENTED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["BAD_GATEWAY"] = 502] = "BAD_GATEWAY";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["SERVICE_UNAVAILABLE"] = 503] = "SERVICE_UNAVAILABLE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["GATEWAY_TIMEOUT"] = 504] = "GATEWAY_TIMEOUT";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["HTTP_VERSION_NOT_SUPPORTED"] = 505] = "HTTP_VERSION_NOT_SUPPORTED";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["INSUFFICIENT_STORAGE"] = 507] = "INSUFFICIENT_STORAGE";
  HTTP_STATUS_CODES[HTTP_STATUS_CODES["NETWORK_AUTHENTICATION_REQUIRED"] = 511] = "NETWORK_AUTHENTICATION_REQUIRED";
})(HTTP_STATUS_CODES || (exports.HTTP_STATUS_CODES = HTTP_STATUS_CODES = {}));
const MODULE_SCA_CHECK_RESULT_LABEL = {
  passed: 'Passed',
  failed: 'Failed',
  'not applicable': 'Not applicable'
};
exports.MODULE_SCA_CHECK_RESULT_LABEL = MODULE_SCA_CHECK_RESULT_LABEL;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfcGF0aCIsIl9pbnRlcm9wUmVxdWlyZURlZmF1bHQiLCJyZXF1aXJlIiwiX3BhY2thZ2UiLCJfbm9kZUNyb24iLCJfc2V0dGluZ3NWYWxpZGF0b3IiLCJQTFVHSU5fVkVSU0lPTiIsInZlcnNpb24iLCJleHBvcnRzIiwiUExVR0lOX1ZFUlNJT05fU0hPUlQiLCJzcGxpdCIsInNwbGljZSIsImpvaW4iLCJXQVpVSF9JTkRFWF9UWVBFX0FMRVJUUyIsIldBWlVIX0FMRVJUU19QUkVGSVgiLCJXQVpVSF9BTEVSVFNfUEFUVEVSTiIsIldBWlVIX0lOREVYX1RZUEVfTU9OSVRPUklORyIsIldBWlVIX01PTklUT1JJTkdfUFJFRklYIiwiV0FaVUhfTU9OSVRPUklOR19QQVRURVJOIiwiV0FaVUhfTU9OSVRPUklOR19URU1QTEFURV9OQU1FIiwiV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0lORElDRVNfU0hBUkRTIiwiV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0lORElDRVNfUkVQTElDQVMiLCJXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfQ1JFQVRJT04iLCJXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfRU5BQkxFRCIsIldBWlVIX01PTklUT1JJTkdfREVGQVVMVF9GUkVRVUVOQ1kiLCJXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfQ1JPTl9GUkVRIiwiV0FaVUhfSU5ERVhfVFlQRV9TVEFUSVNUSUNTIiwiV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX1BSRUZJWCIsIldBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9OQU1FIiwiV0FaVUhfU1RBVElTVElDU19QQVRURVJOIiwiV0FaVUhfU1RBVElTVElDU19URU1QTEFURV9OQU1FIiwiV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0lORElDRVNfU0hBUkRTIiwiV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0lORElDRVNfUkVQTElDQVMiLCJXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfQ1JFQVRJT04iLCJXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfU1RBVFVTIiwiV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0ZSRVFVRU5DWSIsIldBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9DUk9OX0ZSRVEiLCJXQVpVSF9QTFVHSU5fUExBVEZPUk1fVEVNUExBVEVfTkFNRSIsIldBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9JRCIsIldBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9OQU1FIiwiV0FaVUhfU0FNUExFX0FMRVJUX1BSRUZJWCIsIldBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfU0hBUkRTIiwiV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9SRVBMSUNBUyIsIldBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUllfU0VDVVJJVFkiLCJXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JZX0FVRElUSU5HX1BPTElDWV9NT05JVE9SSU5HIiwiV0FaVUhfU0FNUExFX0FMRVJUU19DQVRFR09SWV9USFJFQVRfREVURUNUSU9OIiwiV0FaVUhfU0FNUExFX0FMRVJUU19ERUZBVUxUX05VTUJFUl9BTEVSVFMiLCJXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JJRVNfVFlQRV9BTEVSVFMiLCJzeXNjaGVjayIsImF3cyIsIm9mZmljZSIsImdjcCIsImF1dGhlbnRpY2F0aW9uIiwic3NoIiwiYXBhY2hlIiwiYWxlcnRzIiwid2ViIiwid2luZG93cyIsInNlcnZpY2VfY29udHJvbF9tYW5hZ2VyIiwiZ2l0aHViIiwicm9vdGNoZWNrIiwiYXVkaXQiLCJvcGVuc2NhcCIsImNpc2NhdCIsInZ1bG5lcmFiaWxpdGllcyIsInZpcnVzdG90YWwiLCJvc3F1ZXJ5IiwiZG9ja2VyIiwibWl0cmUiLCJXQVpVSF9TRUNVUklUWV9QTFVHSU5fWFBBQ0tfU0VDVVJJVFkiLCJXQVpVSF9TRUNVUklUWV9QTFVHSU5fT1BFTl9ESVNUUk9fRk9SX0VMQVNUSUNTRUFSQ0giLCJXQVpVSF9TRUNVUklUWV9QTFVHSU5TIiwiV0FaVUhfQ09ORklHVVJBVElPTl9DQUNIRV9USU1FIiwiV0FaVUhfQVBJX1JFU0VSVkVEX0lEX0xPV0VSX1RIQU4iLCJXQVpVSF9EQVRBX1BMVUdJTl9QTEFURk9STV9CQVNFX1BBVEgiLCJXQVpVSF9EQVRBX1BMVUdJTl9QTEFURk9STV9CQVNFX0FCU09MVVRFX1BBVEgiLCJwYXRoIiwiX19kaXJuYW1lIiwiV0FaVUhfREFUQV9BQlNPTFVURV9QQVRIIiwiV0FaVUhfREFUQV9DT05GSUdfRElSRUNUT1JZX1BBVEgiLCJXQVpVSF9EQVRBX0NPTkZJR19BUFBfUEFUSCIsIldBWlVIX0RBVEFfQ09ORklHX1JFR0lTVFJZX1BBVEgiLCJNQVhfTUJfTE9HX0ZJTEVTIiwiV0FaVUhfREFUQV9MT0dTX0RJUkVDVE9SWV9QQVRIIiwiV0FaVUhfREFUQV9MT0dTX1BMQUlOX0ZJTEVOQU1FIiwiV0FaVUhfREFUQV9MT0dTX1BMQUlOX1BBVEgiLCJXQVpVSF9EQVRBX0xPR1NfUkFXX0ZJTEVOQU1FIiwiV0FaVUhfREFUQV9MT0dTX1JBV19QQVRIIiwiV0FaVUhfVUlfTE9HU19QTEFJTl9GSUxFTkFNRSIsIldBWlVIX1VJX0xPR1NfUkFXX0ZJTEVOQU1FIiwiV0FaVUhfVUlfTE9HU19QTEFJTl9QQVRIIiwiV0FaVUhfVUlfTE9HU19SQVdfUEFUSCIsIldBWlVIX0RBVEFfRE9XTkxPQURTX0RJUkVDVE9SWV9QQVRIIiwiV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCIsIldBWlVIX1FVRVVFX0NST05fRlJFUSIsIldBWlVIX0VSUk9SX0RBRU1PTlNfTk9UX1JFQURZIiwiV0FaVUhfQUdFTlRTX09TX1RZUEUiLCJXQVpVSF9NT0RVTEVTX0lEIiwiV0FaVUhfTUVOVV9NQU5BR0VNRU5UX1NFQ1RJT05TX0lEIiwiV0FaVUhfTUVOVV9UT09MU19TRUNUSU9OU19JRCIsIldBWlVIX01FTlVfU0VDVVJJVFlfU0VDVElPTlNfSUQiLCJXQVpVSF9NRU5VX1NFVFRJTkdTX1NFQ1RJT05TX0lEIiwiQVVUSE9SSVpFRF9BR0VOVFMiLCJXQVpVSF9MSU5LX0dJVEhVQiIsIldBWlVIX0xJTktfR09PR0xFX0dST1VQUyIsIldBWlVIX0xJTktfU0xBQ0siLCJIRUFMVEhfQ0hFQ0siLCJIRUFMVEhfQ0hFQ0tfUkVESVJFQ1RJT05fVElNRSIsIldBWlVIX1BMVUdJTl9QTEFURk9STV9TRVRUSU5HX1RJTUVfRklMVEVSIiwiZnJvbSIsInRvIiwiUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfTkFNRV9USU1FX0ZJTFRFUiIsIldBWlVIX1BMVUdJTl9QTEFURk9STV9TRVRUSU5HX01BWF9CVUNLRVRTIiwiUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfTkFNRV9NQVhfQlVDS0VUUyIsIldBWlVIX1BMVUdJTl9QTEFURk9STV9TRVRUSU5HX01FVEFGSUVMRFMiLCJQTFVHSU5fUExBVEZPUk1fU0VUVElOR19OQU1FX01FVEFGSUVMRFMiLCJVSV9MT0dHRVJfTEVWRUxTIiwiV0FSTklORyIsIklORk8iLCJFUlJPUiIsIlVJX1RPQVNUX0NPTE9SIiwiU1VDQ0VTUyIsIkRBTkdFUiIsIkFTU0VUU19CQVNFX1VSTF9QUkVGSVgiLCJBU1NFVFNfUFVCTElDX1VSTCIsIlJFUE9SVFNfTE9HT19JTUFHRV9BU1NFVFNfUkVMQVRJVkVfUEFUSCIsIlJFUE9SVFNfUFJJTUFSWV9DT0xPUiIsIlJFUE9SVFNfUEFHRV9GT09URVJfVEVYVCIsIlJFUE9SVFNfUEFHRV9IRUFERVJfVEVYVCIsIlBMVUdJTl9QTEFURk9STV9OQU1FIiwiUExVR0lOX1BMQVRGT1JNX0JBU0VfSU5TVEFMTEFUSU9OX1BBVEgiLCJQTFVHSU5fUExBVEZPUk1fSU5TVEFMTEFUSU9OX1VTRVIiLCJQTFVHSU5fUExBVEZPUk1fSU5TVEFMTEFUSU9OX1VTRVJfR1JPVVAiLCJQTFVHSU5fUExBVEZPUk1fV0FaVUhfRE9DVU1FTlRBVElPTl9VUkxfUEFUSF9VUEdSQURFX1BMQVRGT1JNIiwiUExVR0lOX1BMQVRGT1JNX1dBWlVIX0RPQ1VNRU5UQVRJT05fVVJMX1BBVEhfVFJPVUJMRVNIT09USU5HIiwiUExVR0lOX1BMQVRGT1JNX1dBWlVIX0RPQ1VNRU5UQVRJT05fVVJMX1BBVEhfQVBQX0NPTkZJR1VSQVRJT04iLCJQTFVHSU5fUExBVEZPUk1fVVJMX0dVSURFIiwiUExVR0lOX1BMQVRGT1JNX1VSTF9HVUlERV9USVRMRSIsIlBMVUdJTl9QTEFURk9STV9SRVFVRVNUX0hFQURFUlMiLCJQTFVHSU5fQVBQX05BTUUiLCJBUElfTkFNRV9BR0VOVF9TVEFUVVMiLCJBQ1RJVkUiLCJESVNDT05ORUNURUQiLCJQRU5ESU5HIiwiTkVWRVJfQ09OTkVDVEVEIiwiVUlfQ09MT1JfQUdFTlRfU1RBVFVTIiwiZGVmYXVsdCIsIlVJX0xBQkVMX05BTUVfQUdFTlRfU1RBVFVTIiwiVUlfT1JERVJfQUdFTlRfU1RBVFVTIiwiQUdFTlRfU1lOQ0VEX1NUQVRVUyIsIlNZTkNFRCIsIk5PVF9TWU5DRUQiLCJET0NVTUVOVEFUSU9OX1dFQl9CQVNFX1VSTCIsIkVMQVNUSUNfTkFNRSIsIkNVU1RPTUlaQVRJT05fRU5EUE9JTlRfUEFZTE9BRF9VUExPQURfQ1VTVE9NX0ZJTEVfTUFYSU1VTV9CWVRFUyIsIlNldHRpbmdDYXRlZ29yeSIsIkVwbHVnaW5TZXR0aW5nVHlwZSIsIlBMVUdJTl9TRVRUSU5HU19DQVRFR09SSUVTIiwidGl0bGUiLCJkZXNjcmlwdGlvbiIsInJlbmRlck9yZGVyIiwiR0VORVJBTCIsIkVYVEVOU0lPTlMiLCJTRUNVUklUWSIsIk1PTklUT1JJTkciLCJTVEFUSVNUSUNTIiwiQ1VTVE9NSVpBVElPTiIsImRvY3VtZW50YXRpb25MaW5rIiwiUExVR0lOX1NFVFRJTkdTIiwiY2F0ZWdvcnkiLCJ0eXBlIiwidGV4dCIsImRlZmF1bHRWYWx1ZSIsImlzQ29uZmlndXJhYmxlRnJvbUZpbGUiLCJpc0NvbmZpZ3VyYWJsZUZyb21VSSIsInJlcXVpcmVzUnVubmluZ0hlYWx0aENoZWNrIiwidmFsaWRhdGUiLCJTZXR0aW5nc1ZhbGlkYXRvciIsImNvbXBvc2UiLCJpc05vdEVtcHR5U3RyaW5nIiwiaGFzTm9TcGFjZXMiLCJub1N0YXJ0c1dpdGhTdHJpbmciLCJoYXNOb3RJbnZhbGlkQ2hhcmFjdGVycyIsInZhbGlkYXRlQmFja2VuZCIsInNjaGVtYSIsInN0cmluZyIsInN3aXRjaCIsIm9wdGlvbnMiLCJ2YWx1ZXMiLCJkaXNhYmxlZCIsImxhYmVsIiwidmFsdWUiLCJlbmFibGVkIiwidWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWUiLCJCb29sZWFuIiwiaXNCb29sZWFuIiwiYm9vbGVhbiIsImVkaXRvciIsImxhbmd1YWdlIiwidWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlIiwiSlNPTiIsInN0cmluZ2lmeSIsInVpRm9ybVRyYW5zZm9ybUlucHV0VmFsdWVUb0NvbmZpZ3VyYXRpb25WYWx1ZSIsInBhcnNlIiwiZXJyb3IiLCJqc29uIiwiYXJyYXkiLCJpc1N0cmluZyIsImFycmF5T2YiLCJzZWxlY3QiLCJsaXRlcmFsIiwibWFwIiwib25lT2YiLCJudW1iZXIiLCJtaW4iLCJpbnRlZ2VyIiwiU3RyaW5nIiwiTnVtYmVyIiwiYmluZCIsInJlcXVpcmVzUmVzdGFydGluZ1BsdWdpblBsYXRmb3JtIiwidmFsaWRhdGVOb2RlQ3JvbkludGVydmFsIiwidW5kZWZpbmVkIiwicmVxdWlyZXNSZWxvYWRpbmdCcm93c2VyVGFiIiwiZmlsZXBpY2tlciIsImZpbGUiLCJleHRlbnNpb25zIiwic2l6ZSIsIm1heEJ5dGVzIiwicmVjb21tZW5kZWQiLCJkaW1lbnNpb25zIiwid2lkdGgiLCJoZWlnaHQiLCJ1bml0Iiwic3RvcmUiLCJyZWxhdGl2ZVBhdGhGaWxlU3lzdGVtIiwiZmlsZW5hbWUiLCJyZXNvbHZlU3RhdGljVVJMIiwiRGF0ZSIsIm5vdyIsImZpbGVQaWNrZXJGaWxlU2l6ZSIsIm1lYW5pbmdmdWxVbml0IiwiZmlsZVBpY2tlclN1cHBvcnRlZEV4dGVuc2lvbnMiLCJkZWZhdWx0VmFsdWVJZk5vdFNldCIsInRleHRhcmVhIiwibWF4Um93cyIsIm1heExlbmd0aCIsIl90aGlzJG9wdGlvbnMiLCJfdGhpcyRvcHRpb25zMiIsIm11bHRpcGxlTGluZXNTdHJpbmciLCJfdGhpcyRvcHRpb25zMyIsIl90aGlzJG9wdGlvbnM0Iiwibm9MaXRlcmFsU3RyaW5nIiwibWluTGVuZ3RoIiwiSFRUUF9TVEFUVVNfQ09ERVMiLCJNT0RVTEVfU0NBX0NIRUNLX1JFU1VMVF9MQUJFTCIsInBhc3NlZCIsImZhaWxlZCJdLCJzb3VyY2VzIjpbImNvbnN0YW50cy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggYXBwIC0gV2F6dWggQ29uc3RhbnRzIGZpbGVcbiAqIENvcHlyaWdodCAoQykgMjAxNS0yMDIyIFdhenVoLCBJbmMuXG4gKlxuICogVGhpcyBwcm9ncmFtIGlzIGZyZWUgc29mdHdhcmU7IHlvdSBjYW4gcmVkaXN0cmlidXRlIGl0IGFuZC9vciBtb2RpZnlcbiAqIGl0IHVuZGVyIHRoZSB0ZXJtcyBvZiB0aGUgR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgYXMgcHVibGlzaGVkIGJ5XG4gKiB0aGUgRnJlZSBTb2Z0d2FyZSBGb3VuZGF0aW9uOyBlaXRoZXIgdmVyc2lvbiAyIG9mIHRoZSBMaWNlbnNlLCBvclxuICogKGF0IHlvdXIgb3B0aW9uKSBhbnkgbGF0ZXIgdmVyc2lvbi5cbiAqXG4gKiBGaW5kIG1vcmUgaW5mb3JtYXRpb24gYWJvdXQgdGhpcyBvbiB0aGUgTElDRU5TRSBmaWxlLlxuICovXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJztcbmltcG9ydCB7IHZlcnNpb24gfSBmcm9tICcuLi9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgdmFsaWRhdGUgYXMgdmFsaWRhdGVOb2RlQ3JvbkludGVydmFsIH0gZnJvbSAnbm9kZS1jcm9uJztcbmltcG9ydCB7IFNldHRpbmdzVmFsaWRhdG9yIH0gZnJvbSAnLi4vY29tbW9uL3NlcnZpY2VzL3NldHRpbmdzLXZhbGlkYXRvcic7XG5cbi8vIFBsdWdpblxuZXhwb3J0IGNvbnN0IFBMVUdJTl9WRVJTSU9OID0gdmVyc2lvbjtcbmV4cG9ydCBjb25zdCBQTFVHSU5fVkVSU0lPTl9TSE9SVCA9IHZlcnNpb24uc3BsaXQoJy4nKS5zcGxpY2UoMCwgMikuam9pbignLicpO1xuXG4vLyBJbmRleCBwYXR0ZXJucyAtIFdhenVoIGFsZXJ0c1xuZXhwb3J0IGNvbnN0IFdBWlVIX0lOREVYX1RZUEVfQUxFUlRTID0gJ2FsZXJ0cyc7XG5leHBvcnQgY29uc3QgV0FaVUhfQUxFUlRTX1BSRUZJWCA9ICd3YXp1aC1hbGVydHMtJztcbmV4cG9ydCBjb25zdCBXQVpVSF9BTEVSVFNfUEFUVEVSTiA9ICd3YXp1aC1hbGVydHMtKic7XG5cbi8vIEpvYiAtIFdhenVoIG1vbml0b3JpbmdcbmV4cG9ydCBjb25zdCBXQVpVSF9JTkRFWF9UWVBFX01PTklUT1JJTkcgPSBcIm1vbml0b3JpbmdcIjtcbmV4cG9ydCBjb25zdCBXQVpVSF9NT05JVE9SSU5HX1BSRUZJWCA9IFwid2F6dWgtbW9uaXRvcmluZy1cIjtcbmV4cG9ydCBjb25zdCBXQVpVSF9NT05JVE9SSU5HX1BBVFRFUk4gPSBcIndhenVoLW1vbml0b3JpbmctKlwiO1xuZXhwb3J0IGNvbnN0IFdBWlVIX01PTklUT1JJTkdfVEVNUExBVEVfTkFNRSA9IFwid2F6dWgtYWdlbnRcIjtcbmV4cG9ydCBjb25zdCBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfSU5ESUNFU19TSEFSRFMgPSAxO1xuZXhwb3J0IGNvbnN0IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9JTkRJQ0VTX1JFUExJQ0FTID0gMDtcbmV4cG9ydCBjb25zdCBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfQ1JFQVRJT04gPSAndyc7XG5leHBvcnQgY29uc3QgV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0VOQUJMRUQgPSB0cnVlO1xuZXhwb3J0IGNvbnN0IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9GUkVRVUVOQ1kgPSA5MDA7XG5leHBvcnQgY29uc3QgV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0NST05fRlJFUSA9ICcwICogKiAqICogKic7XG5cbi8vIEpvYiAtIFdhenVoIHN0YXRpc3RpY3NcbmV4cG9ydCBjb25zdCBXQVpVSF9JTkRFWF9UWVBFX1NUQVRJU1RJQ1MgPSBcInN0YXRpc3RpY3NcIjtcbmV4cG9ydCBjb25zdCBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfUFJFRklYID0gXCJ3YXp1aFwiO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9OQU1FID0gXCJzdGF0aXN0aWNzXCI7XG5leHBvcnQgY29uc3QgV0FaVUhfU1RBVElTVElDU19QQVRURVJOID0gYCR7V0FaVUhfU1RBVElTVElDU19ERUZBVUxUX1BSRUZJWH0tJHtXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfTkFNRX0tKmA7XG5leHBvcnQgY29uc3QgV0FaVUhfU1RBVElTVElDU19URU1QTEFURV9OQU1FID0gYCR7V0FaVUhfU1RBVElTVElDU19ERUZBVUxUX1BSRUZJWH0tJHtXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfTkFNRX1gO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9JTkRJQ0VTX1NIQVJEUyA9IDE7XG5leHBvcnQgY29uc3QgV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0lORElDRVNfUkVQTElDQVMgPSAwO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9DUkVBVElPTiA9ICd3JztcbmV4cG9ydCBjb25zdCBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfU1RBVFVTID0gdHJ1ZTtcbmV4cG9ydCBjb25zdCBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfRlJFUVVFTkNZID0gOTAwO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9DUk9OX0ZSRVEgPSAnMCAqLzUgKiAqICogKic7XG5cbi8vIEpvYiAtIFdhenVoIGluaXRpYWxpemVcbmV4cG9ydCBjb25zdCBXQVpVSF9QTFVHSU5fUExBVEZPUk1fVEVNUExBVEVfTkFNRSA9ICd3YXp1aC1raWJhbmEnO1xuXG4vLyBQZXJtaXNzaW9uc1xuZXhwb3J0IGNvbnN0IFdBWlVIX1JPTEVfQURNSU5JU1RSQVRPUl9JRCA9IDE7XG5leHBvcnQgY29uc3QgV0FaVUhfUk9MRV9BRE1JTklTVFJBVE9SX05BTUUgPSAnYWRtaW5pc3RyYXRvcic7XG5cbi8vIFNhbXBsZSBkYXRhXG5leHBvcnQgY29uc3QgV0FaVUhfU0FNUExFX0FMRVJUX1BSRUZJWCA9ICd3YXp1aC1hbGVydHMtNC54LSc7XG5leHBvcnQgY29uc3QgV0FaVUhfU0FNUExFX0FMRVJUU19JTkRFWF9TSEFSRFMgPSAxO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NBTVBMRV9BTEVSVFNfSU5ERVhfUkVQTElDQVMgPSAwO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUllfU0VDVVJJVFkgPSAnc2VjdXJpdHknO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUllfQVVESVRJTkdfUE9MSUNZX01PTklUT1JJTkcgPSAnYXVkaXRpbmctcG9saWN5LW1vbml0b3JpbmcnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUllfVEhSRUFUX0RFVEVDVElPTiA9ICd0aHJlYXQtZGV0ZWN0aW9uJztcbmV4cG9ydCBjb25zdCBXQVpVSF9TQU1QTEVfQUxFUlRTX0RFRkFVTFRfTlVNQkVSX0FMRVJUUyA9IDMwMDA7XG5leHBvcnQgY29uc3QgV0FaVUhfU0FNUExFX0FMRVJUU19DQVRFR09SSUVTX1RZUEVfQUxFUlRTID0ge1xuICBbV0FaVUhfU0FNUExFX0FMRVJUU19DQVRFR09SWV9TRUNVUklUWV06IFtcbiAgICB7IHN5c2NoZWNrOiB0cnVlIH0sXG4gICAgeyBhd3M6IHRydWUgfSxcbiAgICB7IG9mZmljZTogdHJ1ZSB9LFxuICAgIHsgZ2NwOiB0cnVlIH0sXG4gICAgeyBhdXRoZW50aWNhdGlvbjogdHJ1ZSB9LFxuICAgIHsgc3NoOiB0cnVlIH0sXG4gICAgeyBhcGFjaGU6IHRydWUsIGFsZXJ0czogMjAwMCB9LFxuICAgIHsgd2ViOiB0cnVlIH0sXG4gICAgeyB3aW5kb3dzOiB7IHNlcnZpY2VfY29udHJvbF9tYW5hZ2VyOiB0cnVlIH0sIGFsZXJ0czogMTAwMCB9LFxuICAgIHsgZ2l0aHViOiB0cnVlIH1cbiAgXSxcbiAgW1dBWlVIX1NBTVBMRV9BTEVSVFNfQ0FURUdPUllfQVVESVRJTkdfUE9MSUNZX01PTklUT1JJTkddOiBbXG4gICAgeyByb290Y2hlY2s6IHRydWUgfSxcbiAgICB7IGF1ZGl0OiB0cnVlIH0sXG4gICAgeyBvcGVuc2NhcDogdHJ1ZSB9LFxuICAgIHsgY2lzY2F0OiB0cnVlIH0sXG4gIF0sXG4gIFtXQVpVSF9TQU1QTEVfQUxFUlRTX0NBVEVHT1JZX1RIUkVBVF9ERVRFQ1RJT05dOiBbXG4gICAgeyB2dWxuZXJhYmlsaXRpZXM6IHRydWUgfSxcbiAgICB7IHZpcnVzdG90YWw6IHRydWUgfSxcbiAgICB7IG9zcXVlcnk6IHRydWUgfSxcbiAgICB7IGRvY2tlcjogdHJ1ZSB9LFxuICAgIHsgbWl0cmU6IHRydWUgfSxcbiAgXSxcbn07XG5cbi8vIFNlY3VyaXR5XG5leHBvcnQgY29uc3QgV0FaVUhfU0VDVVJJVFlfUExVR0lOX1hQQUNLX1NFQ1VSSVRZID0gJ1gtUGFjayBTZWN1cml0eSc7XG5leHBvcnQgY29uc3QgV0FaVUhfU0VDVVJJVFlfUExVR0lOX09QRU5fRElTVFJPX0ZPUl9FTEFTVElDU0VBUkNIID0gJ09wZW4gRGlzdHJvIGZvciBFbGFzdGljc2VhcmNoJztcblxuZXhwb3J0IGNvbnN0IFdBWlVIX1NFQ1VSSVRZX1BMVUdJTlMgPSBbXG4gIFdBWlVIX1NFQ1VSSVRZX1BMVUdJTl9YUEFDS19TRUNVUklUWSxcbiAgV0FaVUhfU0VDVVJJVFlfUExVR0lOX09QRU5fRElTVFJPX0ZPUl9FTEFTVElDU0VBUkNILFxuXTtcblxuLy8gQXBwIGNvbmZpZ3VyYXRpb25cbmV4cG9ydCBjb25zdCBXQVpVSF9DT05GSUdVUkFUSU9OX0NBQ0hFX1RJTUUgPSAxMDAwMDsgLy8gdGltZSBpbiBtcztcblxuLy8gUmVzZXJ2ZWQgaWRzIGZvciBVc2Vycy9Sb2xlIG1hcHBpbmdcbmV4cG9ydCBjb25zdCBXQVpVSF9BUElfUkVTRVJWRURfSURfTE9XRVJfVEhBTiA9IDEwMDtcblxuLy8gV2F6dWggZGF0YSBwYXRoXG5jb25zdCBXQVpVSF9EQVRBX1BMVUdJTl9QTEFURk9STV9CQVNFX1BBVEggPSAnZGF0YSc7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9QTFVHSU5fUExBVEZPUk1fQkFTRV9BQlNPTFVURV9QQVRIID0gcGF0aC5qb2luKFxuICBfX2Rpcm5hbWUsXG4gICcuLi8uLi8uLi8nLFxuICBXQVpVSF9EQVRBX1BMVUdJTl9QTEFURk9STV9CQVNFX1BBVEhcbik7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9BQlNPTFVURV9QQVRIID0gcGF0aC5qb2luKFdBWlVIX0RBVEFfUExVR0lOX1BMQVRGT1JNX0JBU0VfQUJTT0xVVEVfUEFUSCwgJ3dhenVoJyk7XG5cbi8vIFdhenVoIGRhdGEgcGF0aCAtIGNvbmZpZ1xuZXhwb3J0IGNvbnN0IFdBWlVIX0RBVEFfQ09ORklHX0RJUkVDVE9SWV9QQVRIID0gcGF0aC5qb2luKFdBWlVIX0RBVEFfQUJTT0xVVEVfUEFUSCwgJ2NvbmZpZycpO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0RBVEFfQ09ORklHX0FQUF9QQVRIID0gcGF0aC5qb2luKFdBWlVIX0RBVEFfQ09ORklHX0RJUkVDVE9SWV9QQVRILCAnd2F6dWgueW1sJyk7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9DT05GSUdfUkVHSVNUUllfUEFUSCA9IHBhdGguam9pbihcbiAgV0FaVUhfREFUQV9DT05GSUdfRElSRUNUT1JZX1BBVEgsXG4gICd3YXp1aC1yZWdpc3RyeS5qc29uJ1xuKTtcblxuLy8gV2F6dWggZGF0YSBwYXRoIC0gbG9nc1xuZXhwb3J0IGNvbnN0IE1BWF9NQl9MT0dfRklMRVMgPSAxMDA7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9MT0dTX0RJUkVDVE9SWV9QQVRIID0gcGF0aC5qb2luKFdBWlVIX0RBVEFfQUJTT0xVVEVfUEFUSCwgJ2xvZ3MnKTtcbmV4cG9ydCBjb25zdCBXQVpVSF9EQVRBX0xPR1NfUExBSU5fRklMRU5BTUUgPSAnd2F6dWhhcHAtcGxhaW4ubG9nJztcbmV4cG9ydCBjb25zdCBXQVpVSF9EQVRBX0xPR1NfUExBSU5fUEFUSCA9IHBhdGguam9pbihcbiAgV0FaVUhfREFUQV9MT0dTX0RJUkVDVE9SWV9QQVRILFxuICBXQVpVSF9EQVRBX0xPR1NfUExBSU5fRklMRU5BTUVcbik7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9MT0dTX1JBV19GSUxFTkFNRSA9ICd3YXp1aGFwcC5sb2cnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX0RBVEFfTE9HU19SQVdfUEFUSCA9IHBhdGguam9pbihcbiAgV0FaVUhfREFUQV9MT0dTX0RJUkVDVE9SWV9QQVRILFxuICBXQVpVSF9EQVRBX0xPR1NfUkFXX0ZJTEVOQU1FXG4pO1xuXG4vLyBXYXp1aCBkYXRhIHBhdGggLSBVSSBsb2dzXG5leHBvcnQgY29uc3QgV0FaVUhfVUlfTE9HU19QTEFJTl9GSUxFTkFNRSA9ICd3YXp1aC11aS1wbGFpbi5sb2cnO1xuZXhwb3J0IGNvbnN0IFdBWlVIX1VJX0xPR1NfUkFXX0ZJTEVOQU1FID0gJ3dhenVoLXVpLmxvZyc7XG5leHBvcnQgY29uc3QgV0FaVUhfVUlfTE9HU19QTEFJTl9QQVRIID0gcGF0aC5qb2luKFxuICBXQVpVSF9EQVRBX0xPR1NfRElSRUNUT1JZX1BBVEgsXG4gIFdBWlVIX1VJX0xPR1NfUExBSU5fRklMRU5BTUVcbik7XG5leHBvcnQgY29uc3QgV0FaVUhfVUlfTE9HU19SQVdfUEFUSCA9IHBhdGguam9pbihXQVpVSF9EQVRBX0xPR1NfRElSRUNUT1JZX1BBVEgsIFdBWlVIX1VJX0xPR1NfUkFXX0ZJTEVOQU1FKTtcblxuLy8gV2F6dWggZGF0YSBwYXRoIC0gZG93bmxvYWRzXG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEggPSBwYXRoLmpvaW4oV0FaVUhfREFUQV9BQlNPTFVURV9QQVRILCAnZG93bmxvYWRzJyk7XG5leHBvcnQgY29uc3QgV0FaVUhfREFUQV9ET1dOTE9BRFNfUkVQT1JUU19ESVJFQ1RPUllfUEFUSCA9IHBhdGguam9pbihcbiAgV0FaVUhfREFUQV9ET1dOTE9BRFNfRElSRUNUT1JZX1BBVEgsXG4gICdyZXBvcnRzJ1xuKTtcblxuLy8gUXVldWVcbmV4cG9ydCBjb25zdCBXQVpVSF9RVUVVRV9DUk9OX0ZSRVEgPSAnKi8xNSAqICogKiAqIConOyAvLyBFdmVyeSAxNSBzZWNvbmRzXG5cbi8vIFdhenVoIGVycm9yc1xuZXhwb3J0IGNvbnN0IFdBWlVIX0VSUk9SX0RBRU1PTlNfTk9UX1JFQURZID0gJ0VSUk9SMzA5OSc7XG5cbi8vIEFnZW50c1xuZXhwb3J0IGVudW0gV0FaVUhfQUdFTlRTX09TX1RZUEUge1xuICBXSU5ET1dTID0gJ3dpbmRvd3MnLFxuICBMSU5VWCA9ICdsaW51eCcsXG4gIFNVTk9TID0gJ3N1bm9zJyxcbiAgREFSV0lOID0gJ2RhcndpbicsXG4gIE9USEVSUyA9ICcnLFxufVxuXG5leHBvcnQgZW51bSBXQVpVSF9NT0RVTEVTX0lEIHtcbiAgU0VDVVJJVFlfRVZFTlRTID0gJ2dlbmVyYWwnLFxuICBJTlRFR1JJVFlfTU9OSVRPUklORyA9ICdmaW0nLFxuICBBTUFaT05fV0VCX1NFUlZJQ0VTID0gJ2F3cycsXG4gIE9GRklDRV8zNjUgPSAnb2ZmaWNlJyxcbiAgR09PR0xFX0NMT1VEX1BMQVRGT1JNID0gJ2djcCcsXG4gIFBPTElDWV9NT05JVE9SSU5HID0gJ3BtJyxcbiAgU0VDVVJJVFlfQ09ORklHVVJBVElPTl9BU1NFU1NNRU5UID0gJ3NjYScsXG4gIEFVRElUSU5HID0gJ2F1ZGl0JyxcbiAgT1BFTl9TQ0FQID0gJ29zY2FwJyxcbiAgVlVMTkVSQUJJTElUSUVTID0gJ3Z1bHMnLFxuICBPU1FVRVJZID0gJ29zcXVlcnknLFxuICBET0NLRVIgPSAnZG9ja2VyJyxcbiAgTUlUUkVfQVRUQUNLID0gJ21pdHJlJyxcbiAgUENJX0RTUyA9ICdwY2knLFxuICBISVBBQSA9ICdoaXBhYScsXG4gIE5JU1RfODAwXzUzID0gJ25pc3QnLFxuICBUU0MgPSAndHNjJyxcbiAgQ0lTX0NBVCA9ICdjaXNjYXQnLFxuICBWSVJVU1RPVEFMID0gJ3ZpcnVzdG90YWwnLFxuICBHRFBSID0gJ2dkcHInLFxuICBHSVRIVUIgPSAnZ2l0aHViJ1xufTtcblxuZXhwb3J0IGVudW0gV0FaVUhfTUVOVV9NQU5BR0VNRU5UX1NFQ1RJT05TX0lEIHtcbiAgTUFOQUdFTUVOVCA9ICdtYW5hZ2VtZW50JyxcbiAgQURNSU5JU1RSQVRJT04gPSAnYWRtaW5pc3RyYXRpb24nLFxuICBSVUxFU0VUID0gJ3J1bGVzZXQnLFxuICBSVUxFUyA9ICdydWxlcycsXG4gIERFQ09ERVJTID0gJ2RlY29kZXJzJyxcbiAgQ0RCX0xJU1RTID0gJ2xpc3RzJyxcbiAgR1JPVVBTID0gJ2dyb3VwcycsXG4gIENPTkZJR1VSQVRJT04gPSAnY29uZmlndXJhdGlvbicsXG4gIFNUQVRVU19BTkRfUkVQT1JUUyA9ICdzdGF0dXNSZXBvcnRzJyxcbiAgU1RBVFVTID0gJ3N0YXR1cycsXG4gIENMVVNURVIgPSAnbW9uaXRvcmluZycsXG4gIExPR1MgPSAnbG9ncycsXG4gIFJFUE9SVElORyA9ICdyZXBvcnRpbmcnLFxuICBTVEFUSVNUSUNTID0gJ3N0YXRpc3RpY3MnLFxufTtcblxuZXhwb3J0IGVudW0gV0FaVUhfTUVOVV9UT09MU19TRUNUSU9OU19JRCB7XG4gIEFQSV9DT05TT0xFID0gJ2RldlRvb2xzJyxcbiAgUlVMRVNFVF9URVNUID0gJ2xvZ3Rlc3QnLFxufTtcblxuZXhwb3J0IGVudW0gV0FaVUhfTUVOVV9TRUNVUklUWV9TRUNUSU9OU19JRCB7XG4gIFVTRVJTID0gJ3VzZXJzJyxcbiAgUk9MRVMgPSAncm9sZXMnLFxuICBQT0xJQ0lFUyA9ICdwb2xpY2llcycsXG4gIFJPTEVTX01BUFBJTkcgPSAncm9sZU1hcHBpbmcnLFxufTtcblxuZXhwb3J0IGVudW0gV0FaVUhfTUVOVV9TRVRUSU5HU19TRUNUSU9OU19JRCB7XG4gIFNFVFRJTkdTID0gJ3NldHRpbmdzJyxcbiAgQVBJX0NPTkZJR1VSQVRJT04gPSAnYXBpJyxcbiAgTU9EVUxFUyA9ICdtb2R1bGVzJyxcbiAgU0FNUExFX0RBVEEgPSAnc2FtcGxlX2RhdGEnLFxuICBDT05GSUdVUkFUSU9OID0gJ2NvbmZpZ3VyYXRpb24nLFxuICBMT0dTID0gJ2xvZ3MnLFxuICBNSVNDRUxMQU5FT1VTID0gJ21pc2NlbGxhbmVvdXMnLFxuICBBQk9VVCA9ICdhYm91dCcsXG59O1xuXG5leHBvcnQgY29uc3QgQVVUSE9SSVpFRF9BR0VOVFMgPSAnYXV0aG9yaXplZC1hZ2VudHMnO1xuXG4vLyBXYXp1aCBsaW5rc1xuZXhwb3J0IGNvbnN0IFdBWlVIX0xJTktfR0lUSFVCID0gJ2h0dHBzOi8vZ2l0aHViLmNvbS93YXp1aCc7XG5leHBvcnQgY29uc3QgV0FaVUhfTElOS19HT09HTEVfR1JPVVBTID0gJ2h0dHBzOi8vZ3JvdXBzLmdvb2dsZS5jb20vZm9ydW0vIyFmb3J1bS93YXp1aCc7XG5leHBvcnQgY29uc3QgV0FaVUhfTElOS19TTEFDSyA9ICdodHRwczovL3dhenVoLmNvbS9jb21tdW5pdHkvam9pbi11cy1vbi1zbGFjayc7XG5cbmV4cG9ydCBjb25zdCBIRUFMVEhfQ0hFQ0sgPSAnaGVhbHRoLWNoZWNrJztcblxuLy8gSGVhbHRoIGNoZWNrXG5leHBvcnQgY29uc3QgSEVBTFRIX0NIRUNLX1JFRElSRUNUSU9OX1RJTUUgPSAzMDA7IC8vbXNcblxuLy8gUGx1Z2luIHBsYXRmb3JtIHNldHRpbmdzXG4vLyBEZWZhdWx0IHRpbWVGaWx0ZXIgc2V0IGJ5IHRoZSBhcHBcbmV4cG9ydCBjb25zdCBXQVpVSF9QTFVHSU5fUExBVEZPUk1fU0VUVElOR19USU1FX0ZJTFRFUiA9IHtcbiAgZnJvbTogJ25vdy0yNGgnLFxuICB0bzogJ25vdycsXG59O1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9QTEFURk9STV9TRVRUSU5HX05BTUVfVElNRV9GSUxURVIgPSAndGltZXBpY2tlcjp0aW1lRGVmYXVsdHMnO1xuXG4vLyBEZWZhdWx0IG1heEJ1Y2tldHMgc2V0IGJ5IHRoZSBhcHBcbmV4cG9ydCBjb25zdCBXQVpVSF9QTFVHSU5fUExBVEZPUk1fU0VUVElOR19NQVhfQlVDS0VUUyA9IDIwMDAwMDtcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fU0VUVElOR19OQU1FX01BWF9CVUNLRVRTID0gJ3RpbWVsaW9uOm1heF9idWNrZXRzJztcblxuLy8gRGVmYXVsdCBtZXRhRmllbGRzIHNldCBieSB0aGUgYXBwXG5leHBvcnQgY29uc3QgV0FaVUhfUExVR0lOX1BMQVRGT1JNX1NFVFRJTkdfTUVUQUZJRUxEUyA9IFsnX3NvdXJjZScsICdfaW5kZXgnXTtcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fU0VUVElOR19OQU1FX01FVEFGSUVMRFMgPSAnbWV0YUZpZWxkcyc7XG5cbi8vIExvZ2dlclxuZXhwb3J0IGNvbnN0IFVJX0xPR0dFUl9MRVZFTFMgPSB7XG4gIFdBUk5JTkc6ICdXQVJOSU5HJyxcbiAgSU5GTzogJ0lORk8nLFxuICBFUlJPUjogJ0VSUk9SJyxcbn07XG5cbmV4cG9ydCBjb25zdCBVSV9UT0FTVF9DT0xPUiA9IHtcbiAgU1VDQ0VTUzogJ3N1Y2Nlc3MnLFxuICBXQVJOSU5HOiAnd2FybmluZycsXG4gIERBTkdFUjogJ2RhbmdlcicsXG59O1xuXG4vLyBBc3NldHNcbmV4cG9ydCBjb25zdCBBU1NFVFNfQkFTRV9VUkxfUFJFRklYID0gJy9wbHVnaW5zL3dhenVoL2Fzc2V0cy8nO1xuZXhwb3J0IGNvbnN0IEFTU0VUU19QVUJMSUNfVVJMID0gJy9wbHVnaW5zL3dhenVoL3B1YmxpYy9hc3NldHMvJztcblxuLy8gUmVwb3J0c1xuZXhwb3J0IGNvbnN0IFJFUE9SVFNfTE9HT19JTUFHRV9BU1NFVFNfUkVMQVRJVkVfUEFUSCA9ICdpbWFnZXMvbG9nb19yZXBvcnRzLnBuZyc7XG5leHBvcnQgY29uc3QgUkVQT1JUU19QUklNQVJZX0NPTE9SID0gJyMyNTZCRDEnO1xuZXhwb3J0IGNvbnN0IFJFUE9SVFNfUEFHRV9GT09URVJfVEVYVCA9ICdDb3B5cmlnaHQgwqkgMjAyMyBXYXp1aCwgSW5jLic7XG5leHBvcnQgY29uc3QgUkVQT1JUU19QQUdFX0hFQURFUl9URVhUID0gJ2luZm9Ad2F6dWguY29tXFxuaHR0cHM6Ly93YXp1aC5jb20nO1xuXG4vLyBQbHVnaW4gcGxhdGZvcm1cbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fTkFNRSA9ICdLaWJhbmEnO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9QTEFURk9STV9CQVNFX0lOU1RBTExBVElPTl9QQVRIID0gJy91c3Ivc2hhcmUva2liYW5hL2RhdGEvd2F6dWgvJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fSU5TVEFMTEFUSU9OX1VTRVIgPSAna2liYW5hJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fSU5TVEFMTEFUSU9OX1VTRVJfR1JPVVAgPSAna2liYW5hJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fV0FaVUhfRE9DVU1FTlRBVElPTl9VUkxfUEFUSF9VUEdSQURFX1BMQVRGT1JNID0gJ3VwZ3JhZGUtZ3VpZGUnO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9QTEFURk9STV9XQVpVSF9ET0NVTUVOVEFUSU9OX1VSTF9QQVRIX1RST1VCTEVTSE9PVElORyA9ICd1c2VyLW1hbnVhbC9lbGFzdGljc2VhcmNoL3Ryb3VibGVzaG9vdGluZy5odG1sJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fV0FaVUhfRE9DVU1FTlRBVElPTl9VUkxfUEFUSF9BUFBfQ09ORklHVVJBVElPTiA9ICd1c2VyLW1hbnVhbC93YXp1aC1kYXNoYm9hcmQvY29uZmlnLWZpbGUuaHRtbCc7XG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX1VSTF9HVUlERSA9ICdodHRwczovL3d3dy5lbGFzdGljLmNvL2d1aWRlL2VuL2VsYXN0aWNzZWFyY2gvcmVmZXJlbmNlL2N1cnJlbnQvaW5kZXguaHRtbCc7XG5leHBvcnQgY29uc3QgUExVR0lOX1BMQVRGT1JNX1VSTF9HVUlERV9USVRMRSA9ICdFbGFzdGljIGd1aWRlJztcbmV4cG9ydCBjb25zdCBQTFVHSU5fUExBVEZPUk1fUkVRVUVTVF9IRUFERVJTID0ge1xuICAna2JuLXhzcmYnOiAna2liYW5hJ1xufTtcblxuLy8gUGx1Z2luIGFwcFxuZXhwb3J0IGNvbnN0IFBMVUdJTl9BUFBfTkFNRSA9ICdXYXp1aCBBcHAnO1xuXG4vLyBVSVxuZXhwb3J0IGNvbnN0IEFQSV9OQU1FX0FHRU5UX1NUQVRVUyA9IHtcbiAgQUNUSVZFOiAnYWN0aXZlJyxcbiAgRElTQ09OTkVDVEVEOiAnZGlzY29ubmVjdGVkJyxcbiAgUEVORElORzogJ3BlbmRpbmcnLFxuICBORVZFUl9DT05ORUNURUQ6ICduZXZlcl9jb25uZWN0ZWQnLFxufSBhcyBjb25zdDtcblxuZXhwb3J0IGNvbnN0IFVJX0NPTE9SX0FHRU5UX1NUQVRVUyA9IHtcbiAgW0FQSV9OQU1FX0FHRU5UX1NUQVRVUy5BQ1RJVkVdOiAnIzAwNzg3MScsXG4gIFtBUElfTkFNRV9BR0VOVF9TVEFUVVMuRElTQ09OTkVDVEVEXTogJyNCRDI3MUUnLFxuICBbQVBJX05BTUVfQUdFTlRfU1RBVFVTLlBFTkRJTkddOiAnI0ZFQzUxNCcsXG4gIFtBUElfTkFNRV9BR0VOVF9TVEFUVVMuTkVWRVJfQ09OTkVDVEVEXTogJyM2NDZBNzcnLFxuICBkZWZhdWx0OiAnIzAwMDAwMCdcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCBjb25zdCBVSV9MQUJFTF9OQU1FX0FHRU5UX1NUQVRVUyA9IHtcbiAgW0FQSV9OQU1FX0FHRU5UX1NUQVRVUy5BQ1RJVkVdOiAnQWN0aXZlJyxcbiAgW0FQSV9OQU1FX0FHRU5UX1NUQVRVUy5ESVNDT05ORUNURURdOiAnRGlzY29ubmVjdGVkJyxcbiAgW0FQSV9OQU1FX0FHRU5UX1NUQVRVUy5QRU5ESU5HXTogJ1BlbmRpbmcnLFxuICBbQVBJX05BTUVfQUdFTlRfU1RBVFVTLk5FVkVSX0NPTk5FQ1RFRF06ICdOZXZlciBjb25uZWN0ZWQnLFxuICBkZWZhdWx0OiAnVW5rbm93bidcbn0gYXMgY29uc3Q7XG5cbmV4cG9ydCBjb25zdCBVSV9PUkRFUl9BR0VOVF9TVEFUVVMgPSBbXG4gIEFQSV9OQU1FX0FHRU5UX1NUQVRVUy5BQ1RJVkUsXG4gIEFQSV9OQU1FX0FHRU5UX1NUQVRVUy5ESVNDT05ORUNURUQsXG4gIEFQSV9OQU1FX0FHRU5UX1NUQVRVUy5QRU5ESU5HLFxuICBBUElfTkFNRV9BR0VOVF9TVEFUVVMuTkVWRVJfQ09OTkVDVEVEXG5dXG5cbmV4cG9ydCBjb25zdCBBR0VOVF9TWU5DRURfU1RBVFVTID0ge1xuICBTWU5DRUQ6ICdzeW5jZWQnLFxuICBOT1RfU1lOQ0VEOiAnbm90IHN5bmNlZCcsXG59XG5cbi8vIERvY3VtZW50YXRpb25cbmV4cG9ydCBjb25zdCBET0NVTUVOVEFUSU9OX1dFQl9CQVNFX1VSTCA9IFwiaHR0cHM6Ly9kb2N1bWVudGF0aW9uLndhenVoLmNvbVwiO1xuXG4vLyBEZWZhdWx0IEVsYXN0aWNzZWFyY2ggdXNlciBuYW1lIGNvbnRleHRcbmV4cG9ydCBjb25zdCBFTEFTVElDX05BTUUgPSAnZWxhc3RpYyc7XG5cblxuLy8gQ3VzdG9taXphdGlvblxuZXhwb3J0IGNvbnN0IENVU1RPTUlaQVRJT05fRU5EUE9JTlRfUEFZTE9BRF9VUExPQURfQ1VTVE9NX0ZJTEVfTUFYSU1VTV9CWVRFUyA9IDEwNDg1NzY7XG5cblxuLy8gUGx1Z2luIHNldHRpbmdzXG5leHBvcnQgZW51bSBTZXR0aW5nQ2F0ZWdvcnkge1xuICBHRU5FUkFMLFxuICBIRUFMVEhfQ0hFQ0ssXG4gIEVYVEVOU0lPTlMsXG4gIE1PTklUT1JJTkcsXG4gIFNUQVRJU1RJQ1MsXG4gIFNFQ1VSSVRZLFxuICBDVVNUT01JWkFUSU9OLFxufTtcblxudHlwZSBUUGx1Z2luU2V0dGluZ09wdGlvbnNUZXh0QXJlYSA9IHtcbiAgbWF4Um93cz86IG51bWJlclxuICBtaW5Sb3dzPzogbnVtYmVyXG4gIG1heExlbmd0aD86IG51bWJlclxufTtcblxudHlwZSBUUGx1Z2luU2V0dGluZ09wdGlvbnNTZWxlY3QgPSB7XG4gIHNlbGVjdDogeyB0ZXh0OiBzdHJpbmcsIHZhbHVlOiBhbnkgfVtdXG59O1xuXG50eXBlIFRQbHVnaW5TZXR0aW5nT3B0aW9uc0VkaXRvciA9IHtcblx0ZWRpdG9yOiB7XG5cdFx0bGFuZ3VhZ2U6IHN0cmluZ1xuXHR9XG59O1xuXG50eXBlIFRQbHVnaW5TZXR0aW5nT3B0aW9uc0ZpbGUgPSB7XG5cdGZpbGU6IHtcblx0XHR0eXBlOiAnaW1hZ2UnXG5cdFx0ZXh0ZW5zaW9ucz86IHN0cmluZ1tdXG5cdFx0c2l6ZT86IHtcblx0XHRcdG1heEJ5dGVzPzogbnVtYmVyXG5cdFx0XHRtaW5CeXRlcz86IG51bWJlclxuXHRcdH1cblx0XHRyZWNvbW1lbmRlZD86IHtcblx0XHRcdGRpbWVuc2lvbnM/OiB7XG5cdFx0XHRcdHdpZHRoOiBudW1iZXIsXG5cdFx0XHRcdGhlaWdodDogbnVtYmVyLFxuXHRcdFx0XHR1bml0OiBzdHJpbmdcblx0XHRcdH1cblx0XHR9XG5cdFx0c3RvcmU/OiB7XG5cdFx0XHRyZWxhdGl2ZVBhdGhGaWxlU3lzdGVtOiBzdHJpbmdcblx0XHRcdGZpbGVuYW1lOiBzdHJpbmdcblx0XHRcdHJlc29sdmVTdGF0aWNVUkw6IChmaWxlbmFtZTogc3RyaW5nKSA9PiBzdHJpbmdcblx0XHR9XG5cdH1cbn07XG5cbnR5cGUgVFBsdWdpblNldHRpbmdPcHRpb25zTnVtYmVyID0ge1xuICBudW1iZXI6IHtcbiAgICBtaW4/OiBudW1iZXJcbiAgICBtYXg/OiBudW1iZXJcbiAgICBpbnRlZ2VyPzogYm9vbGVhblxuICB9XG59O1xuXG50eXBlIFRQbHVnaW5TZXR0aW5nT3B0aW9uc1N3aXRjaCA9IHtcbiAgc3dpdGNoOiB7XG4gICAgdmFsdWVzOiB7XG4gICAgICBkaXNhYmxlZDogeyBsYWJlbD86IHN0cmluZywgdmFsdWU6IGFueSB9LFxuICAgICAgZW5hYmxlZDogeyBsYWJlbD86IHN0cmluZywgdmFsdWU6IGFueSB9LFxuICAgIH1cbiAgfVxufTtcblxuZXhwb3J0IGVudW0gRXBsdWdpblNldHRpbmdUeXBlIHtcbiAgdGV4dCA9ICd0ZXh0JyxcbiAgdGV4dGFyZWEgPSAndGV4dGFyZWEnLFxuICBzd2l0Y2ggPSAnc3dpdGNoJyxcbiAgbnVtYmVyID0gJ251bWJlcicsXG4gIGVkaXRvciA9ICdlZGl0b3InLFxuICBzZWxlY3QgPSAnc2VsZWN0JyxcbiAgZmlsZXBpY2tlciA9ICdmaWxlcGlja2VyJ1xufTtcblxuZXhwb3J0IHR5cGUgVFBsdWdpblNldHRpbmcgPSB7XG4gIC8vIERlZmluZSB0aGUgdGV4dCBkaXNwbGF5ZWQgaW4gdGhlIFVJLlxuICB0aXRsZTogc3RyaW5nXG4gIC8vIERlc2NyaXB0aW9uLlxuICBkZXNjcmlwdGlvbjogc3RyaW5nXG4gIC8vIENhdGVnb3J5LlxuICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5XG4gIC8vIFR5cGUuXG4gIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZVxuICAvLyBEZWZhdWx0IHZhbHVlLlxuICBkZWZhdWx0VmFsdWU6IGFueVxuICAvLyBEZWZhdWx0IHZhbHVlIGlmIGl0IGlzIG5vdCBzZXQuIEl0IGhhcyBwcmVmZXJlbmNlIG92ZXIgYGRlZmF1bHRgLlxuICBkZWZhdWx0VmFsdWVJZk5vdFNldD86IGFueVxuICAvLyBDb25maWd1cmFibGUgZnJvbSB0aGUgY29uZmlndXJhdGlvbiBmaWxlLlxuICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiBib29sZWFuXG4gIC8vIENvbmZpZ3VyYWJsZSBmcm9tIHRoZSBVSSAoU2V0dGluZ3MvQ29uZmlndXJhdGlvbikuXG4gIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBib29sZWFuXG4gIC8vIE1vZGlmeSB0aGUgc2V0dGluZyByZXF1aXJlcyBydW5uaW5nIHRoZSBwbHVnaW4gaGVhbHRoIGNoZWNrIChmcm9udGVuZCkuXG4gIHJlcXVpcmVzUnVubmluZ0hlYWx0aENoZWNrPzogYm9vbGVhblxuICAvLyBNb2RpZnkgdGhlIHNldHRpbmcgcmVxdWlyZXMgcmVsb2FkaW5nIHRoZSBicm93c2VyIHRhYiAoZnJvbnRlbmQpLlxuICByZXF1aXJlc1JlbG9hZGluZ0Jyb3dzZXJUYWI/OiBib29sZWFuXG4gIC8vIE1vZGlmeSB0aGUgc2V0dGluZyByZXF1aXJlcyByZXN0YXJ0aW5nIHRoZSBwbHVnaW4gcGxhdGZvcm0gdG8gdGFrZSBlZmZlY3QuXG4gIHJlcXVpcmVzUmVzdGFydGluZ1BsdWdpblBsYXRmb3JtPzogYm9vbGVhblxuICAvLyBEZWZpbmUgb3B0aW9ucyByZWxhdGVkIHRvIHRoZSBgdHlwZWAuXG4gIG9wdGlvbnM/OlxuICBUUGx1Z2luU2V0dGluZ09wdGlvbnNFZGl0b3IgfFxuICBUUGx1Z2luU2V0dGluZ09wdGlvbnNGaWxlIHxcbiAgVFBsdWdpblNldHRpbmdPcHRpb25zTnVtYmVyIHxcbiAgVFBsdWdpblNldHRpbmdPcHRpb25zU2VsZWN0IHxcbiAgVFBsdWdpblNldHRpbmdPcHRpb25zU3dpdGNoIHxcbiAgVFBsdWdpblNldHRpbmdPcHRpb25zVGV4dEFyZWFcbiAgLy8gVHJhbnNmb3JtIHRoZSBpbnB1dCB2YWx1ZS4gVGhlIHJlc3VsdCBpcyBzYXZlZCBpbiB0aGUgZm9ybSBnbG9iYWwgc3RhdGUgb2YgU2V0dGluZ3MvQ29uZmlndXJhdGlvblxuICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZT86ICh2YWx1ZTogYW55KSA9PiBhbnlcbiAgLy8gVHJhbnNmb3JtIHRoZSBjb25maWd1cmF0aW9uIHZhbHVlIG9yIGRlZmF1bHQgYXMgaW5pdGlhbCB2YWx1ZSBmb3IgdGhlIGlucHV0IGluIFNldHRpbmdzL0NvbmZpZ3VyYXRpb25cbiAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlPzogKHZhbHVlOiBhbnkpID0+IGFueVxuICAvLyBUcmFuc2Zvcm0gdGhlIGlucHV0IHZhbHVlIGNoYW5nZWQgaW4gdGhlIGZvcm0gb2YgU2V0dGluZ3MvQ29uZmlndXJhdGlvbiBhbmQgcmV0dXJuZWQgaW4gdGhlIGBjaGFuZ2VkYCBwcm9wZXJ0eSBvZiB0aGUgaG9vayB1c2VGb3JtXG4gIHVpRm9ybVRyYW5zZm9ybUlucHV0VmFsdWVUb0NvbmZpZ3VyYXRpb25WYWx1ZT86ICh2YWx1ZTogYW55KSA9PiBhbnlcbiAgLy8gVmFsaWRhdGUgdGhlIHZhbHVlIGluIHRoZSBmb3JtIG9mIFNldHRpbmdzL0NvbmZpZ3VyYXRpb24uIEl0IHJldHVybnMgYSBzdHJpbmcgaWYgdGhlcmUgaXMgc29tZSB2YWxpZGF0aW9uIGVycm9yLlxuXHR2YWxpZGF0ZT86ICh2YWx1ZTogYW55KSA9PiBzdHJpbmcgfCB1bmRlZmluZWRcblx0Ly8gVmFsaWRhdGUgZnVuY3Rpb24gY3JlYXRvciB0byB2YWxpZGF0ZSB0aGUgc2V0dGluZyBpbiB0aGUgYmFja2VuZC4gSXQgdXNlcyBgc2NoZW1hYCBvZiB0aGUgYEBrYm4vY29uZmlnLXNjaGVtYWAgcGFja2FnZS5cblx0dmFsaWRhdGVCYWNrZW5kPzogKHNjaGVtYTogYW55KSA9PiAodmFsdWU6IHVua25vd24pID0+IHN0cmluZyB8IHVuZGVmaW5lZFxufTtcblxuZXhwb3J0IHR5cGUgVFBsdWdpblNldHRpbmdXaXRoS2V5ID0gVFBsdWdpblNldHRpbmcgJiB7IGtleTogVFBsdWdpblNldHRpbmdLZXkgfTtcbmV4cG9ydCB0eXBlIFRQbHVnaW5TZXR0aW5nQ2F0ZWdvcnkgPSB7XG4gIHRpdGxlOiBzdHJpbmdcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmdcbiAgZG9jdW1lbnRhdGlvbkxpbms/OiBzdHJpbmdcbiAgcmVuZGVyT3JkZXI/OiBudW1iZXJcbn07XG5cbmV4cG9ydCBjb25zdCBQTFVHSU5fU0VUVElOR1NfQ0FURUdPUklFUzogeyBbY2F0ZWdvcnk6IG51bWJlcl06IFRQbHVnaW5TZXR0aW5nQ2F0ZWdvcnkgfSA9IHtcbiAgW1NldHRpbmdDYXRlZ29yeS5IRUFMVEhfQ0hFQ0tdOiB7XG4gICAgdGl0bGU6ICdIZWFsdGggY2hlY2snLFxuICAgIGRlc2NyaXB0aW9uOiBcIkNoZWNrcyB3aWxsIGJlIGV4ZWN1dGVkIGJ5IHRoZSBhcHAncyBIZWFsdGhjaGVjay5cIixcbiAgICByZW5kZXJPcmRlcjogU2V0dGluZ0NhdGVnb3J5LkhFQUxUSF9DSEVDSyxcbiAgfSxcbiAgW1NldHRpbmdDYXRlZ29yeS5HRU5FUkFMXToge1xuICAgIHRpdGxlOiAnR2VuZXJhbCcsXG4gICAgZGVzY3JpcHRpb246IFwiQmFzaWMgYXBwIHNldHRpbmdzIHJlbGF0ZWQgdG8gYWxlcnRzIGluZGV4IHBhdHRlcm4sIGhpZGUgdGhlIG1hbmFnZXIgYWxlcnRzIGluIHRoZSBkYXNoYm9hcmRzLCBsb2dzIGxldmVsIGFuZCBtb3JlLlwiLFxuICAgIHJlbmRlck9yZGVyOiBTZXR0aW5nQ2F0ZWdvcnkuR0VORVJBTCxcbiAgfSxcbiAgW1NldHRpbmdDYXRlZ29yeS5FWFRFTlNJT05TXToge1xuICAgIHRpdGxlOiAnSW5pdGlhbCBkaXNwbGF5IHN0YXRlIG9mIHRoZSBtb2R1bGVzIG9mIHRoZSBuZXcgQVBJIGhvc3QgZW50cmllcy4nLFxuICAgIGRlc2NyaXB0aW9uOiBcIkV4dGVuc2lvbnMuXCIsXG4gIH0sXG4gIFtTZXR0aW5nQ2F0ZWdvcnkuU0VDVVJJVFldOiB7XG4gICAgdGl0bGU6ICdTZWN1cml0eScsXG4gICAgZGVzY3JpcHRpb246IFwiQXBwbGljYXRpb24gc2VjdXJpdHkgb3B0aW9ucyBzdWNoIGFzIHVuYXV0aG9yaXplZCByb2xlcy5cIixcbiAgICByZW5kZXJPcmRlcjogU2V0dGluZ0NhdGVnb3J5LlNFQ1VSSVRZLFxuICB9LFxuICBbU2V0dGluZ0NhdGVnb3J5Lk1PTklUT1JJTkddOiB7XG4gICAgdGl0bGU6ICdUYXNrOk1vbml0b3JpbmcnLFxuICAgIGRlc2NyaXB0aW9uOiBcIk9wdGlvbnMgcmVsYXRlZCB0byB0aGUgYWdlbnQgc3RhdHVzIG1vbml0b3Jpbmcgam9iIGFuZCBpdHMgc3RvcmFnZSBpbiBpbmRleGVzLlwiLFxuICAgIHJlbmRlck9yZGVyOiBTZXR0aW5nQ2F0ZWdvcnkuTU9OSVRPUklORyxcbiAgfSxcbiAgW1NldHRpbmdDYXRlZ29yeS5TVEFUSVNUSUNTXToge1xuICAgIHRpdGxlOiAnVGFzazpTdGF0aXN0aWNzJyxcbiAgICBkZXNjcmlwdGlvbjogXCJPcHRpb25zIHJlbGF0ZWQgdG8gdGhlIGRhZW1vbnMgbWFuYWdlciBtb25pdG9yaW5nIGpvYiBhbmQgdGhlaXIgc3RvcmFnZSBpbiBpbmRleGVzLi5cIixcbiAgICByZW5kZXJPcmRlcjogU2V0dGluZ0NhdGVnb3J5LlNUQVRJU1RJQ1MsXG4gIH0sXG4gIFtTZXR0aW5nQ2F0ZWdvcnkuQ1VTVE9NSVpBVElPTl06IHtcbiAgICB0aXRsZTogJ0N1c3RvbSBicmFuZGluZycsXG4gICAgZGVzY3JpcHRpb246IFwiSWYgeW91IHdhbnQgdG8gdXNlIGN1c3RvbSBicmFuZGluZyBlbGVtZW50cyBzdWNoIGFzIGxvZ29zLCB5b3UgY2FuIGRvIHNvIGJ5IGVkaXRpbmcgdGhlIHNldHRpbmdzIGJlbG93LlwiLFxuICAgIGRvY3VtZW50YXRpb25MaW5rOiAndXNlci1tYW51YWwvd2F6dWgtZGFzaGJvYXJkL3doaXRlLWxhYmVsaW5nLmh0bWwnLFxuICAgIHJlbmRlck9yZGVyOiBTZXR0aW5nQ2F0ZWdvcnkuQ1VTVE9NSVpBVElPTixcbiAgfVxufTtcblxuZXhwb3J0IGNvbnN0IFBMVUdJTl9TRVRUSU5HUzogeyBba2V5OiBzdHJpbmddOiBUUGx1Z2luU2V0dGluZyB9ID0ge1xuICBcImFsZXJ0cy5zYW1wbGUucHJlZml4XCI6IHtcbiAgICB0aXRsZTogXCJTYW1wbGUgYWxlcnRzIHByZWZpeFwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkRlZmluZSB0aGUgaW5kZXggbmFtZSBwcmVmaXggb2Ygc2FtcGxlIGFsZXJ0cy4gSXQgbXVzdCBtYXRjaCB0aGUgdGVtcGxhdGUgdXNlZCBieSB0aGUgaW5kZXggcGF0dGVybiB0byBhdm9pZCB1bmtub3duIGZpZWxkcyBpbiBkYXNoYm9hcmRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuR0VORVJBTCxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUudGV4dCxcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX1NBTVBMRV9BTEVSVF9QUkVGSVgsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjazogdHJ1ZSxcbiAgICAvLyBWYWxpZGF0aW9uOiBodHRwczovL2dpdGh1Yi5jb20vZWxhc3RpYy9lbGFzdGljc2VhcmNoL2Jsb2IvdjcuMTAuMi9kb2NzL3JlZmVyZW5jZS9pbmRpY2VzL2NyZWF0ZS1pbmRleC5hc2NpaWRvY1xuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaXNOb3RFbXB0eVN0cmluZyxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vU3BhY2VzLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3Iubm9TdGFydHNXaXRoU3RyaW5nKCctJywgJ18nLCAnKycsICcuJyksXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb3RJbnZhbGlkQ2hhcmFjdGVycygnXFxcXCcsICcvJywgJz8nLCAnXCInLCAnPCcsICc+JywgJ3wnLCAnLCcsICcjJywgJyonKVxuICAgICksXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5zdHJpbmcoe3ZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlfSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjaGVja3MuYXBpXCI6IHtcbiAgICB0aXRsZTogXCJBUEkgY29ubmVjdGlvblwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSBBUEkgaGVhbHRoIGNoZWNrIHdoZW4gb3BlbmluZyB0aGUgYXBwLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuSEVBTFRIX0NIRUNLLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjaGVja3MuZmllbGRzXCI6IHtcbiAgICB0aXRsZTogXCJLbm93biBmaWVsZHNcIixcbiAgICBkZXNjcmlwdGlvbjogXCJFbmFibGUgb3IgZGlzYWJsZSB0aGUga25vd24gZmllbGRzIGhlYWx0aCBjaGVjayB3aGVuIG9wZW5pbmcgdGhlIGFwcC5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkhFQUxUSF9DSEVDSyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHN3aXRjaDoge1xuICAgICAgICB2YWx1ZXM6IHtcbiAgICAgICAgICBkaXNhYmxlZDogeyBsYWJlbDogJ2ZhbHNlJywgdmFsdWU6IGZhbHNlIH0sXG4gICAgICAgICAgZW5hYmxlZDogeyBsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZSB9LFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZTogZnVuY3Rpb24gKHZhbHVlOiBib29sZWFuIHwgc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEuYm9vbGVhbigpO1xuXHRcdH0sXG4gIH0sXG4gIFwiY2hlY2tzLm1heEJ1Y2tldHNcIjoge1xuICAgIHRpdGxlOiBcIlNldCBtYXggYnVja2V0cyB0byAyMDAwMDBcIixcbiAgICBkZXNjcmlwdGlvbjogXCJDaGFuZ2UgdGhlIGRlZmF1bHQgdmFsdWUgb2YgdGhlIHBsdWdpbiBwbGF0Zm9ybSBtYXggYnVja2V0cyBjb25maWd1cmF0aW9uLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuSEVBTFRIX0NIRUNLLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZTogZnVuY3Rpb24gKHZhbHVlOiBib29sZWFuIHwgc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEuYm9vbGVhbigpO1xuXHRcdH0sXG4gIH0sXG4gIFwiY2hlY2tzLm1ldGFGaWVsZHNcIjoge1xuICAgIHRpdGxlOiBcIlJlbW92ZSBtZXRhIGZpZWxkc1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkNoYW5nZSB0aGUgZGVmYXVsdCB2YWx1ZSBvZiB0aGUgcGx1Z2luIHBsYXRmb3JtIG1ldGFGaWVsZCBjb25maWd1cmF0aW9uLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuSEVBTFRIX0NIRUNLLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjaGVja3MucGF0dGVyblwiOiB7XG4gICAgdGl0bGU6IFwiSW5kZXggcGF0dGVyblwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSBpbmRleCBwYXR0ZXJuIGhlYWx0aCBjaGVjayB3aGVuIG9wZW5pbmcgdGhlIGFwcC5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkhFQUxUSF9DSEVDSyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHN3aXRjaDoge1xuICAgICAgICB2YWx1ZXM6IHtcbiAgICAgICAgICBkaXNhYmxlZDogeyBsYWJlbDogJ2ZhbHNlJywgdmFsdWU6IGZhbHNlIH0sXG4gICAgICAgICAgZW5hYmxlZDogeyBsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZSB9LFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZTogZnVuY3Rpb24gKHZhbHVlOiBib29sZWFuIHwgc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEuYm9vbGVhbigpO1xuXHRcdH0sXG4gIH0sXG4gIFwiY2hlY2tzLnNldHVwXCI6IHtcbiAgICB0aXRsZTogXCJBUEkgdmVyc2lvblwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSBzZXR1cCBoZWFsdGggY2hlY2sgd2hlbiBvcGVuaW5nIHRoZSBhcHAuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5IRUFMVEhfQ0hFQ0ssXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImNoZWNrcy50ZW1wbGF0ZVwiOiB7XG4gICAgdGl0bGU6IFwiSW5kZXggdGVtcGxhdGVcIixcbiAgICBkZXNjcmlwdGlvbjogXCJFbmFibGUgb3IgZGlzYWJsZSB0aGUgdGVtcGxhdGUgaGVhbHRoIGNoZWNrIHdoZW4gb3BlbmluZyB0aGUgYXBwLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuSEVBTFRIX0NIRUNLLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjaGVja3MudGltZUZpbHRlclwiOiB7XG4gICAgdGl0bGU6IFwiU2V0IHRpbWUgZmlsdGVyIHRvIDI0aFwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkNoYW5nZSB0aGUgZGVmYXVsdCB2YWx1ZSBvZiB0aGUgcGx1Z2luIHBsYXRmb3JtIHRpbWVGaWx0ZXIgY29uZmlndXJhdGlvbi5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkhFQUxUSF9DSEVDSyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHN3aXRjaDoge1xuICAgICAgICB2YWx1ZXM6IHtcbiAgICAgICAgICBkaXNhYmxlZDogeyBsYWJlbDogJ2ZhbHNlJywgdmFsdWU6IGZhbHNlIH0sXG4gICAgICAgICAgZW5hYmxlZDogeyBsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZSB9LFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1DaGFuZ2VkSW5wdXRWYWx1ZTogZnVuY3Rpb24gKHZhbHVlOiBib29sZWFuIHwgc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEuYm9vbGVhbigpO1xuXHRcdH0sXG4gIH0sXG4gIFwiY3Jvbi5wcmVmaXhcIjoge1xuICAgIHRpdGxlOiBcIkNyb24gcHJlZml4XCIsXG4gICAgZGVzY3JpcHRpb246IFwiRGVmaW5lIHRoZSBpbmRleCBwcmVmaXggb2YgcHJlZGVmaW5lZCBqb2JzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuR0VORVJBTCxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUudGV4dCxcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9QUkVGSVgsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICAvLyBWYWxpZGF0aW9uOiBodHRwczovL2dpdGh1Yi5jb20vZWxhc3RpYy9lbGFzdGljc2VhcmNoL2Jsb2IvdjcuMTAuMi9kb2NzL3JlZmVyZW5jZS9pbmRpY2VzL2NyZWF0ZS1pbmRleC5hc2NpaWRvY1xuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaXNOb3RFbXB0eVN0cmluZyxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vU3BhY2VzLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3Iubm9TdGFydHNXaXRoU3RyaW5nKCctJywgJ18nLCAnKycsICcuJyksXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb3RJbnZhbGlkQ2hhcmFjdGVycygnXFxcXCcsICcvJywgJz8nLCAnXCInLCAnPCcsICc+JywgJ3wnLCAnLCcsICcjJywgJyonKVxuICAgICksXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5zdHJpbmcoe3ZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlfSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjcm9uLnN0YXRpc3RpY3MuYXBpc1wiOiB7XG4gICAgdGl0bGU6IFwiSW5jbHVkZXMgQVBJc1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVudGVyIHRoZSBJRCBvZiB0aGUgaG9zdHMgeW91IHdhbnQgdG8gc2F2ZSBkYXRhIGZyb20sIGxlYXZlIHRoaXMgZW1wdHkgdG8gcnVuIHRoZSB0YXNrIG9uIGV2ZXJ5IGhvc3QuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5TVEFUSVNUSUNTLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5lZGl0b3IsXG4gICAgZGVmYXVsdFZhbHVlOiBbXSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIGVkaXRvcjoge1xuICAgICAgICBsYW5ndWFnZTogJ2pzb24nXG4gICAgICB9XG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1Db25maWd1cmF0aW9uVmFsdWVUb0lucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYW55KTogYW55IHtcbiAgICAgIHJldHVybiBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1JbnB1dFZhbHVlVG9Db25maWd1cmF0aW9uVmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogc3RyaW5nKTogYW55IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBKU09OLnBhcnNlKHZhbHVlKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIH07XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuanNvbihTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuYXJyYXkoU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaXNTdHJpbmcsXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vU3BhY2VzLFxuICAgICAgKSksXG4gICAgKSksXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoe3ZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5pc05vdEVtcHR5U3RyaW5nLFxuICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb1NwYWNlcyxcbiAgICAgICl9KSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjcm9uLnN0YXRpc3RpY3MuaW5kZXguY3JlYXRpb25cIjoge1xuICAgIHRpdGxlOiBcIkluZGV4IGNyZWF0aW9uXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRGVmaW5lIHRoZSBpbnRlcnZhbCBpbiB3aGljaCBhIG5ldyBpbmRleCB3aWxsIGJlIGNyZWF0ZWQuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5TVEFUSVNUSUNTLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zZWxlY3QsXG4gICAgb3B0aW9uczoge1xuICAgICAgc2VsZWN0OiBbXG4gICAgICAgIHtcbiAgICAgICAgICB0ZXh0OiBcIkhvdXJseVwiLFxuICAgICAgICAgIHZhbHVlOiBcImhcIlxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgdGV4dDogXCJEYWlseVwiLFxuICAgICAgICAgIHZhbHVlOiBcImRcIlxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgdGV4dDogXCJXZWVrbHlcIixcbiAgICAgICAgICB2YWx1ZTogXCJ3XCJcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHRleHQ6IFwiTW9udGhseVwiLFxuICAgICAgICAgIHZhbHVlOiBcIm1cIlxuICAgICAgICB9XG4gICAgICBdXG4gICAgfSxcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9DUkVBVElPTixcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUnVubmluZ0hlYWx0aENoZWNrOiB0cnVlLFxuICAgIHZhbGlkYXRlOiBmdW5jdGlvbiAodmFsdWUpe1xuXHRcdFx0cmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLmxpdGVyYWwodGhpcy5vcHRpb25zLnNlbGVjdC5tYXAoKHt2YWx1ZX0pID0+IHZhbHVlKSkodmFsdWUpXG5cdFx0fSxcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLm9uZU9mKHRoaXMub3B0aW9ucy5zZWxlY3QubWFwKCh7dmFsdWV9KSA9PiBzY2hlbWEubGl0ZXJhbCh2YWx1ZSkpKTtcblx0XHR9LFxuICB9LFxuICBcImNyb24uc3RhdGlzdGljcy5pbmRleC5uYW1lXCI6IHtcbiAgICB0aXRsZTogXCJJbmRleCBuYW1lXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRGVmaW5lIHRoZSBuYW1lIG9mIHRoZSBpbmRleCBpbiB3aGljaCB0aGUgZG9jdW1lbnRzIHdpbGwgYmUgc2F2ZWQuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5TVEFUSVNUSUNTLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS50ZXh0LFxuICAgIGRlZmF1bHRWYWx1ZTogV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX05BTUUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjazogdHJ1ZSxcbiAgICAvLyBWYWxpZGF0aW9uOiBodHRwczovL2dpdGh1Yi5jb20vZWxhc3RpYy9lbGFzdGljc2VhcmNoL2Jsb2IvdjcuMTAuMi9kb2NzL3JlZmVyZW5jZS9pbmRpY2VzL2NyZWF0ZS1pbmRleC5hc2NpaWRvY1xuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaXNOb3RFbXB0eVN0cmluZyxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vU3BhY2VzLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3Iubm9TdGFydHNXaXRoU3RyaW5nKCctJywgJ18nLCAnKycsICcuJyksXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb3RJbnZhbGlkQ2hhcmFjdGVycygnXFxcXCcsICcvJywgJz8nLCAnXCInLCAnPCcsICc+JywgJ3wnLCAnLCcsICcjJywgJyonKVxuICAgICksXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5zdHJpbmcoe3ZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlfSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjcm9uLnN0YXRpc3RpY3MuaW5kZXgucmVwbGljYXNcIjoge1xuICAgIHRpdGxlOiBcIkluZGV4IHJlcGxpY2FzXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRGVmaW5lIHRoZSBudW1iZXIgb2YgcmVwbGljYXMgdG8gdXNlIGZvciB0aGUgc3RhdGlzdGljcyBpbmRpY2VzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuU1RBVElTVElDUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUubnVtYmVyLFxuICAgIGRlZmF1bHRWYWx1ZTogV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0lORElDRVNfUkVQTElDQVMsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjazogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBudW1iZXI6IHtcbiAgICAgICAgbWluOiAwLFxuICAgICAgICBpbnRlZ2VyOiB0cnVlXG4gICAgICB9XG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1Db25maWd1cmF0aW9uVmFsdWVUb0lucHV0VmFsdWU6IGZ1bmN0aW9uKHZhbHVlOiBudW1iZXIpOiBzdHJpbmcge1xuICAgICAgcmV0dXJuIFN0cmluZyh2YWx1ZSk7XG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1JbnB1dFZhbHVlVG9Db25maWd1cmF0aW9uVmFsdWU6IGZ1bmN0aW9uKHZhbHVlOiBzdHJpbmcpOiBudW1iZXIge1xuICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24odmFsdWUpe1xuXHRcdFx0cmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLm51bWJlcih0aGlzLm9wdGlvbnMubnVtYmVyKSh2YWx1ZSlcblx0XHR9LFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEubnVtYmVyKHt2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZS5iaW5kKHRoaXMpfSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjcm9uLnN0YXRpc3RpY3MuaW5kZXguc2hhcmRzXCI6IHtcbiAgICB0aXRsZTogXCJJbmRleCBzaGFyZHNcIixcbiAgICBkZXNjcmlwdGlvbjogXCJEZWZpbmUgdGhlIG51bWJlciBvZiBzaGFyZHMgdG8gdXNlIGZvciB0aGUgc3RhdGlzdGljcyBpbmRpY2VzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuU1RBVElTVElDUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUubnVtYmVyLFxuICAgIGRlZmF1bHRWYWx1ZTogV0FaVUhfU1RBVElTVElDU19ERUZBVUxUX0lORElDRVNfU0hBUkRTLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSdW5uaW5nSGVhbHRoQ2hlY2s6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgbnVtYmVyOiB7XG4gICAgICAgIG1pbjogMSxcbiAgICAgICAgaW50ZWdlcjogdHJ1ZVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlOiBmdW5jdGlvbih2YWx1ZTogbnVtYmVyKXtcbiAgICAgIHJldHVybiBTdHJpbmcodmFsdWUpXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1JbnB1dFZhbHVlVG9Db25maWd1cmF0aW9uVmFsdWU6IGZ1bmN0aW9uKHZhbHVlOiBzdHJpbmcpOiBudW1iZXIge1xuICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24odmFsdWUpe1xuXHRcdFx0cmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLm51bWJlcih0aGlzLm9wdGlvbnMubnVtYmVyKSh2YWx1ZSlcblx0XHR9LFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEubnVtYmVyKHt2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZS5iaW5kKHRoaXMpfSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjcm9uLnN0YXRpc3RpY3MuaW50ZXJ2YWxcIjoge1xuICAgIHRpdGxlOiBcIkludGVydmFsXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRGVmaW5lIHRoZSBmcmVxdWVuY3kgb2YgdGFzayBleGVjdXRpb24gdXNpbmcgY3JvbiBzY2hlZHVsZSBleHByZXNzaW9ucy5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LlNUQVRJU1RJQ1MsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnRleHQsXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9TVEFUSVNUSUNTX0RFRkFVTFRfQ1JPTl9GUkVRLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSZXN0YXJ0aW5nUGx1Z2luUGxhdGZvcm06IHRydWUsXG4gICAgdmFsaWRhdGU6IGZ1bmN0aW9uKHZhbHVlOiBzdHJpbmcpe1xuXHRcdFx0cmV0dXJuIHZhbGlkYXRlTm9kZUNyb25JbnRlcnZhbCh2YWx1ZSkgPyB1bmRlZmluZWQgOiBcIkludGVydmFsIGlzIG5vdCB2YWxpZC5cIlxuXHRcdH0sXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5zdHJpbmcoe3ZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlfSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJjcm9uLnN0YXRpc3RpY3Muc3RhdHVzXCI6IHtcbiAgICB0aXRsZTogXCJTdGF0dXNcIixcbiAgICBkZXNjcmlwdGlvbjogXCJFbmFibGUgb3IgZGlzYWJsZSB0aGUgc3RhdGlzdGljcyB0YXNrcy5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LlNUQVRJU1RJQ1MsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX1NUQVRJU1RJQ1NfREVGQVVMVF9TVEFUVVMsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImN1c3RvbWl6YXRpb24uZW5hYmxlZFwiOiB7XG5cdFx0dGl0bGU6IFwiU3RhdHVzXCIsXG5cdFx0ZGVzY3JpcHRpb246IFwiRW5hYmxlIG9yIGRpc2FibGUgdGhlIGN1c3RvbWl6YXRpb24uXCIsXG5cdFx0Y2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5DVVNUT01JWkFUSU9OLFxuXHRcdHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG5cdFx0ZGVmYXVsdFZhbHVlOiB0cnVlLFxuXHRcdGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG5cdFx0aXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSZWxvYWRpbmdCcm93c2VyVGFiOiB0cnVlLFxuXHRcdG9wdGlvbnM6IHtcblx0XHRcdHN3aXRjaDoge1xuXHRcdFx0XHR2YWx1ZXM6IHtcblx0XHRcdFx0XHRkaXNhYmxlZDoge2xhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2V9LFxuXHRcdFx0XHRcdGVuYWJsZWQ6IHtsYWJlbDogJ3RydWUnLCB2YWx1ZTogdHJ1ZX0sXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9LFxuXHRcdHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbih2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW57XG5cdFx0XHRyZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG5cdFx0fSxcblx0XHR2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuaXNCb29sZWFuLFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEuYm9vbGVhbigpO1xuXHRcdH0sXG5cdH0sXG4gIFwiY3VzdG9taXphdGlvbi5sb2dvLmFwcFwiOiB7XG4gICAgdGl0bGU6IFwiQXBwIG1haW4gbG9nb1wiLFxuICAgIGRlc2NyaXB0aW9uOiBgVGhpcyBsb2dvIGlzIHVzZWQgaW4gdGhlIGFwcCBtYWluIG1lbnUsIGF0IHRoZSB0b3AgbGVmdCBjb3JuZXIuYCxcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkNVU1RPTUlaQVRJT04sXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLmZpbGVwaWNrZXIsXG4gICAgZGVmYXVsdFZhbHVlOiBcIlwiLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuXHRcdFx0ZmlsZToge1xuXHRcdFx0XHR0eXBlOiAnaW1hZ2UnLFxuXHRcdFx0XHRleHRlbnNpb25zOiBbJy5qcGVnJywgJy5qcGcnLCAnLnBuZycsICcuc3ZnJ10sXG5cdFx0XHRcdHNpemU6IHtcblx0XHRcdFx0XHRtYXhCeXRlczogQ1VTVE9NSVpBVElPTl9FTkRQT0lOVF9QQVlMT0FEX1VQTE9BRF9DVVNUT01fRklMRV9NQVhJTVVNX0JZVEVTLFxuXHRcdFx0XHR9LFxuXHRcdFx0XHRyZWNvbW1lbmRlZDoge1xuXHRcdFx0XHRcdGRpbWVuc2lvbnM6IHtcblx0XHRcdFx0XHRcdHdpZHRoOiAzMDAsXG5cdFx0XHRcdFx0XHRoZWlnaHQ6IDcwLFxuXHRcdFx0XHRcdFx0dW5pdDogJ3B4J1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSxcblx0XHRcdFx0c3RvcmU6IHtcblx0XHRcdFx0XHRyZWxhdGl2ZVBhdGhGaWxlU3lzdGVtOiAncHVibGljL2Fzc2V0cy9jdXN0b20vaW1hZ2VzJyxcblx0XHRcdFx0XHRmaWxlbmFtZTogJ2N1c3RvbWl6YXRpb24ubG9nby5hcHAnLFxuXHRcdFx0XHRcdHJlc29sdmVTdGF0aWNVUkw6IChmaWxlbmFtZTogc3RyaW5nKSA9PiBgY3VzdG9tL2ltYWdlcy8ke2ZpbGVuYW1lfT92PSR7RGF0ZS5ub3coKX1gXG4gICAgICAgICAgLy8gP3Y9JHtEYXRlLm5vdygpfSBpcyB1c2VkIHRvIGZvcmNlIHRoZSBicm93c2VyIHRvIHJlbG9hZCB0aGUgaW1hZ2Ugd2hlbiBhIG5ldyBmaWxlIGlzIHVwbG9hZGVkXG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9LFxuXHRcdHZhbGlkYXRlOiBmdW5jdGlvbih2YWx1ZSl7XG5cdFx0XHRyZXR1cm4gU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcblx0XHRcdFx0U2V0dGluZ3NWYWxpZGF0b3IuZmlsZVBpY2tlckZpbGVTaXplKHsuLi50aGlzLm9wdGlvbnMuZmlsZS5zaXplLCBtZWFuaW5nZnVsVW5pdDogdHJ1ZX0pLFxuXHRcdFx0XHRTZXR0aW5nc1ZhbGlkYXRvci5maWxlUGlja2VyU3VwcG9ydGVkRXh0ZW5zaW9ucyh0aGlzLm9wdGlvbnMuZmlsZS5leHRlbnNpb25zKVxuXHRcdFx0KSh2YWx1ZSlcblx0XHR9LFxuICB9LFxuICBcImN1c3RvbWl6YXRpb24ubG9nby5oZWFsdGhjaGVja1wiOiB7XG4gICAgdGl0bGU6IFwiSGVhbHRoY2hlY2sgbG9nb1wiLFxuICAgIGRlc2NyaXB0aW9uOiBgVGhpcyBsb2dvIGlzIGRpc3BsYXllZCBkdXJpbmcgdGhlIEhlYWx0aGNoZWNrIHJvdXRpbmUgb2YgdGhlIGFwcC5gLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuQ1VTVE9NSVpBVElPTixcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuZmlsZXBpY2tlcixcbiAgICBkZWZhdWx0VmFsdWU6IFwiXCIsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG5cdFx0XHRmaWxlOiB7XG5cdFx0XHRcdHR5cGU6ICdpbWFnZScsXG5cdFx0XHRcdGV4dGVuc2lvbnM6IFsnLmpwZWcnLCAnLmpwZycsICcucG5nJywgJy5zdmcnXSxcblx0XHRcdFx0c2l6ZToge1xuXHRcdFx0XHRcdG1heEJ5dGVzOiBDVVNUT01JWkFUSU9OX0VORFBPSU5UX1BBWUxPQURfVVBMT0FEX0NVU1RPTV9GSUxFX01BWElNVU1fQllURVMsXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHJlY29tbWVuZGVkOiB7XG5cdFx0XHRcdFx0ZGltZW5zaW9uczoge1xuXHRcdFx0XHRcdFx0d2lkdGg6IDMwMCxcblx0XHRcdFx0XHRcdGhlaWdodDogNzAsXG5cdFx0XHRcdFx0XHR1bml0OiAncHgnXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRzdG9yZToge1xuXHRcdFx0XHRcdHJlbGF0aXZlUGF0aEZpbGVTeXN0ZW06ICdwdWJsaWMvYXNzZXRzL2N1c3RvbS9pbWFnZXMnLFxuXHRcdFx0XHRcdGZpbGVuYW1lOiAnY3VzdG9taXphdGlvbi5sb2dvLmhlYWx0aGNoZWNrJyxcblx0XHRcdFx0XHRyZXNvbHZlU3RhdGljVVJMOiAoZmlsZW5hbWU6IHN0cmluZykgPT4gYGN1c3RvbS9pbWFnZXMvJHtmaWxlbmFtZX0/dj0ke0RhdGUubm93KCl9YFxuICAgICAgICAgIC8vID92PSR7RGF0ZS5ub3coKX0gaXMgdXNlZCB0byBmb3JjZSB0aGUgYnJvd3NlciB0byByZWxvYWQgdGhlIGltYWdlIHdoZW4gYSBuZXcgZmlsZSBpcyB1cGxvYWRlZFxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSxcblx0XHR2YWxpZGF0ZTogZnVuY3Rpb24odmFsdWUpe1xuXHRcdFx0cmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG5cdFx0XHRcdFNldHRpbmdzVmFsaWRhdG9yLmZpbGVQaWNrZXJGaWxlU2l6ZSh7Li4udGhpcy5vcHRpb25zLmZpbGUuc2l6ZSwgbWVhbmluZ2Z1bFVuaXQ6IHRydWV9KSxcblx0XHRcdFx0U2V0dGluZ3NWYWxpZGF0b3IuZmlsZVBpY2tlclN1cHBvcnRlZEV4dGVuc2lvbnModGhpcy5vcHRpb25zLmZpbGUuZXh0ZW5zaW9ucylcblx0XHRcdCkodmFsdWUpXG5cdFx0fSxcbiAgfSxcbiAgXCJjdXN0b21pemF0aW9uLmxvZ28ucmVwb3J0c1wiOiB7XG4gICAgdGl0bGU6IFwiUERGIHJlcG9ydHMgbG9nb1wiLFxuICAgIGRlc2NyaXB0aW9uOiBgVGhpcyBsb2dvIGlzIHVzZWQgaW4gdGhlIFBERiByZXBvcnRzIGdlbmVyYXRlZCBieSB0aGUgYXBwLiBJdCdzIHBsYWNlZCBhdCB0aGUgdG9wIGxlZnQgY29ybmVyIG9mIGV2ZXJ5IHBhZ2Ugb2YgdGhlIFBERi5gLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuQ1VTVE9NSVpBVElPTixcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuZmlsZXBpY2tlcixcbiAgICBkZWZhdWx0VmFsdWU6IFwiXCIsXG4gICAgZGVmYXVsdFZhbHVlSWZOb3RTZXQ6IFJFUE9SVFNfTE9HT19JTUFHRV9BU1NFVFNfUkVMQVRJVkVfUEFUSCxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIG9wdGlvbnM6IHtcblx0XHRcdGZpbGU6IHtcblx0XHRcdFx0dHlwZTogJ2ltYWdlJyxcblx0XHRcdFx0ZXh0ZW5zaW9uczogWycuanBlZycsICcuanBnJywgJy5wbmcnXSxcblx0XHRcdFx0c2l6ZToge1xuXHRcdFx0XHRcdG1heEJ5dGVzOiBDVVNUT01JWkFUSU9OX0VORFBPSU5UX1BBWUxPQURfVVBMT0FEX0NVU1RPTV9GSUxFX01BWElNVU1fQllURVMsXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHJlY29tbWVuZGVkOiB7XG5cdFx0XHRcdFx0ZGltZW5zaW9uczoge1xuXHRcdFx0XHRcdFx0d2lkdGg6IDE5MCxcblx0XHRcdFx0XHRcdGhlaWdodDogNDAsXG5cdFx0XHRcdFx0XHR1bml0OiAncHgnXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9LFxuXHRcdFx0XHRzdG9yZToge1xuXHRcdFx0XHRcdHJlbGF0aXZlUGF0aEZpbGVTeXN0ZW06ICdwdWJsaWMvYXNzZXRzL2N1c3RvbS9pbWFnZXMnLFxuXHRcdFx0XHRcdGZpbGVuYW1lOiAnY3VzdG9taXphdGlvbi5sb2dvLnJlcG9ydHMnLFxuXHRcdFx0XHRcdHJlc29sdmVTdGF0aWNVUkw6IChmaWxlbmFtZTogc3RyaW5nKSA9PiBgY3VzdG9tL2ltYWdlcy8ke2ZpbGVuYW1lfWBcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0sXG5cdFx0dmFsaWRhdGU6IGZ1bmN0aW9uKHZhbHVlKXtcblx0XHRcdHJldHVybiBTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuXHRcdFx0XHRTZXR0aW5nc1ZhbGlkYXRvci5maWxlUGlja2VyRmlsZVNpemUoey4uLnRoaXMub3B0aW9ucy5maWxlLnNpemUsIG1lYW5pbmdmdWxVbml0OiB0cnVlfSksXG5cdFx0XHRcdFNldHRpbmdzVmFsaWRhdG9yLmZpbGVQaWNrZXJTdXBwb3J0ZWRFeHRlbnNpb25zKHRoaXMub3B0aW9ucy5maWxlLmV4dGVuc2lvbnMpXG5cdFx0XHQpKHZhbHVlKVxuXHRcdH0sXG4gIH0sXG4gIFwiY3VzdG9taXphdGlvbi5sb2dvLnNpZGViYXJcIjoge1xuICAgIHRpdGxlOiBcIk5hdmlnYXRpb24gZHJhd2VyIGxvZ29cIixcbiAgICBkZXNjcmlwdGlvbjogYFRoaXMgaXMgdGhlIGxvZ28gZm9yIHRoZSBhcHAgdG8gZGlzcGxheSBpbiB0aGUgcGxhdGZvcm0ncyBuYXZpZ2F0aW9uIGRyYXdlciwgdGhpcyBpcywgdGhlIG1haW4gc2lkZWJhciBjb2xsYXBzaWJsZSBtZW51LmAsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5DVVNUT01JWkFUSU9OLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5maWxlcGlja2VyLFxuICAgIGRlZmF1bHRWYWx1ZTogXCJcIixcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUmVsb2FkaW5nQnJvd3NlclRhYjogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG5cdFx0XHRmaWxlOiB7XG5cdFx0XHRcdHR5cGU6ICdpbWFnZScsXG5cdFx0XHRcdGV4dGVuc2lvbnM6IFsnLmpwZWcnLCAnLmpwZycsICcucG5nJywgJy5zdmcnXSxcblx0XHRcdFx0c2l6ZToge1xuXHRcdFx0XHRcdG1heEJ5dGVzOiBDVVNUT01JWkFUSU9OX0VORFBPSU5UX1BBWUxPQURfVVBMT0FEX0NVU1RPTV9GSUxFX01BWElNVU1fQllURVMsXG5cdFx0XHRcdH0sXG5cdFx0XHRcdHJlY29tbWVuZGVkOiB7XG5cdFx0XHRcdFx0ZGltZW5zaW9uczoge1xuXHRcdFx0XHRcdFx0d2lkdGg6IDgwLFxuXHRcdFx0XHRcdFx0aGVpZ2h0OiA4MCxcblx0XHRcdFx0XHRcdHVuaXQ6ICdweCdcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0sXG5cdFx0XHRcdHN0b3JlOiB7XG5cdFx0XHRcdFx0cmVsYXRpdmVQYXRoRmlsZVN5c3RlbTogJ3B1YmxpYy9hc3NldHMvY3VzdG9tL2ltYWdlcycsXG5cdFx0XHRcdFx0ZmlsZW5hbWU6ICdjdXN0b21pemF0aW9uLmxvZ28uc2lkZWJhcicsXG5cdFx0XHRcdFx0cmVzb2x2ZVN0YXRpY1VSTDogKGZpbGVuYW1lOiBzdHJpbmcpID0+IGBjdXN0b20vaW1hZ2VzLyR7ZmlsZW5hbWV9P3Y9JHtEYXRlLm5vdygpfWBcbiAgICAgICAgICAvLyA/dj0ke0RhdGUubm93KCl9IGlzIHVzZWQgdG8gZm9yY2UgdGhlIGJyb3dzZXIgdG8gcmVsb2FkIHRoZSBpbWFnZSB3aGVuIGEgbmV3IGZpbGUgaXMgdXBsb2FkZWRcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0sXG5cdFx0dmFsaWRhdGU6IGZ1bmN0aW9uKHZhbHVlKXtcblx0XHRcdHJldHVybiBTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuXHRcdFx0XHRTZXR0aW5nc1ZhbGlkYXRvci5maWxlUGlja2VyRmlsZVNpemUoey4uLnRoaXMub3B0aW9ucy5maWxlLnNpemUsIG1lYW5pbmdmdWxVbml0OiB0cnVlfSksXG5cdFx0XHRcdFNldHRpbmdzVmFsaWRhdG9yLmZpbGVQaWNrZXJTdXBwb3J0ZWRFeHRlbnNpb25zKHRoaXMub3B0aW9ucy5maWxlLmV4dGVuc2lvbnMpXG5cdFx0XHQpKHZhbHVlKVxuXHRcdH0sXG4gIH0sXG4gIFwiY3VzdG9taXphdGlvbi5yZXBvcnRzLmZvb3RlclwiOiB7XG5cdFx0dGl0bGU6IFwiUmVwb3J0cyBmb290ZXJcIixcblx0XHRkZXNjcmlwdGlvbjogXCJTZXQgdGhlIGZvb3RlciBvZiB0aGUgcmVwb3J0cy5cIixcblx0XHRjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkNVU1RPTUlaQVRJT04sXG5cdFx0dHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnRleHRhcmVhLFxuXHRcdGRlZmF1bHRWYWx1ZTogXCJcIixcbiAgICBkZWZhdWx0VmFsdWVJZk5vdFNldDogUkVQT1JUU19QQUdFX0ZPT1RFUl9URVhULFxuXHRcdGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG5cdFx0aXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczogeyBtYXhSb3dzOiAyLCBtYXhMZW5ndGg6IDUwIH0sXG4gICAgdmFsaWRhdGU6IGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgcmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLm11bHRpcGxlTGluZXNTdHJpbmcoe1xuICAgICAgICBtYXhSb3dzOiB0aGlzLm9wdGlvbnM/Lm1heFJvd3MsXG4gICAgICAgIG1heExlbmd0aDogdGhpcy5vcHRpb25zPy5tYXhMZW5ndGhcbiAgICAgIH0pKHZhbHVlKVxuICAgIH0sXG4gICAgdmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbiAoc2NoZW1hKSB7XG4gICAgICByZXR1cm4gc2NoZW1hLnN0cmluZyh7IHZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlLmJpbmQodGhpcykgfSk7XG4gICAgfSxcbiAgfSxcbiAgXCJjdXN0b21pemF0aW9uLnJlcG9ydHMuaGVhZGVyXCI6IHtcbiAgICB0aXRsZTogXCJSZXBvcnRzIGhlYWRlclwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIlNldCB0aGUgaGVhZGVyIG9mIHRoZSByZXBvcnRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuQ1VTVE9NSVpBVElPTixcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUudGV4dGFyZWEsXG4gICAgZGVmYXVsdFZhbHVlOiBcIlwiLFxuICAgIGRlZmF1bHRWYWx1ZUlmTm90U2V0OiBSRVBPUlRTX1BBR0VfSEVBREVSX1RFWFQsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7IG1heFJvd3M6IDMsIG1heExlbmd0aDogNDAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICByZXR1cm4gU2V0dGluZ3NWYWxpZGF0b3IubXVsdGlwbGVMaW5lc1N0cmluZyh7XG4gICAgICAgIG1heFJvd3M6IHRoaXMub3B0aW9ucz8ubWF4Um93cyxcbiAgICAgICAgbWF4TGVuZ3RoOiB0aGlzLm9wdGlvbnM/Lm1heExlbmd0aFxuICAgICAgfSkodmFsdWUpXG4gICAgfSxcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLnN0cmluZyh7dmFsaWRhdGU6IHRoaXMudmFsaWRhdGUuYmluZCh0aGlzKX0pO1xuXHRcdH0sXG5cdH0sXG4gIFwiZGlzYWJsZWRfcm9sZXNcIjoge1xuICAgIHRpdGxlOiBcIkRpc2FibGUgcm9sZXNcIixcbiAgICBkZXNjcmlwdGlvbjogXCJEaXNhYmxlZCB0aGUgcGx1Z2luIHZpc2liaWxpdHkgZm9yIHVzZXJzIHdpdGggdGhlIHJvbGVzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuU0VDVVJJVFksXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLmVkaXRvcixcbiAgICBkZWZhdWx0VmFsdWU6IFtdLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgZWRpdG9yOiB7XG4gICAgICAgIGxhbmd1YWdlOiAnanNvbidcbiAgICAgIH1cbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNvbmZpZ3VyYXRpb25WYWx1ZVRvSW5wdXRWYWx1ZTogZnVuY3Rpb24gKHZhbHVlOiBhbnkpOiBhbnkge1xuICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHZhbHVlKTtcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUlucHV0VmFsdWVUb0NvbmZpZ3VyYXRpb25WYWx1ZTogZnVuY3Rpb24gKHZhbHVlOiBzdHJpbmcpOiBhbnkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIEpTT04ucGFyc2UodmFsdWUpO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5qc29uKFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5hcnJheShTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5pc1N0cmluZyxcbiAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaXNOb3RFbXB0eVN0cmluZyxcbiAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm9TcGFjZXMsXG4gICAgICApKSxcbiAgICApKSxcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZyh7dmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vU3BhY2VzLFxuICAgICAgKX0pKTtcblx0XHR9LFxuICB9LFxuICBcImVucm9sbG1lbnQuZG5zXCI6IHtcbiAgICB0aXRsZTogXCJFbnJvbGxtZW50IEROU1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIlNwZWNpZmllcyB0aGUgV2F6dWggcmVnaXN0cmF0aW9uIHNlcnZlciwgdXNlZCBmb3IgdGhlIGFnZW50IGVucm9sbG1lbnQuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5HRU5FUkFMLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS50ZXh0LFxuICAgIGRlZmF1bHRWYWx1ZTogXCJcIixcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb1NwYWNlcyxcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLnN0cmluZyh7dmFsaWRhdGU6IHRoaXMudmFsaWRhdGV9KTtcblx0XHR9LFxuICB9LFxuICBcImVucm9sbG1lbnQucGFzc3dvcmRcIjoge1xuICAgIHRpdGxlOiBcIkVucm9sbG1lbnQgcGFzc3dvcmRcIixcbiAgICBkZXNjcmlwdGlvbjogXCJTcGVjaWZpZXMgdGhlIHBhc3N3b3JkIHVzZWQgdG8gYXV0aGVudGljYXRlIGR1cmluZyB0aGUgYWdlbnQgZW5yb2xsbWVudC5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnRleHQsXG4gICAgZGVmYXVsdFZhbHVlOiBcIlwiLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IGZhbHNlLFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc05vdEVtcHR5U3RyaW5nLFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEuc3RyaW5nKHt2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZX0pO1xuXHRcdH0sXG4gIH0sXG4gIFwiZXh0ZW5zaW9ucy5hdWRpdFwiOiB7XG4gICAgdGl0bGU6IFwiU3lzdGVtIGF1ZGl0aW5nXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRW5hYmxlIG9yIGRpc2FibGUgdGhlIEF1ZGl0IHRhYiBvbiBPdmVydmlldyBhbmQgQWdlbnRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuRVhURU5TSU9OUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImV4dGVuc2lvbnMuYXdzXCI6IHtcbiAgICB0aXRsZTogXCJBbWF6b24gQVdTXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRW5hYmxlIG9yIGRpc2FibGUgdGhlIEFtYXpvbiAoQVdTKSB0YWIgb24gT3ZlcnZpZXcuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5FWFRFTlNJT05TLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiBmYWxzZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImV4dGVuc2lvbnMuY2lzY2F0XCI6IHtcbiAgICB0aXRsZTogXCJDSVMtQ0FUXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRW5hYmxlIG9yIGRpc2FibGUgdGhlIENJUy1DQVQgdGFiIG9uIE92ZXJ2aWV3IGFuZCBBZ2VudHMuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5FWFRFTlNJT05TLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiBmYWxzZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImV4dGVuc2lvbnMuZG9ja2VyXCI6IHtcbiAgICB0aXRsZTogXCJEb2NrZXIgbGlzdGVuZXJcIixcbiAgICBkZXNjcmlwdGlvbjogXCJFbmFibGUgb3IgZGlzYWJsZSB0aGUgRG9ja2VyIGxpc3RlbmVyIHRhYiBvbiBPdmVydmlldyBhbmQgQWdlbnRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuRVhURU5TSU9OUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogZmFsc2UsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogZmFsc2UsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG5cdFx0fSxcbiAgfSxcbiAgXCJleHRlbnNpb25zLmdjcFwiOiB7XG4gICAgdGl0bGU6IFwiR29vZ2xlIENsb3VkIHBsYXRmb3JtXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRW5hYmxlIG9yIGRpc2FibGUgdGhlIEdvb2dsZSBDbG91ZCBQbGF0Zm9ybSB0YWIgb24gT3ZlcnZpZXcuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5FWFRFTlNJT05TLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiBmYWxzZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImV4dGVuc2lvbnMuZ2RwclwiOiB7XG4gICAgdGl0bGU6IFwiR0RQUlwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSBHRFBSIHRhYiBvbiBPdmVydmlldyBhbmQgQWdlbnRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuRVhURU5TSU9OUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImV4dGVuc2lvbnMuaGlwYWFcIjoge1xuICAgIHRpdGxlOiBcIkhpcGFhXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRW5hYmxlIG9yIGRpc2FibGUgdGhlIEhJUEFBIHRhYiBvbiBPdmVydmlldyBhbmQgQWdlbnRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuRVhURU5TSU9OUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImV4dGVuc2lvbnMubmlzdFwiOiB7XG4gICAgdGl0bGU6IFwiTklTVFwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSBOSVNUIDgwMC01MyB0YWIgb24gT3ZlcnZpZXcgYW5kIEFnZW50cy5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkVYVEVOU0lPTlMsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnN3aXRjaCxcbiAgICBkZWZhdWx0VmFsdWU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogZmFsc2UsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG5cdFx0fSxcbiAgfSxcbiAgXCJleHRlbnNpb25zLm9zY2FwXCI6IHtcbiAgICB0aXRsZTogXCJPU0NBUFwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSBPcGVuIFNDQVAgdGFiIG9uIE92ZXJ2aWV3IGFuZCBBZ2VudHMuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5FWFRFTlNJT05TLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiBmYWxzZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImV4dGVuc2lvbnMub3NxdWVyeVwiOiB7XG4gICAgdGl0bGU6IFwiT3NxdWVyeVwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSBPc3F1ZXJ5IHRhYiBvbiBPdmVydmlldyBhbmQgQWdlbnRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuRVhURU5TSU9OUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogZmFsc2UsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogZmFsc2UsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG5cdFx0fSxcbiAgfSxcbiAgXCJleHRlbnNpb25zLnBjaVwiOiB7XG4gICAgdGl0bGU6IFwiUENJIERTU1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSBQQ0kgRFNTIHRhYiBvbiBPdmVydmlldyBhbmQgQWdlbnRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuRVhURU5TSU9OUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImV4dGVuc2lvbnMudHNjXCI6IHtcbiAgICB0aXRsZTogXCJUU0NcIixcbiAgICBkZXNjcmlwdGlvbjogXCJFbmFibGUgb3IgZGlzYWJsZSB0aGUgVFNDIHRhYiBvbiBPdmVydmlldyBhbmQgQWdlbnRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuRVhURU5TSU9OUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImV4dGVuc2lvbnMudmlydXN0b3RhbFwiOiB7XG4gICAgdGl0bGU6IFwiVmlydXN0b3RhbFwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSBWaXJ1c1RvdGFsIHRhYiBvbiBPdmVydmlldyBhbmQgQWdlbnRzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuRVhURU5TSU9OUyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogZmFsc2UsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogZmFsc2UsXG4gICAgb3B0aW9uczoge1xuICAgICAgc3dpdGNoOiB7XG4gICAgICAgIHZhbHVlczoge1xuICAgICAgICAgIGRpc2FibGVkOiB7IGxhYmVsOiAnZmFsc2UnLCB2YWx1ZTogZmFsc2UgfSxcbiAgICAgICAgICBlbmFibGVkOiB7IGxhYmVsOiAndHJ1ZScsIHZhbHVlOiB0cnVlIH0sXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUNoYW5nZWRJbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGJvb2xlYW4gfCBzdHJpbmcpOiBib29sZWFuIHtcbiAgICAgIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5pc0Jvb2xlYW4sXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5ib29sZWFuKCk7XG5cdFx0fSxcbiAgfSxcbiAgXCJoaWRlTWFuYWdlckFsZXJ0c1wiOiB7XG4gICAgdGl0bGU6IFwiSGlkZSBtYW5hZ2VyIGFsZXJ0c1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkhpZGUgdGhlIGFsZXJ0cyBvZiB0aGUgbWFuYWdlciBpbiBldmVyeSBkYXNoYm9hcmQuXCIsXG4gICAgY2F0ZWdvcnk6IFNldHRpbmdDYXRlZ29yeS5HRU5FUkFMLFxuICAgIHR5cGU6IEVwbHVnaW5TZXR0aW5nVHlwZS5zd2l0Y2gsXG4gICAgZGVmYXVsdFZhbHVlOiBmYWxzZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUmVsb2FkaW5nQnJvd3NlclRhYjogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImlwLmlnbm9yZVwiOiB7XG4gICAgdGl0bGU6IFwiSW5kZXggcGF0dGVybiBpZ25vcmVcIixcbiAgICBkZXNjcmlwdGlvbjogXCJEaXNhYmxlIGNlcnRhaW4gaW5kZXggcGF0dGVybiBuYW1lcyBmcm9tIGJlaW5nIGF2YWlsYWJsZSBpbiBpbmRleCBwYXR0ZXJuIHNlbGVjdG9yLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuR0VORVJBTCxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuZWRpdG9yLFxuICAgIGRlZmF1bHRWYWx1ZTogW10sXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBlZGl0b3I6IHtcbiAgICAgICAgbGFuZ3VhZ2U6ICdqc29uJ1xuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IGFueSk6IGFueSB7XG4gICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtSW5wdXRWYWx1ZVRvQ29uZmlndXJhdGlvblZhbHVlOiBmdW5jdGlvbiAodmFsdWU6IHN0cmluZyk6IGFueSB7XG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZSh2YWx1ZSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICB9O1xuICAgIH0sXG4gICAgLy8gVmFsaWRhdGlvbjogaHR0cHM6Ly9naXRodWIuY29tL2VsYXN0aWMvZWxhc3RpY3NlYXJjaC9ibG9iL3Y3LjEwLjIvZG9jcy9yZWZlcmVuY2UvaW5kaWNlcy9jcmVhdGUtaW5kZXguYXNjaWlkb2NcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuanNvbihTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuYXJyYXkoU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaXNTdHJpbmcsXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vU3BhY2VzLFxuICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5ub0xpdGVyYWxTdHJpbmcoJy4nLCAnLi4nKSxcbiAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3Iubm9TdGFydHNXaXRoU3RyaW5nKCctJywgJ18nLCAnKycsICcuJyksXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmhhc05vdEludmFsaWRDaGFyYWN0ZXJzKCdcXFxcJywgJy8nLCAnPycsICdcIicsICc8JywgJz4nLCAnfCcsICcsJywgJyMnKVxuICAgICAgKSksXG4gICAgKSksXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoe3ZhbGlkYXRlOiBTZXR0aW5nc1ZhbGlkYXRvci5jb21wb3NlKFxuICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5pc05vdEVtcHR5U3RyaW5nLFxuICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb1NwYWNlcyxcbiAgICAgICAgU2V0dGluZ3NWYWxpZGF0b3Iubm9MaXRlcmFsU3RyaW5nKCcuJywgJy4uJyksXG4gICAgICAgIFNldHRpbmdzVmFsaWRhdG9yLm5vU3RhcnRzV2l0aFN0cmluZygnLScsICdfJywgJysnLCAnLicpLFxuICAgICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb3RJbnZhbGlkQ2hhcmFjdGVycygnXFxcXCcsICcvJywgJz8nLCAnXCInLCAnPCcsICc+JywgJ3wnLCAnLCcsICcjJylcbiAgICAgICl9KSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJpcC5zZWxlY3RvclwiOiB7XG4gICAgdGl0bGU6IFwiSVAgc2VsZWN0b3JcIixcbiAgICBkZXNjcmlwdGlvbjogXCJEZWZpbmUgaWYgdGhlIHVzZXIgaXMgYWxsb3dlZCB0byBjaGFuZ2UgdGhlIHNlbGVjdGVkIGluZGV4IHBhdHRlcm4gZGlyZWN0bHkgZnJvbSB0aGUgdG9wIG1lbnUgYmFyLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuR0VORVJBTCxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiBmYWxzZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcImxvZ3MubGV2ZWxcIjoge1xuICAgIHRpdGxlOiBcIkxvZyBsZXZlbFwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkxvZ2dpbmcgbGV2ZWwgb2YgdGhlIEFwcC5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnNlbGVjdCxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzZWxlY3Q6IFtcbiAgICAgICAge1xuICAgICAgICAgIHRleHQ6IFwiSW5mb1wiLFxuICAgICAgICAgIHZhbHVlOiBcImluZm9cIlxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgdGV4dDogXCJEZWJ1Z1wiLFxuICAgICAgICAgIHZhbHVlOiBcImRlYnVnXCJcbiAgICAgICAgfVxuICAgICAgXVxuICAgIH0sXG4gICAgZGVmYXVsdFZhbHVlOiBcImluZm9cIixcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUmVzdGFydGluZ1BsdWdpblBsYXRmb3JtOiB0cnVlLFxuICAgIHZhbGlkYXRlOiBmdW5jdGlvbiAodmFsdWUpe1xuXHRcdFx0cmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLmxpdGVyYWwodGhpcy5vcHRpb25zLnNlbGVjdC5tYXAoKHt2YWx1ZX0pID0+IHZhbHVlKSkodmFsdWUpXG5cdFx0fSxcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLm9uZU9mKHRoaXMub3B0aW9ucy5zZWxlY3QubWFwKCh7dmFsdWV9KSA9PiBzY2hlbWEubGl0ZXJhbCh2YWx1ZSkpKTtcblx0XHR9LFxuICB9LFxuICBcInBhdHRlcm5cIjoge1xuICAgIHRpdGxlOiBcIkluZGV4IHBhdHRlcm5cIixcbiAgICBkZXNjcmlwdGlvbjogXCJEZWZhdWx0IGluZGV4IHBhdHRlcm4gdG8gdXNlIG9uIHRoZSBhcHAuIElmIHRoZXJlJ3Mgbm8gdmFsaWQgaW5kZXggcGF0dGVybiwgdGhlIGFwcCB3aWxsIGF1dG9tYXRpY2FsbHkgY3JlYXRlIG9uZSB3aXRoIHRoZSBuYW1lIGluZGljYXRlZCBpbiB0aGlzIG9wdGlvbi5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnRleHQsXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9BTEVSVFNfUEFUVEVSTixcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21GaWxlOiB0cnVlLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbVVJOiB0cnVlLFxuICAgIHJlcXVpcmVzUnVubmluZ0hlYWx0aENoZWNrOiB0cnVlLFxuICAgIC8vIFZhbGlkYXRpb246IGh0dHBzOi8vZ2l0aHViLmNvbS9lbGFzdGljL2VsYXN0aWNzZWFyY2gvYmxvYi92Ny4xMC4yL2RvY3MvcmVmZXJlbmNlL2luZGljZXMvY3JlYXRlLWluZGV4LmFzY2lpZG9jXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmNvbXBvc2UoXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5pc05vdEVtcHR5U3RyaW5nLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm9TcGFjZXMsXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5ub0xpdGVyYWxTdHJpbmcoJy4nLCAnLi4nKSxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLm5vU3RhcnRzV2l0aFN0cmluZygnLScsICdfJywgJysnLCAnLicpLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3IuaGFzTm90SW52YWxpZENoYXJhY3RlcnMoJ1xcXFwnLCAnLycsICc/JywgJ1wiJywgJzwnLCAnPicsICd8JywgJywnLCAnIycpXG4gICAgKSxcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLnN0cmluZyh7dmFsaWRhdGU6IHRoaXMudmFsaWRhdGV9KTtcblx0XHR9LFxuICB9LFxuICBcInRpbWVvdXRcIjoge1xuICAgIHRpdGxlOiBcIlJlcXVlc3QgdGltZW91dFwiLFxuICAgIGRlc2NyaXB0aW9uOiBcIk1heGltdW0gdGltZSwgaW4gbWlsbGlzZWNvbmRzLCB0aGUgYXBwIHdpbGwgd2FpdCBmb3IgYW4gQVBJIHJlc3BvbnNlIHdoZW4gbWFraW5nIHJlcXVlc3RzIHRvIGl0LiBJdCB3aWxsIGJlIGlnbm9yZWQgaWYgdGhlIHZhbHVlIGlzIHNldCB1bmRlciAxNTAwIG1pbGxpc2Vjb25kcy5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5LkdFTkVSQUwsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLm51bWJlcixcbiAgICBkZWZhdWx0VmFsdWU6IDIwMDAwLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgbnVtYmVyOiB7XG4gICAgICAgIG1pbjogMTUwMCxcbiAgICAgICAgaW50ZWdlcjogdHJ1ZVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlOiBmdW5jdGlvbih2YWx1ZTogbnVtYmVyKXtcbiAgICAgIHJldHVybiBTdHJpbmcodmFsdWUpXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1JbnB1dFZhbHVlVG9Db25maWd1cmF0aW9uVmFsdWU6IGZ1bmN0aW9uKHZhbHVlOiBzdHJpbmcpOiBudW1iZXIge1xuICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24odmFsdWUpe1xuXHRcdFx0cmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLm51bWJlcih0aGlzLm9wdGlvbnMubnVtYmVyKSh2YWx1ZSk7XG5cdFx0fSxcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLm51bWJlcih7dmFsaWRhdGU6IHRoaXMudmFsaWRhdGUuYmluZCh0aGlzKX0pO1xuXHRcdH0sXG4gIH0sXG4gIFwid2F6dWgubW9uaXRvcmluZy5jcmVhdGlvblwiOiB7XG4gICAgdGl0bGU6IFwiSW5kZXggY3JlYXRpb25cIixcbiAgICBkZXNjcmlwdGlvbjogXCJEZWZpbmUgdGhlIGludGVydmFsIGluIHdoaWNoIGEgbmV3IHdhenVoLW1vbml0b3JpbmcgaW5kZXggd2lsbCBiZSBjcmVhdGVkLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuTU9OSVRPUklORyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc2VsZWN0LFxuICAgIG9wdGlvbnM6IHtcbiAgICAgIHNlbGVjdDogW1xuICAgICAgICB7XG4gICAgICAgICAgdGV4dDogXCJIb3VybHlcIixcbiAgICAgICAgICB2YWx1ZTogXCJoXCJcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHRleHQ6IFwiRGFpbHlcIixcbiAgICAgICAgICB2YWx1ZTogXCJkXCJcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHRleHQ6IFwiV2Vla2x5XCIsXG4gICAgICAgICAgdmFsdWU6IFwid1wiXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICB0ZXh0OiBcIk1vbnRobHlcIixcbiAgICAgICAgICB2YWx1ZTogXCJtXCJcbiAgICAgICAgfVxuICAgICAgXVxuICAgIH0sXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9NT05JVE9SSU5HX0RFRkFVTFRfQ1JFQVRJT04sXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjazogdHJ1ZSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24gKHZhbHVlKXtcblx0XHRcdHJldHVybiBTZXR0aW5nc1ZhbGlkYXRvci5saXRlcmFsKHRoaXMub3B0aW9ucy5zZWxlY3QubWFwKCh7dmFsdWV9KSA9PiB2YWx1ZSkpKHZhbHVlKVxuXHRcdH0sXG5cdFx0dmFsaWRhdGVCYWNrZW5kOiBmdW5jdGlvbihzY2hlbWEpe1xuXHRcdFx0cmV0dXJuIHNjaGVtYS5vbmVPZih0aGlzLm9wdGlvbnMuc2VsZWN0Lm1hcCgoe3ZhbHVlfSkgPT4gc2NoZW1hLmxpdGVyYWwodmFsdWUpKSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJ3YXp1aC5tb25pdG9yaW5nLmVuYWJsZWRcIjoge1xuICAgIHRpdGxlOiBcIlN0YXR1c1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkVuYWJsZSBvciBkaXNhYmxlIHRoZSB3YXp1aC1tb25pdG9yaW5nIGluZGV4IGNyZWF0aW9uIGFuZC9vciB2aXN1YWxpemF0aW9uLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuTU9OSVRPUklORyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUuc3dpdGNoLFxuICAgIGRlZmF1bHRWYWx1ZTogV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0VOQUJMRUQsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1Jlc3RhcnRpbmdQbHVnaW5QbGF0Zm9ybTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBzd2l0Y2g6IHtcbiAgICAgICAgdmFsdWVzOiB7XG4gICAgICAgICAgZGlzYWJsZWQ6IHsgbGFiZWw6ICdmYWxzZScsIHZhbHVlOiBmYWxzZSB9LFxuICAgICAgICAgIGVuYWJsZWQ6IHsgbGFiZWw6ICd0cnVlJywgdmFsdWU6IHRydWUgfSxcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ2hhbmdlZElucHV0VmFsdWU6IGZ1bmN0aW9uICh2YWx1ZTogYm9vbGVhbiB8IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgICAgcmV0dXJuIEJvb2xlYW4odmFsdWUpO1xuICAgIH0sXG4gICAgdmFsaWRhdGU6IFNldHRpbmdzVmFsaWRhdG9yLmlzQm9vbGVhbixcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLmJvb2xlYW4oKTtcblx0XHR9LFxuICB9LFxuICBcIndhenVoLm1vbml0b3JpbmcuZnJlcXVlbmN5XCI6IHtcbiAgICB0aXRsZTogXCJGcmVxdWVuY3lcIixcbiAgICBkZXNjcmlwdGlvbjogXCJGcmVxdWVuY3ksIGluIHNlY29uZHMsIG9mIEFQSSByZXF1ZXN0cyB0byBnZXQgdGhlIHN0YXRlIG9mIHRoZSBhZ2VudHMgYW5kIGNyZWF0ZSBhIG5ldyBkb2N1bWVudCBpbiB0aGUgd2F6dWgtbW9uaXRvcmluZyBpbmRleCB3aXRoIHRoaXMgZGF0YS5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5Lk1PTklUT1JJTkcsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLm51bWJlcixcbiAgICBkZWZhdWx0VmFsdWU6IFdBWlVIX01PTklUT1JJTkdfREVGQVVMVF9GUkVRVUVOQ1ksXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1Jlc3RhcnRpbmdQbHVnaW5QbGF0Zm9ybTogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBudW1iZXI6IHtcbiAgICAgICAgbWluOiA2MCxcbiAgICAgICAgaW50ZWdlcjogdHJ1ZVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlOiBmdW5jdGlvbih2YWx1ZTogbnVtYmVyKXtcbiAgICAgIHJldHVybiBTdHJpbmcodmFsdWUpXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1JbnB1dFZhbHVlVG9Db25maWd1cmF0aW9uVmFsdWU6IGZ1bmN0aW9uKHZhbHVlOiBzdHJpbmcpOiBudW1iZXIge1xuICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24odmFsdWUpe1xuXHRcdFx0cmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLm51bWJlcih0aGlzLm9wdGlvbnMubnVtYmVyKSh2YWx1ZSk7XG5cdFx0fSxcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLm51bWJlcih7dmFsaWRhdGU6IHRoaXMudmFsaWRhdGUuYmluZCh0aGlzKX0pO1xuXHRcdH0sXG4gIH0sXG4gIFwid2F6dWgubW9uaXRvcmluZy5wYXR0ZXJuXCI6IHtcbiAgICB0aXRsZTogXCJJbmRleCBwYXR0ZXJuXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRGVmYXVsdCBpbmRleCBwYXR0ZXJuIHRvIHVzZSBmb3IgV2F6dWggbW9uaXRvcmluZy5cIixcbiAgICBjYXRlZ29yeTogU2V0dGluZ0NhdGVnb3J5Lk1PTklUT1JJTkcsXG4gICAgdHlwZTogRXBsdWdpblNldHRpbmdUeXBlLnRleHQsXG4gICAgZGVmYXVsdFZhbHVlOiBXQVpVSF9NT05JVE9SSU5HX1BBVFRFUk4sXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjazogdHJ1ZSxcbiAgICB2YWxpZGF0ZTogU2V0dGluZ3NWYWxpZGF0b3IuY29tcG9zZShcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLmlzTm90RW1wdHlTdHJpbmcsXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb1NwYWNlcyxcbiAgICAgIFNldHRpbmdzVmFsaWRhdG9yLm5vTGl0ZXJhbFN0cmluZygnLicsICcuLicpLFxuICAgICAgU2V0dGluZ3NWYWxpZGF0b3Iubm9TdGFydHNXaXRoU3RyaW5nKCctJywgJ18nLCAnKycsICcuJyksXG4gICAgICBTZXR0aW5nc1ZhbGlkYXRvci5oYXNOb3RJbnZhbGlkQ2hhcmFjdGVycygnXFxcXCcsICcvJywgJz8nLCAnXCInLCAnPCcsICc+JywgJ3wnLCAnLCcsICcjJylcbiAgICApLFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEuc3RyaW5nKHttaW5MZW5ndGg6IDEsIHZhbGlkYXRlOiB0aGlzLnZhbGlkYXRlfSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJ3YXp1aC5tb25pdG9yaW5nLnJlcGxpY2FzXCI6IHtcbiAgICB0aXRsZTogXCJJbmRleCByZXBsaWNhc1wiLFxuICAgIGRlc2NyaXB0aW9uOiBcIkRlZmluZSB0aGUgbnVtYmVyIG9mIHJlcGxpY2FzIHRvIHVzZSBmb3IgdGhlIHdhenVoLW1vbml0b3JpbmctKiBpbmRpY2VzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuTU9OSVRPUklORyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUubnVtYmVyLFxuICAgIGRlZmF1bHRWYWx1ZTogV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0lORElDRVNfUkVQTElDQVMsXG4gICAgaXNDb25maWd1cmFibGVGcm9tRmlsZTogdHJ1ZSxcbiAgICBpc0NvbmZpZ3VyYWJsZUZyb21VSTogdHJ1ZSxcbiAgICByZXF1aXJlc1J1bm5pbmdIZWFsdGhDaGVjazogdHJ1ZSxcbiAgICBvcHRpb25zOiB7XG4gICAgICBudW1iZXI6IHtcbiAgICAgICAgbWluOiAwLFxuICAgICAgICBpbnRlZ2VyOiB0cnVlXG4gICAgICB9XG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1Db25maWd1cmF0aW9uVmFsdWVUb0lucHV0VmFsdWU6IGZ1bmN0aW9uKHZhbHVlOiBudW1iZXIpe1xuICAgICAgcmV0dXJuIFN0cmluZyh2YWx1ZSlcbiAgICB9LFxuICAgIHVpRm9ybVRyYW5zZm9ybUlucHV0VmFsdWVUb0NvbmZpZ3VyYXRpb25WYWx1ZTogZnVuY3Rpb24odmFsdWU6IHN0cmluZyk6IG51bWJlciB7XG4gICAgICByZXR1cm4gTnVtYmVyKHZhbHVlKTtcbiAgICB9LFxuICAgIHZhbGlkYXRlOiBmdW5jdGlvbih2YWx1ZSl7XG5cdFx0XHRyZXR1cm4gU2V0dGluZ3NWYWxpZGF0b3IubnVtYmVyKHRoaXMub3B0aW9ucy5udW1iZXIpKHZhbHVlKTtcblx0XHR9LFxuXHRcdHZhbGlkYXRlQmFja2VuZDogZnVuY3Rpb24oc2NoZW1hKXtcblx0XHRcdHJldHVybiBzY2hlbWEubnVtYmVyKHt2YWxpZGF0ZTogdGhpcy52YWxpZGF0ZS5iaW5kKHRoaXMpfSk7XG5cdFx0fSxcbiAgfSxcbiAgXCJ3YXp1aC5tb25pdG9yaW5nLnNoYXJkc1wiOiB7XG4gICAgdGl0bGU6IFwiSW5kZXggc2hhcmRzXCIsXG4gICAgZGVzY3JpcHRpb246IFwiRGVmaW5lIHRoZSBudW1iZXIgb2Ygc2hhcmRzIHRvIHVzZSBmb3IgdGhlIHdhenVoLW1vbml0b3JpbmctKiBpbmRpY2VzLlwiLFxuICAgIGNhdGVnb3J5OiBTZXR0aW5nQ2F0ZWdvcnkuTU9OSVRPUklORyxcbiAgICB0eXBlOiBFcGx1Z2luU2V0dGluZ1R5cGUubnVtYmVyLFxuICAgIGRlZmF1bHRWYWx1ZTogV0FaVUhfTU9OSVRPUklOR19ERUZBVUxUX0lORElDRVNfU0hBUkRTLFxuICAgIGlzQ29uZmlndXJhYmxlRnJvbUZpbGU6IHRydWUsXG4gICAgaXNDb25maWd1cmFibGVGcm9tVUk6IHRydWUsXG4gICAgcmVxdWlyZXNSdW5uaW5nSGVhbHRoQ2hlY2s6IHRydWUsXG4gICAgb3B0aW9uczoge1xuICAgICAgbnVtYmVyOiB7XG4gICAgICAgIG1pbjogMSxcbiAgICAgICAgaW50ZWdlcjogdHJ1ZVxuICAgICAgfVxuICAgIH0sXG4gICAgdWlGb3JtVHJhbnNmb3JtQ29uZmlndXJhdGlvblZhbHVlVG9JbnB1dFZhbHVlOiBmdW5jdGlvbih2YWx1ZTogbnVtYmVyKXtcbiAgICAgIHJldHVybiBTdHJpbmcodmFsdWUpXG4gICAgfSxcbiAgICB1aUZvcm1UcmFuc2Zvcm1JbnB1dFZhbHVlVG9Db25maWd1cmF0aW9uVmFsdWU6IGZ1bmN0aW9uKHZhbHVlOiBzdHJpbmcpOiBudW1iZXIge1xuICAgICAgcmV0dXJuIE51bWJlcih2YWx1ZSk7XG4gICAgfSxcbiAgICB2YWxpZGF0ZTogZnVuY3Rpb24odmFsdWUpe1xuXHRcdFx0cmV0dXJuIFNldHRpbmdzVmFsaWRhdG9yLm51bWJlcih0aGlzLm9wdGlvbnMubnVtYmVyKSh2YWx1ZSk7XG5cdFx0fSxcblx0XHR2YWxpZGF0ZUJhY2tlbmQ6IGZ1bmN0aW9uKHNjaGVtYSl7XG5cdFx0XHRyZXR1cm4gc2NoZW1hLm51bWJlcih7dmFsaWRhdGU6IHRoaXMudmFsaWRhdGUuYmluZCh0aGlzKX0pO1xuXHRcdH0sXG4gIH1cbn07XG5cbmV4cG9ydCB0eXBlIFRQbHVnaW5TZXR0aW5nS2V5ID0ga2V5b2YgdHlwZW9mIFBMVUdJTl9TRVRUSU5HUztcblxuZXhwb3J0IGVudW0gSFRUUF9TVEFUVVNfQ09ERVMge1xuICBDT05USU5VRSA9IDEwMCxcbiAgU1dJVENISU5HX1BST1RPQ09MUyA9IDEwMSxcbiAgUFJPQ0VTU0lORyA9IDEwMixcbiAgT0sgPSAyMDAsXG4gIENSRUFURUQgPSAyMDEsXG4gIEFDQ0VQVEVEID0gMjAyLFxuICBOT05fQVVUSE9SSVRBVElWRV9JTkZPUk1BVElPTiA9IDIwMyxcbiAgTk9fQ09OVEVOVCA9IDIwNCxcbiAgUkVTRVRfQ09OVEVOVCA9IDIwNSxcbiAgUEFSVElBTF9DT05URU5UID0gMjA2LFxuICBNVUxUSV9TVEFUVVMgPSAyMDcsXG4gIE1VTFRJUExFX0NIT0lDRVMgPSAzMDAsXG4gIE1PVkVEX1BFUk1BTkVOVExZID0gMzAxLFxuICBNT1ZFRF9URU1QT1JBUklMWSA9IDMwMixcbiAgU0VFX09USEVSID0gMzAzLFxuICBOT1RfTU9ESUZJRUQgPSAzMDQsXG4gIFVTRV9QUk9YWSA9IDMwNSxcbiAgVEVNUE9SQVJZX1JFRElSRUNUID0gMzA3LFxuICBQRVJNQU5FTlRfUkVESVJFQ1QgPSAzMDgsXG4gIEJBRF9SRVFVRVNUID0gNDAwLFxuICBVTkFVVEhPUklaRUQgPSA0MDEsXG4gIFBBWU1FTlRfUkVRVUlSRUQgPSA0MDIsXG4gIEZPUkJJRERFTiA9IDQwMyxcbiAgTk9UX0ZPVU5EID0gNDA0LFxuICBNRVRIT0RfTk9UX0FMTE9XRUQgPSA0MDUsXG4gIE5PVF9BQ0NFUFRBQkxFID0gNDA2LFxuICBQUk9YWV9BVVRIRU5USUNBVElPTl9SRVFVSVJFRCA9IDQwNyxcbiAgUkVRVUVTVF9USU1FT1VUID0gNDA4LFxuICBDT05GTElDVCA9IDQwOSxcbiAgR09ORSA9IDQxMCxcbiAgTEVOR1RIX1JFUVVJUkVEID0gNDExLFxuICBQUkVDT05ESVRJT05fRkFJTEVEID0gNDEyLFxuICBSRVFVRVNUX1RPT19MT05HID0gNDEzLFxuICBSRVFVRVNUX1VSSV9UT09fTE9ORyA9IDQxNCxcbiAgVU5TVVBQT1JURURfTUVESUFfVFlQRSA9IDQxNSxcbiAgUkVRVUVTVEVEX1JBTkdFX05PVF9TQVRJU0ZJQUJMRSA9IDQxNixcbiAgRVhQRUNUQVRJT05fRkFJTEVEID0gNDE3LFxuICBJTV9BX1RFQVBPVCA9IDQxOCxcbiAgSU5TVUZGSUNJRU5UX1NQQUNFX09OX1JFU09VUkNFID0gNDE5LFxuICBNRVRIT0RfRkFJTFVSRSA9IDQyMCxcbiAgTUlTRElSRUNURURfUkVRVUVTVCA9IDQyMSxcbiAgVU5QUk9DRVNTQUJMRV9FTlRJVFkgPSA0MjIsXG4gIExPQ0tFRCA9IDQyMyxcbiAgRkFJTEVEX0RFUEVOREVOQ1kgPSA0MjQsXG4gIFBSRUNPTkRJVElPTl9SRVFVSVJFRCA9IDQyOCxcbiAgVE9PX01BTllfUkVRVUVTVFMgPSA0MjksXG4gIFJFUVVFU1RfSEVBREVSX0ZJRUxEU19UT09fTEFSR0UgPSA0MzEsXG4gIFVOQVZBSUxBQkxFX0ZPUl9MRUdBTF9SRUFTT05TID0gNDUxLFxuICBJTlRFUk5BTF9TRVJWRVJfRVJST1IgPSA1MDAsXG4gIE5PVF9JTVBMRU1FTlRFRCA9IDUwMSxcbiAgQkFEX0dBVEVXQVkgPSA1MDIsXG4gIFNFUlZJQ0VfVU5BVkFJTEFCTEUgPSA1MDMsXG4gIEdBVEVXQVlfVElNRU9VVCA9IDUwNCxcbiAgSFRUUF9WRVJTSU9OX05PVF9TVVBQT1JURUQgPSA1MDUsXG4gIElOU1VGRklDSUVOVF9TVE9SQUdFID0gNTA3LFxuICBORVRXT1JLX0FVVEhFTlRJQ0FUSU9OX1JFUVVJUkVEID0gNTExXG59XG5cbi8vIE1vZHVsZSBTZWN1cml0eSBjb25maWd1cmF0aW9uIGFzc2Vzc21lbnRcbmV4cG9ydCBjb25zdCBNT0RVTEVfU0NBX0NIRUNLX1JFU1VMVF9MQUJFTCA9IHtcbiAgcGFzc2VkOiAnUGFzc2VkJyxcbiAgZmFpbGVkOiAnRmFpbGVkJyxcbiAgJ25vdCBhcHBsaWNhYmxlJzogJ05vdCBhcHBsaWNhYmxlJ1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQVdBLElBQUFBLEtBQUEsR0FBQUMsc0JBQUEsQ0FBQUMsT0FBQTtBQUNBLElBQUFDLFFBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLFNBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLGtCQUFBLEdBQUFILE9BQUE7QUFkQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQU1BO0FBQ08sTUFBTUksY0FBYyxHQUFHQyxnQkFBTztBQUFDQyxPQUFBLENBQUFGLGNBQUEsR0FBQUEsY0FBQTtBQUMvQixNQUFNRyxvQkFBb0IsR0FBR0YsZ0JBQU8sQ0FBQ0csS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDQyxJQUFJLENBQUMsR0FBRyxDQUFDOztBQUU3RTtBQUFBSixPQUFBLENBQUFDLG9CQUFBLEdBQUFBLG9CQUFBO0FBQ08sTUFBTUksdUJBQXVCLEdBQUcsUUFBUTtBQUFDTCxPQUFBLENBQUFLLHVCQUFBLEdBQUFBLHVCQUFBO0FBQ3pDLE1BQU1DLG1CQUFtQixHQUFHLGVBQWU7QUFBQ04sT0FBQSxDQUFBTSxtQkFBQSxHQUFBQSxtQkFBQTtBQUM1QyxNQUFNQyxvQkFBb0IsR0FBRyxnQkFBZ0I7O0FBRXBEO0FBQUFQLE9BQUEsQ0FBQU8sb0JBQUEsR0FBQUEsb0JBQUE7QUFDTyxNQUFNQywyQkFBMkIsR0FBRyxZQUFZO0FBQUNSLE9BQUEsQ0FBQVEsMkJBQUEsR0FBQUEsMkJBQUE7QUFDakQsTUFBTUMsdUJBQXVCLEdBQUcsbUJBQW1CO0FBQUNULE9BQUEsQ0FBQVMsdUJBQUEsR0FBQUEsdUJBQUE7QUFDcEQsTUFBTUMsd0JBQXdCLEdBQUcsb0JBQW9CO0FBQUNWLE9BQUEsQ0FBQVUsd0JBQUEsR0FBQUEsd0JBQUE7QUFDdEQsTUFBTUMsOEJBQThCLEdBQUcsYUFBYTtBQUFDWCxPQUFBLENBQUFXLDhCQUFBLEdBQUFBLDhCQUFBO0FBQ3JELE1BQU1DLHVDQUF1QyxHQUFHLENBQUM7QUFBQ1osT0FBQSxDQUFBWSx1Q0FBQSxHQUFBQSx1Q0FBQTtBQUNsRCxNQUFNQyx5Q0FBeUMsR0FBRyxDQUFDO0FBQUNiLE9BQUEsQ0FBQWEseUNBQUEsR0FBQUEseUNBQUE7QUFDcEQsTUFBTUMsaUNBQWlDLEdBQUcsR0FBRztBQUFDZCxPQUFBLENBQUFjLGlDQUFBLEdBQUFBLGlDQUFBO0FBQzlDLE1BQU1DLGdDQUFnQyxHQUFHLElBQUk7QUFBQ2YsT0FBQSxDQUFBZSxnQ0FBQSxHQUFBQSxnQ0FBQTtBQUM5QyxNQUFNQyxrQ0FBa0MsR0FBRyxHQUFHO0FBQUNoQixPQUFBLENBQUFnQixrQ0FBQSxHQUFBQSxrQ0FBQTtBQUMvQyxNQUFNQyxrQ0FBa0MsR0FBRyxhQUFhOztBQUUvRDtBQUFBakIsT0FBQSxDQUFBaUIsa0NBQUEsR0FBQUEsa0NBQUE7QUFDTyxNQUFNQywyQkFBMkIsR0FBRyxZQUFZO0FBQUNsQixPQUFBLENBQUFrQiwyQkFBQSxHQUFBQSwyQkFBQTtBQUNqRCxNQUFNQywrQkFBK0IsR0FBRyxPQUFPO0FBQUNuQixPQUFBLENBQUFtQiwrQkFBQSxHQUFBQSwrQkFBQTtBQUNoRCxNQUFNQyw2QkFBNkIsR0FBRyxZQUFZO0FBQUNwQixPQUFBLENBQUFvQiw2QkFBQSxHQUFBQSw2QkFBQTtBQUNuRCxNQUFNQyx3QkFBd0IsR0FBSSxHQUFFRiwrQkFBZ0MsSUFBR0MsNkJBQThCLElBQUc7QUFBQ3BCLE9BQUEsQ0FBQXFCLHdCQUFBLEdBQUFBLHdCQUFBO0FBQ3pHLE1BQU1DLDhCQUE4QixHQUFJLEdBQUVILCtCQUFnQyxJQUFHQyw2QkFBOEIsRUFBQztBQUFDcEIsT0FBQSxDQUFBc0IsOEJBQUEsR0FBQUEsOEJBQUE7QUFDN0csTUFBTUMsdUNBQXVDLEdBQUcsQ0FBQztBQUFDdkIsT0FBQSxDQUFBdUIsdUNBQUEsR0FBQUEsdUNBQUE7QUFDbEQsTUFBTUMseUNBQXlDLEdBQUcsQ0FBQztBQUFDeEIsT0FBQSxDQUFBd0IseUNBQUEsR0FBQUEseUNBQUE7QUFDcEQsTUFBTUMsaUNBQWlDLEdBQUcsR0FBRztBQUFDekIsT0FBQSxDQUFBeUIsaUNBQUEsR0FBQUEsaUNBQUE7QUFDOUMsTUFBTUMsK0JBQStCLEdBQUcsSUFBSTtBQUFDMUIsT0FBQSxDQUFBMEIsK0JBQUEsR0FBQUEsK0JBQUE7QUFDN0MsTUFBTUMsa0NBQWtDLEdBQUcsR0FBRztBQUFDM0IsT0FBQSxDQUFBMkIsa0NBQUEsR0FBQUEsa0NBQUE7QUFDL0MsTUFBTUMsa0NBQWtDLEdBQUcsZUFBZTs7QUFFakU7QUFBQTVCLE9BQUEsQ0FBQTRCLGtDQUFBLEdBQUFBLGtDQUFBO0FBQ08sTUFBTUMsbUNBQW1DLEdBQUcsY0FBYzs7QUFFakU7QUFBQTdCLE9BQUEsQ0FBQTZCLG1DQUFBLEdBQUFBLG1DQUFBO0FBQ08sTUFBTUMsMkJBQTJCLEdBQUcsQ0FBQztBQUFDOUIsT0FBQSxDQUFBOEIsMkJBQUEsR0FBQUEsMkJBQUE7QUFDdEMsTUFBTUMsNkJBQTZCLEdBQUcsZUFBZTs7QUFFNUQ7QUFBQS9CLE9BQUEsQ0FBQStCLDZCQUFBLEdBQUFBLDZCQUFBO0FBQ08sTUFBTUMseUJBQXlCLEdBQUcsbUJBQW1CO0FBQUNoQyxPQUFBLENBQUFnQyx5QkFBQSxHQUFBQSx5QkFBQTtBQUN0RCxNQUFNQyxnQ0FBZ0MsR0FBRyxDQUFDO0FBQUNqQyxPQUFBLENBQUFpQyxnQ0FBQSxHQUFBQSxnQ0FBQTtBQUMzQyxNQUFNQyxrQ0FBa0MsR0FBRyxDQUFDO0FBQUNsQyxPQUFBLENBQUFrQyxrQ0FBQSxHQUFBQSxrQ0FBQTtBQUM3QyxNQUFNQyxxQ0FBcUMsR0FBRyxVQUFVO0FBQUNuQyxPQUFBLENBQUFtQyxxQ0FBQSxHQUFBQSxxQ0FBQTtBQUN6RCxNQUFNQyx1REFBdUQsR0FBRyw0QkFBNEI7QUFBQ3BDLE9BQUEsQ0FBQW9DLHVEQUFBLEdBQUFBLHVEQUFBO0FBQzdGLE1BQU1DLDZDQUE2QyxHQUFHLGtCQUFrQjtBQUFDckMsT0FBQSxDQUFBcUMsNkNBQUEsR0FBQUEsNkNBQUE7QUFDekUsTUFBTUMseUNBQXlDLEdBQUcsSUFBSTtBQUFDdEMsT0FBQSxDQUFBc0MseUNBQUEsR0FBQUEseUNBQUE7QUFDdkQsTUFBTUMsMENBQTBDLEdBQUc7RUFDeEQsQ0FBQ0oscUNBQXFDLEdBQUcsQ0FDdkM7SUFBRUssUUFBUSxFQUFFO0VBQUssQ0FBQyxFQUNsQjtJQUFFQyxHQUFHLEVBQUU7RUFBSyxDQUFDLEVBQ2I7SUFBRUMsTUFBTSxFQUFFO0VBQUssQ0FBQyxFQUNoQjtJQUFFQyxHQUFHLEVBQUU7RUFBSyxDQUFDLEVBQ2I7SUFBRUMsY0FBYyxFQUFFO0VBQUssQ0FBQyxFQUN4QjtJQUFFQyxHQUFHLEVBQUU7RUFBSyxDQUFDLEVBQ2I7SUFBRUMsTUFBTSxFQUFFLElBQUk7SUFBRUMsTUFBTSxFQUFFO0VBQUssQ0FBQyxFQUM5QjtJQUFFQyxHQUFHLEVBQUU7RUFBSyxDQUFDLEVBQ2I7SUFBRUMsT0FBTyxFQUFFO01BQUVDLHVCQUF1QixFQUFFO0lBQUssQ0FBQztJQUFFSCxNQUFNLEVBQUU7RUFBSyxDQUFDLEVBQzVEO0lBQUVJLE1BQU0sRUFBRTtFQUFLLENBQUMsQ0FDakI7RUFDRCxDQUFDZix1REFBdUQsR0FBRyxDQUN6RDtJQUFFZ0IsU0FBUyxFQUFFO0VBQUssQ0FBQyxFQUNuQjtJQUFFQyxLQUFLLEVBQUU7RUFBSyxDQUFDLEVBQ2Y7SUFBRUMsUUFBUSxFQUFFO0VBQUssQ0FBQyxFQUNsQjtJQUFFQyxNQUFNLEVBQUU7RUFBSyxDQUFDLENBQ2pCO0VBQ0QsQ0FBQ2xCLDZDQUE2QyxHQUFHLENBQy9DO0lBQUVtQixlQUFlLEVBQUU7RUFBSyxDQUFDLEVBQ3pCO0lBQUVDLFVBQVUsRUFBRTtFQUFLLENBQUMsRUFDcEI7SUFBRUMsT0FBTyxFQUFFO0VBQUssQ0FBQyxFQUNqQjtJQUFFQyxNQUFNLEVBQUU7RUFBSyxDQUFDLEVBQ2hCO0lBQUVDLEtBQUssRUFBRTtFQUFLLENBQUM7QUFFbkIsQ0FBQzs7QUFFRDtBQUFBNUQsT0FBQSxDQUFBdUMsMENBQUEsR0FBQUEsMENBQUE7QUFDTyxNQUFNc0Isb0NBQW9DLEdBQUcsaUJBQWlCO0FBQUM3RCxPQUFBLENBQUE2RCxvQ0FBQSxHQUFBQSxvQ0FBQTtBQUMvRCxNQUFNQyxtREFBbUQsR0FBRywrQkFBK0I7QUFBQzlELE9BQUEsQ0FBQThELG1EQUFBLEdBQUFBLG1EQUFBO0FBRTVGLE1BQU1DLHNCQUFzQixHQUFHLENBQ3BDRixvQ0FBb0MsRUFDcENDLG1EQUFtRCxDQUNwRDs7QUFFRDtBQUFBOUQsT0FBQSxDQUFBK0Qsc0JBQUEsR0FBQUEsc0JBQUE7QUFDTyxNQUFNQyw4QkFBOEIsR0FBRyxLQUFLLENBQUMsQ0FBQzs7QUFFckQ7QUFBQWhFLE9BQUEsQ0FBQWdFLDhCQUFBLEdBQUFBLDhCQUFBO0FBQ08sTUFBTUMsZ0NBQWdDLEdBQUcsR0FBRzs7QUFFbkQ7QUFBQWpFLE9BQUEsQ0FBQWlFLGdDQUFBLEdBQUFBLGdDQUFBO0FBQ0EsTUFBTUMsb0NBQW9DLEdBQUcsTUFBTTtBQUM1QyxNQUFNQyw2Q0FBNkMsR0FBR0MsYUFBSSxDQUFDaEUsSUFBSSxDQUNwRWlFLFNBQVMsRUFDVCxXQUFXLEVBQ1hILG9DQUFvQyxDQUNyQztBQUFDbEUsT0FBQSxDQUFBbUUsNkNBQUEsR0FBQUEsNkNBQUE7QUFDSyxNQUFNRyx3QkFBd0IsR0FBR0YsYUFBSSxDQUFDaEUsSUFBSSxDQUFDK0QsNkNBQTZDLEVBQUUsT0FBTyxDQUFDOztBQUV6RztBQUFBbkUsT0FBQSxDQUFBc0Usd0JBQUEsR0FBQUEsd0JBQUE7QUFDTyxNQUFNQyxnQ0FBZ0MsR0FBR0gsYUFBSSxDQUFDaEUsSUFBSSxDQUFDa0Usd0JBQXdCLEVBQUUsUUFBUSxDQUFDO0FBQUN0RSxPQUFBLENBQUF1RSxnQ0FBQSxHQUFBQSxnQ0FBQTtBQUN2RixNQUFNQywwQkFBMEIsR0FBR0osYUFBSSxDQUFDaEUsSUFBSSxDQUFDbUUsZ0NBQWdDLEVBQUUsV0FBVyxDQUFDO0FBQUN2RSxPQUFBLENBQUF3RSwwQkFBQSxHQUFBQSwwQkFBQTtBQUM1RixNQUFNQywrQkFBK0IsR0FBR0wsYUFBSSxDQUFDaEUsSUFBSSxDQUN0RG1FLGdDQUFnQyxFQUNoQyxxQkFBcUIsQ0FDdEI7O0FBRUQ7QUFBQXZFLE9BQUEsQ0FBQXlFLCtCQUFBLEdBQUFBLCtCQUFBO0FBQ08sTUFBTUMsZ0JBQWdCLEdBQUcsR0FBRztBQUFDMUUsT0FBQSxDQUFBMEUsZ0JBQUEsR0FBQUEsZ0JBQUE7QUFDN0IsTUFBTUMsOEJBQThCLEdBQUdQLGFBQUksQ0FBQ2hFLElBQUksQ0FBQ2tFLHdCQUF3QixFQUFFLE1BQU0sQ0FBQztBQUFDdEUsT0FBQSxDQUFBMkUsOEJBQUEsR0FBQUEsOEJBQUE7QUFDbkYsTUFBTUMsOEJBQThCLEdBQUcsb0JBQW9CO0FBQUM1RSxPQUFBLENBQUE0RSw4QkFBQSxHQUFBQSw4QkFBQTtBQUM1RCxNQUFNQywwQkFBMEIsR0FBR1QsYUFBSSxDQUFDaEUsSUFBSSxDQUNqRHVFLDhCQUE4QixFQUM5QkMsOEJBQThCLENBQy9CO0FBQUM1RSxPQUFBLENBQUE2RSwwQkFBQSxHQUFBQSwwQkFBQTtBQUNLLE1BQU1DLDRCQUE0QixHQUFHLGNBQWM7QUFBQzlFLE9BQUEsQ0FBQThFLDRCQUFBLEdBQUFBLDRCQUFBO0FBQ3BELE1BQU1DLHdCQUF3QixHQUFHWCxhQUFJLENBQUNoRSxJQUFJLENBQy9DdUUsOEJBQThCLEVBQzlCRyw0QkFBNEIsQ0FDN0I7O0FBRUQ7QUFBQTlFLE9BQUEsQ0FBQStFLHdCQUFBLEdBQUFBLHdCQUFBO0FBQ08sTUFBTUMsNEJBQTRCLEdBQUcsb0JBQW9CO0FBQUNoRixPQUFBLENBQUFnRiw0QkFBQSxHQUFBQSw0QkFBQTtBQUMxRCxNQUFNQywwQkFBMEIsR0FBRyxjQUFjO0FBQUNqRixPQUFBLENBQUFpRiwwQkFBQSxHQUFBQSwwQkFBQTtBQUNsRCxNQUFNQyx3QkFBd0IsR0FBR2QsYUFBSSxDQUFDaEUsSUFBSSxDQUMvQ3VFLDhCQUE4QixFQUM5QkssNEJBQTRCLENBQzdCO0FBQUNoRixPQUFBLENBQUFrRix3QkFBQSxHQUFBQSx3QkFBQTtBQUNLLE1BQU1DLHNCQUFzQixHQUFHZixhQUFJLENBQUNoRSxJQUFJLENBQUN1RSw4QkFBOEIsRUFBRU0sMEJBQTBCLENBQUM7O0FBRTNHO0FBQUFqRixPQUFBLENBQUFtRixzQkFBQSxHQUFBQSxzQkFBQTtBQUNPLE1BQU1DLG1DQUFtQyxHQUFHaEIsYUFBSSxDQUFDaEUsSUFBSSxDQUFDa0Usd0JBQXdCLEVBQUUsV0FBVyxDQUFDO0FBQUN0RSxPQUFBLENBQUFvRixtQ0FBQSxHQUFBQSxtQ0FBQTtBQUM3RixNQUFNQywyQ0FBMkMsR0FBR2pCLGFBQUksQ0FBQ2hFLElBQUksQ0FDbEVnRixtQ0FBbUMsRUFDbkMsU0FBUyxDQUNWOztBQUVEO0FBQUFwRixPQUFBLENBQUFxRiwyQ0FBQSxHQUFBQSwyQ0FBQTtBQUNPLE1BQU1DLHFCQUFxQixHQUFHLGdCQUFnQixDQUFDLENBQUM7O0FBRXZEO0FBQUF0RixPQUFBLENBQUFzRixxQkFBQSxHQUFBQSxxQkFBQTtBQUNPLE1BQU1DLDZCQUE2QixHQUFHLFdBQVc7O0FBRXhEO0FBQUF2RixPQUFBLENBQUF1Riw2QkFBQSxHQUFBQSw2QkFBQTtBQUFBLElBQ1lDLG9CQUFvQjtBQUFBeEYsT0FBQSxDQUFBd0Ysb0JBQUEsR0FBQUEsb0JBQUE7QUFBQSxXQUFwQkEsb0JBQW9CO0VBQXBCQSxvQkFBb0I7RUFBcEJBLG9CQUFvQjtFQUFwQkEsb0JBQW9CO0VBQXBCQSxvQkFBb0I7RUFBcEJBLG9CQUFvQjtBQUFBLEdBQXBCQSxvQkFBb0IsS0FBQXhGLE9BQUEsQ0FBQXdGLG9CQUFBLEdBQXBCQSxvQkFBb0I7QUFBQSxJQVFwQkMsZ0JBQWdCO0FBQUF6RixPQUFBLENBQUF5RixnQkFBQSxHQUFBQSxnQkFBQTtBQUFBLFdBQWhCQSxnQkFBZ0I7RUFBaEJBLGdCQUFnQjtFQUFoQkEsZ0JBQWdCO0VBQWhCQSxnQkFBZ0I7RUFBaEJBLGdCQUFnQjtFQUFoQkEsZ0JBQWdCO0VBQWhCQSxnQkFBZ0I7RUFBaEJBLGdCQUFnQjtFQUFoQkEsZ0JBQWdCO0VBQWhCQSxnQkFBZ0I7RUFBaEJBLGdCQUFnQjtFQUFoQkEsZ0JBQWdCO0VBQWhCQSxnQkFBZ0I7RUFBaEJBLGdCQUFnQjtFQUFoQkEsZ0JBQWdCO0VBQWhCQSxnQkFBZ0I7RUFBaEJBLGdCQUFnQjtFQUFoQkEsZ0JBQWdCO0VBQWhCQSxnQkFBZ0I7RUFBaEJBLGdCQUFnQjtFQUFoQkEsZ0JBQWdCO0VBQWhCQSxnQkFBZ0I7QUFBQSxHQUFoQkEsZ0JBQWdCLEtBQUF6RixPQUFBLENBQUF5RixnQkFBQSxHQUFoQkEsZ0JBQWdCO0FBc0IzQjtBQUFDLElBRVVDLGlDQUFpQztBQUFBMUYsT0FBQSxDQUFBMEYsaUNBQUEsR0FBQUEsaUNBQUE7QUFBQSxXQUFqQ0EsaUNBQWlDO0VBQWpDQSxpQ0FBaUM7RUFBakNBLGlDQUFpQztFQUFqQ0EsaUNBQWlDO0VBQWpDQSxpQ0FBaUM7RUFBakNBLGlDQUFpQztFQUFqQ0EsaUNBQWlDO0VBQWpDQSxpQ0FBaUM7RUFBakNBLGlDQUFpQztFQUFqQ0EsaUNBQWlDO0VBQWpDQSxpQ0FBaUM7RUFBakNBLGlDQUFpQztFQUFqQ0EsaUNBQWlDO0VBQWpDQSxpQ0FBaUM7RUFBakNBLGlDQUFpQztBQUFBLEdBQWpDQSxpQ0FBaUMsS0FBQTFGLE9BQUEsQ0FBQTBGLGlDQUFBLEdBQWpDQSxpQ0FBaUM7QUFlNUM7QUFBQyxJQUVVQyw0QkFBNEI7QUFBQTNGLE9BQUEsQ0FBQTJGLDRCQUFBLEdBQUFBLDRCQUFBO0FBQUEsV0FBNUJBLDRCQUE0QjtFQUE1QkEsNEJBQTRCO0VBQTVCQSw0QkFBNEI7QUFBQSxHQUE1QkEsNEJBQTRCLEtBQUEzRixPQUFBLENBQUEyRiw0QkFBQSxHQUE1QkEsNEJBQTRCO0FBR3ZDO0FBQUMsSUFFVUMsK0JBQStCO0FBQUE1RixPQUFBLENBQUE0RiwrQkFBQSxHQUFBQSwrQkFBQTtBQUFBLFdBQS9CQSwrQkFBK0I7RUFBL0JBLCtCQUErQjtFQUEvQkEsK0JBQStCO0VBQS9CQSwrQkFBK0I7RUFBL0JBLCtCQUErQjtBQUFBLEdBQS9CQSwrQkFBK0IsS0FBQTVGLE9BQUEsQ0FBQTRGLCtCQUFBLEdBQS9CQSwrQkFBK0I7QUFLMUM7QUFBQyxJQUVVQywrQkFBK0I7QUFBQTdGLE9BQUEsQ0FBQTZGLCtCQUFBLEdBQUFBLCtCQUFBO0FBQUEsV0FBL0JBLCtCQUErQjtFQUEvQkEsK0JBQStCO0VBQS9CQSwrQkFBK0I7RUFBL0JBLCtCQUErQjtFQUEvQkEsK0JBQStCO0VBQS9CQSwrQkFBK0I7RUFBL0JBLCtCQUErQjtFQUEvQkEsK0JBQStCO0VBQS9CQSwrQkFBK0I7QUFBQSxHQUEvQkEsK0JBQStCLEtBQUE3RixPQUFBLENBQUE2RiwrQkFBQSxHQUEvQkEsK0JBQStCO0FBUzFDO0FBRU0sTUFBTUMsaUJBQWlCLEdBQUcsbUJBQW1COztBQUVwRDtBQUFBOUYsT0FBQSxDQUFBOEYsaUJBQUEsR0FBQUEsaUJBQUE7QUFDTyxNQUFNQyxpQkFBaUIsR0FBRywwQkFBMEI7QUFBQy9GLE9BQUEsQ0FBQStGLGlCQUFBLEdBQUFBLGlCQUFBO0FBQ3JELE1BQU1DLHdCQUF3QixHQUFHLCtDQUErQztBQUFDaEcsT0FBQSxDQUFBZ0csd0JBQUEsR0FBQUEsd0JBQUE7QUFDakYsTUFBTUMsZ0JBQWdCLEdBQUcsOENBQThDO0FBQUNqRyxPQUFBLENBQUFpRyxnQkFBQSxHQUFBQSxnQkFBQTtBQUV4RSxNQUFNQyxZQUFZLEdBQUcsY0FBYzs7QUFFMUM7QUFBQWxHLE9BQUEsQ0FBQWtHLFlBQUEsR0FBQUEsWUFBQTtBQUNPLE1BQU1DLDZCQUE2QixHQUFHLEdBQUcsQ0FBQyxDQUFDOztBQUVsRDtBQUNBO0FBQUFuRyxPQUFBLENBQUFtRyw2QkFBQSxHQUFBQSw2QkFBQTtBQUNPLE1BQU1DLHlDQUF5QyxHQUFHO0VBQ3ZEQyxJQUFJLEVBQUUsU0FBUztFQUNmQyxFQUFFLEVBQUU7QUFDTixDQUFDO0FBQUN0RyxPQUFBLENBQUFvRyx5Q0FBQSxHQUFBQSx5Q0FBQTtBQUNLLE1BQU1HLHdDQUF3QyxHQUFHLHlCQUF5Qjs7QUFFakY7QUFBQXZHLE9BQUEsQ0FBQXVHLHdDQUFBLEdBQUFBLHdDQUFBO0FBQ08sTUFBTUMseUNBQXlDLEdBQUcsTUFBTTtBQUFDeEcsT0FBQSxDQUFBd0cseUNBQUEsR0FBQUEseUNBQUE7QUFDekQsTUFBTUMsd0NBQXdDLEdBQUcsc0JBQXNCOztBQUU5RTtBQUFBekcsT0FBQSxDQUFBeUcsd0NBQUEsR0FBQUEsd0NBQUE7QUFDTyxNQUFNQyx3Q0FBd0MsR0FBRyxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUM7QUFBQzFHLE9BQUEsQ0FBQTBHLHdDQUFBLEdBQUFBLHdDQUFBO0FBQ3ZFLE1BQU1DLHVDQUF1QyxHQUFHLFlBQVk7O0FBRW5FO0FBQUEzRyxPQUFBLENBQUEyRyx1Q0FBQSxHQUFBQSx1Q0FBQTtBQUNPLE1BQU1DLGdCQUFnQixHQUFHO0VBQzlCQyxPQUFPLEVBQUUsU0FBUztFQUNsQkMsSUFBSSxFQUFFLE1BQU07RUFDWkMsS0FBSyxFQUFFO0FBQ1QsQ0FBQztBQUFDL0csT0FBQSxDQUFBNEcsZ0JBQUEsR0FBQUEsZ0JBQUE7QUFFSyxNQUFNSSxjQUFjLEdBQUc7RUFDNUJDLE9BQU8sRUFBRSxTQUFTO0VBQ2xCSixPQUFPLEVBQUUsU0FBUztFQUNsQkssTUFBTSxFQUFFO0FBQ1YsQ0FBQzs7QUFFRDtBQUFBbEgsT0FBQSxDQUFBZ0gsY0FBQSxHQUFBQSxjQUFBO0FBQ08sTUFBTUcsc0JBQXNCLEdBQUcsd0JBQXdCO0FBQUNuSCxPQUFBLENBQUFtSCxzQkFBQSxHQUFBQSxzQkFBQTtBQUN4RCxNQUFNQyxpQkFBaUIsR0FBRywrQkFBK0I7O0FBRWhFO0FBQUFwSCxPQUFBLENBQUFvSCxpQkFBQSxHQUFBQSxpQkFBQTtBQUNPLE1BQU1DLHVDQUF1QyxHQUFHLHlCQUF5QjtBQUFDckgsT0FBQSxDQUFBcUgsdUNBQUEsR0FBQUEsdUNBQUE7QUFDMUUsTUFBTUMscUJBQXFCLEdBQUcsU0FBUztBQUFDdEgsT0FBQSxDQUFBc0gscUJBQUEsR0FBQUEscUJBQUE7QUFDeEMsTUFBTUMsd0JBQXdCLEdBQUcsOEJBQThCO0FBQUN2SCxPQUFBLENBQUF1SCx3QkFBQSxHQUFBQSx3QkFBQTtBQUNoRSxNQUFNQyx3QkFBd0IsR0FBRyxtQ0FBbUM7O0FBRTNFO0FBQUF4SCxPQUFBLENBQUF3SCx3QkFBQSxHQUFBQSx3QkFBQTtBQUNPLE1BQU1DLG9CQUFvQixHQUFHLFFBQVE7QUFBQ3pILE9BQUEsQ0FBQXlILG9CQUFBLEdBQUFBLG9CQUFBO0FBQ3RDLE1BQU1DLHNDQUFzQyxHQUFHLCtCQUErQjtBQUFDMUgsT0FBQSxDQUFBMEgsc0NBQUEsR0FBQUEsc0NBQUE7QUFDL0UsTUFBTUMsaUNBQWlDLEdBQUcsUUFBUTtBQUFDM0gsT0FBQSxDQUFBMkgsaUNBQUEsR0FBQUEsaUNBQUE7QUFDbkQsTUFBTUMsdUNBQXVDLEdBQUcsUUFBUTtBQUFDNUgsT0FBQSxDQUFBNEgsdUNBQUEsR0FBQUEsdUNBQUE7QUFDekQsTUFBTUMsNkRBQTZELEdBQUcsZUFBZTtBQUFDN0gsT0FBQSxDQUFBNkgsNkRBQUEsR0FBQUEsNkRBQUE7QUFDdEYsTUFBTUMsNERBQTRELEdBQUcsZ0RBQWdEO0FBQUM5SCxPQUFBLENBQUE4SCw0REFBQSxHQUFBQSw0REFBQTtBQUN0SCxNQUFNQyw4REFBOEQsR0FBRyw4Q0FBOEM7QUFBQy9ILE9BQUEsQ0FBQStILDhEQUFBLEdBQUFBLDhEQUFBO0FBQ3RILE1BQU1DLHlCQUF5QixHQUFHLDRFQUE0RTtBQUFDaEksT0FBQSxDQUFBZ0kseUJBQUEsR0FBQUEseUJBQUE7QUFDL0csTUFBTUMsK0JBQStCLEdBQUcsZUFBZTtBQUFDakksT0FBQSxDQUFBaUksK0JBQUEsR0FBQUEsK0JBQUE7QUFDeEQsTUFBTUMsK0JBQStCLEdBQUc7RUFDN0MsVUFBVSxFQUFFO0FBQ2QsQ0FBQzs7QUFFRDtBQUFBbEksT0FBQSxDQUFBa0ksK0JBQUEsR0FBQUEsK0JBQUE7QUFDTyxNQUFNQyxlQUFlLEdBQUcsV0FBVzs7QUFFMUM7QUFBQW5JLE9BQUEsQ0FBQW1JLGVBQUEsR0FBQUEsZUFBQTtBQUNPLE1BQU1DLHFCQUFxQixHQUFHO0VBQ25DQyxNQUFNLEVBQUUsUUFBUTtFQUNoQkMsWUFBWSxFQUFFLGNBQWM7RUFDNUJDLE9BQU8sRUFBRSxTQUFTO0VBQ2xCQyxlQUFlLEVBQUU7QUFDbkIsQ0FBVTtBQUFDeEksT0FBQSxDQUFBb0kscUJBQUEsR0FBQUEscUJBQUE7QUFFSixNQUFNSyxxQkFBcUIsR0FBRztFQUNuQyxDQUFDTCxxQkFBcUIsQ0FBQ0MsTUFBTSxHQUFHLFNBQVM7RUFDekMsQ0FBQ0QscUJBQXFCLENBQUNFLFlBQVksR0FBRyxTQUFTO0VBQy9DLENBQUNGLHFCQUFxQixDQUFDRyxPQUFPLEdBQUcsU0FBUztFQUMxQyxDQUFDSCxxQkFBcUIsQ0FBQ0ksZUFBZSxHQUFHLFNBQVM7RUFDbERFLE9BQU8sRUFBRTtBQUNYLENBQVU7QUFBQzFJLE9BQUEsQ0FBQXlJLHFCQUFBLEdBQUFBLHFCQUFBO0FBRUosTUFBTUUsMEJBQTBCLEdBQUc7RUFDeEMsQ0FBQ1AscUJBQXFCLENBQUNDLE1BQU0sR0FBRyxRQUFRO0VBQ3hDLENBQUNELHFCQUFxQixDQUFDRSxZQUFZLEdBQUcsY0FBYztFQUNwRCxDQUFDRixxQkFBcUIsQ0FBQ0csT0FBTyxHQUFHLFNBQVM7RUFDMUMsQ0FBQ0gscUJBQXFCLENBQUNJLGVBQWUsR0FBRyxpQkFBaUI7RUFDMURFLE9BQU8sRUFBRTtBQUNYLENBQVU7QUFBQzFJLE9BQUEsQ0FBQTJJLDBCQUFBLEdBQUFBLDBCQUFBO0FBRUosTUFBTUMscUJBQXFCLEdBQUcsQ0FDbkNSLHFCQUFxQixDQUFDQyxNQUFNLEVBQzVCRCxxQkFBcUIsQ0FBQ0UsWUFBWSxFQUNsQ0YscUJBQXFCLENBQUNHLE9BQU8sRUFDN0JILHFCQUFxQixDQUFDSSxlQUFlLENBQ3RDO0FBQUF4SSxPQUFBLENBQUE0SSxxQkFBQSxHQUFBQSxxQkFBQTtBQUVNLE1BQU1DLG1CQUFtQixHQUFHO0VBQ2pDQyxNQUFNLEVBQUUsUUFBUTtFQUNoQkMsVUFBVSxFQUFFO0FBQ2QsQ0FBQzs7QUFFRDtBQUFBL0ksT0FBQSxDQUFBNkksbUJBQUEsR0FBQUEsbUJBQUE7QUFDTyxNQUFNRywwQkFBMEIsR0FBRyxpQ0FBaUM7O0FBRTNFO0FBQUFoSixPQUFBLENBQUFnSiwwQkFBQSxHQUFBQSwwQkFBQTtBQUNPLE1BQU1DLFlBQVksR0FBRyxTQUFTOztBQUdyQztBQUFBakosT0FBQSxDQUFBaUosWUFBQSxHQUFBQSxZQUFBO0FBQ08sTUFBTUMsK0RBQStELEdBQUcsT0FBTzs7QUFHdEY7QUFBQWxKLE9BQUEsQ0FBQWtKLCtEQUFBLEdBQUFBLCtEQUFBO0FBQUEsSUFDWUMsZUFBZTtBQUFBbkosT0FBQSxDQUFBbUosZUFBQSxHQUFBQSxlQUFBO0FBQUEsV0FBZkEsZUFBZTtFQUFmQSxlQUFlLENBQWZBLGVBQWU7RUFBZkEsZUFBZSxDQUFmQSxlQUFlO0VBQWZBLGVBQWUsQ0FBZkEsZUFBZTtFQUFmQSxlQUFlLENBQWZBLGVBQWU7RUFBZkEsZUFBZSxDQUFmQSxlQUFlO0VBQWZBLGVBQWUsQ0FBZkEsZUFBZTtFQUFmQSxlQUFlLENBQWZBLGVBQWU7QUFBQSxHQUFmQSxlQUFlLEtBQUFuSixPQUFBLENBQUFtSixlQUFBLEdBQWZBLGVBQWU7QUFRMUI7QUFBQyxJQTBEVUMsa0JBQWtCO0FBQUFwSixPQUFBLENBQUFvSixrQkFBQSxHQUFBQSxrQkFBQTtBQUFBLFdBQWxCQSxrQkFBa0I7RUFBbEJBLGtCQUFrQjtFQUFsQkEsa0JBQWtCO0VBQWxCQSxrQkFBa0I7RUFBbEJBLGtCQUFrQjtFQUFsQkEsa0JBQWtCO0VBQWxCQSxrQkFBa0I7RUFBbEJBLGtCQUFrQjtBQUFBLEdBQWxCQSxrQkFBa0IsS0FBQXBKLE9BQUEsQ0FBQW9KLGtCQUFBLEdBQWxCQSxrQkFBa0I7QUFRN0I7QUFxRE0sTUFBTUMsMEJBQTBFLEdBQUc7RUFDeEYsQ0FBQ0YsZUFBZSxDQUFDakQsWUFBWSxHQUFHO0lBQzlCb0QsS0FBSyxFQUFFLGNBQWM7SUFDckJDLFdBQVcsRUFBRSxtREFBbUQ7SUFDaEVDLFdBQVcsRUFBRUwsZUFBZSxDQUFDakQ7RUFDL0IsQ0FBQztFQUNELENBQUNpRCxlQUFlLENBQUNNLE9BQU8sR0FBRztJQUN6QkgsS0FBSyxFQUFFLFNBQVM7SUFDaEJDLFdBQVcsRUFBRSxxSEFBcUg7SUFDbElDLFdBQVcsRUFBRUwsZUFBZSxDQUFDTTtFQUMvQixDQUFDO0VBQ0QsQ0FBQ04sZUFBZSxDQUFDTyxVQUFVLEdBQUc7SUFDNUJKLEtBQUssRUFBRSxtRUFBbUU7SUFDMUVDLFdBQVcsRUFBRTtFQUNmLENBQUM7RUFDRCxDQUFDSixlQUFlLENBQUNRLFFBQVEsR0FBRztJQUMxQkwsS0FBSyxFQUFFLFVBQVU7SUFDakJDLFdBQVcsRUFBRSwwREFBMEQ7SUFDdkVDLFdBQVcsRUFBRUwsZUFBZSxDQUFDUTtFQUMvQixDQUFDO0VBQ0QsQ0FBQ1IsZUFBZSxDQUFDUyxVQUFVLEdBQUc7SUFDNUJOLEtBQUssRUFBRSxpQkFBaUI7SUFDeEJDLFdBQVcsRUFBRSxnRkFBZ0Y7SUFDN0ZDLFdBQVcsRUFBRUwsZUFBZSxDQUFDUztFQUMvQixDQUFDO0VBQ0QsQ0FBQ1QsZUFBZSxDQUFDVSxVQUFVLEdBQUc7SUFDNUJQLEtBQUssRUFBRSxpQkFBaUI7SUFDeEJDLFdBQVcsRUFBRSxzRkFBc0Y7SUFDbkdDLFdBQVcsRUFBRUwsZUFBZSxDQUFDVTtFQUMvQixDQUFDO0VBQ0QsQ0FBQ1YsZUFBZSxDQUFDVyxhQUFhLEdBQUc7SUFDL0JSLEtBQUssRUFBRSxpQkFBaUI7SUFDeEJDLFdBQVcsRUFBRSx5R0FBeUc7SUFDdEhRLGlCQUFpQixFQUFFLGlEQUFpRDtJQUNwRVAsV0FBVyxFQUFFTCxlQUFlLENBQUNXO0VBQy9CO0FBQ0YsQ0FBQztBQUFDOUosT0FBQSxDQUFBcUosMEJBQUEsR0FBQUEsMEJBQUE7QUFFSyxNQUFNVyxlQUFrRCxHQUFHO0VBQ2hFLHNCQUFzQixFQUFFO0lBQ3RCVixLQUFLLEVBQUUsc0JBQXNCO0lBQzdCQyxXQUFXLEVBQUUsNElBQTRJO0lBQ3pKVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ00sT0FBTztJQUNqQ1MsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ2UsSUFBSTtJQUM3QkMsWUFBWSxFQUFFcEkseUJBQXlCO0lBQ3ZDcUksc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQkMsMEJBQTBCLEVBQUUsSUFBSTtJQUNoQztJQUNBQyxRQUFRLEVBQUVDLG9DQUFpQixDQUFDQyxPQUFPLENBQ2pDRCxvQ0FBaUIsQ0FBQ0UsZ0JBQWdCLEVBQ2xDRixvQ0FBaUIsQ0FBQ0csV0FBVyxFQUM3Qkgsb0NBQWlCLENBQUNJLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxFQUN4REosb0NBQWlCLENBQUNLLHVCQUF1QixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUM3RjtJQUNIQyxlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQUNULFFBQVEsRUFBRSxJQUFJLENBQUNBO01BQVEsQ0FBQyxDQUFDO0lBQ2hEO0VBQ0EsQ0FBQztFQUNELFlBQVksRUFBRTtJQUNabEIsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsV0FBVyxFQUFFLDhEQUE4RDtJQUMzRVUsUUFBUSxFQUFFZCxlQUFlLENBQUNqRCxZQUFZO0lBQ3RDZ0UsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BQU07SUFDL0JkLFlBQVksRUFBRSxJQUFJO0lBQ2xCQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxJQUFJO0lBQzFCYSxPQUFPLEVBQUU7TUFDUEQsTUFBTSxFQUFFO1FBQ05FLE1BQU0sRUFBRTtVQUNOQyxRQUFRLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQU0sQ0FBQztVQUMxQ0MsT0FBTyxFQUFFO1lBQUVGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFLO1FBQ3hDO01BQ0Y7SUFDRixDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVVGLEtBQXVCLEVBQVc7TUFDNUUsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUN2Q1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNBLENBQUM7RUFDRCxlQUFlLEVBQUU7SUFDZnRDLEtBQUssRUFBRSxjQUFjO0lBQ3JCQyxXQUFXLEVBQUUsdUVBQXVFO0lBQ3BGVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ2pELFlBQVk7SUFDdENnRSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFBTTtJQUMvQmQsWUFBWSxFQUFFLElBQUk7SUFDbEJDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJhLE9BQU8sRUFBRTtNQUNQRCxNQUFNLEVBQUU7UUFDTkUsTUFBTSxFQUFFO1VBQ05DLFFBQVEsRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFQyxLQUFLLEVBQUU7VUFBTSxDQUFDO1VBQzFDQyxPQUFPLEVBQUU7WUFBRUYsS0FBSyxFQUFFLE1BQU07WUFBRUMsS0FBSyxFQUFFO1VBQUs7UUFDeEM7TUFDRjtJQUNGLENBQUM7SUFDREUsZ0NBQWdDLEVBQUUsU0FBQUEsQ0FBVUYsS0FBdUIsRUFBVztNQUM1RSxPQUFPRyxPQUFPLENBQUNILEtBQUssQ0FBQztJQUN2QixDQUFDO0lBQ0RmLFFBQVEsRUFBRUMsb0NBQWlCLENBQUNrQixTQUFTO0lBQ3ZDWixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQ1ksT0FBTyxFQUFFO0lBQ3hCO0VBQ0EsQ0FBQztFQUNELG1CQUFtQixFQUFFO0lBQ25CdEMsS0FBSyxFQUFFLDJCQUEyQjtJQUNsQ0MsV0FBVyxFQUFFLDRFQUE0RTtJQUN6RlUsUUFBUSxFQUFFZCxlQUFlLENBQUNqRCxZQUFZO0lBQ3RDZ0UsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BQU07SUFDL0JkLFlBQVksRUFBRSxJQUFJO0lBQ2xCQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxJQUFJO0lBQzFCYSxPQUFPLEVBQUU7TUFDUEQsTUFBTSxFQUFFO1FBQ05FLE1BQU0sRUFBRTtVQUNOQyxRQUFRLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQU0sQ0FBQztVQUMxQ0MsT0FBTyxFQUFFO1lBQUVGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFLO1FBQ3hDO01BQ0Y7SUFDRixDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVVGLEtBQXVCLEVBQVc7TUFDNUUsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUN2Q1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNBLENBQUM7RUFDRCxtQkFBbUIsRUFBRTtJQUNuQnRDLEtBQUssRUFBRSxvQkFBb0I7SUFDM0JDLFdBQVcsRUFBRSwwRUFBMEU7SUFDdkZVLFFBQVEsRUFBRWQsZUFBZSxDQUFDakQsWUFBWTtJQUN0Q2dFLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsSUFBSTtJQUNsQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQmEsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0QsZ0JBQWdCLEVBQUU7SUFDaEJ0QyxLQUFLLEVBQUUsZUFBZTtJQUN0QkMsV0FBVyxFQUFFLHdFQUF3RTtJQUNyRlUsUUFBUSxFQUFFZCxlQUFlLENBQUNqRCxZQUFZO0lBQ3RDZ0UsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BQU07SUFDL0JkLFlBQVksRUFBRSxJQUFJO0lBQ2xCQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxJQUFJO0lBQzFCYSxPQUFPLEVBQUU7TUFDUEQsTUFBTSxFQUFFO1FBQ05FLE1BQU0sRUFBRTtVQUNOQyxRQUFRLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQU0sQ0FBQztVQUMxQ0MsT0FBTyxFQUFFO1lBQUVGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFLO1FBQ3hDO01BQ0Y7SUFDRixDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVVGLEtBQXVCLEVBQVc7TUFDNUUsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUN2Q1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNBLENBQUM7RUFDRCxjQUFjLEVBQUU7SUFDZHRDLEtBQUssRUFBRSxhQUFhO0lBQ3BCQyxXQUFXLEVBQUUsZ0VBQWdFO0lBQzdFVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ2pELFlBQVk7SUFDdENnRSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFBTTtJQUMvQmQsWUFBWSxFQUFFLElBQUk7SUFDbEJDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJhLE9BQU8sRUFBRTtNQUNQRCxNQUFNLEVBQUU7UUFDTkUsTUFBTSxFQUFFO1VBQ05DLFFBQVEsRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFQyxLQUFLLEVBQUU7VUFBTSxDQUFDO1VBQzFDQyxPQUFPLEVBQUU7WUFBRUYsS0FBSyxFQUFFLE1BQU07WUFBRUMsS0FBSyxFQUFFO1VBQUs7UUFDeEM7TUFDRjtJQUNGLENBQUM7SUFDREUsZ0NBQWdDLEVBQUUsU0FBQUEsQ0FBVUYsS0FBdUIsRUFBVztNQUM1RSxPQUFPRyxPQUFPLENBQUNILEtBQUssQ0FBQztJQUN2QixDQUFDO0lBQ0RmLFFBQVEsRUFBRUMsb0NBQWlCLENBQUNrQixTQUFTO0lBQ3ZDWixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQ1ksT0FBTyxFQUFFO0lBQ3hCO0VBQ0EsQ0FBQztFQUNELGlCQUFpQixFQUFFO0lBQ2pCdEMsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsV0FBVyxFQUFFLG1FQUFtRTtJQUNoRlUsUUFBUSxFQUFFZCxlQUFlLENBQUNqRCxZQUFZO0lBQ3RDZ0UsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BQU07SUFDL0JkLFlBQVksRUFBRSxJQUFJO0lBQ2xCQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxJQUFJO0lBQzFCYSxPQUFPLEVBQUU7TUFDUEQsTUFBTSxFQUFFO1FBQ05FLE1BQU0sRUFBRTtVQUNOQyxRQUFRLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQU0sQ0FBQztVQUMxQ0MsT0FBTyxFQUFFO1lBQUVGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFLO1FBQ3hDO01BQ0Y7SUFDRixDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVVGLEtBQXVCLEVBQVc7TUFDNUUsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUN2Q1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNBLENBQUM7RUFDRCxtQkFBbUIsRUFBRTtJQUNuQnRDLEtBQUssRUFBRSx3QkFBd0I7SUFDL0JDLFdBQVcsRUFBRSwyRUFBMkU7SUFDeEZVLFFBQVEsRUFBRWQsZUFBZSxDQUFDakQsWUFBWTtJQUN0Q2dFLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsSUFBSTtJQUNsQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQmEsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0QsYUFBYSxFQUFFO0lBQ2J0QyxLQUFLLEVBQUUsYUFBYTtJQUNwQkMsV0FBVyxFQUFFLDZDQUE2QztJQUMxRFUsUUFBUSxFQUFFZCxlQUFlLENBQUNNLE9BQU87SUFDakNTLElBQUksRUFBRWQsa0JBQWtCLENBQUNlLElBQUk7SUFDN0JDLFlBQVksRUFBRWpKLCtCQUErQjtJQUM3Q2tKLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUI7SUFDQUUsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ0MsT0FBTyxDQUNqQ0Qsb0NBQWlCLENBQUNFLGdCQUFnQixFQUNsQ0Ysb0NBQWlCLENBQUNHLFdBQVcsRUFDN0JILG9DQUFpQixDQUFDSSxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFDeERKLG9DQUFpQixDQUFDSyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FDN0Y7SUFDSEMsZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFDVCxRQUFRLEVBQUUsSUFBSSxDQUFDQTtNQUFRLENBQUMsQ0FBQztJQUNoRDtFQUNBLENBQUM7RUFDRCxzQkFBc0IsRUFBRTtJQUN0QmxCLEtBQUssRUFBRSxlQUFlO0lBQ3RCQyxXQUFXLEVBQUUsdUdBQXVHO0lBQ3BIVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1UsVUFBVTtJQUNwQ0ssSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ3lDLE1BQU07SUFDL0J6QixZQUFZLEVBQUUsRUFBRTtJQUNoQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQmEsT0FBTyxFQUFFO01BQ1BVLE1BQU0sRUFBRTtRQUNOQyxRQUFRLEVBQUU7TUFDWjtJQUNGLENBQUM7SUFDREMsNkNBQTZDLEVBQUUsU0FBQUEsQ0FBVVIsS0FBVSxFQUFPO01BQ3hFLE9BQU9TLElBQUksQ0FBQ0MsU0FBUyxDQUFDVixLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUNEVyw2Q0FBNkMsRUFBRSxTQUFBQSxDQUFVWCxLQUFhLEVBQU87TUFDM0UsSUFBSTtRQUNGLE9BQU9TLElBQUksQ0FBQ0csS0FBSyxDQUFDWixLQUFLLENBQUM7TUFDMUIsQ0FBQyxDQUFDLE9BQU9hLEtBQUssRUFBRTtRQUNkLE9BQU9iLEtBQUs7TUFDZDtNQUFDO0lBQ0gsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDNEIsSUFBSSxDQUFDNUIsb0NBQWlCLENBQUNDLE9BQU8sQ0FDeERELG9DQUFpQixDQUFDNkIsS0FBSyxDQUFDN0Isb0NBQWlCLENBQUNDLE9BQU8sQ0FDL0NELG9DQUFpQixDQUFDOEIsUUFBUSxFQUMxQjlCLG9DQUFpQixDQUFDRSxnQkFBZ0IsRUFDbENGLG9DQUFpQixDQUFDRyxXQUFXLENBQzlCLENBQUMsQ0FDSCxDQUFDO0lBQ0pHLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDd0IsT0FBTyxDQUFDeEIsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFBQ1QsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ0MsT0FBTyxDQUNuRUQsb0NBQWlCLENBQUNFLGdCQUFnQixFQUNsQ0Ysb0NBQWlCLENBQUNHLFdBQVc7TUFDOUIsQ0FBQyxDQUFDLENBQUM7SUFDUjtFQUNBLENBQUM7RUFDRCxnQ0FBZ0MsRUFBRTtJQUNoQ3RCLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFdBQVcsRUFBRSwyREFBMkQ7SUFDeEVVLFFBQVEsRUFBRWQsZUFBZSxDQUFDVSxVQUFVO0lBQ3BDSyxJQUFJLEVBQUVkLGtCQUFrQixDQUFDcUQsTUFBTTtJQUMvQnRCLE9BQU8sRUFBRTtNQUNQc0IsTUFBTSxFQUFFLENBQ047UUFDRXRDLElBQUksRUFBRSxRQUFRO1FBQ2RvQixLQUFLLEVBQUU7TUFDVCxDQUFDLEVBQ0Q7UUFDRXBCLElBQUksRUFBRSxPQUFPO1FBQ2JvQixLQUFLLEVBQUU7TUFDVCxDQUFDLEVBQ0Q7UUFDRXBCLElBQUksRUFBRSxRQUFRO1FBQ2RvQixLQUFLLEVBQUU7TUFDVCxDQUFDLEVBQ0Q7UUFDRXBCLElBQUksRUFBRSxTQUFTO1FBQ2ZvQixLQUFLLEVBQUU7TUFDVCxDQUFDO0lBRUwsQ0FBQztJQUNEbkIsWUFBWSxFQUFFM0ksaUNBQWlDO0lBQy9DNEksc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQkMsMEJBQTBCLEVBQUUsSUFBSTtJQUNoQ0MsUUFBUSxFQUFFLFNBQUFBLENBQVVlLEtBQUssRUFBQztNQUMzQixPQUFPZCxvQ0FBaUIsQ0FBQ2lDLE9BQU8sQ0FBQyxJQUFJLENBQUN2QixPQUFPLENBQUNzQixNQUFNLENBQUNFLEdBQUcsQ0FBQyxDQUFDO1FBQUNwQjtNQUFLLENBQUMsS0FBS0EsS0FBSyxDQUFDLENBQUMsQ0FBQ0EsS0FBSyxDQUFDO0lBQ3JGLENBQUM7SUFDRFIsZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUM0QixLQUFLLENBQUMsSUFBSSxDQUFDekIsT0FBTyxDQUFDc0IsTUFBTSxDQUFDRSxHQUFHLENBQUMsQ0FBQztRQUFDcEI7TUFBSyxDQUFDLEtBQUtQLE1BQU0sQ0FBQzBCLE9BQU8sQ0FBQ25CLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDakY7RUFDQSxDQUFDO0VBQ0QsNEJBQTRCLEVBQUU7SUFDNUJqQyxLQUFLLEVBQUUsWUFBWTtJQUNuQkMsV0FBVyxFQUFFLG9FQUFvRTtJQUNqRlUsUUFBUSxFQUFFZCxlQUFlLENBQUNVLFVBQVU7SUFDcENLLElBQUksRUFBRWQsa0JBQWtCLENBQUNlLElBQUk7SUFDN0JDLFlBQVksRUFBRWhKLDZCQUE2QjtJQUMzQ2lKLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJDLDBCQUEwQixFQUFFLElBQUk7SUFDaEM7SUFDQUMsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ0MsT0FBTyxDQUNqQ0Qsb0NBQWlCLENBQUNFLGdCQUFnQixFQUNsQ0Ysb0NBQWlCLENBQUNHLFdBQVcsRUFDN0JILG9DQUFpQixDQUFDSSxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFDeERKLG9DQUFpQixDQUFDSyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FDN0Y7SUFDSEMsZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFDVCxRQUFRLEVBQUUsSUFBSSxDQUFDQTtNQUFRLENBQUMsQ0FBQztJQUNoRDtFQUNBLENBQUM7RUFDRCxnQ0FBZ0MsRUFBRTtJQUNoQ2xCLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFdBQVcsRUFBRSxrRUFBa0U7SUFDL0VVLFFBQVEsRUFBRWQsZUFBZSxDQUFDVSxVQUFVO0lBQ3BDSyxJQUFJLEVBQUVkLGtCQUFrQixDQUFDeUQsTUFBTTtJQUMvQnpDLFlBQVksRUFBRTVJLHlDQUF5QztJQUN2RDZJLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJDLDBCQUEwQixFQUFFLElBQUk7SUFDaENZLE9BQU8sRUFBRTtNQUNQMEIsTUFBTSxFQUFFO1FBQ05DLEdBQUcsRUFBRSxDQUFDO1FBQ05DLE9BQU8sRUFBRTtNQUNYO0lBQ0YsQ0FBQztJQUNEaEIsNkNBQTZDLEVBQUUsU0FBQUEsQ0FBU1IsS0FBYSxFQUFVO01BQzdFLE9BQU95QixNQUFNLENBQUN6QixLQUFLLENBQUM7SUFDdEIsQ0FBQztJQUNEVyw2Q0FBNkMsRUFBRSxTQUFBQSxDQUFTWCxLQUFhLEVBQVU7TUFDN0UsT0FBTzBCLE1BQU0sQ0FBQzFCLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBQ0RmLFFBQVEsRUFBRSxTQUFBQSxDQUFTZSxLQUFLLEVBQUM7TUFDMUIsT0FBT2Qsb0NBQWlCLENBQUNvQyxNQUFNLENBQUMsSUFBSSxDQUFDMUIsT0FBTyxDQUFDMEIsTUFBTSxDQUFDLENBQUN0QixLQUFLLENBQUM7SUFDNUQsQ0FBQztJQUNEUixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQzZCLE1BQU0sQ0FBQztRQUFDckMsUUFBUSxFQUFFLElBQUksQ0FBQ0EsUUFBUSxDQUFDMEMsSUFBSSxDQUFDLElBQUk7TUFBQyxDQUFDLENBQUM7SUFDM0Q7RUFDQSxDQUFDO0VBQ0QsOEJBQThCLEVBQUU7SUFDOUI1RCxLQUFLLEVBQUUsY0FBYztJQUNyQkMsV0FBVyxFQUFFLGdFQUFnRTtJQUM3RVUsUUFBUSxFQUFFZCxlQUFlLENBQUNVLFVBQVU7SUFDcENLLElBQUksRUFBRWQsa0JBQWtCLENBQUN5RCxNQUFNO0lBQy9CekMsWUFBWSxFQUFFN0ksdUNBQXVDO0lBQ3JEOEksc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQkMsMEJBQTBCLEVBQUUsSUFBSTtJQUNoQ1ksT0FBTyxFQUFFO01BQ1AwQixNQUFNLEVBQUU7UUFDTkMsR0FBRyxFQUFFLENBQUM7UUFDTkMsT0FBTyxFQUFFO01BQ1g7SUFDRixDQUFDO0lBQ0RoQiw2Q0FBNkMsRUFBRSxTQUFBQSxDQUFTUixLQUFhLEVBQUM7TUFDcEUsT0FBT3lCLE1BQU0sQ0FBQ3pCLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBQ0RXLDZDQUE2QyxFQUFFLFNBQUFBLENBQVNYLEtBQWEsRUFBVTtNQUM3RSxPQUFPMEIsTUFBTSxDQUFDMUIsS0FBSyxDQUFDO0lBQ3RCLENBQUM7SUFDRGYsUUFBUSxFQUFFLFNBQUFBLENBQVNlLEtBQUssRUFBQztNQUMxQixPQUFPZCxvQ0FBaUIsQ0FBQ29DLE1BQU0sQ0FBQyxJQUFJLENBQUMxQixPQUFPLENBQUMwQixNQUFNLENBQUMsQ0FBQ3RCLEtBQUssQ0FBQztJQUM1RCxDQUFDO0lBQ0RSLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDNkIsTUFBTSxDQUFDO1FBQUNyQyxRQUFRLEVBQUUsSUFBSSxDQUFDQSxRQUFRLENBQUMwQyxJQUFJLENBQUMsSUFBSTtNQUFDLENBQUMsQ0FBQztJQUMzRDtFQUNBLENBQUM7RUFDRCwwQkFBMEIsRUFBRTtJQUMxQjVELEtBQUssRUFBRSxVQUFVO0lBQ2pCQyxXQUFXLEVBQUUseUVBQXlFO0lBQ3RGVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1UsVUFBVTtJQUNwQ0ssSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ2UsSUFBSTtJQUM3QkMsWUFBWSxFQUFFeEksa0NBQWtDO0lBQ2hEeUksc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQjZDLGdDQUFnQyxFQUFFLElBQUk7SUFDdEMzQyxRQUFRLEVBQUUsU0FBQUEsQ0FBU2UsS0FBYSxFQUFDO01BQ2xDLE9BQU8sSUFBQTZCLGtCQUF3QixFQUFDN0IsS0FBSyxDQUFDLEdBQUc4QixTQUFTLEdBQUcsd0JBQXdCO0lBQzlFLENBQUM7SUFDRHRDLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFBQ1QsUUFBUSxFQUFFLElBQUksQ0FBQ0E7TUFBUSxDQUFDLENBQUM7SUFDaEQ7RUFDQSxDQUFDO0VBQ0Qsd0JBQXdCLEVBQUU7SUFDeEJsQixLQUFLLEVBQUUsUUFBUTtJQUNmQyxXQUFXLEVBQUUseUNBQXlDO0lBQ3REVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1UsVUFBVTtJQUNwQ0ssSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BQU07SUFDL0JkLFlBQVksRUFBRTFJLCtCQUErQjtJQUM3QzJJLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJhLE9BQU8sRUFBRTtNQUNQRCxNQUFNLEVBQUU7UUFDTkUsTUFBTSxFQUFFO1VBQ05DLFFBQVEsRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFQyxLQUFLLEVBQUU7VUFBTSxDQUFDO1VBQzFDQyxPQUFPLEVBQUU7WUFBRUYsS0FBSyxFQUFFLE1BQU07WUFBRUMsS0FBSyxFQUFFO1VBQUs7UUFDeEM7TUFDRjtJQUNGLENBQUM7SUFDREUsZ0NBQWdDLEVBQUUsU0FBQUEsQ0FBVUYsS0FBdUIsRUFBVztNQUM1RSxPQUFPRyxPQUFPLENBQUNILEtBQUssQ0FBQztJQUN2QixDQUFDO0lBQ0RmLFFBQVEsRUFBRUMsb0NBQWlCLENBQUNrQixTQUFTO0lBQ3ZDWixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQ1ksT0FBTyxFQUFFO0lBQ3hCO0VBQ0EsQ0FBQztFQUNELHVCQUF1QixFQUFFO0lBQ3pCdEMsS0FBSyxFQUFFLFFBQVE7SUFDZkMsV0FBVyxFQUFFLHNDQUFzQztJQUNuRFUsUUFBUSxFQUFFZCxlQUFlLENBQUNXLGFBQWE7SUFDdkNJLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsSUFBSTtJQUNsQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUN4QmdELDJCQUEyQixFQUFFLElBQUk7SUFDbkNuQyxPQUFPLEVBQUU7TUFDUkQsTUFBTSxFQUFFO1FBQ1BFLE1BQU0sRUFBRTtVQUNQQyxRQUFRLEVBQUU7WUFBQ0MsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQUssQ0FBQztVQUN4Q0MsT0FBTyxFQUFFO1lBQUNGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFJO1FBQ3JDO01BQ0Q7SUFDRCxDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVNGLEtBQXVCLEVBQVU7TUFDM0UsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdEIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUNyQ1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNELENBQUM7RUFDQSx3QkFBd0IsRUFBRTtJQUN4QnRDLEtBQUssRUFBRSxlQUFlO0lBQ3RCQyxXQUFXLEVBQUcsaUVBQWdFO0lBQzlFVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1csYUFBYTtJQUN2Q0ksSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ21FLFVBQVU7SUFDbkNuRCxZQUFZLEVBQUUsRUFBRTtJQUNoQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQmEsT0FBTyxFQUFFO01BQ1ZxQyxJQUFJLEVBQUU7UUFDTHRELElBQUksRUFBRSxPQUFPO1FBQ2J1RCxVQUFVLEVBQUUsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUM7UUFDN0NDLElBQUksRUFBRTtVQUNMQyxRQUFRLEVBQUV6RTtRQUNYLENBQUM7UUFDRDBFLFdBQVcsRUFBRTtVQUNaQyxVQUFVLEVBQUU7WUFDWEMsS0FBSyxFQUFFLEdBQUc7WUFDVkMsTUFBTSxFQUFFLEVBQUU7WUFDVkMsSUFBSSxFQUFFO1VBQ1A7UUFDRCxDQUFDO1FBQ0RDLEtBQUssRUFBRTtVQUNOQyxzQkFBc0IsRUFBRSw2QkFBNkI7VUFDckRDLFFBQVEsRUFBRSx3QkFBd0I7VUFDbENDLGdCQUFnQixFQUFHRCxRQUFnQixJQUFNLGlCQUFnQkEsUUFBUyxNQUFLRSxJQUFJLENBQUNDLEdBQUcsRUFBRztVQUM3RTtRQUNOO01BQ0Q7SUFDRCxDQUFDOztJQUNEOUQsUUFBUSxFQUFFLFNBQUFBLENBQVNlLEtBQUssRUFBQztNQUN4QixPQUFPZCxvQ0FBaUIsQ0FBQ0MsT0FBTyxDQUMvQkQsb0NBQWlCLENBQUM4RCxrQkFBa0IsQ0FBQztRQUFDLEdBQUcsSUFBSSxDQUFDcEQsT0FBTyxDQUFDcUMsSUFBSSxDQUFDRSxJQUFJO1FBQUVjLGNBQWMsRUFBRTtNQUFJLENBQUMsQ0FBQyxFQUN2Ri9ELG9DQUFpQixDQUFDZ0UsNkJBQTZCLENBQUMsSUFBSSxDQUFDdEQsT0FBTyxDQUFDcUMsSUFBSSxDQUFDQyxVQUFVLENBQUMsQ0FDN0UsQ0FBQ2xDLEtBQUssQ0FBQztJQUNUO0VBQ0EsQ0FBQztFQUNELGdDQUFnQyxFQUFFO0lBQ2hDakMsS0FBSyxFQUFFLGtCQUFrQjtJQUN6QkMsV0FBVyxFQUFHLG1FQUFrRTtJQUNoRlUsUUFBUSxFQUFFZCxlQUFlLENBQUNXLGFBQWE7SUFDdkNJLElBQUksRUFBRWQsa0JBQWtCLENBQUNtRSxVQUFVO0lBQ25DbkQsWUFBWSxFQUFFLEVBQUU7SUFDaEJDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJhLE9BQU8sRUFBRTtNQUNWcUMsSUFBSSxFQUFFO1FBQ0x0RCxJQUFJLEVBQUUsT0FBTztRQUNidUQsVUFBVSxFQUFFLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDO1FBQzdDQyxJQUFJLEVBQUU7VUFDTEMsUUFBUSxFQUFFekU7UUFDWCxDQUFDO1FBQ0QwRSxXQUFXLEVBQUU7VUFDWkMsVUFBVSxFQUFFO1lBQ1hDLEtBQUssRUFBRSxHQUFHO1lBQ1ZDLE1BQU0sRUFBRSxFQUFFO1lBQ1ZDLElBQUksRUFBRTtVQUNQO1FBQ0QsQ0FBQztRQUNEQyxLQUFLLEVBQUU7VUFDTkMsc0JBQXNCLEVBQUUsNkJBQTZCO1VBQ3JEQyxRQUFRLEVBQUUsZ0NBQWdDO1VBQzFDQyxnQkFBZ0IsRUFBR0QsUUFBZ0IsSUFBTSxpQkFBZ0JBLFFBQVMsTUFBS0UsSUFBSSxDQUFDQyxHQUFHLEVBQUc7VUFDN0U7UUFDTjtNQUNEO0lBQ0QsQ0FBQzs7SUFDRDlELFFBQVEsRUFBRSxTQUFBQSxDQUFTZSxLQUFLLEVBQUM7TUFDeEIsT0FBT2Qsb0NBQWlCLENBQUNDLE9BQU8sQ0FDL0JELG9DQUFpQixDQUFDOEQsa0JBQWtCLENBQUM7UUFBQyxHQUFHLElBQUksQ0FBQ3BELE9BQU8sQ0FBQ3FDLElBQUksQ0FBQ0UsSUFBSTtRQUFFYyxjQUFjLEVBQUU7TUFBSSxDQUFDLENBQUMsRUFDdkYvRCxvQ0FBaUIsQ0FBQ2dFLDZCQUE2QixDQUFDLElBQUksQ0FBQ3RELE9BQU8sQ0FBQ3FDLElBQUksQ0FBQ0MsVUFBVSxDQUFDLENBQzdFLENBQUNsQyxLQUFLLENBQUM7SUFDVDtFQUNBLENBQUM7RUFDRCw0QkFBNEIsRUFBRTtJQUM1QmpDLEtBQUssRUFBRSxrQkFBa0I7SUFDekJDLFdBQVcsRUFBRyx5SEFBd0g7SUFDdElVLFFBQVEsRUFBRWQsZUFBZSxDQUFDVyxhQUFhO0lBQ3ZDSSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDbUUsVUFBVTtJQUNuQ25ELFlBQVksRUFBRSxFQUFFO0lBQ2hCc0Usb0JBQW9CLEVBQUVySCx1Q0FBdUM7SUFDN0RnRCxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxJQUFJO0lBQzFCYSxPQUFPLEVBQUU7TUFDVnFDLElBQUksRUFBRTtRQUNMdEQsSUFBSSxFQUFFLE9BQU87UUFDYnVELFVBQVUsRUFBRSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDO1FBQ3JDQyxJQUFJLEVBQUU7VUFDTEMsUUFBUSxFQUFFekU7UUFDWCxDQUFDO1FBQ0QwRSxXQUFXLEVBQUU7VUFDWkMsVUFBVSxFQUFFO1lBQ1hDLEtBQUssRUFBRSxHQUFHO1lBQ1ZDLE1BQU0sRUFBRSxFQUFFO1lBQ1ZDLElBQUksRUFBRTtVQUNQO1FBQ0QsQ0FBQztRQUNEQyxLQUFLLEVBQUU7VUFDTkMsc0JBQXNCLEVBQUUsNkJBQTZCO1VBQ3JEQyxRQUFRLEVBQUUsNEJBQTRCO1VBQ3RDQyxnQkFBZ0IsRUFBR0QsUUFBZ0IsSUFBTSxpQkFBZ0JBLFFBQVM7UUFDbkU7TUFDRDtJQUNELENBQUM7SUFDRDNELFFBQVEsRUFBRSxTQUFBQSxDQUFTZSxLQUFLLEVBQUM7TUFDeEIsT0FBT2Qsb0NBQWlCLENBQUNDLE9BQU8sQ0FDL0JELG9DQUFpQixDQUFDOEQsa0JBQWtCLENBQUM7UUFBQyxHQUFHLElBQUksQ0FBQ3BELE9BQU8sQ0FBQ3FDLElBQUksQ0FBQ0UsSUFBSTtRQUFFYyxjQUFjLEVBQUU7TUFBSSxDQUFDLENBQUMsRUFDdkYvRCxvQ0FBaUIsQ0FBQ2dFLDZCQUE2QixDQUFDLElBQUksQ0FBQ3RELE9BQU8sQ0FBQ3FDLElBQUksQ0FBQ0MsVUFBVSxDQUFDLENBQzdFLENBQUNsQyxLQUFLLENBQUM7SUFDVDtFQUNBLENBQUM7RUFDRCw0QkFBNEIsRUFBRTtJQUM1QmpDLEtBQUssRUFBRSx3QkFBd0I7SUFDL0JDLFdBQVcsRUFBRywwSEFBeUg7SUFDdklVLFFBQVEsRUFBRWQsZUFBZSxDQUFDVyxhQUFhO0lBQ3ZDSSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDbUUsVUFBVTtJQUNuQ25ELFlBQVksRUFBRSxFQUFFO0lBQ2hCQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxJQUFJO0lBQzFCZ0QsMkJBQTJCLEVBQUUsSUFBSTtJQUNqQ25DLE9BQU8sRUFBRTtNQUNWcUMsSUFBSSxFQUFFO1FBQ0x0RCxJQUFJLEVBQUUsT0FBTztRQUNidUQsVUFBVSxFQUFFLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDO1FBQzdDQyxJQUFJLEVBQUU7VUFDTEMsUUFBUSxFQUFFekU7UUFDWCxDQUFDO1FBQ0QwRSxXQUFXLEVBQUU7VUFDWkMsVUFBVSxFQUFFO1lBQ1hDLEtBQUssRUFBRSxFQUFFO1lBQ1RDLE1BQU0sRUFBRSxFQUFFO1lBQ1ZDLElBQUksRUFBRTtVQUNQO1FBQ0QsQ0FBQztRQUNEQyxLQUFLLEVBQUU7VUFDTkMsc0JBQXNCLEVBQUUsNkJBQTZCO1VBQ3JEQyxRQUFRLEVBQUUsNEJBQTRCO1VBQ3RDQyxnQkFBZ0IsRUFBR0QsUUFBZ0IsSUFBTSxpQkFBZ0JBLFFBQVMsTUFBS0UsSUFBSSxDQUFDQyxHQUFHLEVBQUc7VUFDN0U7UUFDTjtNQUNEO0lBQ0QsQ0FBQzs7SUFDRDlELFFBQVEsRUFBRSxTQUFBQSxDQUFTZSxLQUFLLEVBQUM7TUFDeEIsT0FBT2Qsb0NBQWlCLENBQUNDLE9BQU8sQ0FDL0JELG9DQUFpQixDQUFDOEQsa0JBQWtCLENBQUM7UUFBQyxHQUFHLElBQUksQ0FBQ3BELE9BQU8sQ0FBQ3FDLElBQUksQ0FBQ0UsSUFBSTtRQUFFYyxjQUFjLEVBQUU7TUFBSSxDQUFDLENBQUMsRUFDdkYvRCxvQ0FBaUIsQ0FBQ2dFLDZCQUE2QixDQUFDLElBQUksQ0FBQ3RELE9BQU8sQ0FBQ3FDLElBQUksQ0FBQ0MsVUFBVSxDQUFDLENBQzdFLENBQUNsQyxLQUFLLENBQUM7SUFDVDtFQUNBLENBQUM7RUFDRCw4QkFBOEIsRUFBRTtJQUNoQ2pDLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFdBQVcsRUFBRSxnQ0FBZ0M7SUFDN0NVLFFBQVEsRUFBRWQsZUFBZSxDQUFDVyxhQUFhO0lBQ3ZDSSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDdUYsUUFBUTtJQUNqQ3ZFLFlBQVksRUFBRSxFQUFFO0lBQ2RzRSxvQkFBb0IsRUFBRW5ILHdCQUF3QjtJQUNoRDhDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDeEJhLE9BQU8sRUFBRTtNQUFFeUQsT0FBTyxFQUFFLENBQUM7TUFBRUMsU0FBUyxFQUFFO0lBQUcsQ0FBQztJQUN0Q3JFLFFBQVEsRUFBRSxTQUFBQSxDQUFVZSxLQUFLLEVBQUU7TUFBQSxJQUFBdUQsYUFBQSxFQUFBQyxjQUFBO01BQ3pCLE9BQU90RSxvQ0FBaUIsQ0FBQ3VFLG1CQUFtQixDQUFDO1FBQzNDSixPQUFPLEdBQUFFLGFBQUEsR0FBRSxJQUFJLENBQUMzRCxPQUFPLGNBQUEyRCxhQUFBLHVCQUFaQSxhQUFBLENBQWNGLE9BQU87UUFDOUJDLFNBQVMsR0FBQUUsY0FBQSxHQUFFLElBQUksQ0FBQzVELE9BQU8sY0FBQTRELGNBQUEsdUJBQVpBLGNBQUEsQ0FBY0Y7TUFDM0IsQ0FBQyxDQUFDLENBQUN0RCxLQUFLLENBQUM7SUFDWCxDQUFDO0lBQ0RSLGVBQWUsRUFBRSxTQUFBQSxDQUFVQyxNQUFNLEVBQUU7TUFDakMsT0FBT0EsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRVQsUUFBUSxFQUFFLElBQUksQ0FBQ0EsUUFBUSxDQUFDMEMsSUFBSSxDQUFDLElBQUk7TUFBRSxDQUFDLENBQUM7SUFDOUQ7RUFDRixDQUFDO0VBQ0QsOEJBQThCLEVBQUU7SUFDOUI1RCxLQUFLLEVBQUUsZ0JBQWdCO0lBQ3ZCQyxXQUFXLEVBQUUsZ0NBQWdDO0lBQzdDVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1csYUFBYTtJQUN2Q0ksSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ3VGLFFBQVE7SUFDakN2RSxZQUFZLEVBQUUsRUFBRTtJQUNoQnNFLG9CQUFvQixFQUFFbEgsd0JBQXdCO0lBQzlDNkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQmEsT0FBTyxFQUFFO01BQUV5RCxPQUFPLEVBQUUsQ0FBQztNQUFFQyxTQUFTLEVBQUU7SUFBRyxDQUFDO0lBQ3RDckUsUUFBUSxFQUFFLFNBQUFBLENBQVVlLEtBQUssRUFBRTtNQUFBLElBQUEwRCxjQUFBLEVBQUFDLGNBQUE7TUFDekIsT0FBT3pFLG9DQUFpQixDQUFDdUUsbUJBQW1CLENBQUM7UUFDM0NKLE9BQU8sR0FBQUssY0FBQSxHQUFFLElBQUksQ0FBQzlELE9BQU8sY0FBQThELGNBQUEsdUJBQVpBLGNBQUEsQ0FBY0wsT0FBTztRQUM5QkMsU0FBUyxHQUFBSyxjQUFBLEdBQUUsSUFBSSxDQUFDL0QsT0FBTyxjQUFBK0QsY0FBQSx1QkFBWkEsY0FBQSxDQUFjTDtNQUMzQixDQUFDLENBQUMsQ0FBQ3RELEtBQUssQ0FBQztJQUNYLENBQUM7SUFDSFIsZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFDVCxRQUFRLEVBQUUsSUFBSSxDQUFDQSxRQUFRLENBQUMwQyxJQUFJLENBQUMsSUFBSTtNQUFDLENBQUMsQ0FBQztJQUMzRDtFQUNELENBQUM7RUFDQSxnQkFBZ0IsRUFBRTtJQUNoQjVELEtBQUssRUFBRSxlQUFlO0lBQ3RCQyxXQUFXLEVBQUUsMERBQTBEO0lBQ3ZFVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1EsUUFBUTtJQUNsQ08sSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ3lDLE1BQU07SUFDL0J6QixZQUFZLEVBQUUsRUFBRTtJQUNoQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQmEsT0FBTyxFQUFFO01BQ1BVLE1BQU0sRUFBRTtRQUNOQyxRQUFRLEVBQUU7TUFDWjtJQUNGLENBQUM7SUFDREMsNkNBQTZDLEVBQUUsU0FBQUEsQ0FBVVIsS0FBVSxFQUFPO01BQ3hFLE9BQU9TLElBQUksQ0FBQ0MsU0FBUyxDQUFDVixLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUNEVyw2Q0FBNkMsRUFBRSxTQUFBQSxDQUFVWCxLQUFhLEVBQU87TUFDM0UsSUFBSTtRQUNGLE9BQU9TLElBQUksQ0FBQ0csS0FBSyxDQUFDWixLQUFLLENBQUM7TUFDMUIsQ0FBQyxDQUFDLE9BQU9hLEtBQUssRUFBRTtRQUNkLE9BQU9iLEtBQUs7TUFDZDtNQUFDO0lBQ0gsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDNEIsSUFBSSxDQUFDNUIsb0NBQWlCLENBQUNDLE9BQU8sQ0FDeERELG9DQUFpQixDQUFDNkIsS0FBSyxDQUFDN0Isb0NBQWlCLENBQUNDLE9BQU8sQ0FDL0NELG9DQUFpQixDQUFDOEIsUUFBUSxFQUMxQjlCLG9DQUFpQixDQUFDRSxnQkFBZ0IsRUFDbENGLG9DQUFpQixDQUFDRyxXQUFXLENBQzlCLENBQUMsQ0FDSCxDQUFDO0lBQ0pHLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDd0IsT0FBTyxDQUFDeEIsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFBQ1QsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ0MsT0FBTyxDQUNuRUQsb0NBQWlCLENBQUNFLGdCQUFnQixFQUNsQ0Ysb0NBQWlCLENBQUNHLFdBQVc7TUFDOUIsQ0FBQyxDQUFDLENBQUM7SUFDUjtFQUNBLENBQUM7RUFDRCxnQkFBZ0IsRUFBRTtJQUNoQnRCLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFdBQVcsRUFBRSx5RUFBeUU7SUFDdEZVLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUFPO0lBQ2pDUyxJQUFJLEVBQUVkLGtCQUFrQixDQUFDZSxJQUFJO0lBQzdCQyxZQUFZLEVBQUUsRUFBRTtJQUNoQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQkUsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ0csV0FBVztJQUN6Q0csZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFDVCxRQUFRLEVBQUUsSUFBSSxDQUFDQTtNQUFRLENBQUMsQ0FBQztJQUNoRDtFQUNBLENBQUM7RUFDRCxxQkFBcUIsRUFBRTtJQUNyQmxCLEtBQUssRUFBRSxxQkFBcUI7SUFDNUJDLFdBQVcsRUFBRSwwRUFBMEU7SUFDdkZVLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUFPO0lBQ2pDUyxJQUFJLEVBQUVkLGtCQUFrQixDQUFDZSxJQUFJO0lBQzdCQyxZQUFZLEVBQUUsRUFBRTtJQUNoQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsS0FBSztJQUMzQkUsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ0UsZ0JBQWdCO0lBQzlDSSxlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQUNULFFBQVEsRUFBRSxJQUFJLENBQUNBO01BQVEsQ0FBQyxDQUFDO0lBQ2hEO0VBQ0EsQ0FBQztFQUNELGtCQUFrQixFQUFFO0lBQ2xCbEIsS0FBSyxFQUFFLGlCQUFpQjtJQUN4QkMsV0FBVyxFQUFFLHlEQUF5RDtJQUN0RVUsUUFBUSxFQUFFZCxlQUFlLENBQUNPLFVBQVU7SUFDcENRLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsSUFBSTtJQUNsQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsS0FBSztJQUMzQmEsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0QsZ0JBQWdCLEVBQUU7SUFDaEJ0QyxLQUFLLEVBQUUsWUFBWTtJQUNuQkMsV0FBVyxFQUFFLHFEQUFxRDtJQUNsRVUsUUFBUSxFQUFFZCxlQUFlLENBQUNPLFVBQVU7SUFDcENRLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsS0FBSztJQUNuQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsS0FBSztJQUMzQmEsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0QsbUJBQW1CLEVBQUU7SUFDbkJ0QyxLQUFLLEVBQUUsU0FBUztJQUNoQkMsV0FBVyxFQUFFLDJEQUEyRDtJQUN4RVUsUUFBUSxFQUFFZCxlQUFlLENBQUNPLFVBQVU7SUFDcENRLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsS0FBSztJQUNuQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsS0FBSztJQUMzQmEsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0QsbUJBQW1CLEVBQUU7SUFDbkJ0QyxLQUFLLEVBQUUsaUJBQWlCO0lBQ3hCQyxXQUFXLEVBQUUsbUVBQW1FO0lBQ2hGVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ08sVUFBVTtJQUNwQ1EsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BQU07SUFDL0JkLFlBQVksRUFBRSxLQUFLO0lBQ25CQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxLQUFLO0lBQzNCYSxPQUFPLEVBQUU7TUFDUEQsTUFBTSxFQUFFO1FBQ05FLE1BQU0sRUFBRTtVQUNOQyxRQUFRLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQU0sQ0FBQztVQUMxQ0MsT0FBTyxFQUFFO1lBQUVGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFLO1FBQ3hDO01BQ0Y7SUFDRixDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVVGLEtBQXVCLEVBQVc7TUFDNUUsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUN2Q1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNBLENBQUM7RUFDRCxnQkFBZ0IsRUFBRTtJQUNoQnRDLEtBQUssRUFBRSx1QkFBdUI7SUFDOUJDLFdBQVcsRUFBRSw4REFBOEQ7SUFDM0VVLFFBQVEsRUFBRWQsZUFBZSxDQUFDTyxVQUFVO0lBQ3BDUSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFBTTtJQUMvQmQsWUFBWSxFQUFFLEtBQUs7SUFDbkJDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLEtBQUs7SUFDM0JhLE9BQU8sRUFBRTtNQUNQRCxNQUFNLEVBQUU7UUFDTkUsTUFBTSxFQUFFO1VBQ05DLFFBQVEsRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFQyxLQUFLLEVBQUU7VUFBTSxDQUFDO1VBQzFDQyxPQUFPLEVBQUU7WUFBRUYsS0FBSyxFQUFFLE1BQU07WUFBRUMsS0FBSyxFQUFFO1VBQUs7UUFDeEM7TUFDRjtJQUNGLENBQUM7SUFDREUsZ0NBQWdDLEVBQUUsU0FBQUEsQ0FBVUYsS0FBdUIsRUFBVztNQUM1RSxPQUFPRyxPQUFPLENBQUNILEtBQUssQ0FBQztJQUN2QixDQUFDO0lBQ0RmLFFBQVEsRUFBRUMsb0NBQWlCLENBQUNrQixTQUFTO0lBQ3ZDWixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQ1ksT0FBTyxFQUFFO0lBQ3hCO0VBQ0EsQ0FBQztFQUNELGlCQUFpQixFQUFFO0lBQ2pCdEMsS0FBSyxFQUFFLE1BQU07SUFDYkMsV0FBVyxFQUFFLHdEQUF3RDtJQUNyRVUsUUFBUSxFQUFFZCxlQUFlLENBQUNPLFVBQVU7SUFDcENRLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsSUFBSTtJQUNsQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsS0FBSztJQUMzQmEsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0Qsa0JBQWtCLEVBQUU7SUFDbEJ0QyxLQUFLLEVBQUUsT0FBTztJQUNkQyxXQUFXLEVBQUUseURBQXlEO0lBQ3RFVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ08sVUFBVTtJQUNwQ1EsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BQU07SUFDL0JkLFlBQVksRUFBRSxJQUFJO0lBQ2xCQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxLQUFLO0lBQzNCYSxPQUFPLEVBQUU7TUFDUEQsTUFBTSxFQUFFO1FBQ05FLE1BQU0sRUFBRTtVQUNOQyxRQUFRLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQU0sQ0FBQztVQUMxQ0MsT0FBTyxFQUFFO1lBQUVGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFLO1FBQ3hDO01BQ0Y7SUFDRixDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVVGLEtBQXVCLEVBQVc7TUFDNUUsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUN2Q1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNBLENBQUM7RUFDRCxpQkFBaUIsRUFBRTtJQUNqQnRDLEtBQUssRUFBRSxNQUFNO0lBQ2JDLFdBQVcsRUFBRSwrREFBK0Q7SUFDNUVVLFFBQVEsRUFBRWQsZUFBZSxDQUFDTyxVQUFVO0lBQ3BDUSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFBTTtJQUMvQmQsWUFBWSxFQUFFLElBQUk7SUFDbEJDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLEtBQUs7SUFDM0JhLE9BQU8sRUFBRTtNQUNQRCxNQUFNLEVBQUU7UUFDTkUsTUFBTSxFQUFFO1VBQ05DLFFBQVEsRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFQyxLQUFLLEVBQUU7VUFBTSxDQUFDO1VBQzFDQyxPQUFPLEVBQUU7WUFBRUYsS0FBSyxFQUFFLE1BQU07WUFBRUMsS0FBSyxFQUFFO1VBQUs7UUFDeEM7TUFDRjtJQUNGLENBQUM7SUFDREUsZ0NBQWdDLEVBQUUsU0FBQUEsQ0FBVUYsS0FBdUIsRUFBVztNQUM1RSxPQUFPRyxPQUFPLENBQUNILEtBQUssQ0FBQztJQUN2QixDQUFDO0lBQ0RmLFFBQVEsRUFBRUMsb0NBQWlCLENBQUNrQixTQUFTO0lBQ3ZDWixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQ1ksT0FBTyxFQUFFO0lBQ3hCO0VBQ0EsQ0FBQztFQUNELGtCQUFrQixFQUFFO0lBQ2xCdEMsS0FBSyxFQUFFLE9BQU87SUFDZEMsV0FBVyxFQUFFLDZEQUE2RDtJQUMxRVUsUUFBUSxFQUFFZCxlQUFlLENBQUNPLFVBQVU7SUFDcENRLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsS0FBSztJQUNuQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsS0FBSztJQUMzQmEsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0Qsb0JBQW9CLEVBQUU7SUFDcEJ0QyxLQUFLLEVBQUUsU0FBUztJQUNoQkMsV0FBVyxFQUFFLDJEQUEyRDtJQUN4RVUsUUFBUSxFQUFFZCxlQUFlLENBQUNPLFVBQVU7SUFDcENRLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsS0FBSztJQUNuQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsS0FBSztJQUMzQmEsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0QsZ0JBQWdCLEVBQUU7SUFDaEJ0QyxLQUFLLEVBQUUsU0FBUztJQUNoQkMsV0FBVyxFQUFFLDJEQUEyRDtJQUN4RVUsUUFBUSxFQUFFZCxlQUFlLENBQUNPLFVBQVU7SUFDcENRLElBQUksRUFBRWQsa0JBQWtCLENBQUM4QixNQUFNO0lBQy9CZCxZQUFZLEVBQUUsSUFBSTtJQUNsQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsS0FBSztJQUMzQmEsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0QsZ0JBQWdCLEVBQUU7SUFDaEJ0QyxLQUFLLEVBQUUsS0FBSztJQUNaQyxXQUFXLEVBQUUsdURBQXVEO0lBQ3BFVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ08sVUFBVTtJQUNwQ1EsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BQU07SUFDL0JkLFlBQVksRUFBRSxJQUFJO0lBQ2xCQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxLQUFLO0lBQzNCYSxPQUFPLEVBQUU7TUFDUEQsTUFBTSxFQUFFO1FBQ05FLE1BQU0sRUFBRTtVQUNOQyxRQUFRLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQU0sQ0FBQztVQUMxQ0MsT0FBTyxFQUFFO1lBQUVGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFLO1FBQ3hDO01BQ0Y7SUFDRixDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVVGLEtBQXVCLEVBQVc7TUFDNUUsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUN2Q1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNBLENBQUM7RUFDRCx1QkFBdUIsRUFBRTtJQUN2QnRDLEtBQUssRUFBRSxZQUFZO0lBQ25CQyxXQUFXLEVBQUUsOERBQThEO0lBQzNFVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ08sVUFBVTtJQUNwQ1EsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQzhCLE1BQU07SUFDL0JkLFlBQVksRUFBRSxLQUFLO0lBQ25CQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxLQUFLO0lBQzNCYSxPQUFPLEVBQUU7TUFDUEQsTUFBTSxFQUFFO1FBQ05FLE1BQU0sRUFBRTtVQUNOQyxRQUFRLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQU0sQ0FBQztVQUMxQ0MsT0FBTyxFQUFFO1lBQUVGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFLO1FBQ3hDO01BQ0Y7SUFDRixDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVVGLEtBQXVCLEVBQVc7TUFDNUUsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUN2Q1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNBLENBQUM7RUFDRCxtQkFBbUIsRUFBRTtJQUNuQnRDLEtBQUssRUFBRSxxQkFBcUI7SUFDNUJDLFdBQVcsRUFBRSxvREFBb0Q7SUFDakVVLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUFPO0lBQ2pDUyxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFBTTtJQUMvQmQsWUFBWSxFQUFFLEtBQUs7SUFDbkJDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJnRCwyQkFBMkIsRUFBRSxJQUFJO0lBQ2pDbkMsT0FBTyxFQUFFO01BQ1BELE1BQU0sRUFBRTtRQUNORSxNQUFNLEVBQUU7VUFDTkMsUUFBUSxFQUFFO1lBQUVDLEtBQUssRUFBRSxPQUFPO1lBQUVDLEtBQUssRUFBRTtVQUFNLENBQUM7VUFDMUNDLE9BQU8sRUFBRTtZQUFFRixLQUFLLEVBQUUsTUFBTTtZQUFFQyxLQUFLLEVBQUU7VUFBSztRQUN4QztNQUNGO0lBQ0YsQ0FBQztJQUNERSxnQ0FBZ0MsRUFBRSxTQUFBQSxDQUFVRixLQUF1QixFQUFXO01BQzVFLE9BQU9HLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFDRGYsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ2tCLFNBQVM7SUFDdkNaLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDWSxPQUFPLEVBQUU7SUFDeEI7RUFDQSxDQUFDO0VBQ0QsV0FBVyxFQUFFO0lBQ1h0QyxLQUFLLEVBQUUsc0JBQXNCO0lBQzdCQyxXQUFXLEVBQUUscUZBQXFGO0lBQ2xHVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ00sT0FBTztJQUNqQ1MsSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ3lDLE1BQU07SUFDL0J6QixZQUFZLEVBQUUsRUFBRTtJQUNoQkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQmEsT0FBTyxFQUFFO01BQ1BVLE1BQU0sRUFBRTtRQUNOQyxRQUFRLEVBQUU7TUFDWjtJQUNGLENBQUM7SUFDREMsNkNBQTZDLEVBQUUsU0FBQUEsQ0FBVVIsS0FBVSxFQUFPO01BQ3hFLE9BQU9TLElBQUksQ0FBQ0MsU0FBUyxDQUFDVixLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUNEVyw2Q0FBNkMsRUFBRSxTQUFBQSxDQUFVWCxLQUFhLEVBQU87TUFDM0UsSUFBSTtRQUNGLE9BQU9TLElBQUksQ0FBQ0csS0FBSyxDQUFDWixLQUFLLENBQUM7TUFDMUIsQ0FBQyxDQUFDLE9BQU9hLEtBQUssRUFBRTtRQUNkLE9BQU9iLEtBQUs7TUFDZDtNQUFDO0lBQ0gsQ0FBQztJQUNEO0lBQ0FmLFFBQVEsRUFBRUMsb0NBQWlCLENBQUM0QixJQUFJLENBQUM1QixvQ0FBaUIsQ0FBQ0MsT0FBTyxDQUN4REQsb0NBQWlCLENBQUM2QixLQUFLLENBQUM3QixvQ0FBaUIsQ0FBQ0MsT0FBTyxDQUMvQ0Qsb0NBQWlCLENBQUM4QixRQUFRLEVBQzFCOUIsb0NBQWlCLENBQUNFLGdCQUFnQixFQUNsQ0Ysb0NBQWlCLENBQUNHLFdBQVcsRUFDN0JILG9DQUFpQixDQUFDMEUsZUFBZSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsRUFDNUMxRSxvQ0FBaUIsQ0FBQ0ksa0JBQWtCLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLEVBQ3hESixvQ0FBaUIsQ0FBQ0ssdUJBQXVCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FDeEYsQ0FBQyxDQUNILENBQUM7SUFDSkMsZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUN3QixPQUFPLENBQUN4QixNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFDVCxRQUFRLEVBQUVDLG9DQUFpQixDQUFDQyxPQUFPLENBQ25FRCxvQ0FBaUIsQ0FBQ0UsZ0JBQWdCLEVBQ2xDRixvQ0FBaUIsQ0FBQ0csV0FBVyxFQUM3Qkgsb0NBQWlCLENBQUMwRSxlQUFlLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxFQUM1QzFFLG9DQUFpQixDQUFDSSxrQkFBa0IsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFDeERKLG9DQUFpQixDQUFDSyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQztNQUN4RixDQUFDLENBQUMsQ0FBQztJQUNSO0VBQ0EsQ0FBQztFQUNELGFBQWEsRUFBRTtJQUNieEIsS0FBSyxFQUFFLGFBQWE7SUFDcEJDLFdBQVcsRUFBRSxvR0FBb0c7SUFDakhVLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUFPO0lBQ2pDUyxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFBTTtJQUMvQmQsWUFBWSxFQUFFLElBQUk7SUFDbEJDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLEtBQUs7SUFDM0JhLE9BQU8sRUFBRTtNQUNQRCxNQUFNLEVBQUU7UUFDTkUsTUFBTSxFQUFFO1VBQ05DLFFBQVEsRUFBRTtZQUFFQyxLQUFLLEVBQUUsT0FBTztZQUFFQyxLQUFLLEVBQUU7VUFBTSxDQUFDO1VBQzFDQyxPQUFPLEVBQUU7WUFBRUYsS0FBSyxFQUFFLE1BQU07WUFBRUMsS0FBSyxFQUFFO1VBQUs7UUFDeEM7TUFDRjtJQUNGLENBQUM7SUFDREUsZ0NBQWdDLEVBQUUsU0FBQUEsQ0FBVUYsS0FBdUIsRUFBVztNQUM1RSxPQUFPRyxPQUFPLENBQUNILEtBQUssQ0FBQztJQUN2QixDQUFDO0lBQ0RmLFFBQVEsRUFBRUMsb0NBQWlCLENBQUNrQixTQUFTO0lBQ3ZDWixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQ1ksT0FBTyxFQUFFO0lBQ3hCO0VBQ0EsQ0FBQztFQUNELFlBQVksRUFBRTtJQUNadEMsS0FBSyxFQUFFLFdBQVc7SUFDbEJDLFdBQVcsRUFBRSwyQkFBMkI7SUFDeENVLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUFPO0lBQ2pDUyxJQUFJLEVBQUVkLGtCQUFrQixDQUFDcUQsTUFBTTtJQUMvQnRCLE9BQU8sRUFBRTtNQUNQc0IsTUFBTSxFQUFFLENBQ047UUFDRXRDLElBQUksRUFBRSxNQUFNO1FBQ1pvQixLQUFLLEVBQUU7TUFDVCxDQUFDLEVBQ0Q7UUFDRXBCLElBQUksRUFBRSxPQUFPO1FBQ2JvQixLQUFLLEVBQUU7TUFDVCxDQUFDO0lBRUwsQ0FBQztJQUNEbkIsWUFBWSxFQUFFLE1BQU07SUFDcEJDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUI2QyxnQ0FBZ0MsRUFBRSxJQUFJO0lBQ3RDM0MsUUFBUSxFQUFFLFNBQUFBLENBQVVlLEtBQUssRUFBQztNQUMzQixPQUFPZCxvQ0FBaUIsQ0FBQ2lDLE9BQU8sQ0FBQyxJQUFJLENBQUN2QixPQUFPLENBQUNzQixNQUFNLENBQUNFLEdBQUcsQ0FBQyxDQUFDO1FBQUNwQjtNQUFLLENBQUMsS0FBS0EsS0FBSyxDQUFDLENBQUMsQ0FBQ0EsS0FBSyxDQUFDO0lBQ3JGLENBQUM7SUFDRFIsZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUM0QixLQUFLLENBQUMsSUFBSSxDQUFDekIsT0FBTyxDQUFDc0IsTUFBTSxDQUFDRSxHQUFHLENBQUMsQ0FBQztRQUFDcEI7TUFBSyxDQUFDLEtBQUtQLE1BQU0sQ0FBQzBCLE9BQU8sQ0FBQ25CLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDakY7RUFDQSxDQUFDO0VBQ0QsU0FBUyxFQUFFO0lBQ1RqQyxLQUFLLEVBQUUsZUFBZTtJQUN0QkMsV0FBVyxFQUFFLDJKQUEySjtJQUN4S1UsUUFBUSxFQUFFZCxlQUFlLENBQUNNLE9BQU87SUFDakNTLElBQUksRUFBRWQsa0JBQWtCLENBQUNlLElBQUk7SUFDN0JDLFlBQVksRUFBRTdKLG9CQUFvQjtJQUNsQzhKLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJDLDBCQUEwQixFQUFFLElBQUk7SUFDaEM7SUFDQUMsUUFBUSxFQUFFQyxvQ0FBaUIsQ0FBQ0MsT0FBTyxDQUNqQ0Qsb0NBQWlCLENBQUNFLGdCQUFnQixFQUNsQ0Ysb0NBQWlCLENBQUNHLFdBQVcsRUFDN0JILG9DQUFpQixDQUFDMEUsZUFBZSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsRUFDNUMxRSxvQ0FBaUIsQ0FBQ0ksa0JBQWtCLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLEVBQ3hESixvQ0FBaUIsQ0FBQ0ssdUJBQXVCLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FDeEY7SUFDSEMsZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFDVCxRQUFRLEVBQUUsSUFBSSxDQUFDQTtNQUFRLENBQUMsQ0FBQztJQUNoRDtFQUNBLENBQUM7RUFDRCxTQUFTLEVBQUU7SUFDVGxCLEtBQUssRUFBRSxpQkFBaUI7SUFDeEJDLFdBQVcsRUFBRSxrS0FBa0s7SUFDL0tVLFFBQVEsRUFBRWQsZUFBZSxDQUFDTSxPQUFPO0lBQ2pDUyxJQUFJLEVBQUVkLGtCQUFrQixDQUFDeUQsTUFBTTtJQUMvQnpDLFlBQVksRUFBRSxLQUFLO0lBQ25CQyxzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxJQUFJO0lBQzFCYSxPQUFPLEVBQUU7TUFDUDBCLE1BQU0sRUFBRTtRQUNOQyxHQUFHLEVBQUUsSUFBSTtRQUNUQyxPQUFPLEVBQUU7TUFDWDtJQUNGLENBQUM7SUFDRGhCLDZDQUE2QyxFQUFFLFNBQUFBLENBQVNSLEtBQWEsRUFBQztNQUNwRSxPQUFPeUIsTUFBTSxDQUFDekIsS0FBSyxDQUFDO0lBQ3RCLENBQUM7SUFDRFcsNkNBQTZDLEVBQUUsU0FBQUEsQ0FBU1gsS0FBYSxFQUFVO01BQzdFLE9BQU8wQixNQUFNLENBQUMxQixLQUFLLENBQUM7SUFDdEIsQ0FBQztJQUNEZixRQUFRLEVBQUUsU0FBQUEsQ0FBU2UsS0FBSyxFQUFDO01BQzFCLE9BQU9kLG9DQUFpQixDQUFDb0MsTUFBTSxDQUFDLElBQUksQ0FBQzFCLE9BQU8sQ0FBQzBCLE1BQU0sQ0FBQyxDQUFDdEIsS0FBSyxDQUFDO0lBQzVELENBQUM7SUFDRFIsZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUM2QixNQUFNLENBQUM7UUFBQ3JDLFFBQVEsRUFBRSxJQUFJLENBQUNBLFFBQVEsQ0FBQzBDLElBQUksQ0FBQyxJQUFJO01BQUMsQ0FBQyxDQUFDO0lBQzNEO0VBQ0EsQ0FBQztFQUNELDJCQUEyQixFQUFFO0lBQzNCNUQsS0FBSyxFQUFFLGdCQUFnQjtJQUN2QkMsV0FBVyxFQUFFLDRFQUE0RTtJQUN6RlUsUUFBUSxFQUFFZCxlQUFlLENBQUNTLFVBQVU7SUFDcENNLElBQUksRUFBRWQsa0JBQWtCLENBQUNxRCxNQUFNO0lBQy9CdEIsT0FBTyxFQUFFO01BQ1BzQixNQUFNLEVBQUUsQ0FDTjtRQUNFdEMsSUFBSSxFQUFFLFFBQVE7UUFDZG9CLEtBQUssRUFBRTtNQUNULENBQUMsRUFDRDtRQUNFcEIsSUFBSSxFQUFFLE9BQU87UUFDYm9CLEtBQUssRUFBRTtNQUNULENBQUMsRUFDRDtRQUNFcEIsSUFBSSxFQUFFLFFBQVE7UUFDZG9CLEtBQUssRUFBRTtNQUNULENBQUMsRUFDRDtRQUNFcEIsSUFBSSxFQUFFLFNBQVM7UUFDZm9CLEtBQUssRUFBRTtNQUNULENBQUM7SUFFTCxDQUFDO0lBQ0RuQixZQUFZLEVBQUV0SixpQ0FBaUM7SUFDL0N1SixzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxJQUFJO0lBQzFCQywwQkFBMEIsRUFBRSxJQUFJO0lBQ2hDQyxRQUFRLEVBQUUsU0FBQUEsQ0FBVWUsS0FBSyxFQUFDO01BQzNCLE9BQU9kLG9DQUFpQixDQUFDaUMsT0FBTyxDQUFDLElBQUksQ0FBQ3ZCLE9BQU8sQ0FBQ3NCLE1BQU0sQ0FBQ0UsR0FBRyxDQUFDLENBQUM7UUFBQ3BCO01BQUssQ0FBQyxLQUFLQSxLQUFLLENBQUMsQ0FBQyxDQUFDQSxLQUFLLENBQUM7SUFDckYsQ0FBQztJQUNEUixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQzRCLEtBQUssQ0FBQyxJQUFJLENBQUN6QixPQUFPLENBQUNzQixNQUFNLENBQUNFLEdBQUcsQ0FBQyxDQUFDO1FBQUNwQjtNQUFLLENBQUMsS0FBS1AsTUFBTSxDQUFDMEIsT0FBTyxDQUFDbkIsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUNqRjtFQUNBLENBQUM7RUFDRCwwQkFBMEIsRUFBRTtJQUMxQmpDLEtBQUssRUFBRSxRQUFRO0lBQ2ZDLFdBQVcsRUFBRSw2RUFBNkU7SUFDMUZVLFFBQVEsRUFBRWQsZUFBZSxDQUFDUyxVQUFVO0lBQ3BDTSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDOEIsTUFBTTtJQUMvQmQsWUFBWSxFQUFFckosZ0NBQWdDO0lBQzlDc0osc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQjZDLGdDQUFnQyxFQUFFLElBQUk7SUFDdENoQyxPQUFPLEVBQUU7TUFDUEQsTUFBTSxFQUFFO1FBQ05FLE1BQU0sRUFBRTtVQUNOQyxRQUFRLEVBQUU7WUFBRUMsS0FBSyxFQUFFLE9BQU87WUFBRUMsS0FBSyxFQUFFO1VBQU0sQ0FBQztVQUMxQ0MsT0FBTyxFQUFFO1lBQUVGLEtBQUssRUFBRSxNQUFNO1lBQUVDLEtBQUssRUFBRTtVQUFLO1FBQ3hDO01BQ0Y7SUFDRixDQUFDO0lBQ0RFLGdDQUFnQyxFQUFFLFNBQUFBLENBQVVGLEtBQXVCLEVBQVc7TUFDNUUsT0FBT0csT0FBTyxDQUFDSCxLQUFLLENBQUM7SUFDdkIsQ0FBQztJQUNEZixRQUFRLEVBQUVDLG9DQUFpQixDQUFDa0IsU0FBUztJQUN2Q1osZUFBZSxFQUFFLFNBQUFBLENBQVNDLE1BQU0sRUFBQztNQUNoQyxPQUFPQSxNQUFNLENBQUNZLE9BQU8sRUFBRTtJQUN4QjtFQUNBLENBQUM7RUFDRCw0QkFBNEIsRUFBRTtJQUM1QnRDLEtBQUssRUFBRSxXQUFXO0lBQ2xCQyxXQUFXLEVBQUUsK0lBQStJO0lBQzVKVSxRQUFRLEVBQUVkLGVBQWUsQ0FBQ1MsVUFBVTtJQUNwQ00sSUFBSSxFQUFFZCxrQkFBa0IsQ0FBQ3lELE1BQU07SUFDL0J6QyxZQUFZLEVBQUVwSixrQ0FBa0M7SUFDaERxSixzQkFBc0IsRUFBRSxJQUFJO0lBQzVCQyxvQkFBb0IsRUFBRSxJQUFJO0lBQzFCNkMsZ0NBQWdDLEVBQUUsSUFBSTtJQUN0Q2hDLE9BQU8sRUFBRTtNQUNQMEIsTUFBTSxFQUFFO1FBQ05DLEdBQUcsRUFBRSxFQUFFO1FBQ1BDLE9BQU8sRUFBRTtNQUNYO0lBQ0YsQ0FBQztJQUNEaEIsNkNBQTZDLEVBQUUsU0FBQUEsQ0FBU1IsS0FBYSxFQUFDO01BQ3BFLE9BQU95QixNQUFNLENBQUN6QixLQUFLLENBQUM7SUFDdEIsQ0FBQztJQUNEVyw2Q0FBNkMsRUFBRSxTQUFBQSxDQUFTWCxLQUFhLEVBQVU7TUFDN0UsT0FBTzBCLE1BQU0sQ0FBQzFCLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBQ0RmLFFBQVEsRUFBRSxTQUFBQSxDQUFTZSxLQUFLLEVBQUM7TUFDMUIsT0FBT2Qsb0NBQWlCLENBQUNvQyxNQUFNLENBQUMsSUFBSSxDQUFDMUIsT0FBTyxDQUFDMEIsTUFBTSxDQUFDLENBQUN0QixLQUFLLENBQUM7SUFDNUQsQ0FBQztJQUNEUixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQzZCLE1BQU0sQ0FBQztRQUFDckMsUUFBUSxFQUFFLElBQUksQ0FBQ0EsUUFBUSxDQUFDMEMsSUFBSSxDQUFDLElBQUk7TUFBQyxDQUFDLENBQUM7SUFDM0Q7RUFDQSxDQUFDO0VBQ0QsMEJBQTBCLEVBQUU7SUFDMUI1RCxLQUFLLEVBQUUsZUFBZTtJQUN0QkMsV0FBVyxFQUFFLG9EQUFvRDtJQUNqRVUsUUFBUSxFQUFFZCxlQUFlLENBQUNTLFVBQVU7SUFDcENNLElBQUksRUFBRWQsa0JBQWtCLENBQUNlLElBQUk7SUFDN0JDLFlBQVksRUFBRTFKLHdCQUF3QjtJQUN0QzJKLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJDLDBCQUEwQixFQUFFLElBQUk7SUFDaENDLFFBQVEsRUFBRUMsb0NBQWlCLENBQUNDLE9BQU8sQ0FDakNELG9DQUFpQixDQUFDRSxnQkFBZ0IsRUFDbENGLG9DQUFpQixDQUFDRyxXQUFXLEVBQzdCSCxvQ0FBaUIsQ0FBQzBFLGVBQWUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEVBQzVDMUUsb0NBQWlCLENBQUNJLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxFQUN4REosb0NBQWlCLENBQUNLLHVCQUF1QixDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQ3hGO0lBQ0hDLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDQyxNQUFNLENBQUM7UUFBQ21FLFNBQVMsRUFBRSxDQUFDO1FBQUU1RSxRQUFRLEVBQUUsSUFBSSxDQUFDQTtNQUFRLENBQUMsQ0FBQztJQUM5RDtFQUNBLENBQUM7RUFDRCwyQkFBMkIsRUFBRTtJQUMzQmxCLEtBQUssRUFBRSxnQkFBZ0I7SUFDdkJDLFdBQVcsRUFBRSwwRUFBMEU7SUFDdkZVLFFBQVEsRUFBRWQsZUFBZSxDQUFDUyxVQUFVO0lBQ3BDTSxJQUFJLEVBQUVkLGtCQUFrQixDQUFDeUQsTUFBTTtJQUMvQnpDLFlBQVksRUFBRXZKLHlDQUF5QztJQUN2RHdKLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG9CQUFvQixFQUFFLElBQUk7SUFDMUJDLDBCQUEwQixFQUFFLElBQUk7SUFDaENZLE9BQU8sRUFBRTtNQUNQMEIsTUFBTSxFQUFFO1FBQ05DLEdBQUcsRUFBRSxDQUFDO1FBQ05DLE9BQU8sRUFBRTtNQUNYO0lBQ0YsQ0FBQztJQUNEaEIsNkNBQTZDLEVBQUUsU0FBQUEsQ0FBU1IsS0FBYSxFQUFDO01BQ3BFLE9BQU95QixNQUFNLENBQUN6QixLQUFLLENBQUM7SUFDdEIsQ0FBQztJQUNEVyw2Q0FBNkMsRUFBRSxTQUFBQSxDQUFTWCxLQUFhLEVBQVU7TUFDN0UsT0FBTzBCLE1BQU0sQ0FBQzFCLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBQ0RmLFFBQVEsRUFBRSxTQUFBQSxDQUFTZSxLQUFLLEVBQUM7TUFDMUIsT0FBT2Qsb0NBQWlCLENBQUNvQyxNQUFNLENBQUMsSUFBSSxDQUFDMUIsT0FBTyxDQUFDMEIsTUFBTSxDQUFDLENBQUN0QixLQUFLLENBQUM7SUFDNUQsQ0FBQztJQUNEUixlQUFlLEVBQUUsU0FBQUEsQ0FBU0MsTUFBTSxFQUFDO01BQ2hDLE9BQU9BLE1BQU0sQ0FBQzZCLE1BQU0sQ0FBQztRQUFDckMsUUFBUSxFQUFFLElBQUksQ0FBQ0EsUUFBUSxDQUFDMEMsSUFBSSxDQUFDLElBQUk7TUFBQyxDQUFDLENBQUM7SUFDM0Q7RUFDQSxDQUFDO0VBQ0QseUJBQXlCLEVBQUU7SUFDekI1RCxLQUFLLEVBQUUsY0FBYztJQUNyQkMsV0FBVyxFQUFFLHdFQUF3RTtJQUNyRlUsUUFBUSxFQUFFZCxlQUFlLENBQUNTLFVBQVU7SUFDcENNLElBQUksRUFBRWQsa0JBQWtCLENBQUN5RCxNQUFNO0lBQy9CekMsWUFBWSxFQUFFeEosdUNBQXVDO0lBQ3JEeUosc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsb0JBQW9CLEVBQUUsSUFBSTtJQUMxQkMsMEJBQTBCLEVBQUUsSUFBSTtJQUNoQ1ksT0FBTyxFQUFFO01BQ1AwQixNQUFNLEVBQUU7UUFDTkMsR0FBRyxFQUFFLENBQUM7UUFDTkMsT0FBTyxFQUFFO01BQ1g7SUFDRixDQUFDO0lBQ0RoQiw2Q0FBNkMsRUFBRSxTQUFBQSxDQUFTUixLQUFhLEVBQUM7TUFDcEUsT0FBT3lCLE1BQU0sQ0FBQ3pCLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBQ0RXLDZDQUE2QyxFQUFFLFNBQUFBLENBQVNYLEtBQWEsRUFBVTtNQUM3RSxPQUFPMEIsTUFBTSxDQUFDMUIsS0FBSyxDQUFDO0lBQ3RCLENBQUM7SUFDRGYsUUFBUSxFQUFFLFNBQUFBLENBQVNlLEtBQUssRUFBQztNQUMxQixPQUFPZCxvQ0FBaUIsQ0FBQ29DLE1BQU0sQ0FBQyxJQUFJLENBQUMxQixPQUFPLENBQUMwQixNQUFNLENBQUMsQ0FBQ3RCLEtBQUssQ0FBQztJQUM1RCxDQUFDO0lBQ0RSLGVBQWUsRUFBRSxTQUFBQSxDQUFTQyxNQUFNLEVBQUM7TUFDaEMsT0FBT0EsTUFBTSxDQUFDNkIsTUFBTSxDQUFDO1FBQUNyQyxRQUFRLEVBQUUsSUFBSSxDQUFDQSxRQUFRLENBQUMwQyxJQUFJLENBQUMsSUFBSTtNQUFDLENBQUMsQ0FBQztJQUMzRDtFQUNBO0FBQ0YsQ0FBQztBQUFDbE4sT0FBQSxDQUFBZ0ssZUFBQSxHQUFBQSxlQUFBO0FBQUEsSUFJVXFGLGlCQUFpQixFQTJEN0I7QUFBQXJQLE9BQUEsQ0FBQXFQLGlCQUFBLEdBQUFBLGlCQUFBO0FBQUEsV0EzRFlBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0VBQWpCQSxpQkFBaUIsQ0FBakJBLGlCQUFpQjtFQUFqQkEsaUJBQWlCLENBQWpCQSxpQkFBaUI7RUFBakJBLGlCQUFpQixDQUFqQkEsaUJBQWlCO0FBQUEsR0FBakJBLGlCQUFpQixLQUFBclAsT0FBQSxDQUFBcVAsaUJBQUEsR0FBakJBLGlCQUFpQjtBQTREdEIsTUFBTUMsNkJBQTZCLEdBQUc7RUFDM0NDLE1BQU0sRUFBRSxRQUFRO0VBQ2hCQyxNQUFNLEVBQUUsUUFBUTtFQUNoQixnQkFBZ0IsRUFBRTtBQUNwQixDQUFDO0FBQUF4UCxPQUFBLENBQUFzUCw2QkFBQSxHQUFBQSw2QkFBQSJ9